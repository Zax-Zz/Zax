<?php
$ngVis = file_get_contents("system/visitor.json");
$vis = json_decode($ngVis,true);

include 'system/datalog.php';
if (isset($_POST['pass'])){
    $pass = $_POST['pass'];
    if ($pass == $password){
        echo "true";
    } else {
        echo 'false';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Setting</title>
        <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a0a1f 0%, #1a0033 100%);
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .wrapper {
            display: flex;
            flex-direction: column;
            gap: 30px;
            width: 100%;
            max-width: 440px;
        }
        .container {
            background: rgba(15,15,35,0.85);
            backdrop-filter: blur(24px);
            border: 1px solid rgba(0,255,255,0.25);
            border-radius: 28px;
            padding: 40px 28px;
            box-shadow: 0 25px 70px rgba(0,0,0,0.7);
        }
        h1 {
            text-align: center;
            font-size: 2.8rem;
            font-weight: 700;
            margin-bottom: 40px;
            background: linear-gradient(90deg, #00f0ff, #c026d3);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .stats { display:flex; gap:12px; margin-bottom:38px; }
        .card {
            flex:1; background:rgba(255,255,255,0.07);
            border:1px solid rgba(0,255,255,0.35);
            border-radius:18px;
            padding:18px 10px;
            text-align:center;
        }
        .card h3 { font-size:0.78rem; opacity:0.8; margin-bottom:4px; }
        .card p { font-size:1.85rem; font-weight:700; color:#67e8f9; }
        .field { margin-bottom:24px; }
        .field label { display:block; margin-bottom:8px; font-size:0.95rem; opacity:0.85; }
        .field input {
            width:100%; background:rgba(255,255,255,0.08);
            border:1.5px solid rgba(103,232,249,0.5);
            color:#fff; padding:16px 20px;
            border-radius:16px; font-size:1.05rem;
        }
        .ganti-btn {
            margin-top:30px; width:100%; padding:17px;
            background:linear-gradient(90deg,#00f0ff,#c026d3);
            color:#0a0a1f; font-size:1.2rem; font-weight:700;
            border:none; border-radius:16px; cursor:pointer;
            box-shadow:0 0 35px rgba(0,240,255,0.7);
        }
        .ganti-btn:hover { transform:translateY(-3px); box-shadow:0 0 50px rgba(192,38,211,0.8); }
        .keterangan {
            text-align:center; margin-top:20px; font-size:0.9rem;
            color:#67e8f9;
        }
        .keterangan a { text-decoration:underline; text-underline-offset:6px; cursor:pointer; }
    </style>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap');
        body { font-family: 'Orbitron', sans-serif; }
        .neon-cyan { text-shadow: 0 0 20px #67e8f9, 0 0 40px #67e8f9; }
        .glass { background: rgba(15,23,42,0.6); backdrop-filter: blur(20px); border: 1px solid rgba(103,232,249,0.3); }
        .glitch { position:relative; color:#67e8f9; }
        .glitch::before,.glitch::after { content:attr(data-text); position:absolute; top:0; left:0; width:100%; height:100%; }
        .glitch::before { animation:glitch-anim 2s infinite linear alternate-reverse; clip-path:polygon(0 0,100% 0,100% 33%,0 33%); color:#22d3ee; }
        .glitch::after { animation:glitch-anim2 3s infinite linear alternate-reverse; clip-path:polygon(0 67%,100% 67%,100% 100%,0 100%); color:#a5f3fc; }
        @keyframes glitch-anim { 0%{transform:translate(0)} 20%{transform:translate(-3px,3px)} 40%{transform:translate(-3px,-3px)} 60%{transform:translate(3px,3px)} 80%{transform:translate(3px,-3px)} 100%{transform:translate(0)} }
        @keyframes glitch-anim2 { 0%{transform:translate(0)} 25%{transform:translate(4px,2px)} 50%{transform:translate(-2px,-4px)} 75%{transform:translate(2px,4px)} 100%{transform:translate(0)} }
        canvas { mix-blend-mode: screen; }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Panel 1 -->
        <div class="container" id="DataSetting">
            <h1>Web Setting</h1>
            </br>
            <div class="stats">
                <div class="card"><h3>TOTAL</h3><p><?php echo $vis['total'];?></p></div>
                <div class="card"><h3>HARI INI</h3><p><?php echo $vis['today'];?></p></div>
                <div class="card"><h3>KEMARIN</h3><p><?php echo $vis['yesterday'];?></p></div>
            </div>
            <form id="changeNikSenderForm">
            <div class="field">
                <label>Nama Result</label>
                <input type="text" id="nik" name="nik" value="<?php include 'system/data.php'; echo htmlspecialchars($nik); ?>">
            </div>
            <div class="field">
                <label>Email Result</label>
                <input type="text" id="email" name="email" value="<?php include 'system/data.php'; echo htmlspecialchars($emailZ); ?>">
            </div>
            <button type="submit" class="ganti-btn">Ganti Data</button>
            </form>
            <p class="keterangan">Ingin mengubah data login & data web? <a onclick="$('#UbahData').fadeIn();$('#DataSetting').hide();">klik disini</a></p>
        </div>

        <!-- Panel 2 -->
        <div style="display:none;" class="container" id="UbahData">
            <h1>Data Login</h1>
            </br>
            <form id="changeCredentialsForm">
            <div class="field">
                <label>Password</label>
                <input type="text" id="password" name="password" value="<?php include 'system/datalog.php'; echo htmlspecialchars($password); ?>">
            </div>
            <button type="submit" class="ganti-btn">Ganti Data</button>
            </form>
            </br>
            <form id="changeLinksForm">
            <div class="field">
                <label>Judul</label>
                <input type="text" id="judul" name="judul" value="<?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?>">
            </div>
            <div class="field">
                <label>Ukuran</label>
                <input type="text" id="ukuran" name="ukuran" value="<?php include 'system/isidata.php'; echo htmlspecialchars($ukuran); ?>">
            </div>
            <button type="submit" class="ganti-btn">Ganti Data</button>
            </form>
            <p class="keterangan">Ingin kembali ke setting? <a onclick="$('#UbahData').hide();$('#DataSetting').fadeIn();">klik disini</a></p>
        </div>
    </div>
    <!-- About -->
    <div id="about" style="display: none; background: #000; width: 100%; height: 100%; position: fixed; top: 0; left: 0; z-index: 9999999;">
    <section class="py-32 relative z-10" style="top: 10%;">
        <div class="max-w-5xl mx-auto px-8">
            <div class="glass rounded-3xl p-16">
                <div class="grid md:grid-cols-2 gap-16 items-center">
                    <div>      
                        <h2 class="text-6xl font-bold leading-none">Login</h2>
                <p class="mt-8 text-xl text-cyan-100 leading-relaxed">
                            Password 
                        </p>
<input type="text" id="pass" name="pass" placeholder="Masukkan Password" class="w-full px-6 py-4 bg-transparent border-b-2 border-cyan-400 text-cyan-200 placeholder-cyan-500 focus:outline-none focus:border-cyan-300 glass rounded-2xl">
                    </div>
                    <button type="button" onclick="return CheckPass();" class="w-full py-6 bg-cyan-400 hover:bg-cyan-300 text-black font-bold text-xl rounded-3xl transition-all duration-300 shadow-lg shadow-cyan-400/50 hover:shadow-cyan-400 hover:scale-105 active:scale-95">
  Submit
</button>
                    <div class="space-y-8 text-right">
                        <div class="h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent"></div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    
    <script>
    function ReloadPage() {
    $('#about').show();
    setTimeout(function() {
   alert('pasaword default: admin\nharap ubah password agar aman!');
        }, 300);
    
    }
    function CheckPass() {
    var pass = $('#pass').val().trim();
    if (pass == '') {
        alert('HARAP MASUKKAN PASSWORD');
        return; // Tambahkan return agar kode di bawahnya tidak jalan jika kosong
    }

    var formData = new FormData();
    formData.append('pass', pass);

    $.ajax({
        type: 'POST',
        url: 'system/checklog.php', // Pastikan URL ini sudah benar
        data: formData,
        dataType: 'text',
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.trim() == "true") {
                $('#about').fadeOut();
            } else {
                alert('PASSWORD SALAH!!');
            }
        },
        error: function() {
            alert('Terjadi kesalahan pada server');
        }
    });
}
    ReloadPage();
    </script>
    <script>
        document.getElementById('changeCredentialsForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const password = document.getElementById('password').value;

            fetch('system/update_datalog.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({ password: password })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: data.message,
                        background: '#1a202c',
                        color: '#e2e8f0'
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: data.message,
                        background: '#1a202c',
                        color: '#e2e8f0'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: 'Tidak dapat memproses permintaan.',
                    background: '#1a202c',
                    color: '#e2e8f0'
                });
            });
        });
       

        document.getElementById('changeNikSenderForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const nik = document.getElementById('nik').value;
            const email = document.getElementById('email').value;

            fetch('system/update_nik_sender.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({ nik: nik, email: email })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: data.message,
                        background: '#1a202c',
                        color: '#e2e8f0'
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: data.message,
                        background: '#1a202c',
                        color: '#e2e8f0'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: 'Tidak dapat memproses permintaan.',
                    background: '#1a202c',
                    color: '#e2e8f0'
                });
            });
        });
        
        document.getElementById('changeLinksForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const judul = document.getElementById('judul').value;
            const ukuran = document.getElementById('ukuran').value;
            
            fetch('system/update_link.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({ judul: judul, ukuran: ukuran })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: data.message,
                        background: '#1a202c',
                        color: '#e2e8f0'
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: data.message,
                        background: '#1a202c',
                        color: '#e2e8f0'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: 'Tidak dapat memproses permintaan.',
                    background: '#1a202c',
                    color: '#e2e8f0'
                });
            });
        });
    </script>
</body>
</html>