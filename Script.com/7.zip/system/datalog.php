<?php
$password = "admin";
?>