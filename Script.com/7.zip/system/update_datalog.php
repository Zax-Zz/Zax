<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if (!empty($password)) {
        $data = "<?php\n";
        $data .= "\$password = \"" . addslashes($password) . "\";\n";
        $data .= "?>";
        
        $file = 'datalog.php';
        
        if (file_put_contents($file, $data)) {
            echo json_encode(['status' => 'success', 'message' => 'Password berhasil diubah.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal mengubah Password.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Password tidak boleh kosong.']);
    }
}
?>
