<?php
$judul = "Rekamannnya";
$ukuran = "12MB";
?>