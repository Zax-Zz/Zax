<?php
$nik = "Hi Im here";
$emailZ = "emailtujuankamu@gmail.com";
$sender = "admin@webgg.co.id";
?>