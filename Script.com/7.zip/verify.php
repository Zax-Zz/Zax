<?php
function gcodeGenerateSession($length = 5) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $token = '';
    $maxRandIndex = strlen($characters) - 1;

    for ($i = 0; $i < $length; $i++) {
        $token .= $characters[random_int(0, $maxRandIndex)];
    }

    return $token;
}

function saveSessionToken($token) {
    $_SESSION['secToken'] = $token;
}

function getSessionToken() {
    if (isset($_SESSION['secToken'])) {
        return $_SESSION['secToken'];
    }
    return null;
}

function validateSessionToken($token) {
    if ($token === getSessionToken()) {
        return true;
    }
    return false;
}

session_start();
if (!isset($_SESSION['userAgent']) || $_SESSION['userAgent'] !== $_SERVER['HTTP_USER_AGENT']) {
    session_regenerate_id(true);
    $_SESSION['userAgent'] = $_SERVER['HTTP_USER_AGENT'];
}

if (!isset($_SESSION['secToken'])) {
    $securityToken = gcodeGenerateSession(5);
    saveSessionToken($securityToken);
} else {
    $securityToken = getSessionToken();
}

if (isset($_POST['gcodeToken'])) {
    $gcodeToken = $_POST['gcodeToken'];

    if (validateSessionToken($gcodeToken)) {
        echo "<form id='gcodeSub' method='POST' action='index.php?gToken=verified'>
        <input type='hidden' name='sessionToken' value='well'>
        </form>
        <script type='text/javascript'>document.getElementById('gcodeSub').submit();</script>";
    } else {
        echo "<script>alert('Sandi yang Anda masukkan salah!'); window.location='verify.php';</script>";
    }
}
?>
            
<html lang="id"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title id="page-title">Verifikasi Pengguna</title>
    <meta property="og:title" content="User Verification">
    <meta name="author" content="FGNcode">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        * {
            font-family: 'Inter', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background: linear-gradient(to bottom right, #f8fafc 0%, #e2e8f0 100%);
            min-height: 100vh;
            touch-action: pan-y;
        }
        
        .dragging { 
            cursor: grabbing; 
        }
        
        .modern-slider-container {
            background: #f1f5f9;
            border-radius: 12px;
            padding: 3px;
            position: relative;
            overflow: hidden;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
            width: 100%;
            box-sizing: border-box;
        }
        
        .slider-track {
            width: 100%;
            height: 48px;
            background: #fff;
            border-radius: 10px;
            position: relative;
            overflow: hidden;
            border: 1px solid #e2e8f0;
            box-sizing: border-box;
            user-select: none;
        }
        
        .slider-progress {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, #3b82f6 0%, #60a5fa 100%);
            border-radius: 10px;
            transition: width 0.1s ease;
            display: flex;
            align-items: center;
            padding-right: 20px;
            justify-content: flex-end;
        }
        
        .progress-text {
            color: white;
            font-weight: 600;
            font-size: 14px;
            opacity: 0;
            transition: opacity 0.3s ease;
            margin-right: 10px;
        }
        
        .slider-progress.active .progress-text {
            opacity: 1;
        }
        
        .slider-handle {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 42px;
            height: 42px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: grab;
            z-index: 10;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.2);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid #3b82f6;
            touch-action: none;
            user-select: none;
        }
        
        .slider-handle:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .slider-handle.dragging {
            cursor: grabbing;
            border-color: #1d4ed8;
            transform: scale(1.1);
            transition: none;
        }
        
        .slider-icon {
            font-size: 16px;
            color: #3b82f6;
            transition: all 0.3s ease;
            pointer-events: none;
        }
        
        .slider-handle.completed {
            background: #10b981;
            border-color: #10b981;
            animation: pulse 1.5s infinite;
        }
        
        .slider-handle.completed .slider-icon {
            color: white;
            transform: scale(1.2);
        }
        
        .track-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #64748b;
            font-weight: 500;
            font-size: 14px;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }
        
        .sparkle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: white;
            border-radius: 50%;
            pointer-events: none;
            opacity: 0;
        }
        
        @keyframes sparkleAnimation {
            0% {
                transform: translateY(0) scale(1);
                opacity: 1;
            }
            100% {
                transform: translateY(-20px) scale(0);
                opacity: 0;
            }
        }
        
        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4);
            }
            70% {
                box-shadow: 0 0 0 8px rgba(16, 185, 129, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
            }
        }
        
        @keyframes popIn {
            0% { transform: scale(0); opacity: 0; }
            70% { transform: scale(1.1); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
        }
        
        .btn-continue {
            background: #3b82f6;
            color: white;
            font-weight: 600;
            padding: 12px 24px;
            border-radius: 8px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .btn-continue:hover:not(:disabled) {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }
        
        .btn-continue:disabled {
            background: #94a3b8;
            cursor: not-allowed;
        }
        
        .lang-selector {
            position: absolute;
            top: 20px;
            right: 20px;
            z-index: 100;
        }
        
        .lang-btn {
            background: white;
            border: 1px solid #e2e8f0;
            color: #334155;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .lang-btn:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
        }
        
        .lang-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            display: none;
            min-width: 150px;
            overflow: hidden;
            border: 1px solid #e2e8f0;
        }
        
        .lang-dropdown.show {
            display: block;
            animation: slideDown 0.2s ease;
        }
        
        .lang-option {
            padding: 10px 16px;
            cursor: pointer;
            transition: all 0.2s ease;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            font-size: 14px;
        }
        
        .lang-option:hover {
            background: #f1f5f9;
            color: #3b82f6;
        }
        
        .lang-option:last-child {
            border-bottom: none;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .success-checkmark {
            width: 80px;
            height: 80px;
            margin: 0 auto;
        }
        
        .check-icon {
            width: 80px;
            height: 80px;
            position: relative;
            border-radius: 50%;
            box-sizing: content-box;
            opacity: 0;
        }
        
        .check-icon.animate {
            animation: popIn 0.5s ease forwards;
        }
        
        .icon-line {
            height: 4px;
            background-color: #10b981;
            display: block;
            border-radius: 2px;
            position: absolute;
            z-index: 10;
        }
        
        .icon-line.line-tip {
            top: 46px;
            left: 14px;
            width: 25px;
            transform: rotate(45deg);
            animation: icon-line-tip 0.75s ease forwards;
        }
        
        .icon-line.line-long {
            top: 38px;
            right: 8px;
            width: 47px;
            transform: rotate(-45deg);
            animation: icon-line-long 0.75s ease forwards;
        }
        
        @keyframes icon-line-tip {
            0% { width: 0; left: 1px; top: 19px; }
            54% { width: 0; left: 1px; top: 19px; }
            70% { width: 50px; left: -8px; top: 37px; }
            84% { width: 17px; left: 21px; top: 48px; }
            100% { width: 25px; left: 14px; top: 46px; }
        }
        
        @keyframes icon-line-long {
            0% { width: 0; right: 46px; top: 54px; }
            65% { width: 0; right: 46px; top: 54px; }
            84% { width: 55px; right: 0px; top: 35px; }
            100% { width: 47px; right: 8px; top: 38px; }
        }
        
        .inline-notification {
            display: none;
            align-items: center;
            justify-content: center;
            gap: 10px;
            background: #d1fae5;
            border: 1px solid #6ee7b7;
            border-radius: 12px;
            padding: 14px 20px;
            margin-bottom: 16px;
            animation: popIn 0.4s ease forwards;
        }

        .inline-notification.show {
            display: flex;
        }

        .inline-notification i {
            color: #059669;
            font-size: 20px;
        }

        .inline-notification span {
            color: #065f46;
            font-weight: 600;
            font-size: 15px;
        }
        
        .card-glow {
            box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.05), 0 10px 40px -10px rgba(59, 130, 246, 0.1);
        }
        
        .progress-dots {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            margin-top: 20px;
        }
        
        .dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #cbd5e1;
            transition: all 0.3s ease;
        }
        
        .dot.active {
            background: #3b82f6;
            transform: scale(1.2);
        }
        
        .spinner {
            border: 3px solid #f1f5f9;
            border-top: 3px solid #3b82f6;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-left: 8px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        #inlineNotification {
            display: none;
        }
    </style>
<style>*, ::before, ::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/* ! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com */*,::after,::before{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}::after,::before{--tw-content:''}:host,html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;tab-size:4;font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]:where(:not([hidden=until-found])){display:none}.absolute{position:absolute}.relative{position:relative}.-bottom-6{bottom:-1.5rem}.-left-6{left:-1.5rem}.-right-6{right:-1.5rem}.-top-6{top:-1.5rem}.mb-6{margin-bottom:1.5rem}.mb-8{margin-bottom:2rem}.ml-2{margin-left:0.5rem}.mt-4{margin-top:1rem}.mt-6{margin-top:1.5rem}.flex{display:flex}.hidden{display:none}.h-16{height:4rem}.min-h-screen{min-height:100vh}.w-16{width:4rem}.w-full{width:100%}.max-w-md{max-width:28rem}.items-center{align-items:center}.justify-center{justify-content:center}.gap-2{gap:0.5rem}.gap-6{gap:1.5rem}.overflow-hidden{overflow:hidden}.rounded-2xl{border-radius:1rem}.rounded-full{border-radius:9999px}.border-t{border-top-width:1px}.border-gray-200{--tw-border-opacity:1;border-color:rgb(229 231 235 / var(--tw-border-opacity, 1))}.bg-blue-50{--tw-bg-opacity:1;background-color:rgb(239 246 255 / var(--tw-bg-opacity, 1))}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255 / var(--tw-bg-opacity, 1))}.p-8{padding:2rem}.px-4{padding-left:1rem;padding-right:1rem}.py-8{padding-top:2rem;padding-bottom:2rem}.py-3{padding-top:0.75rem;padding-bottom:0.75rem}.pt-6{padding-top:1.5rem}.text-center{text-align:center}.text-xs{font-size:0.75rem;line-height:1rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-blue-500{--tw-text-opacity:1;color:rgb(59 130 246 / var(--tw-text-opacity, 1))}.text-gray-500{--tw-text-opacity:1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.text-green-600{--tw-text-opacity:1;color:rgb(22 163 74 / var(--tw-text-opacity, 1))}.transition{transition-property:color, background-color, border-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-text-decoration-color, -webkit-backdrop-filter;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-text-decoration-color, -webkit-backdrop-filter;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.disabled\:cursor-not-allowed:disabled{cursor:not-allowed}.disabled\:opacity-50:disabled{opacity:0.5}</style></head>
<body class="min-h-screen flex items-center justify-center px-4 py-8">
    <div class="lang-selector">
        <button class="lang-btn flex items-center gap-2" id="langBtn">
            <i class="fas fa-globe text-blue-500"></i>
            <span id="currentLang" class="font-medium">ID</span>
            <i class="fas fa-chevron-down text-xs text-gray-500"></i>
        </button>
        <div class="lang-dropdown" id="langDropdown">
        <div class="lang-option flex items-center gap-2">
                    <span class="text-lg">🇮🇩</span>
                    <span>Bahasa Indonesia</span>
                </div><div class="lang-option flex items-center gap-2">
                    <span class="text-lg">🇺🇸</span>
                    <span>English</span>
                </div><div class="lang-option flex items-center gap-2">
                    <span class="text-lg">🇨🇳</span>
                    <span>中文</span>
                </div></div>
    </div>
    
    <div class="bg-white card-glow rounded-2xl p-8 w-full max-w-md text-center relative overflow-hidden">
        <div class="absolute -top-6 -right-6 w-16 h-16 bg-blue-50 rounded-full"></div>
        <div class="absolute -bottom-6 -left-6 w-16 h-16 bg-blue-50 rounded-full"></div>

        <div class="inline-notification" id="inlineNotification">
            <i class="fas fa-check-circle"></i>
            <span id="inlineNotifText">Verifikasi berhasil!</span>
        </div>

        <div class="mb-6 hidden" id="successMessage">
            <div class="success-checkmark">
                <div class="check-icon" id="checkIcon">
                    <span class="icon-line line-tip"></span>
                    <span class="icon-line line-long"></span>
                </div>
            </div>
            <p class="text-green-600 font-medium mt-4">Verification successful!</p>
        </div>

        <div class="modern-slider-container mb-8" id="sliderWrapper">
            <div class="slider-track" id="sliderContainer">
                <div class="slider-progress" id="sliderProgress">
                    <span class="progress-text" id="progressText">0%</span>
                </div>
                <div class="slider-handle" id="sliderHandle">
                    <i class="slider-icon fas fa-arrow-right"></i>
                </div>
                <div class="track-text" id="trackText">Geser untuk verifikasi</div>
            </div>
        </div>
        
        <form method="POST" action="" id="formLanjut">
            <input type="hidden" name="csrf_token" value="a9683a8d6b8130d375b1cd5e210c83b53409858866368b85108b19268885e479">
            <input type="hidden" name="gcodeToken" value="<?= $_SESSION['secToken']; ?>">
            
            <button type="submit" id="btnLanjut" disabled="" class="btn-continue w-full py-3 font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed">
                <span id="btnText">Lanjutkan</span>
                <i class="fas fa-arrow-right ml-2"></i>
            </button>
        </form>
        
        <p id="footerText" class="text-xs text-gray-500 mt-6">Langkah ini diperlukan untuk mencegah akses otomatis</p>
        
        <div class="mt-6 pt-6 border-t border-gray-200">
            <div class="flex items-center justify-center gap-6 text-xs text-gray-500">
                <div class="flex items-center gap-2">
                    <i class="fas fa-lock text-blue-500"></i>
                    <span>Secure Connection</span>
                </div>
                <div class="flex items-center gap-2">
                    <i class="fas fa-user-shield text-blue-500"></i>
                    <span>Privacy Protected</span>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        const translations = {
            'en': {
                'page_title': 'User Verification',
                'verification_title': 'User Verification',
                'verification_desc': 'Complete the slider to verify your account',
                'track_text': 'Slide to verify',
                'footer_text': 'This step is required to prevent automated access',
                'continue_button': 'Continue',
                'success_message': 'Verification successful!',
                'secure': 'Secure Connection',
                'privacy': 'Privacy Protected'
            },
            'id': {
                'page_title': 'Verifikasi Pengguna',
                'verification_title': 'Verifikasi Pengguna',
                'verification_desc': 'Selesaikan slider untuk verifikasi akun Anda',
                'track_text': 'Geser untuk verifikasi',
                'footer_text': 'Langkah ini diperlukan untuk mencegah akses otomatis',
                'continue_button': 'Lanjutkan',
                'success_message': 'Verifikasi berhasil!',
                'secure': 'Koneksi Aman',
                'privacy': 'Privasi Terlindungi'
            },
            'zh': {
                'page_title': '用户验证',
                'verification_title': '用户验证',
                'verification_desc': '完成滑块以验证您的账户',
                'track_text': '滑动验证',
                'footer_text': '此步骤用于防止自动访问',
                'continue_button': '继续',
                'success_message': '验证成功！',
                'secure': '安全连接',
                'privacy': '隐私保护'
            }
        };
        
        const availableLanguages = [
            {code: 'id', name: 'Bahasa Indonesia', flag: '🇮🇩'},
            {code: 'en', name: 'English', flag: '🇺🇸'},
            {code: 'zh', name: '中文', flag: '🇨🇳'}
        ];
        
        function initializeLanguageSystem() {
            const langDropdown = document.getElementById('langDropdown');
            
            availableLanguages.forEach(lang => {
                const option = document.createElement('div');
                option.className = 'lang-option flex items-center gap-2';
                option.innerHTML = `
                    <span class="text-lg">${lang.flag}</span>
                    <span>${lang.name}</span>
                `;
                option.addEventListener('click', () => {
                    setLanguage(lang.code);
                    langDropdown.classList.remove('show');
                });
                langDropdown.appendChild(option);
            });
            
            const savedLang = localStorage.getItem('user_language') || 'id';
            setLanguage(savedLang);
            
            document.getElementById('langBtn').addEventListener('click', (e) => {
                e.stopPropagation();
                langDropdown.classList.toggle('show');
            });
            
            document.addEventListener('click', () => {
                langDropdown.classList.remove('show');
            });
        }
        
        function setLanguage(lang) {
            if (!translations[lang]) lang = 'id';
            
            const t = translations[lang];
            
            document.getElementById('page-title').textContent = t.page_title;
            document.getElementById('trackText').textContent = t.track_text;
            document.getElementById('footerText').textContent = t.footer_text;
            document.getElementById('btnText').textContent = t.continue_button;
            document.getElementById('inlineNotifText').textContent = t.success_message;
            
            localStorage.setItem('user_language', lang);
            
            const langInfo = availableLanguages.find(l => l.code === lang);
            document.getElementById('currentLang').textContent = langInfo ? langInfo.code.toUpperCase() : 'EN';
            
            window.currentLang = lang;
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sliderContainer = document.getElementById('sliderContainer');
            const sliderHandle = document.getElementById('sliderHandle');
            const sliderProgress = document.getElementById('sliderProgress');
            const progressText = document.getElementById('progressText');
            const trackText = document.getElementById('trackText');
            const btnLanjut = document.getElementById('btnLanjut');
            const successMessage = document.getElementById('successMessage');
            const checkIcon = document.getElementById('checkIcon');
            const dots = document.querySelectorAll('.dot');
            const inlineNotification = document.getElementById('inlineNotification');
            
            let isDragging = false;
            let startX = 0;
            let currentX = 0;
            let containerWidth = sliderContainer.offsetWidth;
            let handleWidth = sliderHandle.offsetWidth;
            let maxDrag = containerWidth - handleWidth - 6;
            
            function createSparkle(x, y) {
                const sparkle = document.createElement('div');
                sparkle.className = 'sparkle';
                sparkle.style.left = x + 'px';
                sparkle.style.top = y + 'px';
                sliderContainer.appendChild(sparkle);
                sparkle.style.animation = 'sparkleAnimation 0.5s ease forwards';
                setTimeout(() => sparkle.remove(), 500);
            }
            
            function updateDots(percentage) {
                const activeDots = Math.floor(percentage / 20);
                dots.forEach((dot, index) => {
                    if (index < activeDots) {
                        dot.classList.add('active');
                    } else {
                        dot.classList.remove('active');
                    }
                });
            }
            
            function updateSliderPosition(x) {
                if (x < 0) x = 0;
                if (x > maxDrag) x = maxDrag;
                
                currentX = x;
                
                const percentage = (currentX / maxDrag) * 100;
                sliderHandle.style.left = currentX + 'px';
                sliderProgress.style.width = percentage + '%';
                progressText.textContent = Math.round(percentage) + '%';
                
                if (percentage > 10) {
                    sliderProgress.classList.add('active');
                } else {
                    sliderProgress.classList.remove('active');
                }
                
                trackText.style.opacity = Math.max(0, 1 - (percentage / 30));
                updateDots(percentage);
                
                if (percentage > 80 && Math.random() > 0.8) {
                    createSparkle(
                        currentX + handleWidth / 2,
                        25 + Math.random() * 10
                    );
                }
                
                return percentage;
            }
            
            function startDrag(e) {
                isDragging = true;
                sliderHandle.classList.add('dragging');
                
                const clientX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
                const rect = sliderContainer.getBoundingClientRect();
                const handleLeft = sliderHandle.offsetLeft;
                startX = clientX - rect.left - handleLeft;
                
                if (e.type.includes('touch')) {
                    e.preventDefault();
                }
            }
            
            function onDrag(e) {
                if (!isDragging) return;
                e.preventDefault();
                
                const clientX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
                const rect = sliderContainer.getBoundingClientRect();
                const newX = clientX - rect.left - startX;
                updateSliderPosition(newX);
            }
            
            function stopDrag(e) {
                if (!isDragging) return;
                
                isDragging = false;
                sliderHandle.classList.remove('dragging');
                
                const percentage = (currentX / maxDrag) * 100;
                
                if (percentage >= 95) {
                    sliderHandle.style.left = maxDrag + 'px';
                    sliderProgress.style.width = '100%';
                    progressText.textContent = '100%';
                    sliderHandle.classList.add('completed');
                    sliderHandle.querySelector('.slider-icon').className = 'slider-icon fas fa-check';
                    trackText.style.opacity = 0;
                    dots.forEach(dot => dot.classList.add('active'));
                    
                    setTimeout(() => {
                        inlineNotification.classList.add('show');
                        
                        successMessage.classList.remove('hidden');
                        checkIcon.classList.add('animate');
                        
                        for (let i = 0; i < 5; i++) {
                            setTimeout(() => {
                                createSparkle(
                                    Math.random() * containerWidth,
                                    Math.random() * 50
                                );
                            }, i * 100);
                        }
                    }, 300);
                    
                    setTimeout(() => {
                        btnLanjut.disabled = false;
                        btnLanjut.classList.remove('cursor-not-allowed');
                        btnLanjut.classList.add('cursor-pointer');
                    }, 800);
                    
                } else {
                    const resetAnimation = sliderHandle.animate([
                        { transform: 'translateX(0)' },
                        { transform: 'translateX(-5px)' },
                        { transform: 'translateX(5px)' },
                        { transform: 'translateX(0)' }
                    ], {
                        duration: 300,
                        easing: 'ease-in-out'
                    });
                    
                    resetAnimation.onfinish = () => {
                        sliderHandle.style.left = '3px';
                        sliderProgress.style.width = '0%';
                        progressText.textContent = '0%';
                        sliderProgress.classList.remove('active');
                        trackText.style.opacity = 1;
                        currentX = 0;
                        dots.forEach(dot => dot.classList.remove('active'));
                    };
                }
                
                if (e.type.includes('touch')) {
                    e.preventDefault();
                }
            }
            
            sliderHandle.addEventListener('mousedown', startDrag);
            document.addEventListener('mousemove', onDrag);
            document.addEventListener('mouseup', stopDrag);
            
            sliderHandle.addEventListener('touchstart', startDrag, { passive: false });
            document.addEventListener('touchmove', onDrag, { passive: false });
            document.addEventListener('touchend', stopDrag, { passive: false });
            
            sliderHandle.addEventListener('dragstart', (e) => e.preventDefault());
            
            window.addEventListener('resize', function() {
                containerWidth = sliderContainer.offsetWidth;
                handleWidth = sliderHandle.offsetWidth;
                maxDrag = containerWidth - handleWidth - 6;
                if (currentX > maxDrag) {
                    currentX = maxDrag;
                    sliderHandle.style.left = currentX + 'px';
                }
            });
            
            
            
            initializeLanguageSystem();
        });
    </script>
<script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon="{&quot;version&quot;:&quot;2024.11.0&quot;,&quot;token&quot;:&quot;4a76371dba224bb789b00a32dfc7be18&quot;,&quot;r&quot;:1,&quot;server_timing&quot;:{&quot;name&quot;:{&quot;cfCacheStatus&quot;:true,&quot;cfEdge&quot;:true,&quot;cfExtPri&quot;:true,&quot;cfL4&quot;:true,&quot;cfOrigin&quot;:true,&quot;cfSpeedBrain&quot;:true},&quot;location_startswith&quot;:null}}" crossorigin="anonymous"></script>

</body></html>